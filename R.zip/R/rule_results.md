---
title: "Export business rules' results to disk"
output: html_document
---
Export business rules' results to disk
====================================================



This report has been generated on 2016-04-26.





# Get the rules



# Add view for extra details on results


```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW vx_rule_failures_ids 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
create view vx_rule_failures_ids as
	select distinct * from rule_failures_ids 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW vx_rules 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
CREATE VIEW [dbo].[vx_rules] AS
	SELECT
		vx_rules.BR
		,vx_rules.entitytype
		,vx_rules.Depth
		,vx_rules.Importance
		,vx_rules.ErrorCause
		,vx_rules.approvedDate
		,vx_rules.dataelements
		,vx_rules.en
		,vx_rules.nl
		,vx_rules.[rule]
		,vx_rules.condition
		,vx_rules.BU
		,vx_rules.ruleOwner as responsible_business_department
		,vx_rules.[system]
		,vx_rules.[approvedBy] as [approvedBy]
		,dataelements.num_dataelements
		,rule_load_date as [rule_date]
		,ISNULL(failure_count.Errors, 0) as Errors
		,failure_count.reportname as reportname
		,failure_count.reportdate as reportdate
		,ss.n_superset
		,CASE WHEN ISNULL(ss.n_superset,0) = 0 THEN NULL ELSE (errors*100.0)/(ss.n_superset*1.0) END AS ErrorPct
	FROM
		SourceData.dbo.vx_rules
		LEFT JOIN
			(SELECT BR, count(*) as num_dataelements
			FROM SourceData.dbo.vx_rules_dataelements
			GROUP BY BR) as dataelements
		ON vx_rules.BR = dataelements.BR
		LEFT JOIN(
			SELECT BR, reportname, reportdate, COUNT(*) as Errors
			FROM DataQuality.dbo.vx_rule_failures_ids as fails
			GROUP BY BR, reportname, reportdate
			) as failure_count
			ON vx_rules.BR = failure_count.BR
		LEFT JOIN DataQuality.dbo.superset_counts ss
			ON vx_rules.BR = ss.BR 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW vx_rules_failures 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
CREATE VIEW [dbo].[vx_rules_failures] AS
	SELECT  [System]
      ,[Responsible Business Department]
      ,[BR Description (Native language)]
      ,[BR]
      ,[entitytype]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,[tradeid]
      ,[fail_reportname]
      ,[fail_reportdate]
	  ,[reasons blacklisted]
	  ,[reasons whitelisted]
			, case when [reasons whitelisted] is not null
					then 1
					else 0
					end whitelisted
			, case when [reasons blacklisted] is not null  or [reasons whitelisted] is null
				then 1
				else 0
				end as fail
			, case when [reasons blacklisted] is not null
					then 1
					else 0
					end blacklisted
			, case when ([reasons blacklisted] is null and [reasons whitelisted] is null ) or
					 ([reasons blacklisted] is not null and [reasons whitelisted] is not null )
				then 1
				else 0
				end as unhandled
			, case when [Blacklisted 0-meting] is not null and [reasons whitelisted] is null
				then 1
				else 0
				end as 'Not cleaned'
			, ISNULL([Responsible for cleaning],'') as [Responsible for cleaning]
						, CHARINDEX('|', [Responsible for cleaning]) AS [Solver person]
			, CASE WHEN [Responsible for cleaning] IS NULL THEN 0 ELSE 1 END AS [Solver department]
			, ISNULL([reasons whitelisted],'')+ ISNULL([reasons blacklisted], '') as reasons
	 FROM (
		select
			fails.System
			, rules.ruleOwner as [Responsible Business Department]
			, rules.nl as [BR Description (Native language)]
			, fails.BR
			, rules.entitytype
			, fails.insid
			, fails.prfid
			, fails.fxid
			, fails.tradeid
			, fails.reportname as fail_reportname
			, fails.reportdate as fail_reportdate
			, STUFF(
					(SELECT
						distinct ', '+ CHAR(13) + ISNULL(whitelist.reason, '')
						FROM
							SourceData.dbo.vx_whitelist whitelist
						WHERE whitelist.BR = fails.BR
							and ((whitelist.insid is null and fails.insid is null) or fails.insid = whitelist.insid)
							and ((whitelist.prfid is null  and fails.prfid is null) or fails.prfid = whitelist.prfid)
							and ((whitelist.fxid is null  and fails.fxid is null) or fails.fxid = whitelist.fxid)
							and ((whitelist.tradeid is null and fails.tradeid is null) or fails.tradeid = whitelist.tradeid)
						FOR XML PATH(''), TYPE
					).value('.','varchar(max)')
					,1,3, ''
				) AS "reasons whitelisted"
			, STUFF(
					(SELECT
						distinct ', '+ CHAR(13) + ISNULL(blacklist.reason, '')
						FROM
							SourceData.dbo.vx_blacklist blacklist
						WHERE blacklist.BR = fails.BR
							and ((blacklist.insid is null and fails.insid is null) or fails.insid = blacklist.insid)
							and ((blacklist.prfid is null and fails.prfid is null) or fails.prfid = blacklist.prfid)
							and ((blacklist.fxid is null and fails.fxid is null) or fails.fxid = blacklist.fxid)
							and ((blacklist.tradeid is null and fails.tradeid is null) or fails.tradeid = blacklist.tradeid)
						FOR XML PATH(''), TYPE
					).value('.','varchar(max)')
					,1,3, ''
				) AS "reasons blacklisted"
			, STUFF(
					(SELECT
						distinct ', '+ CHAR(13) + ISNULL(blacklist.reason, '')
						FROM
							SourceData.dbo.vx_blacklist_4B blacklist
						WHERE blacklist.BR = fails.BR
							and (blacklist.insid is null or fails.insid = blacklist.insid)
							and (blacklist.prfid is null or fails.prfid = blacklist.prfid)
							and (blacklist.fxid is null or fails.fxid = blacklist.fxid)
							and (blacklist.tradeid is null or fails.tradeid = blacklist.tradeid)
						FOR XML PATH(''), TYPE
					).value('.','varchar(max)')
					,1,3, ''
				) AS "Blacklisted 0-meting"
			, STUFF(
					(SELECT
						distinct ', '+ CHAR(13) + ISNULL(blacklist.solver, '')
						FROM
							SourceData.dbo.vx_blacklist blacklist
						WHERE blacklist.BR = fails.BR
							and (blacklist.insid is null or fails.insid = blacklist.insid)
							and (blacklist.prfid is null or fails.prfid = blacklist.prfid)
							and (blacklist.fxid is null or fails.fxid = blacklist.fxid)
							and (blacklist.tradeid is null or fails.tradeid = blacklist.tradeid)
						FOR XML PATH(''), TYPE
					).value('.','varchar(max)')
					,1,3, ''
				) AS "Responsible for cleaning"
		FROM
			vx_rule_failures_ids as fails
			left join SourceData.dbo.vx_rules as rules
			on fails.BR = rules.BR
	) as marked_failures 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW vx_rules_dataelements 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
CREATE VIEW [dbo].[vx_rules_dataelements] AS
	SELECT BR, dataelement
	FROM SourceData.dbo.vx_rules_dataelements 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW flat_rules_failures_attributes 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
CREATE VIEW [dbo].[flat_rules_failures_attributes] AS
	SELECT
		fails.BR,
		fails.whitelisted,
		fails.blacklisted,
		fails.insid,
		fails.prfid,
		fails.fxid,
		fails.tradeid,
      fails.[entitytype]
      ,[source_date]
      ,[source_file]
      ,[BOOK_VALUE]
      ,[CLIENT_NAME]
      ,[COUPON]
      ,[CURRENCY]
      ,[DLAMAssetClass1]
      ,[DLAMAssetClass2]
      ,[DLAMAssetClass3]
      ,[DLAMAssetClass4]
      ,[DLAMRATING]
      ,[DLAMSector1]
      ,[DLAMSector2]
      ,[DLAMSector3]
      ,[EXPIRATION]
      ,[FXRATE]
      ,[IDENTIFIER]
      ,[ISSUE_DATE]
      ,[MARKET_VALUE]
      ,[MATURITY]
      ,[NOMINAL_VALUE]
      ,[OPTION_TYPE]
      ,[PAYMENT_FREQUENCY]
      ,[PORTFOLIO_NAME]
      ,[PRICE]
      ,[proddat]
      ,[QUANTITY]
      ,[SECURITY]
      ,[STRIKE]
      ,[UNDERLYING]
      ,[Type]
	FROM
		vx_rules_failures as fails
		left join SourceData.dbo.vx_entities as details
		on
		    ((details.insid is null and fails.insid is null) or fails.insid = details.insid)
		and ((details.prfid is null and fails.prfid is null) or fails.prfid = details.prfid)
		and ((details.fxid is null and fails.fxid is null) or fails.fxid = details.fxid)
		and ((details.tradeid is null and fails.tradeid is null) or fails.tradeid = details.tradeid)
		and not(fails.insid is null
			and fails.prfid is null
			and fails.fxid is null
			and fails.tradeid is null) 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW vx_del4a_dqa 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
create view vx_del4a_dqa as
select
	rules.System,
	de.Number as "Data Element",
	rules.BR as "BR number",
	isnull(fails.fail_reportdate, latest_reportdate) as	"Run Date",
	system_data.latest_sourcedate as "Source Date",
	rules.entitytype as "Entity Type",
	  isnull(failure_ids.totalcount, 0) as Total,
      isnull(fails.failcount, 0) as Errors,
	  isnull(fails.num_whitelisted, 0) as Whitelisted,
	  isnull(fails.num_fail, 0) as Failed,
      isnull(fails.num_blacklisted, 0) as Blacklisted,
      isnull(fails.num_unhandled, 0) as Unhandled
from
	SourceData.dbo.vx_rules as rules
	left join
	SourceData.dbo.vx_rules_dataelements de_ref
	on rules.BR = de_ref.BR
	left join
	SourceData.dbo.dataelements de
	on de_ref.dataelement = de.Dataelement
	left join(
		select
			fail_reportdate,
			BR,
			count(*) as failcount,
			sum(whitelisted) as num_whitelisted,
			sum(blacklisted) as num_blacklisted,
			sum(unhandled) as num_unhandled,
			sum(fail) as num_fail
		from
			DataQuality.dbo.[vx_rules_failures]
		group by BR, fail_reportdate) as fails
	on rules.BR = fails.BR
	left join
	(select [system], max(reportdate) as latest_reportdate
		from DataQuality.dbo.vx_rule_failures_ids group by [system]) as system_run
	on rules.system=system_run.[system]
	left join
	(select [system], max(source_date) as latest_sourcedate
		from SourceData.dbo.vx_entities group by [system]) as system_data
	on rules.system=system_data.[system]
	left join
	(select BR, count(*) as totalcount
		from DataQuality.dbo.[rule_failures_ids] group by BR) as failure_ids
	on rules.BR = failure_ids.BR 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW vx_del4a_vta 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
create view vx_del4a_vta as
select
	"BU",
	rules."System",
	rules.entitytype as "Entity Type",
	rules.BR as "BR number",
	rules.Depth,
	rules.Importance,
	case
		when
			approvedDate is null or modificationDate is null or approvedDate < modificationDate
			or len(approvedBy) = 0
			or approvedBy is null
		then 'rule verification'
		else
			case
				when system_run.latest_reportdate is null or system_run.latest_reportdate < modificationDate
				then 'awaiting results'
				else
					case
						when resultApprovalDate is null
							or resultApprovalDate < modificationDate
							or resultApprovalDate < system_data.latest_sourcedate
						then 'result verification'
						else 'done'
						end
				end
		end as "BR Status",
	nl as "BR Description (Native language)",
	en as "BR Description (EN)",
	STUFF(
            (SELECT
                ', '+ CHAR(13)+ CHAR(10) + de.Datalabel
                FROM
					SourceData.dbo.vx_rules_dataelements de_ref
					left join
					SourceData.dbo.dataelements de
					on de_ref.dataelement = de.Dataelement
                WHERE rules.BR = de_ref.BR
                ORDER BY de.Datalabel
                FOR XML PATH(''), TYPE
            ).value('.','varchar(max)')
            ,1,4, ''
        ) AS "SII Data Element(s)",
	STUFF(
            (SELECT
                ', '+ CHAR(13)+ CHAR(10) + de.[Description]
                FROM
					SourceData.dbo.vx_rules_dataelements de_ref
					left join
					SourceData.dbo.dataelements de
					on de_ref.dataelement = de.Dataelement
                WHERE rules.BR = de_ref.BR
                ORDER BY de.Datalabel
                FOR XML PATH(''), TYPE
            ).value('.','varchar(max)')
            ,1,4, ''
        ) AS "SII Data Element(s) Description(s)",
	[rule] as "Proposed Rule",
	"Condition",
	rules.datasource as "Used database or exports",
	referencedata as "Reference data",
	ruleOwner as "Responsible Business Department",
	approvedBy as "Approved by",
	modificationDate as "Date rule modification",
	approvedDate as "Date rule Approved",
	resultApprovalDate as "Date exceptions verified",
	system_run.latest_reportdate as "Date exceptions generated",
	system_data.latest_sourcedate as "Date source",
	STUFF(
            (SELECT
                ', '+ CHAR(13)+ CHAR(10) + colnames.colname
                FROM
					DataQuality.dbo.rule_failures_colnames colnames
                WHERE colnames.BR = rules.BR
                FOR XML PATH(''), TYPE
            ).value('.','varchar(max)')
            ,1,4, ''
        ) AS "Fields in output"	,
	Query
from
	SourceData.dbo.vx_rules as rules
	left join
	(select [system], max(reportdate) as latest_reportdate
		from DataQuality.dbo.vx_rule_failures_ids group by [system]) as system_run
	on rules.system=system_run.[system]
	left join
	(select [system], max(source_date) as latest_sourcedate
		from SourceData.dbo.vx_entities group by [system]) as system_data
	on rules.system=system_data.[system]
--order by System, BR 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW vx_del4a_ruleverification 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
create view vx_del4a_ruleverification as
select
	   rules.[System]
      ,[BR number]
      ,[BR Status]
      ,isnull(fails.failcount, 0) as Errors
      ,isnull(fails.num_whitelisted, 0) as Whitelisted
      ,isnull(fails.num_blacklisted, 0) as Blacklisted
      ,isnull(fails.num_unhandled, 0) as Unhandled
      ,[Entity Type]
      ,[Depth]
      ,[Importance]
      ,[BR Description (Native language)]
      ,[BR Description (EN)]
      ,[SII Data Element(s)]
      ,[Proposed Rule]
      ,[Condition]
      ,[Used database or exports]
      ,[Reference data]
      ,[Responsible Business Department]
      ,[Approved by]
      ,[Date rule modification]
      ,[Date rule Approved]
      ,[Date exceptions generated]
      ,[Date exceptions verified]
	  ,[Date source]
from
	DataQuality.dbo.vx_del4a_vta as rules
	left join(
		select
			fail_reportdate,
			BR,
			count(*) as failcount,
			sum(whitelisted) as num_whitelisted,
			sum(blacklisted) as num_blacklisted,
			sum(unhandled) as num_unhandled
		from
			DataQuality.dbo.[vx_rules_failures]
		group by BR, fail_reportdate) as fails
	on rules.[BR number] = fails.BR
	left join
	(select [system], max(reportdate) as latest_reportdate
		from DataQuality.dbo.vx_rule_failures_ids group by [system]) as system_run
	on rules.System=system_run.[system] 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW vx_del4a_entity_coverage 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
CREATE VIEW vx_del4a_entity_coverage AS
SELECT de.[System]
      ,number as [Data element Number]
      ,de.Dataelement as [Data element]
      ,[NumHasValue] as [Num HasValue]
      ,[NumValidRange] as [Num ValidRange]
      ,[NumSelfConsistent] as [Num SelfConsistent]
      ,[NumOtherConsistent] as [Num OtherConsistent]
      ,[NumExternallyConsistent] as [Num ExternallyConsistent]
      ,[NumRules] as [Num Available Rules]
	  ,isnull(de_fails.NumRulesFailing, 0) as [Num Failing Rules (with non-whitelisted failures)]
  FROM [SourceData].[dbo].[vx_overviews_depths_rulesperdataelement] de
  left join
  (select  [System], [Data Element] as [Dataelement], count(distinct([BR number])) as NumRulesFailing from vx_del4a_dqa where Failed>0 group by [System],[Data Element]) as de_fails
  on de.Number = de_fails.Dataelement
  and de.System=de_fails.System
UNION ALL
	SELECT
		   sys_depth.System
		   , 'XX98 TOTAL' as Number
		  ,'FAILING' as [Dataelement]
		  ,isnull(sum(IsHasValue),0) as NumHasValue
		  ,isnull(sum(IsValidRange),0) as NumValidRange
		  ,isnull(sum(IsSelfConsistent),0) as NumSelfConsistent
		  ,isnull(sum(IsOtherConsistent),0) as NumOtherConsistent
		  ,isnull(sum(IsExternallyConsistent),0) as NumExternallyConsistent
		  ,count(*) as NumRules
		  ,isnull(sum(IsSomething), 0) as NumRulesFailing
	  FROM
	  (
	  select
		rules.[system] as [system],
		case rules.Depth
			when 'HasValue' then 1
			else 0
			end as IsHasValue,
		case rules.Depth
			when 'ValidRange' then 1
			else 0
			end as IsValidRange,
		case rules.Depth
			when 'SelfConsistent' then 1
			else 0
			end as IsSelfConsistent,
		case rules.Depth
			when 'OtherConsistent' then 1
			else 0
			end as IsOtherConsistent,
		case rules.Depth
			when 'ExternallyConsistent' then 1
			else 0
			end as IsExternallyConsistent,
		1 as IsSomething
	  from
		vx_rules as rules
		where BR in (select [BR number] from vx_del4a_dqa where failed>0)
	) as sys_depth
	group by
			System
union all
	SELECT
		   sys_depth.System
		   , 'XX99 TOTAL' as Number
		  ,'AVAILABLE' as [Dataelement]
		  ,isnull(sum(IsHasValue),0) as NumHasValue
		  ,isnull(sum(IsValidRange),0) as NumValidRange
		  ,isnull(sum(IsSelfConsistent),0) as NumSelfConsistent
		  ,isnull(sum(IsOtherConsistent),0) as NumOtherConsistent
		  ,isnull(sum(IsExternallyConsistent),0) as NumExternallyConsistent
		  ,count(*) as NumRules
		  ,isnull(sys_fails.NumRulesFailing, 0) as NumRulesFailing
	  FROM
	  (
	  select
		rules.[system] as [system],
		case rules.Depth
			when 'HasValue' then 1
			else 0
			end as IsHasValue,
		case rules.Depth
			when 'ValidRange' then 1
			else 0
			end as IsValidRange,
		case rules.Depth
			when 'SelfConsistent' then 1
			else 0
			end as IsSelfConsistent,
		case rules.Depth
			when 'OtherConsistent' then 1
			else 0
			end as IsOtherConsistent,
		case rules.Depth
			when 'ExternallyConsistent' then 1
			else 0
			end as IsExternallyConsistent
	  from
		vx_rules as rules) as sys_depth
		  left join
		  (select  [System], count(distinct([BR number])) as NumRulesFailing from vx_del4a_dqa where failed>0 group by [System]) as sys_fails
		  on sys_depth.System=sys_fails.System
	group by
			sys_depth.System, sys_fails.NumRulesFailing 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW vx_del4a_entity_counts 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
CREATE VIEW vx_del4a_entity_counts AS
	select count_available.[system]
		  ,count_available.[entitytype]
		  ,num as [Total number of entities]
		  ,isnull(numIncomplete,0) as [Number Incomplete Entities (ex whitelisted)]
		  ,isnull(numInaccurate,0) as [Number Inaccurate Entities (ex whitelisted)]
		  ,isnull(numInvalid,0) as [Total Number Invalid Entities (ex whitelisted)]
	FROM
		(
		  SELECT [system]
			  ,[entitytype]
			  ,count(*) as num
		  FROM [SourceData].[dbo].[vx_entities]
		  GROUP BY
			  [system]
			  ,[entitytype]
		  ) as count_available
	  left join
			(
			select system, entitytype, count(*) as numIncomplete
			from
				(select distinct system, entitytype, insid, prfid, fxid, tradeid from [vx_rules_failures]
					where BR in (select BR from vx_rules where depth = 'HasValue')
					and fail>0) as unique_fails
				group by system, entitytype
			) as count_incomplete
			on count_available.system=count_incomplete.system
			and count_available.entitytype=count_incomplete.entitytype
	  left join
			(
			select system, entitytype, count(*) as numInaccurate
			from
				(select distinct system, entitytype, insid, prfid, fxid, tradeid from [vx_rules_failures]
					where BR in (select BR from vx_rules where depth != 'HasValue')
					and fail>0) as unique_fails
			group by system, entitytype
			) as count_inaccurate
			on count_available.system=count_inaccurate.system
			and count_available.entitytype=count_inaccurate.entitytype
	left join
			(
			select system, entitytype, count(*) as numInvalid
			from
				(select distinct system, entitytype, insid, prfid, fxid, tradeid from [vx_rules_failures]
				where fail>0
				) as unique_fails
			group by system, entitytype
			) as count_invalid
			on count_available.system=count_invalid.system
			and count_available.entitytype=count_invalid.entitytype 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW vx_del4a_dataelement_quality 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
CREATE VIEW vx_del4a_dataelement_quality AS
	Select
		elements_with_fails.System,
		elements_with_fails.Number as [Data element Number],
		elements_with_fails.Dataelement as [Data Element],
		sum(InstrumentFails) as [Failing Instruments (ex whitelisted)],
		sum(CurrencyFails) as [Failing Currencies (ex whitelisted)],
		sum(HoldingFails) as [Failing Holdings (ex whitelisted)],
		sum(PortfolioFails) as [Failing Portfolios (ex whitelisted)],
		sum(TradeFails) as [Failing Trades (ex whitelisted)],
		sum(AnyFails) as [Failures (ex whitelisted)]
	FROM
	(
		Select
			all_elements.System,
			all_elements.Number,
			all_elements.Dataelement,
			isnull(case when entitytype='instrument'
				then fails
				else 0 end, 0)
				as InstrumentFails,
			isnull(case when entitytype='currency'
				then fails
				else 0 end, 0)
				as CurrencyFails,
			isnull(case when entitytype='holding'
				then fails
				else 0 end , 0)
				as HoldingFails,
			isnull(case when entitytype='portfolio'
				then fails
				else 0 end, 0)
				as PortfolioFails,
			isnull(case when entitytype='trade'
				then fails
				else 0 end, 0)
				as TradeFails,
			isnull(fails, 0) as AnyFails
		from
			(select distinct
				System
				,[Number]
				,Dataelement
			FROM SourceData.dbo.vx_overviews_depths_rulesperdataelement) as all_elements
			left join
			(select
				System, number, entitytype, count(*) as fails
			from
				(select distinct fails.system, dataelements.Number, rules.entitytype, insid, prfid, fxid, tradeid
					from
						vx_rules_failures as fails
						left join SourceData.dbo.vx_rules as rules
						on fails.BR = rules.BR
						left join SourceData.dbo.vx_rules_dataelements as rules_de
						on fails.BR = rules_de.BR
						left join SourceData.dbo.dataelements
						on rules_de.dataelement = dataelements.Dataelement
					where fail>0) as unique_fails
			group by System, number, entitytype) as rule_de_fails
			on all_elements.Number=rule_de_fails.Number
	) as elements_with_fails
	GROUP BY
		elements_with_fails.System,
		elements_with_fails.Number,
		elements_with_fails.Dataelement
UNION ALL
	Select
		System,
		'XX98 TOTAL' as Number,
		'FAILING' as [Dataelement],
		sum(InstrumentNum) as InstrumentFails,
		sum(CurrencyNum) as CurrencyFails,
		sum(HoldingNum) as HoldingFails,
		sum(PortfolioNum) as PortfolioFails,
		sum(TradeNum) as TradeFails,
		sum(AnyNum) as AnyFails
	FROM
		(Select
			System,
			case when [entitytype]='instrument'
				then [Total Number Invalid Entities (ex whitelisted)]
				else 0 end
				as InstrumentNum,
			case when [entitytype]='currency'
				then [Total Number Invalid Entities (ex whitelisted)]
				else 0 end
				as CurrencyNum,
			case when [entitytype]='holding'
				then [Total Number Invalid Entities (ex whitelisted)]
				else 0 end
				as HoldingNum,
			case when [entitytype]='portfolio'
				then [Total Number Invalid Entities (ex whitelisted)]
				else 0 end
				as PortfolioNum,
			case when [entitytype]='trade'
				then [Total Number Invalid Entities (ex whitelisted)]
				else 0 end
				as TradeNum,
				[Total Number Invalid Entities (ex whitelisted)] as AnyNum
		from
			vx_del4a_entity_counts
			) as entity_counts
	group by System
UNION ALL
	Select
		System,
		'XX99 TOTAL' as Number,
		'AVAILABLE' as [Dataelement],
		sum(InstrumentNum) as InstrumentFails,
		sum(CurrencyNum) as CurrencyFails,
		sum(HoldingNum) as HoldingFails,
		sum(PortfolioNum) as PortfolioFails,
		sum(TradeNum) as TradeFails,
		sum(AnyNum) as AnyFails
	FROM
		(Select
			System,
			case when [entitytype]='instrument'
				then [Total number of entities]
				else 0 end
				as InstrumentNum,
			case when [entitytype]='currency'
				then [Total number of entities]
				else 0 end
				as CurrencyNum,
			case when [entitytype]='holding'
				then [Total number of entities]
				else 0 end
				as HoldingNum,
			case when [entitytype]='portfolio'
				then [Total number of entities]
				else 0 end
				as PortfolioNum,
			case when [entitytype]='trade'
				then [Total number of entities]
				else 0 end
				as TradeNum,
				[Total number of entities] as AnyNum
		from
			vx_del4a_entity_counts
			) as entity_counts
	group by System 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
DROP VIEW vx_del4b_1meting 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
CREATE VIEW vx_del4b_1meting AS
SELECT
	r.System,
	r.BR,
	SUM(ISNULL(blacklisted,0)) AS blacklisted,
	SUM(ISNULL(whitelisted,0)) AS whitelisted,
	SUM(ISNULL([Not cleaned],0)) AS [Not cleaned],
SUM(ISNULL(unhandled,0)) AS unhandled,
SUM(isnull(fail,0)) AS failures,
COUNT(f.BR) AS findings
FROM
	SourceData.dbo.vx_rules r
	LEFT JOIN dataquality.dbo.vx_rules_failures f
		ON r.BR = f.BR
GROUP BY
	r.System,r.BR 
```

# Dump results


```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=DataQuality"
```



