---
title: "Wrapup business rules import"
output: html_document
---
Portia Database business rules
====================================================




This report has been generated on 2016-04-26 16:07:27.



# Views on top of rules of any system


```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_whitelist 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_whitelist AS
select [BR]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,[tradeid]
      ,[owner]
      ,[date]
      ,[reason]
	  ,bevestigddoor
	  ,bevestigdop
      ,[source_date]
      ,[source_file] from PO_whitelist
union all
select [BR]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,[tradeid]
      ,[owner]
      ,[date]
      ,[reason]
	  ,bevestigddoor
	  ,bevestigdop
	  ,[source_date]
      ,[source_file] from FA_whitelist
union all
select [BR]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,[tradeid]
      ,[owner]
      ,[date]
      ,[reason]
	  ,bevestigddoor
	  ,bevestigdop
	  ,[source_date]
      ,[source_file] from VIS_whitelist
union all
select [BR]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,[tradeid]
      ,[owner]
      ,[date]
      ,[reason]
	  ,bevestigddoor
	  ,bevestigdop
	  ,[source_date]
      ,[source_file] from GL_whitelist 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_blacklist 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_blacklist AS
select  [BR]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,[tradeid]
      ,[owner]
      ,[date]
	  ,solver
      ,[reason]
	  ,clean
	  ,clean_date
      ,[source_date]
      ,[source_file] from PO_blacklist
union all
select  [BR]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,[tradeid]
      ,[owner]
      ,[date]
	  ,solver
      ,[reason]
	  	  ,clean
	  ,clean_date
      ,[source_date]
      ,[source_file] from FA_blacklist
union all
select  [BR]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,[tradeid]
      ,[owner]
      ,[date]
	  ,solver
      ,[reason]
	  	  ,clean
	  ,clean_date
      ,[source_date]
      ,[source_file] from VIS_blacklist
union all
select  [BR]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,[tradeid]
      ,[owner]
      ,[date]
	  ,solver
      ,[reason]
	  	  ,clean
	  ,clean_date
      ,[source_date]
      ,[source_file] from GL_blacklist 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_rules 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
CREATE VIEW vx_rules AS
SELECT
		[BU]
      ,[system]
	  ,PO_rules.[BR]
      ,[entitytype]
      ,[Depth]
      ,[Importance]
      ,[ErrorCause]
      ,[modificationDate]
      ,[ruleOwner]
      ,[approvedBy]
      ,[approvedDate]
      ,[resultApprovalDate]
      ,[dataelements]
      ,[datasource]
      ,[referencedata]
      ,[en]
      ,[nl]
      ,[rule]
      ,[condition]
      ,[Feedback]
      ,[rule_load_date]
      ,[source_file]
	,queries.query
      ,PO_rules_supersets.superset_query
FROM
	SourceData.dbo.PO_rules
	LEFT JOIN
	SourceData.dbo.PO_rules_queries as queries on PO_rules.BR=queries.BR
      LEFT JOIN
      SourceData.dbo.PO_rules_supersets on PO_rules.BR=PO_rules_supersets.BR
UNION ALL
SELECT
		[BU]
      ,[system]
	  ,FA_rules.[BR]
      ,[entitytype]
      ,[Depth]
      ,[Importance]
      ,[ErrorCause]
      ,[modificationDate]
      ,[ruleOwner]
      ,[approvedBy]
      ,[approvedDate]
      ,[resultApprovalDate]
      ,[dataelements]
      ,[datasource]
      ,[referencedata]
      ,[en]
      ,[nl]
      ,[rule]
      ,[condition]
      ,[Feedback]
      ,[rule_load_date]
      ,[source_file]
	,queries.query
      ,FA_rules_supersets.superset_query
FROM
	SourceData.dbo.FA_rules
	LEFT JOIN
	SourceData.dbo.FA_rules_queries as queries on FA_rules.BR=queries.BR
      LEFT JOIN
      SourceData.dbo.FA_rules_supersets on FA_rules.BR=FA_rules_supersets.BR
UNION ALL
SELECT
		[BU]
      ,[system]
	  ,rules.[BR]
      ,[entitytype]
      ,[Depth]
      ,[Importance]
      ,[ErrorCause]
      ,[modificationDate]
      ,[ruleOwner]
      ,[approvedBy]
      ,[approvedDate]
      ,[resultApprovalDate]
      ,[dataelements]
      ,[datasource]
      ,[referencedata]
      ,[en]
      ,[nl]
      ,[rule]
      ,[condition]
      ,[Feedback]
      ,[rule_load_date]
      ,[source_file]
	,queries.query
      ,supersets.superset_query
FROM
	SourceData.dbo.VIS_rules as rules
	LEFT JOIN
	SourceData.dbo.VIS_rules_queries as queries on rules.BR=queries.BR
      LEFT JOIN
      SourceData.dbo.VIS_rules_supersets as supersets on rules.BR=supersets.BR
UNION ALL
SELECT
		[BU]
      ,[system]
	  ,rules.[BR]
      ,[entitytype]
      ,[Depth]
      ,[Importance]
      ,[ErrorCause]
      ,[modificationDate]
      ,[ruleOwner]
      ,[approvedBy]
      ,[approvedDate]
      ,[resultApprovalDate]
      ,[dataelements]
      ,[datasource]
      ,[referencedata]
      ,[en]
      ,[nl]
      ,[rule]
      ,[condition]
      ,[Feedback]
      ,[rule_load_date]
      ,[source_file]
	,queries.query
      ,supersets.superset_query
FROM
	SourceData.dbo.GL_rules as rules
	LEFT JOIN
	SourceData.dbo.GL_rules_queries as queries on rules.BR=queries.BR
      LEFT JOIN
      SourceData.dbo.GL_rules_supersets as supersets on rules.BR=supersets.BR 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_rules_dataelements 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
CREATE VIEW vx_rules_dataelements AS
SELECT
	*
FROM
	SourceData.dbo.PO_rules_dataelements
UNION ALL
SELECT
	*
FROM
	SourceData.dbo.FA_rules_dataelements
UNION ALL
SELECT
	*
FROM
	SourceData.dbo.VIS_rules_dataelements
UNION ALL
SELECT
	*
FROM
	SourceData.dbo.GL_rules_dataelements 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_entities 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_entities as
	select
		'Portia' as system,
		entitytype
	   ,[insid]
	   ,[prfid]
	   ,CONVERT(varchar, [fxid]) as fxid
	   ,CONVERT(varchar,tradeid) AS [tradeid]
      ,[source_file]
      ,[source_date]
	  ,[BOOK_VALUE]
	  ,[CLIENT_NAME]
	  ,[COUPON]
      ,[CURRENCY]
      ,[DLAMAssetClass1]
      ,[DLAMAssetClass2]
      ,[DLAMAssetClass3]
      ,[DLAMAssetClass4]
      ,[DLAMSector1]
      ,[DLAMSector2]
      ,[DLAMSector3]
      ,[DLAMSector4]
      ,[DLAMRating]
      ,[Expiration]
      ,[FXRATE]
      ,[IDENTIFIER]
      ,[ISSUE_DATE]
      ,[MARKET_VALUE]
      ,[MATURITY]
      ,[NOMINAL_VALUE]
	  ,[OPTION_TYPE]
      ,[PAYMENT_FREQUENCY]
      ,[PORTFOLIO_NAME]
      ,[PRICE]
      ,[proddat]
      ,[QUANTITY]
      ,[SECURITY]
	  ,STRIKE
      ,[UNDERLYING]
	  ,NULL as [Type]
	from vx_PO_entities
union all
	select
		'FrontArena' as system,
		entitytype
	   ,[insid]
	   ,[prfid]
	   ,CONVERT(varchar, [fxid]) as fxid
	   ,CONVERT(varchar,tradeid) AS [tradeid]
      ,[source_file]
      ,[source_date]
	  ,NULL as [BOOK_VALUE]
	  ,NULL as [CLIENT_NAME]
	  ,COUPON
      ,[CURRENCY]
      ,[DLAMAssetClass1]
      ,[DLAMAssetClass2]
      ,[DLAMAssetClass3]
      ,[DLAMAssetClass4]
      ,[DLAMSector1]
      ,[DLAMSector2]
      ,[DLAMSector3]
      ,[DLAMSector4]
      ,[DLAMRating]
      ,[Expiration]
      ,[FXRATE]
      ,[IDENTIFIER]
      ,[ISSUE_DATE]
      ,[MARKET_VALUE]
      ,[MATURITY]
      ,[NOMINAL_VALUE]
	  ,NULL as [OPTION_TYPE]
      ,NULL as [PAYMENT_FREQUENCY]
      ,[PORTFOLIO_NAME]
      ,[PRICE]
      ,[proddat]
      ,NULL as [QUANTITY]
      ,NULL as [SECURITY]
	  ,STRIKE
      ,NULL as [UNDERLYING]
	  ,[Type]
	from vx_FA_entities
union all
	select
		'Globe$' as [System]
		,entitytype
	   ,[insid]
	   ,[prfid]
	   ,CONVERT(varchar, [fxid]) as fxid
	   ,CONVERT(varchar,tradeid) AS [tradeid]
      ,[source_file]
      ,[source_date]
	  ,NULL AS [BOOK_VALUE]
	  ,NULL AS [CLIENT_NAME]
	  ,NULL AS COUPON
      ,[CURRENCY]
      ,[DLAMAssetClass1]
      ,[DLAMAssetClass2]
      ,[DLAMAssetClass3]
      ,NULL AS [DLAMAssetClass4]
      ,[DLAMSector1]
      ,[DLAMSector2]
      ,[DLAMSector3]
      ,[DLAMSector4]
      ,NULL AS [DLAMRating]
      ,NULL AS [Expiration]
      ,[FXRATE]
      ,[IDENTIFIER]
      ,NULL AS [ISSUE_DATE]
      ,[MARKET_VALUE]
      ,[MATURITY]
      ,[NOMINAL_VALUE]
	  ,NULL AS [OPTION_TYPE]
      ,NULL AS [PAYMENT_FREQUENCY]
      ,[PORTFOLIO_NAME]
      ,[PRICE]
      ,NULL AS [proddat]
      ,[QUANTITY]
      ,[SECURITY]
	  ,NULL AS STRIKE
      ,NULL AS [UNDERLYING]
	  ,NULL AS [Type]
	from vx_GL_entities 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_blacklist_4b 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
CREATE VIEW [dbo].[vx_Blacklist_4B] AS
SELECT
ResponsibleBusinessDepartment AS [owner]
      ,[BRDescriptionNativelanguage]
      ,[BR]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,CONVERT(varchar,[tradeid]) as [tradeid]
      ,[fail_reportname]
      ,[fail_reportdate]
      ,NULL AS [date]
      ,Responsibleforcleaning AS [solver]
      ,NULL AS [clean]
      ,NULL AS [clean_date]
      ,reasons AS [reason]
      ,NULL AS [date_orig]
      ,NULL AS [clean_date_failed]
      ,NULL AS [clean_date_orig]
      ,NULL AS [source_date]
      ,NULL AS [source_file]
FROM
PO_4A
WHERE
confirmed = '1'
union all
SELECT
ResponsibleBusinessDepartment AS [owner]
      ,[BRDescriptionNativelanguage]
      ,[BR]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,CONVERT(varchar,[tradeid]) as [tradeid]
      ,[fail_reportname]
      ,[fail_reportdate]
      ,NULL AS [date]
      ,Responsibleforcleaning AS [solver]
      ,NULL AS [clean]
      ,NULL AS [clean_date]
      ,reasons AS [reason]
      ,NULL AS [date_orig]
      ,NULL AS [clean_date_failed]
      ,NULL AS [clean_date_orig]
      ,NULL AS [source_date]
      ,NULL AS [source_file]
FROM
FA_4A
union all
SELECT
ResponsibleBusinessDepartment AS [owner]
      ,[BRDescriptionNativelanguage]
      ,[BR]
      ,[insid]
      ,[prfid]
      ,[fxid]
      ,CONVERT(varchar,[tradeid])
      ,[fail_reportname]
      ,[fail_reportdate]
      ,NULL AS [date]
      ,Responsibleforcleaning AS [solver]
      ,NULL AS [clean]
      ,NULL AS [clean_date]
      ,reasons AS [reason]
      ,NULL AS [date_orig]
      ,NULL AS [clean_date_failed]
      ,NULL AS [clean_date_orig]
      ,NULL AS [source_date]
      ,NULL AS [source_file]
FROM
GL_4A
-- confirmed = '1' 
```

