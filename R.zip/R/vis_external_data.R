#Reads data from locations not managed by git
source("R/config.R")

destination_connect <- function(){db.connect(sourcedata_connection)}

vis_d_vgd_cmplx_def <-list(
    destination=destination_connect,
    name="VIS_DM_D_VGD_CMPLX",
    origin = vispath(vis_complex_file),
    read=function(x) read.csv2(x, sep="|", na.strings=c(), stringsAsFactors = TRUE, check.names=F),
    typechanges=list(
    list(trynumeric=T, col.ignore="KDSTR_NR_OMS"),
    list(POSIXct.format= "%d-%m-%y")),
    constants = list(source_date = as.Date(source_date_vis_f)),
    val_col = "CMPLX_ID"
)

vis_d_vgd_my_def <- list(
    destination=destination_connect,
    name = "VIS_DM_D_VGD_MY",
    origin = vispath(vis_my_file),
    read=function(x) read.csv2(x, sep="|", na.strings=c(), stringsAsFactors = TRUE, check.names=F),
    typechanges=list(
    list(trynumeric=T),
    list(POSIXct.format= "%d-%m-%y")),
    constants = list(source_date = as.Date(source_date_vis_f)),
    val_col = "MY_ID"
)

vis_f_vgd_fin_gev_def <- list(
    destination = destination_connect,
    name = "VIS_DM_F_VGD_FIN_GEV",
    origin = vispath(vis_fin_file),
    read = function(x) read.csv2(x, sep="|", na.strings=c(), stringsAsFactors = TRUE, check.names=F),
    typechanges = list(
    list(trynumeric = T),
    list(POSIXct.format = "%d-%m-%y")),
    constants = list(source_date = as.Date(source_date_vis_f)),
    val_col = "MY_ID"
)

vis_d_vgd_rap_maand_def <- list(
    destination = destination_connect,
    name = "VIS_DM_V_VGD_RAP_MAAND",
    origin = vispath(vis_rap_file),
    read = function(x) read.csv(x, sep="|", na.strings=c(), stringsAsFactors = TRUE, check.names=F),
    typechanges = list(
    list(trynumeric = T),
    list(POSIXct.format = "%d-%m-%y")),
    constants = list(source_date = as.Date(source_date_vis_f)),
    val_col = "LD_DAT_ID"
)

vis_directproperty_def <- list(
		destination = destination_connect,
    name = "VIS_DL_Direct_Property",
    origin = vispath(vis_dlprop_file),
    read = function(x) read.csv(x, na.strings=c(), stringsAsFactors = TRUE, check.names=F, strip.white=T),
    typechanges = list(
    list(trynumeric = T),
    list(POSIXct.format = "%d-%m-%Y")),
    constants = list(source_date = as.Date(source_date_vis_f)),
		val_col = "FXRATE"
)