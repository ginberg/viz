require(gdata)

verify.elements <- function(rule_elements, system_elements){
	allowed_elements <- if("Data.element" %in% colnames(system_elements)){
		system_elements$Data.element
	} else if ("Dataelement" %in% colnames(system_elements)){
		system_elements$Dataelement
	} else{
		stop(paste0("Could not find expected R colname or SQL colname in system_elements, only got ", paste(collapse =", ", system_elements)))
	}
	wrong_elements <- subset(rule_elements, !(dataelement %in% allowed_elements))
	if(nrow(wrong_elements)>0){
		cat("\r\nRules with invalid elements:\r\n")
		print(wrong_elements)
		cat("\r\nAllowed elements:\r\n:")
		print(sort(unique(allowed_elements)))
		warning("There are rules with wrong elements, check html for details")
	}
}

unlist.elements <- function(rules_prep){
	stopifnot("dataelements" %in% colnames(rules_prep))
	rule_elements <- lapply(strsplit(rules_prep$dataelements, ","), trim)
	rule_names <- rep(rules_prep$BR, sapply(rule_elements, length))
	rule_elements <- data.frame(BR=rule_names, dataelement=unlist(rule_elements))
	rule_elements
}

verify.entities <- function(rules_prep){
	stopifnot("entitytype" %in% colnames(rules_prep))
	allowed_entities <- c('portfolio', 'holding', 'instrument', 'trade', 'currency')
	wrong_entities <- subset(rules_prep, is.null(entitytype) | !(entitytype %in% allowed_entities))
	if(nrow(wrong_entities)>0){
		cat("\r\nRules with invalid entities:\r\n")
		print(wrong_entities)
		cat("\r\nAllowed entities:\r\n:")
		print(allowed_entities)
		warning("There are rules with wrong entities, check html for details")
	}
}

verify.BR <- function(rules_prep, prefix){
	wrong_brs <- subset(rules_prep, is.null(BR) | !startsWith(BR, prefix))
	if(nrow(wrong_brs)>0){
		cat(paste0("\r\nRules with invalid BR id (they don't start with ", prefix, ":\r\n"))
		print(wrong_brs)
		warning("There are rules with wrong ids, check html for details")
	}
}

#Load sql query files for a BR and return a df
load.rules_queries <- function(rules_prep){
  id_count <- table(rules_prep$BR)
  invalid_id_counts <- id_count > 1
  if(sum(invalid_id_counts)>0){
	  stop(paste0("Rules '", paste(collapse="', '", names(id_count[invalid_id_counts])), "' occur multiple times. Respectively ", paste(collapse=", ", id_count[invalid_id_counts])," times."))
  }
  rule_sql_files <- lapply(rules_prep$BR, function(BR) list.files(path="./SQL/businessrules/", pattern=paste0("^", BR, "_.*\\.sql$"), ignore.case=T, full.names=T))
  names(rule_sql_files) <- rules_prep$BR
  rule_sql_count <- sapply(rule_sql_files, length)
  rule_sql_count_0 <- rule_sql_count == 0
  if(sum(rule_sql_count_0)>0){
	  stop(paste0("\r\nRules '", paste(collapse="', '", names(rule_sql_files)[rule_sql_count_0]),"' have no matching sql files:\r\n"))
  }
  rule_sql_count_p1 <- rule_sql_count > 1
  if(sum(rule_sql_count_p1)>0){
	warning(rule_sql_files[rule_sql_count_p1])
	stop(paste0("\r\nRules '", paste(collapse="', '", names(rule_sql_files)[rule_sql_count_p1]),"' have multiple matching sql files:\r\n"))
  }
  rule_sql_query <- unlist(lapply(rule_sql_files, function(sql_file_path){
										     paste(collapse="\r\n",readLines(sql_file_path, encoding="UTF-8-BOM"))
											  }
								  )
						  )
  rule_queries <- data.frame("BR"=rules_prep$BR, "query"=as.vector(rule_sql_query), stringsAsFactors=F)
  rule_queries
}

load.rules_supersetqueries <- function(rules_prep) {
  # This function takes ------, makes a list of SQL source files that define supersets for business rules
  # (by checking the named files in the superset directory), and returns a dataframe of the rule + query
  id_count <- table(rules_prep$BR)
  invalid_id_counts <- id_count > 1
  if(sum(invalid_id_counts)>0){
    stop(paste0("Rules '", paste(collapse="', '", names(id_count[invalid_id_counts])), "' occur multiple times. Respectively ", paste(collapse=", ", id_count[invalid_id_counts])," times."))
  }
  rule_sql_files <- lapply(rules_prep$BR, function(BR) list.files(path="./SQL/businessrules/BR_superset/", pattern=paste0("^", BR, "_.*\\.sql$"), ignore.case=T, full.names=T))
  names(rule_sql_files) <- rules_prep$BR
  rule_sql_count <- sapply(rule_sql_files, length)
  rule_sql_count_0 <- rule_sql_count == 0
  
  #########################
  # RE-ENABLE WHEN ALL RULES HAVE SUPERSET RULES (this is the check where every rule is supposed to have a superset.sql)
  #if(sum(rule_sql_count_0)>0){
  #  stop(paste0("\r\nRules '", paste(collapse="', '", names(rule_sql_files)[rule_sql_count_0]),"' have no matching sql files:\r\n"))
  #}
  #########################
  #########################
  # POSSIBLE TODO:
  # Generate a dummy dataframe ('BR', 'NA') when no superset rules are found; this would prevent vx_rules.sql from breaking
  #########################
  rule_sql_count_p1 <- rule_sql_count > 1
  if(sum(rule_sql_count_p1)>0){
    warning(rule_sql_files[rule_sql_count_p1])
    stop(paste0("\r\nRules '", paste(collapse="', '", names(rule_sql_files)[rule_sql_count_p1]),"' have multiple matching sql files:\r\n"))
  }
  if (length(unlist(rule_sql_files)) == 0) {
    warning(rule_sql_files)
    stop(paste0("No superset rules found"))
  }
  rule_sql_query <- unlist(lapply(rule_sql_files, function(sql_file_path){
    if(length(sql_file_path > 0)) {
      paste(collapse="\r\n",readLines(sql_file_path, encoding="UTF-8-BOM"))
    }
    else {
      paste("")
    }
  }))
  rule_queries <- data.frame("BR"=rules_prep$BR, "superset_query"=as.vector(rule_sql_query), stringsAsFactors=F)
  rule_queries
}

