#Copy this file to config.R and modify settings when needed

#RUN SETTINGS
source_date <- "20160412"
source_date_f <- format(as.Date(source_date, "%Y%m%d"))
source_date_fa <- "20160413"
source_date_fa_f <- format(as.Date(source_date_fa, "%Y%m%d"))
source_date_gl <- "20160426"
source_date_gl_f <- format(as.Date(source_date_gl, "%Y%m%d"))
source_date_vis <- "20160222"
source_date_vis_f <- format(as.Date(source_date_vis, "%Y%m%d"))
run_systems <- c("portia", "fa")
#run_systems <- c("portia","fa","globes","vis")

#PATH SETTINGS
dlam_data_path<-"Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps"
common_data_path<-paste(dlam_data_path,"Prio 0 - Common Data", source_date, sep="/")
input_data_path<-paste(dlam_data_path,"Prio 0 - Input", source_date, sep="/")
portia_data_path<-paste(dlam_data_path,"Prio 1 - Portia", source_date, sep="/")
fa_data_path<-paste(dlam_data_path,"/Prio 2 - Front Arena", source_date_fa, sep="/")
vis_data_path<-paste(dlam_data_path,"/Prio 3 - VIS", source_date_vis, sep="/")
globes_data_path<-paste(dlam_data_path,"/Prio 3 - Globe$", source_date_gl, sep="/")
pipeline_input_path<-"../inputdata"
output_path<-"../output"
output_br_path<-"../output/businessrules"
output_br_results_path<-"../output/businessrules/br_resultaten"
data_path<-"../data"

#DATABASE SETTINGS
sourcedata_connection <- 'driver={SQL Server};server=ONTW7D00489;database=SourceData;trusted_connection=true'
fa_exports_connection <- 'driver={SQL Server};server=ONTW7D00489;database=FA_exports;trusted_connection=true'
fa_connection <- 'driver={SQL Server};server=ONTW7D00489;database=AM_AdsP;trusted_connection=true'
fa_analysis_connection <- 'driver={SQL Server};server=ONTW7D00489;database=AM_AdsP_analysis;trusted_connection=true'
dataquality_connection <- 'driver={SQL Server};server=ONTW7D00489;database=DataQuality;trusted_connection=true'
has_portia_db <- FALSE # Set to true if you have a portia connection
#portia_connection <- 'driver={SQL Server};server=TRIFINLDTI10\DTI;database=portia;trusted_connection=true'
has_fa_db <- TRUE
library(RODBC)
db.connect <- function(...){
  return(odbcDriverConnect(...))
}

#filesnames common
frm_fields_file <- "frm_fields.csv"
dataelements_descriptions_file <- "dataelement_descriptions.csv"
clients_file <- "20151108 Clients.csv"
dlam_asset_class_tree_file <- "dlam_asset_class_tree.csv"
dlam_sector_tree_file <- "dlam_sector_tree.csv"
ratingmap_file <- "ratingmap.csv"
mapping_wft_sector_file <- "mapping_wft_sector.csv"
whitelist_industry_dlam_file <- "whitelist_industry_dlamsector3.csv"
whitelist_dra_sector_file <- "whitelist_dra_sector.csv"
whitelist_gics1_dlam3_file <- "whitelist_gics1_dlamsector3.csv"
whitelist_cic_assetclass_file <- "whitelist_cic_assetclass.csv"
whitelist_cedar_assetclass_file <- "whitelist_assetclass_cedar.csv"
whitelist_dbinstype_assetclass_file <- "whitelist_assetclass_dbinstype.csv"
fndstt_known_mismatches_file <- "fndstt_known_mismatches.csv"

#filenames portia
portia_rl_file <- "portia_rules.csv"
portia_bl_file <- "portia_blacklist.csv"
portia_wl_file <- "portia_whitelist.csv"
portia_4a_file <- "portia_4a.csv"
dmsec_file <- "DMsecsHLD.csv"
portia_total_file <- "RM-PortiaTotal_P_20160413.csv"
portia_saldo_file <- "portsaldo.csv"
fndstt_file <- "FNDSTT.dat"
fndstt__desc_file <- "fndstt_description.csv"
fb_hist_file <- "fb-hist.csv"
fb_hist_infl_file <- "fb-hist-inflatie.csv"
portia_hfx_file <- "hfx.csv"
cedar_file <- "cedar.csv"
future_codes_file <- "isin_future_codes.csv"
future_months_file <- "isin_future_months.csv"

#filenames fa
fa_rl_file <- "frontarena_rules.csv"
fa_bl_file <- "frontarena_blacklist.csv"
fa_wl_file <- "frontarena_whitelist.csv"
fa_4a_file <- "frontarena_4a.csv"
fa_hfx_file <- "hfx-13042016.csv"
fa_loan_file <- "FA_Loan_P_20160414.csv"
fa_derivatives_file <- "FA_Derivatives_P_20160414.csv"
dl_derivatives_file <- "DLDerivativesReportRisk2016-04-14.csv"
fieldmapping_fa_db <- "fieldmapping_frontarena_db.csv"

#filenames globes
globes_rl_file <- "globe$_rules.csv"
globes_bl_file <- "globe$_blacklist.csv"
globes_wl_file <- "globe$_whitelist.csv"
globes_4a_file <- "globe$_4a.csv"
globes_fx_file <- "fx.prn"
globes_fx_pms_file <- "fxpms.csv"
globes_fx_hb_file <- "fxhb.csv"
globes_risk_ff_deals_file <- "RISK  FORWARDS_openstaande fxdeals.csv"
globes_risk_ff_file <- "RISK  FORWARDS_forwards.csv"
globes_risk_ff_code_file <- "RISK  FORWARDS_globescode_to_portia.csv"
globes_risk_ff_type_file <- "RISK  FORWARDS_portfolio_to_typegeld.csv"
globes_limit_file <- "Limieten gesplitst naar Eigen Geld.csv"

#filenames vis
vis_rl_file <- "vis_rules.csv"
vis_bl_file <- "vis_blacklist.csv"
vis_wl_file <- "vis_whitelist.csv"
vis_4a_file <- "vis_4a.csv"
vis_complex_file <- "DM_D_VGD_CMPLX 20160107.csv"
vis_my_file <- "DM_D_VGD_MY 20160107.csv"
vis_fin_file <- "DM_F_VGD_FIN_GEV 20160107.csv"
vis_rap_file <- "DM_V_VGD_RAP_MAAND 20160107.csv"
vis_dlprop_file <- "DL Direct Property 2015-12-31 Solvency.csv"
