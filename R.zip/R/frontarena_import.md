---
title: "Front Arena import"
output: html_document
---




# Data Import

This report has been generated on 2016-04-26.





# DLAM_HOLDING

```r
#void <- load.data(fa_holding)
```

# DLAM TRADES

```r
#void <- load.data(fa_trades)
```

# Front Arena Loans

```r
void <- load.data(c(fa_loan,list(transforms=list(extract_coupon_from_start))))
```

DEBUG [2016-04-26 16:06:42] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 2 - Front Arena/20160413/FA_Loan_P_20160414.csv
Preprocessing data read from *FA_Loan_P_20160414.csv*  

```
Thera are 1 empty column names at indices 34, they have been given name X with numeric sufixes:
[1] "Columns with only <NA> values are removed : Issuer, Country of Risk, X1"
```
Final column names of original dataframe:  

```
 [1] "Instrument Name"      "Portfolio Name"       "Date"                 "None"                 "FaceNominal"         
 [6] "Rec Fixed Rate"       "Maturity Date"        "Issuer"               "Country of Risk"      "DispFx"              
[11] "Pos"                  "PLPos"                "Currency"             "Price"                "Val End"             
[16] "Accrued Interest End" "DLAM Rating"          "DLAM Sector 1"        "DLAM Sector 2"        "DLAM Sector 3"       
[21] "DLAM Sector 4"        "StartDate"            "Yield FI"             "Modified Duration FI" "Convexity FI"        
[26] "DLAMAssetClass1"      "DLAMAssetClass2"      "DLAMAssetClass3"      "DLAMAssetClass4"      "Cedar_BU_Nr"         
[31] "FairValueLevel"       "ID-CodeS2"            "IdentifierType"       "X1"                  
```
Converted column Date to POSIXct (format=%Y-%m-%d %H:%M:%S)  with no failures on 62 nonempty values.  
Converted column MaturityDate to POSIXct (format=%d/%m/%Y)  with no failures on 62 nonempty values.  
Converted column StartDate to POSIXct (format=%d/%m/%Y)  with no failures on 62 nonempty values.  
DEBUG [2016-04-26 16:06:42] Saving data to table FA_loan

```
DEBUG [2016-04-26 16:06:43] Validate, rowcount for dataset FA_loan_orig, file: 62, table: 62
DEBUG [2016-04-26 16:06:43] Validate, columncount for dataset FA_loan_orig, file: 34, table: 34
DEBUG [2016-04-26 16:06:43] Validate, hashtotal for dataset FA_loan_orig, column Price, file: 7348.50609955765, table: 7348.50609955765
DEBUG [2016-04-26 16:06:43] Validate, rowcount for dataset FA_loan, file: 62, table: 62
DEBUG [2016-04-26 16:06:43] Validate, columncount for dataset FA_loan, file: 39, table: 39
DEBUG [2016-04-26 16:06:43] Validate, hashtotal for dataset FA_loan, column Price, file: 7348.50609955765, table: 7348.50609955765

```

Saved processed file originating from  *FA_Loan_P_20160414.csv* in the database as table named  **FA_loan**   

# Front Arena Derivatives

```r
void <- load.data(c(fa_deriv, list(transforms=list(extract_coupon_from_end))))
```

DEBUG [2016-04-26 16:06:43] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 2 - Front Arena/20160413/FA_Derivatives_P_20160414.csv
Preprocessing data read from *FA_Derivatives_P_20160414.csv*  

```
Thera are 1 empty column names at indices 31, they have been given name X with numeric sufixes:
[1] "Columns with only <NA> values are removed : Convexity, X1"
```
Final column names of original dataframe:  

```
 [1] "Instrument Name"         "Portfolio Name"          "Date"                    "Outstanding Nominal End"
 [5] "Pay Fixed Rate"          "Rec Fixed Rate"          "Coupon"                  "Maturity Date"          
 [9] "Issuer"                  "Country of Risk"         "DispFx"                  "Currency"               
[13] "Price"                   "Val End (EUR)"           "Acc SubL"                "DLAM Rating"            
[17] "StartDate"               "Expiry"                  "Strike"                  "Modified Duration"      
[21] "Convexity"               "BPV"                     "DLAMAssetClass1"         "DLAMAssetClass2"        
[25] "DLAMAssetClass3"         "DLAMAssetClass4"         "DLAM Sector 1"           "DLAM Sector 2"          
[29] "DLAM Sector 3"           "DLAM Sector 4"           "X1"                     
```
Converted column Date to POSIXct (format=%Y-%m-%d %H:%M:%S)  with no failures on 348 nonempty values.  
Converted column MaturityDate to POSIXct (format=%d/%m/%Y)  with no failures on 348 nonempty values.  
Converted column StartDate to POSIXct (format=%d/%m/%Y)  with no failures on 346 nonempty values.   All unique failures: ''.  
Converted column Expiry to POSIXct (format=%d/%m/%Y)  with no failures on 348 nonempty values.  
DEBUG [2016-04-26 16:06:45] Saving data to table FA_deriv

```
DEBUG [2016-04-26 16:06:46] Validate, rowcount for dataset FA_deriv_orig, file: 348, table: 348
DEBUG [2016-04-26 16:06:46] Validate, columncount for dataset FA_deriv_orig, file: 31, table: 31
DEBUG [2016-04-26 16:06:46] Validate, hashtotal for dataset FA_deriv_orig, column Price, file: 2275.86931668325, table: 2275.86931668325
DEBUG [2016-04-26 16:06:47] Validate, rowcount for dataset FA_deriv, file: 348, table: 348
DEBUG [2016-04-26 16:06:47] Validate, columncount for dataset FA_deriv, file: 39, table: 39
DEBUG [2016-04-26 16:06:47] Validate, hashtotal for dataset FA_deriv, column Price, file: 2275.86931668325, table: 2275.86931668325

```

Saved processed file originating from  *FA_Derivatives_P_20160414.csv* in the database as table named  **FA_deriv**   

# Front Arena Derivatives Report

```r
void <- load.data(fa_derivreport)
```

DEBUG [2016-04-26 16:06:48] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 2 - Front Arena/20160413/DLDerivativesReportRisk2016-04-14.csv
Preprocessing data read from *DLDerivativesReportRisk2016-04-14.csv*  

```
Thera are 1 empty column names at indices 136, they have been given name X with numeric sufixes:
[1] "Columns with only <NA> values are removed : Pay Leg Index Ref, Pay Index Ref BB, Pay Leg Spread, Rec Leg Spread, Fair Value Seasonality Correction, Fair Value Seasonality Correction (EUR), Flat Index Ratio, X1"
```
Final column names of original dataframe:  

```
  [1] "AsOfDate"                                "BatchDateTime"                          
  [3] "Instrument"                              "RefISIN"                                
  [5] "Portfolio"                               "Instrument Type"                        
  [7] "B/S"                                     "Outstanding Nominal End"                
  [9] "DispFx"                                  "Currency"                               
 [11] "Start Date"                              "End Date"                               
 [13] "Pay Type"                                "Issuer RedCode"                         
 [15] "Underlying Instrument"                   "Underlying Type"                        
 [17] "Strike Price"                            "Strike Type"                            
 [19] "Exercise Type"                           "Call or Put"                            
 [21] "Expiry"                                  "Settlement Type"                        
 [23] "DLAMAssetClass1"                         "DLAMAssetClass2"                        
 [25] "DLAMAssetClass3"                         "DLAMAssetClass4"                        
 [27] "DLAM Classification level 1"             "DLAM Classification level 2"            
 [29] "DLAM Classification level 3"             "DLAM Classification level 4"            
 [31] "Underlying Tenor"                        "Underlying Tenor Unit"                  
 [33] "Coupon"                                  "Pay Leg Type"                           
 [35] "Pay Leg Currency"                        "Pay Float Rate Ref"                     
 [37] "Pay Float Ref BB"                        "Pay Leg Index Type"                     
 [39] "Pay Leg Index Ref"                       "Pay Index Ref BB"                       
 [41] "Pay Fixed Rate"                          "Pay Leg Spread"                         
 [43] "Pay Day Count"                           "Pay Leg Pay Cal"                        
 [45] "Pay Leg Rolling"                         "Pay Leg Roll Period Base Day"           
 [47] "Rec Leg Type"                            "Rec Leg Currency"                       
 [49] "Rec Float Rate Ref"                      "Rec Float Ref BB"                       
 [51] "Rec Leg Index Type"                      "Rec Leg Index Ref"                      
 [53] "Rec Index Ref BB"                        "Rec Fixed Rate"                         
 [55] "Rec Leg Spread"                          "Rec Day Count"                          
 [57] "Rec Leg Pay Cal"                         "Rec Leg Rolling"                        
 [59] "Rec Leg Roll Period Base Day"            "Open Premium"                           
 [61] "Open Premium Discounted"                 "Fair Value Premium"                     
 [63] "Fair Value Premium At Expiry"            "Pay Leg Accrued"                        
 [65] "Pay Leg Clean Val"                       "Pay Leg PV"                             
 [67] "Rec Leg Accrued"                         "Rec Leg Clean Val End"                  
 [69] "Rec Leg PV"                              "Accrued Interest Position"              
 [71] "Clean Value Position"                    "Fair Value Position"                    
 [73] "Fair Value No Seasonality"               "Fair Value Seasonality Correction"      
 [75] "Open Premium (EUR)"                      "Open Premium Discounted (EUR)"          
 [77] "Fair Value Premium (EUR)"                "Fair Value Premium At Expiry (EUR)"     
 [79] "Pay Leg Accrued (EUR)"                   "Pay Leg Clean Val (EUR)"                
 [81] "Pay Leg PV (EUR)"                        "Rec Leg Clean Val End (EUR)"            
 [83] "Rec Leg Accrued (EUR)"                   "Rec Leg PV (EUR)"                       
 [85] "Accrued Interest Position (EUR)"         "Clean Value Position (EUR)"             
 [87] "Fair Value Position (EUR)"               "Fair Value No Seasonality (EUR)"        
 [89] "Fair Value Seasonality Correction (EUR)" "Val End (EUR)"                          
 [91] "Price"                                   "Delta"                                  
 [93] "DV01"                                    "Modified Duration"                      
 [95] "Gamma"                                   "DDV01"                                  
 [97] "Vega (1% abs)"                           "Norm Vol"                               
 [99] "Theta (1 bday total diff)"               "Theta (1 bday partial diff)"            
[101] "Par Rate"                                "Discount Delta"                         
[103] "Base CPI"                                "Ref CPI"                                
[105] "Flat Index Ratio"                        "Total Index Ratio"                      
[107] "CPI Index At Maturity"                   "IDelta"                                 
[109] "Inflation Gamma"                         "C Delta"                                
[111] "Trade Number"                            "Transaction Type"                       
[113] "Premium"                                 "Premium Currency"                       
[115] "Trade Time"                              "Acquire Day"                            
[117] "Value Day"                               "DLAM Rating"                            
[119] "Country of Risk"                         "Issuer"                                 
[121] "Counterparty"                            "Counterparty BB"                        
[123] "Rec Rate"                                "CP_LEI"                                 
[125] "BB_IssuerID"                             "Cedar_BU_nr"                            
[127] "FairValueLevel"                          "InterestSettledRecLeg (EUR)"            
[129] "InterestSettledPayLeg (EUR)"             "ID-CodeS2"                              
[131] "IdentifierType"                          "UnderlyingIdentifier"                   
[133] "UnderlyingIdentifierType"                "ContractNumber"                         
[135] "ContractSize"                            "X1"                                     
```
Did not convert column RefISIN to numeric  because of too many failures (15) compared to successes (4)
Converted column OutstandingNominalEnd to numeric  with no failures on 349 nonempty values.  
Converted column DispFx to numeric  with no failures on 349 nonempty values.  
Converted column StrikePrice to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column UnderlyingTenor to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column Coupon to numeric  with no failures on 346 nonempty values.   All unique failures: ''.  
Converted column PayFixedRate to numeric  with no failures on 170 nonempty values.   All unique failures: ''.  
Converted column RecFixedRate to numeric  with no failures on 178 nonempty values.   All unique failures: ''.  
Converted column OpenPremium to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column OpenPremiumDiscounted to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column FairValuePremium to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column FairValuePremiumAtExpiry to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column PayLegAccrued to numeric  with no failures on 221 nonempty values.   All unique failures: ''.  
Converted column PayLegCleanVal to numeric  with no failures on 347 nonempty values.   All unique failures: ''.  
Converted column PayLegPV to numeric  with no failures on 347 nonempty values.   All unique failures: ''.  
Converted column RecLegAccrued to numeric  with no failures on 210 nonempty values.   All unique failures: ''.  
Converted column RecLegCleanValEnd to numeric  with no failures on 347 nonempty values.   All unique failures: ''.  
Converted column RecLegPV to numeric  with no failures on 347 nonempty values.   All unique failures: ''.  
Converted column AccruedInterestPosition to numeric  with no failures on 223 nonempty values.   All unique failures: ''.  
Converted column CleanValuePosition to numeric  with no failures on 349 nonempty values.  
Converted column FairValuePosition to numeric  with no failures on 349 nonempty values.  
Converted column FairValueNoSeasonality to numeric  with no failures on 57 nonempty values.   All unique failures: ''.  
Converted column OpenPremiumEUR to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column OpenPremiumDiscountedEUR to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column FairValuePremiumEUR to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column FairValuePremiumAtExpiryEUR to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column PayLegAccruedEUR to numeric  with no failures on 221 nonempty values.   All unique failures: ''.  
Converted column PayLegCleanValEUR to numeric  with no failures on 347 nonempty values.   All unique failures: ''.  
Converted column PayLegPVEUR to numeric  with no failures on 347 nonempty values.   All unique failures: ''.  
Converted column RecLegCleanValEndEUR to numeric  with no failures on 347 nonempty values.   All unique failures: ''.  
Converted column RecLegAccruedEUR to numeric  with no failures on 210 nonempty values.   All unique failures: ''.  
Converted column RecLegPVEUR to numeric  with no failures on 347 nonempty values.   All unique failures: ''.  
Converted column AccruedInterestPositionEUR to numeric  with no failures on 223 nonempty values.   All unique failures: ''.  
Converted column CleanValuePositionEUR to numeric  with no failures on 349 nonempty values.  
Converted column FairValuePositionEUR to numeric  with no failures on 349 nonempty values.  
Converted column FairValueNoSeasonalityEUR to numeric  with no failures on 57 nonempty values.   All unique failures: ''.  
Converted column ValEndEUR to numeric  with no failures on 349 nonempty values.  
Converted column Price to numeric  with no failures on 349 nonempty values.  
Converted column Delta to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column DV01 to numeric  with no failures on 349 nonempty values.  
Converted column ModifiedDuration to numeric  with no failures on 349 nonempty values.  
Converted column Gamma to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column DDV01 to numeric  with no failures on 348 nonempty values.   All unique failures: ''.  
Converted column Vega1abs to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column NormVol to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column Theta1bdaytotaldiff to numeric  with no failures on 349 nonempty values.  
Converted column Theta1bdaypartialdiff to numeric  with no failures on 2 nonempty values.   All unique failures: ''.  
Converted column ParRate to numeric  with no failures on 348 nonempty values.   All unique failures: ''.  
Converted column DiscountDelta to numeric  with no failures on 344 nonempty values.   All unique failures: ''.  
Converted column BaseCPI to numeric  with no failures on 57 nonempty values.   All unique failures: ''.  
Converted column RefCPI to numeric  with no failures on 57 nonempty values.   All unique failures: ''.  
Converted column TotalIndexRatio to numeric  with no failures on 57 nonempty values.   All unique failures: ''.  
Converted column CPIIndexAtMaturity to numeric  with no failures on 57 nonempty values.   All unique failures: ''.  
Converted column IDelta to numeric  with no failures on 57 nonempty values.   All unique failures: ''.  
Converted column InflationGamma to numeric  with no failures on 57 nonempty values.   All unique failures: ''.  
Converted column CDelta to numeric  with no failures on 15 nonempty values.   All unique failures: ''.  
Converted column Premium to numeric  with no failures on 34 nonempty values.   All unique failures: ''.  
Converted column RecRate to numeric  with no failures on 15 nonempty values.   All unique failures: ''.  
Converted column InterestSettledRecLegEUR to numeric  with no failures on 135 nonempty values.   All unique failures: ''.  
Converted column InterestSettledPayLegEUR to numeric  with no failures on 145 nonempty values.   All unique failures: ''.  
Converted column ContractNumber to numeric  with no failures on 349 nonempty values.  
Converted column ContractSize to numeric  with no failures on 349 nonempty values.  
Converted column BatchDateTime to POSIXct (format=%Y-%m-%d %H:%M:%S)  with no failures on 349 nonempty values.  
Converted column Expiry to POSIXct (format=%Y-%m-%d %H:%M:%S)  with no failures on 349 nonempty values.  
Converted column TradeTime to POSIXct (format=%Y-%m-%d %H:%M:%S)  with no failures on 349 nonempty values.  
Converted column AsOfDate to POSIXct (format=%Y-%m-%d)  with no failures on 349 nonempty values.  
Converted column BatchDateTime to POSIXct (format=%Y-%m-%d)  with no failures on 349 nonempty values.  
Converted column StartDate to POSIXct (format=%Y-%m-%d)  with no failures on 347 nonempty values.   All unique failures: ''.  
Converted column EndDate to POSIXct (format=%Y-%m-%d)  with no failures on 347 nonempty values.   All unique failures: ''.  
Converted column Expiry to POSIXct (format=%Y-%m-%d)  with no failures on 349 nonempty values.  
Converted column PayLegRollPeriodBaseDay to POSIXct (format=%Y-%m-%d)  with no failures on 349 nonempty values.  
Converted column RecLegRollPeriodBaseDay to POSIXct (format=%Y-%m-%d)  with no failures on 349 nonempty values.  
Converted column TradeTime to POSIXct (format=%Y-%m-%d)  with no failures on 349 nonempty values.  
Converted column AcquireDay to POSIXct (format=%Y-%m-%d)  with no failures on 349 nonempty values.  
Converted column ValueDay to POSIXct (format=%Y-%m-%d)  with no failures on 349 nonempty values.  
DEBUG [2016-04-26 16:06:48] Saving data to table FA_derivreport

```
[1] "Column '11: Mean relative differenc not found in target."
DEBUG [2016-04-26 16:06:50] Validate, rowcount for dataset FA_derivreport_orig, file: 349, table: 349
DEBUG [2016-04-26 16:06:50] Validate, columncount for dataset FA_derivreport_orig, file: 136, table: 136
DEBUG [2016-04-26 16:06:50] Validate, hashtotal for dataset FA_derivreport_orig, column Price, file: 2272.98485529624, table: 2272.98485529624
DEBUG [2016-04-26 16:06:52] Validate, rowcount for dataset FA_derivreport, file: 349, table: 349
DEBUG [2016-04-26 16:06:52] Validate, columncount for dataset FA_derivreport, file: 135, table: 135
DEBUG [2016-04-26 16:06:52] Validate, hashtotal for dataset FA_derivreport, column Price, file: 2272.98485529624, table: 2272.98485529624

```

Saved processed file originating from  *DLDerivativesReportRisk2016-04-14.csv* in the database as table named  **FA_derivreport**   

# Exchange rates
DEBUG [2016-04-26 16:06:53] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 2 - Front Arena/20160413/hfx-13042016.csv
Preprocessing data read from *hfx-13042016.csv*  

```
Removing explicitly provided colnames RATETYPE
Renaming column CURRENCY to fxid
Renaming column Rate to FXRATE
Renaming column RATEDATE to ReportingDate
Renaming column EURtoVV to INV_FXRATE
```
Final column names of original dataframe:  

```
[1] "CURRENCY" "RATETYPE" "Rate"     "RATEDATE" "EURtoVV" 
```
Converted column ReportingDate to Date (format=%d/%m/%Y)  with no failures on 57 nonempty values.  
DEBUG [2016-04-26 16:06:53] Saving data to table FA_exchangerates

```
DEBUG [2016-04-26 16:06:55] Validate, rowcount for dataset FA_exchangerates_orig, file: 57, table: 57
DEBUG [2016-04-26 16:06:55] Validate, columncount for dataset FA_exchangerates_orig, file: 5, table: 5
DEBUG [2016-04-26 16:06:55] Validate, hashtotal for dataset FA_exchangerates_orig, column Rate, file: 18.6742224461, table: 18.6742224461
DEBUG [2016-04-26 16:06:55] Validate, rowcount for dataset FA_exchangerates, file: 58, table: 58
DEBUG [2016-04-26 16:06:55] Validate, columncount for dataset FA_exchangerates, file: 7, table: 7
DEBUG [2016-04-26 16:06:55] Validate, hashtotal for dataset FA_exchangerates, column FXRATE, file: 19.6742224461, table: 19.6742224461

```

Saved processed file originating from  *hfx-13042016.csv* in the database as table named  **FA_exchangerates**   


# Database enrichments

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
DROP VIEW PRICE_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
IF OBJECT_ID('PRICE_ADDITIONAL') IS NOT NULL
	DROP VIEW PRICE_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
CREATE VIEW PRICE_ADDITIONAL AS
SELECT
       PR.[prinbr]
      ,PR.[insaddr]
      ,PR.[bid]
      ,PR.[ask]
      ,PR.[curr]
	  ,C.insid							AS curr_desc
  FROM [AM_AdsP].[dbo].[price] PR
  LEFT JOIN [AM_AdsP].[dbo].[instrument] C
  ON PR.curr = C.insaddr 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
DROP VIEW LEG_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
IF OBJECT_ID('LEG_ADDITIONAL') IS NOT NULL
	DROP VIEW LEG_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
CREATE VIEW LEG_ADDITIONAL AS
SELECT
       [insaddr]
      ,[legnbr]
      ,[type]											AS legtype
      ,[payleg]
      ,[daycount_method]
      ,[curr]
      ,[nominal_factor]
      ,[float_rate]
      ,[rounding]
      ,[decimals]
      ,[fixed_rate]
      ,[fixed_coupon]
	  ,[start_day]
	  ,[end_day]
	  ,[float_rate_factor]
	  ,LT.tag											AS legtype_desc
  FROM [AM_AdsP].[dbo].[leg] L
  LEFT JOIN [AM_AdsP].[dbo].[ds_enums] LT
  ON L.[type] = LT.value AND LT.name = 'LegType' 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
--			,[updat_usrnbr] 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
DROP VIEW PARTY_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
IF OBJECT_ID('PARTY_ADDITIONAL') IS NOT NULL
	DROP VIEW PARTY_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
CREATE VIEW PARTY_ADDITIONAL AS
SELECT
     PT.[ptynbr]										AS      [party_ptynbr]
	,PT.[ptyid]											AS      [party_ptyid]
	,PT.[type]											AS      [party_type]
	,PT.[fullname]										AS      [party_fullname]
	,PT_T.[tag]											AS		[partytype_desc]
  FROM [AM_AdsP].[dbo].[party] PT
  LEFT JOIN [AM_AdsP].[dbo].[ds_enums] PT_T
  ON PT.[type] = PT_T.value AND PT_T.name = 'PartyType' 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
DROP VIEW TRADE_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
IF OBJECT_ID('TRADE_ADDITIONAL') IS NOT NULL
	DROP VIEW TRADE_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
CREATE VIEW TRADE_ADDITIONAL AS
SELECT
	 T.[trdnbr]										AS      [trade_trdnbr]
	,T.[prfnbr]										AS      [trade_prfnbr]
	,T.[insaddr]									AS      [trade_insaddr]
	,T.[quantity]									AS      [trade_quantity]
	,T.[price]										AS      [trade_price]
	,T.[status]										AS      [trade_status]
	,T.[category]									AS		trade_category
	,T.[type]										AS		trade_type
	,T.[curr]										AS      [curr]
	,T.[original_curr]								AS		[original_curr]
	,T.[trade_curr]									AS		[trade_curr]
	,C.[insid]										AS		[curr_desc]
	,TC.[insid]										AS		[original_curr_desc]
	,OC.[insid]										AS		[trade_curr_desc]
	,[T_T].tag										AS		trade_type_desc
	,[T_S].tag										AS		trade_status_desc
	,[T_C].tag										AS		trade_category_desc
	,AI_TCYN.value									AS		trade_closed
	FROM [AM_AdsP].[dbo].[trade] T
  LEFT JOIN [AM_AdsP].[dbo].[ds_enums] [T_T]
  ON T.[type] = [T_T].value AND [T_T].name = 'TradeType'
  LEFT JOIN [AM_AdsP].[dbo].[ds_enums] [T_S]
  ON T.[status] = [T_S].value AND T_S.name = 'TradeStatus'
  LEFT JOIN [AM_AdsP].[dbo].[ds_enums] [T_C]
  ON T.[category] = [T_C].value AND T_C.name = 'TradeCategory'
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] AI_TCYN
  ON T.trdnbr = AI_TCYN.recaddr AND AI_TCYN.addinf_specnbr = 9
  LEFT JOIN AM_AdsP.dbo.instrument C
  ON T.curr = C.insaddr
  LEFT JOIN AM_AdsP.dbo.instrument TC
  ON T.trade_curr = TC.insaddr
  LEFT JOIN AM_AdsP.dbo.instrument OC
  ON T.original_curr = OC.insaddr
WHERE
	[T_S].tag = 'BO Confirmed' 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
--,T.[base_cost_dirty]                            AS      [trade_base_cost_dirty] 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
DROP VIEW PORTFOLIO_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
IF OBJECT_ID('PORTFOLIO_ADDITIONAL') IS NOT NULL
	DROP VIEW PORTFOLIO_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
CREATE VIEW PORTFOLIO_ADDITIONAL AS
SELECT
	 P.[prfnbr]												AS      [portfolio_prfnbr]
	,P.[prfid]												AS      [portfolio_prfid]
	,P.[assinf]												AS      [portfolio_assinf]
	,P.[owner_ptynbr]										AS      [portfolio_owner_ptynbr]
	FROM [AM_AdsP].[dbo].[portfolio] P 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
DROP VIEW INSTRUMENT_INSCOPE 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
IF OBJECT_ID('INSTRUMENT_INSCOPE') IS NOT NULL
	DROP VIEW INSTRUMENT_INSCOPE 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
CREATE VIEW INSTRUMENT_INSCOPE AS
SELECT DISTINCT
       [trade_insaddr]							AS insaddr
FROM [AM_AdsP].[dbo].[TRADE_ADDITIONAL] TA
INNER JOIN AM_AdsP.dbo.PORTFOLIO_ADDITIONAL PO
ON TA.trade_prfnbr = PO.portfolio_prfnbr
INNER JOIN AM_AdsP.dbo.instrument I
ON TA.trade_insaddr = I.insaddr
WHERE trade_status_desc IN ('BO Confirmed', 'FO Confirmed')
AND trade_category_desc NOT IN('Collateral')
AND PO.portfolio_prfid NOT LIKE '%VD%'
AND I.instype != 21
AND trade_closed IN ('NO')
AND I.exp_day > '2015-08-18'
---ADD EXPERATION DATE 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
DROP VIEW INSTRUMENT_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
IF OBJECT_ID('INSTRUMENT_ADDITIONAL') IS NOT NULL
	DROP VIEW INSTRUMENT_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
CREATE VIEW INSTRUMENT_ADDITIONAL AS
SELECT
	  I.[insaddr]																			AS      [insaddr]
	 ,I.[insid]																				AS      [insid]
	,CASE
		WHEN I.[insid] NOT LIKE '%#%' THEN I.[insid]
		WHEN LEN(I.[insid])-LEN(REPLACE(I.insid,'#','')) = 1 THEN
			CASE
				WHEN I.[insid] LIKE '%/#%' THEN LEFT(I.insid, CHARINDEX('#',I.insid)-2)
				ELSE LEFT(I.insid, CHARINDEX('#',I.insid)-1)
			END
	END																						AS		[insid_nohash]
    ,I.[issuer]    																			AS      [issuer]
    ,I.[instype]																			AS      [instype]
	,I.[issuer_ptynbr]																		AS		[issuer_ptynbr]
	,I.[und_insaddr]    																	AS      [und_insaddr]
    ,I.[und_instype]    																	AS      [und_instype]
  , UT.[tag]                                           AS [und_instype_desc]
	,I.[generic]																			AS		[generic]
	,I.[otc]																				AS		[otc]
	,I.[curr]																				AS		[currency]
	,I.[strike_price]																		AS		[strike_price]
	,I.[exp_day]																			AS		[exp_day]
	 ,I.[issue_day]  																		AS      [issue_day]
	,IT.[tag]																				AS		[instype_desc]
    ,UI.[insid]																				AS		[und_insid]
	,PT.[ptyid]																				AS		[issuer_pty]
	,PT.[type]																				AS		[issuer_pty_type]
	,PT_T.tag																				AS		[issuer_pty_type_desc]
	,CUR.insid																				AS		[currency_desc]
	,CURTYPE.[tag]																			AS    [currency_instype_desc]
	,RT_DL.[value]																			AS		[DLAMRating]
	,RT_MD.[value]																			AS		[MoodyRating]
	,RT_SP.[value]																			AS		[SnPRating]
	,RT_F.[value]																			AS		[FitchRating]
	,RT_AV.[value]																			AS		[AgencyAvRating]
	,AI_DS1.[value]																			AS		[DLAMSector1]
	,AI_DS2.[value]																			AS		[DLAMSector2]
	,AI_DS3.[value]																			AS		[DLAMSector3]
	,AI_DS4.[value]																			AS		[DLAMSector4]
	,AI_DAC1.[value]																		AS		[DLAMAssetClass1]
	,AI_DAC2.[value]																		AS		[DLAMAssetClass2]
	,AI_DAC3.[value]																		AS		[DLAMAssetClass3]
	,AI_DAC4.[value]																		AS		[DLAMAssetClass4]
	,LEN( I.[insid]) - LEN( REPLACE( I.[insid] , '/' , ''))									AS		[COUNT_SLASHES /]
    ,LEN( I.[insid]) - LEN( REPLACE( I.[insid] , '_' , ''))									AS		[COUNT_UNDERSCORE(_)]
    ,LEN( I.[insid]) - LEN( REPLACE( I.[insid] , '*' , ''))									AS		[COUNT_UNSUSED *]
    ,LEN( I.[insid]) - LEN( REPLACE( I.[insid] , '%' , ''))									AS		[COUNT_PERCENTAGE %]
    ,LEN( I.[insid]) - LEN( REPLACE( I.[insid] , '-' , ''))									AS		[COUNT_DASHES -]
	,CASE WHEN IN_SCOPE.insaddr IS NOT NULL THEN 1 ELSE 0 END							    AS		[in_scope]
  FROM [AM_AdsP].[dbo].[instrument] I
  LEFT JOIN [AM_AdsP].[dbo].[ds_enums] IT
  ON I.instype = IT.value AND IT.name = 'InsType'
  LEFT JOIN [AM_AdsP].[dbo].[ds_enums] UT
  ON I.und_instype = UT.value AND UT.name = 'InsType'
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] AI_DS1
  ON I.insaddr = AI_DS1.recaddr AND AI_DS1.addinf_specnbr = 36
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] AI_DS2
  ON I.insaddr = AI_DS2.recaddr AND AI_DS2.addinf_specnbr = 37
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] AI_DS3
  ON I.insaddr = AI_DS3.recaddr AND AI_DS3.addinf_specnbr = 38
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] AI_DS4
  ON I.insaddr = AI_DS4.recaddr AND AI_DS4.addinf_specnbr = 39
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] AI_DAC1
  ON I.insaddr = AI_DAC1.recaddr AND AI_DAC1.addinf_specnbr = 96
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] AI_DAC2
  ON I.insaddr = AI_DAC2.recaddr AND AI_DAC2.addinf_specnbr = 95
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] AI_DAC3
  ON I.insaddr = AI_DAC3.recaddr AND AI_DAC3.addinf_specnbr = 94
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] AI_DAC4
  ON I.insaddr = AI_DAC4.recaddr AND AI_DAC4.addinf_specnbr = 97
  LEFT JOIN [AM_AdsP].[dbo].[party] PT
  ON I.issuer_ptynbr = PT.ptynbr
  LEFT JOIN [AM_AdsP].[dbo].[INSTRUMENT] UI
  ON UI.[insaddr] = I.und_insaddr
  LEFT JOIN [AM_AdsP].[dbo].[ds_enums] PT_T
  ON PT.[type] = PT_T.value AND PT_T.name = 'PartyType'
  LEFT JOIN [AM_AdsP].[dbo].[instrument] CUR
  ON I.curr = CUR.insaddr
  LEFT JOIN [AM_AdsP].[dbo].[ds_enums] CURTYPE
  ON CUR.instype = CURTYPE.value AND CURTYPE.name = 'InsType'
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] RT_DL
  ON I.insaddr = RT_DL.recaddr AND RT_DL.addinf_specnbr = 81
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] RT_MD
  ON I.insaddr = RT_MD.recaddr AND RT_MD.addinf_specnbr = 57
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] RT_SP
  ON I.insaddr = RT_SP.recaddr AND RT_SP.addinf_specnbr = 68
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] RT_F
  ON I.insaddr = RT_F.recaddr AND RT_F.addinf_specnbr = 65
  LEFT JOIN [AM_AdsP].[dbo].[additional_info] RT_AV
  ON I.insaddr = RT_AV.recaddr AND RT_AV.addinf_specnbr = 114
  LEFT JOIN [AM_AdsP].[dbo].[INSTRUMENT_INSCOPE] IN_SCOPE
  ON I.insaddr = IN_SCOPE.insaddr 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
DROP VIEW INSTRUMENT_POSITION 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
IF OBJECT_ID('INSTRUMENT_POSITION') IS NOT NULL
	DROP VIEW INSTRUMENT_POSITION 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
CREATE VIEW INSTRUMENT_POSITION AS
 SELECT
       T.[trade_prfnbr]						AS prfnbr
      ,T.[trade_insaddr]					AS insaddr
      ,T.[position]							AS position
	  ,P.portfolio_prfid					AS prfid
	  ,I.in_scope							AS in_scope
	  ,I.insid								AS insid
  FROM
  (SELECT
	trade_prfnbr,
	trade_insaddr,
	SUM([trade_quantity])				AS position
  FROM [AM_AdsP].[dbo].[TRADE_ADDITIONAL]
  GROUP BY trade_prfnbr, trade_insaddr, trade_prfnbr
  ) as T
  LEFT JOIN  [AM_AdsP].[dbo].[PORTFOLIO_ADDITIONAL] P
  ON T.trade_prfnbr = P.portfolio_prfnbr
  LEFT JOIN  [AM_AdsP].[dbo].[INSTRUMENT_ADDITIONAL] I
  ON T.trade_insaddr = I.insaddr
  WHERE (
	i.insaddr IS NULL
	or i.in_scope = 1) 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
DROP VIEW PRICE_HIST_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
USE [AM_AdsP] 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
IF OBJECT_ID('PRICE_HIST_ADDITIONAL') IS NOT NULL
	DROP VIEW PRICE_HIST_ADDITIONAL 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=AM_AdsP"
create view [PRICE_HIST_ADDITIONAL] as
SELECT
	  INSTRUMENT_ADDITIONAL.insid as price_insid
	  ,INSTRUMENT_ADDITIONAL.instype_desc as price_instype_desc
      ,price_CUR.insid as price_cur_insid
      ,[day]
	  ,max([bid]) as bid
      ,max([ask]) as ask
      ,max([last_]) as last_
      ,max([settle]) as settle
  FROM [AM_AdsP].[dbo].[price_hst]
  LEFT JOIN [AM_AdsP].[dbo].[instrument] price_CUR
  ON [price_hst].curr = price_CUR.insaddr
  LEFT JOIN [AM_AdsP].[dbo].[ds_enums] CURTYPE
  ON price_CUR.instype = CURTYPE.value AND CURTYPE.name = 'InsType'
  left join INSTRUMENT_ADDITIONAL
  on price_hst.insaddr=INSTRUMENT_ADDITIONAL.insaddr
  where INSTRUMENT_ADDITIONAL.insaddr is not null
  and INSTRUMENT_ADDITIONAL.instype_desc='Curr'
GROUP BY
	INSTRUMENT_ADDITIONAL.insid
	,INSTRUMENT_ADDITIONAL.instype_desc
	,price_CUR.insid
	,[day] 
```


```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_FA_holding 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_FA_holding as
select
	exports.*,
	dbdata.position as db_position
from (
		select
			InstrumentName as insid,
			PortfolioName as prfid,
			source_file,
			source_date,
			POS AS Quantity,
			Currency as CURRENCY,
			DispFX as FXRATE,
			InstrumentName as IDENTIFIER,
			ValEnd as MARKET_VALUE,
			MaturityDate as MATURITY,
			[None] as NOMINAL_VALUE,
			PortfolioName as [PORTFOLIO_NAME],
			Price as PRICE,
			[Date] as proddat,
			AccruedInterestEnd as AccruedInterest
		from FA_loan
	union all
		select
			InstrumentName as insid,
			PortfolioName as prfid,
			source_file,
			source_date,
			OutstandingNominalEnd AS Quantity,
			Currency as CURRENCY,
			DispFX as FXRATE,
			InstrumentName as IDENTIFIER,
			ValEndEUR as MARKET_VALUE,
			MaturityDate as MATURITY,
			OutstandingNominalEnd as NOMINAL_VALUE,
			PortfolioName as [PORTFOLIO_NAME],
			Price as PRICE,
			[Date] as proddat,
			0 as AccruedInterest
		from FA_deriv
) as exports
left join
	AM_AdsP.dbo.INSTRUMENT_POSITION as dbdata
	on dbdata.in_scope=1
	and dbdata.insid = exports.insid collate SQL_Latin1_General_CP1_CI_AS
	and dbdata.prfid = exports.prfid collate SQL_Latin1_General_CP1_CI_AS 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_FA_instrument 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_FA_instrument as
select
	exports.*,
	dbdata.instype_desc as db_instype_desc
from (
		select distinct
			InstrumentName as insid,
			source_file,
			source_date,
			RecFixedRate as COUPON,
			Currency as CURRENCY,
			DLAMAssetClass1,
			DLAMAssetClass2,
			DLAMAssetClass3,
			DLAMAssetClass4,
			DLAMSector1,
			DLAMSector2,
			DLAMSector3,
			DLAMSector4,
			DLAMRating,
			NULL as Expiration,
			DispFX as FXRATE,
			InstrumentName as IDENTIFIER,
			StartDate as [ISSUE_DATE],
			MaturityDate as MATURITY,
			Price as PRICE,
			[Date] as proddat,
			NULL as STRIKE,
			'' as [Type],
			InstrumentName_Coupon as IDENTIFIER_Coupon,
			InstrumentName_CouponNum as IDENTIFIER_CouponNum
		from FA_loan
	union all
		select distinct
			InstrumentName as insid,
			source_file,
			source_date,
			Coupon as COUPON,
			Currency as CURRENCY,
			DLAMAssetClass1,
			DLAMAssetClass2,
			DLAMAssetClass3,
			DLAMAssetClass4,
			DLAMSector1,
			DLAMSector2,
			DLAMSector3,
			DLAMSector4,
			DLAMRating,
			Expiry as Expiration,
			DispFX as FXRATE,
			InstrumentName as IDENTIFIER,
			StartDate as [ISSUE_DATE],
			MaturityDate as MATURITY,
			Price as PRICE,
			[Date] as proddat,
			Strike as STRIKE,
			CallOrPut as [Type],
			InstrumentName_Coupon as IDENTIFIER_Coupon,
			InstrumentName_CouponNum as IDENTIFIER_CouponNum
		from
			(select
				FA_deriv.*, CallorPut
			from FA_deriv left join FA_derivreport
				on FA_deriv.InstrumentName = FA_derivreport.Instrument
				and FA_deriv.PortfolioName = FA_derivreport.Portfolio
			) as derivatives
) as exports
left join
	AM_AdsP.dbo.INSTRUMENT_ADDITIONAL as dbdata
	on dbdata.in_scope=1
	and dbdata.insid = exports.insid collate SQL_Latin1_General_CP1_CI_AS 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_FA_portfolio 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_FA_portfolio as
select
	exports.*,
	dbdata.portfolio_assinf as db_assinf
from (
		select distinct
			PortfolioName as prfid,
			source_file,
			source_date,
			PortfolioName as [PORTFOLIO_NAME],
			[Date] as proddat
		from FA_loan
	union all
		select distinct
			PortfolioName as prfid,
			source_file,
			source_date,
			PortfolioName as [PORTFOLIO_NAME],
			[Date] as proddat
		from FA_deriv
) as exports
left join
	AM_AdsP.dbo.PORTFOLIO_ADDITIONAL as dbdata
	on dbdata.portfolio_prfid = exports.prfid collate SQL_Latin1_General_CP1_CI_AS 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_FA_currency 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_FA_currency as
	select distinct
		Currency as fxid,
		source_file,
		source_date,
		Currency as CURRENCY,
		DispFX as FXRATE,
		[Date] as proddat
	from FA_loan
union all
	select distinct
		Currency as fxid,
		source_file,
		source_date,
		Currency as CURRENCY,
		DispFX as FXRATE,
		[Date] as proddat
	from FA_deriv
union all
	select distinct
		Currency as fxid,
		source_file,
		source_date,
		Currency as CURRENCY,
		DispFx as FXRate,
		AsOfDate as proddat
	from
		fa_derivreport 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_FA_entities 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_FA_entities AS
SELECT
	  'instrument' as entitytype,
	   [insid]
	  ,NULL as prfid
	  ,NULL as fxid
	   ,NULL as [tradeid]
      ,[source_file]
      ,[source_date]
      ,[COUPON]
      ,[CURRENCY]
      ,[DLAMAssetClass1]
      ,[DLAMAssetClass2]
      ,[DLAMAssetClass3]
      ,[DLAMAssetClass4]
      ,[DLAMSector1]
      ,[DLAMSector2]
      ,[DLAMSector3]
      ,[DLAMSector4]
      ,[DLAMRating]
      ,[Expiration]
      ,[FXRATE]
      ,[IDENTIFIER]
      ,[ISSUE_DATE]
	  ,NULL as [MARKET_VALUE]
      ,[MATURITY]
      ,NULL as [NOMINAL_VALUE]
      ,NULL as [PORTFOLIO_NAME]
      ,[PRICE]
      ,[proddat]
      ,[STRIKE]
      ,[Type]
  FROM [SourceData].[dbo].[vx_FA_instrument]
union all
SELECT 'holding' as entitytype,
	   [insid]
      ,[prfid]
	  ,NULL as fxid
	   ,NULL as [tradeid]
      ,[source_file]
      ,[source_date]
	  ,NULL as COUPON
      ,[CURRENCY]
      ,NULL as [DLAMAssetClass1]
      ,NULL as [DLAMAssetClass2]
      ,NULL as [DLAMAssetClass3]
      ,NULL as [DLAMAssetClass4]
      ,NULL as [DLAMSector1]
      ,NULL as [DLAMSector2]
      ,NULL as [DLAMSector3]
      ,NULL as [DLAMSector4]
      ,NULL as [DLAMRating]
      ,NULL as [Expiration]
      ,[FXRATE]
      ,[IDENTIFIER]
      ,NULL as [ISSUE_DATE]
      ,[MARKET_VALUE]
      ,[MATURITY]
      ,[NOMINAL_VALUE]
      ,[PORTFOLIO_NAME]
      ,[PRICE]
      ,[proddat]
	  ,NULL as [STRIKE]
	  ,NULL as [Type]
  FROM [SourceData].[dbo].[vx_FA_holding]
union all
SELECT 'portfolio' as entitytype
	  ,NULL as [insid]
	  ,[prfid]
	  ,NULL as fxid
	   ,NULL as [tradeid]
      ,[source_file]
      ,[source_date]
	  ,NULL as COUPON
      ,NULL as [CURRENCY]
      ,NULL as [DLAMAssetClass1]
      ,NULL as [DLAMAssetClass2]
      ,NULL as [DLAMAssetClass3]
      ,NULL as [DLAMAssetClass4]
      ,NULL as [DLAMSector1]
      ,NULL as [DLAMSector2]
      ,NULL as [DLAMSector3]
      ,NULL as [DLAMSector4]
      ,NULL as [DLAMRating]
      ,NULL as [Expiration]
      ,NULL as [FXRATE]
      ,NULL as [IDENTIFIER]
      ,NULL as [ISSUE_DATE]
      ,NULL as [MARKET_VALUE]
      ,NULL as [MATURITY]
      ,NULL as [NOMINAL_VALUE]
      ,[PORTFOLIO_NAME]
      ,NULL as [PRICE]
      ,[proddat]
	  ,NULL as STRIKE
	  ,NULL as Type
  FROM [SourceData].[dbo].[vx_FA_portfolio]
union ALL
SELECT 'currency' as entitytype
	   ,NULL as [insid]
	   ,NULL as [prfid]
	   ,[fxid]
	   ,NULL as [tradeid]
      ,[source_file]
      ,[source_date]
	  ,NULL as COUPON
      ,[CURRENCY]
      ,NULL as [DLAMAssetClass1]
      ,NULL as [DLAMAssetClass2]
      ,NULL as [DLAMAssetClass3]
      ,NULL as [DLAMAssetClass4]
      ,NULL as [DLAMSector1]
      ,NULL as [DLAMSector2]
      ,NULL as [DLAMSector3]
      ,NULL as [DLAMSector4]
      ,NULL as [DLAMRating]
      ,NULL as [Expiration]
      ,[FXRATE]
      ,NULL as [IDENTIFIER]
      ,NULL as [ISSUE_DATE]
      ,NULL as [MARKET_VALUE]
      ,NULL as [MATURITY]
      ,NULL as [NOMINAL_VALUE]
      ,NULL as [PORTFOLIO_NAME]
      ,NULL as [PRICE]
      ,[proddat]
	  ,NULL as STRIKE
	  ,NULL as [Type]
  FROM [SourceData].[dbo].[vx_FA_currency] 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_FA_instrument_twice 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_FA_instrument_twice as
select
	exports_and_database.*,
	dbdata.instype_desc as db_instype_desc
from (
		select
			InstrumentName as insid,
			source_file,
			source_date,
			RecFixedRate as COUPON,
			Currency as CURRENCY,
			DLAMAssetClass1,
			DLAMAssetClass2,
			DLAMAssetClass3,
			DLAMAssetClass4,
			DLAMSector1,
			DLAMSector2,
			DLAMSector3,
			DLAMSector4,
			DLAMRating,
			NULL as Expiration,
			InstrumentName as IDENTIFIER,
			StartDate as [ISSUE_DATE],
			MaturityDate as MATURITY,
			NULL as STRIKE
			, SUM(POS) AS TOTAL_Quantity
			, SUM([None]) as TOTAL_NOMINAL_VALUE
		from FA_loan
		group by
			InstrumentName,
			source_file,
			source_date,
			RecFixedRate,
			Currency,
			DLAMAssetClass1,
			DLAMAssetClass2,
			DLAMAssetClass3,
			DLAMAssetClass4,
			DLAMSector1,
			DLAMSector2,
			DLAMSector3,
			DLAMSector4,
			DLAMRating,
			InstrumentName,
			StartDate,
			MaturityDate
	union all
		select
			InstrumentName as insid,
			source_file,
			source_date,
			Coupon as COUPON,
			Currency as CURRENCY,
			DLAMAssetClass1,
			DLAMAssetClass2,
			DLAMAssetClass3,
			DLAMAssetClass4,
			DLAMSector1,
			DLAMSector2,
			DLAMSector3,
			DLAMSector4,
			DLAMRating,
			Expiry as Expiration,
			InstrumentName as IDENTIFIER,
			StartDate as [ISSUE_DATE],
			MaturityDate as MATURITY,
			Strike as STRIKE,
			SUM(OutstandingNominalEnd) AS TOTAL_Quantity,
			SUM(OutstandingNominalEnd) as TOTAL_NOMINAL_VALUE
		from
			(select
				FA_deriv.*, CallorPut
			from FA_deriv left join FA_derivreport
				on FA_deriv.InstrumentName = FA_derivreport.Instrument
				and FA_deriv.PortfolioName = FA_derivreport.Portfolio
			) as derivatives
		group by
			InstrumentName,
			source_file,
			source_date,
			Coupon,
			Currency,
			DLAMAssetClass1,
			DLAMAssetClass2,
			DLAMAssetClass3,
			DLAMAssetClass4,
			DLAMSector1,
			DLAMSector2,
			DLAMSector3,
			DLAMSector4,
			DLAMRating,
			Expiry,
			InstrumentName,
			StartDate,
			MaturityDate,
			Strike
	union all
	select distinct
			IA.insid collate SQL_Latin1_General_CP1_CI_AS,
			'FrontArenaDb' as source_file,
			NULL as source_date,
			fixed_rate as COUPON,
			currency_desc collate SQL_Latin1_General_CP1_CI_AS as CURRENCY ,
			isnull(DLAMAssetClass1,'-') collate SQL_Latin1_General_CP1_CI_AS,
			isnull(DLAMAssetClass2,'-') collate SQL_Latin1_General_CP1_CI_AS,
			isnull(DLAMAssetClass3,'-') collate SQL_Latin1_General_CP1_CI_AS,
			isnull(DLAMAssetClass4,'-') collate SQL_Latin1_General_CP1_CI_AS,
			isnull(DLAMSector1,'-') collate SQL_Latin1_General_CP1_CI_AS,
			isnull(DLAMSector2,'-') collate SQL_Latin1_General_CP1_CI_AS,
			isnull(DLAMSector3,'-') collate SQL_Latin1_General_CP1_CI_AS,
			isnull(DLAMSector4,'-') collate SQL_Latin1_General_CP1_CI_AS,
			DLAMRating collate SQL_Latin1_General_CP1_CI_AS,
			case when DLAMAssetClass2 = 'Bond'
				then NULL
				else exp_day
				end as Expiration,
			IA.insid collate SQL_Latin1_General_CP1_CI_AS as IDENTIFIER,
			leg_date.issue_day as [ISSUE_DATE],
			case when DLAMAssetClass2 = 'Bond'
				then exp_day
				else NULL
				end as MATURITY,
			case when strike_price != 0
				then strike_price
				else NULL
				end as STRIKE
			, TOTAL_QUANTITY
			, TOTAL_NOMINAL_VALUE
		from AM_AdsP.dbo.INSTRUMENT_ADDITIONAL IA
		left join (select insaddr, min(start_day) as issue_day from AM_AdsP.dbo.LEG_ADDITIONAL group by insaddr) as leg_date
		on IA.insaddr = leg_date.insaddr
		left join (select insid, SUM(position) as TOTAL_QUANTITY, SUM(position) as TOTAL_NOMINAL_VALUE FROM [AM_AdsP].[dbo].INSTRUMENT_POSITION group by insid) as total_holding
		on IA.insid = total_holding.insid
		LEFT JOIN AM_AdsP.dbo.LEG_ADDITIONAL LA
		ON IA.insaddr = LA.insaddr AND LA.fixed_rate IS NOT NULL
		where in_scope = 1
) as exports_and_database
left join
	AM_AdsP.dbo.INSTRUMENT_ADDITIONAL as dbdata
	on dbdata.in_scope=1
	and dbdata.insid = exports_and_database.insid collate SQL_Latin1_General_CP1_CI_AS 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_FA_holding_twice 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_FA_holding_twice as
select
	exports.*,
	dbdata.position as db_position
from (
		select
			InstrumentName as insid,
			PortfolioName as prfid,
			source_file,
			source_date,
			POS AS Quantity,
			Currency as CURRENCY,
			InstrumentName as IDENTIFIER,
			[None] as NOMINAL_VALUE,
			PortfolioName as [PORTFOLIO_NAME]
		from FA_loan
	union all
		select
			InstrumentName as insid,
			PortfolioName as prfid,
			source_file,
			source_date,
			OutstandingNominalEnd AS Quantity,
			Currency as CURRENCY,
			InstrumentName as IDENTIFIER,
			OutstandingNominalEnd as NOMINAL_VALUE,
			PortfolioName as [PORTFOLIO_NAME]
		from FA_deriv
	union all
		select
			insid collate SQL_Latin1_General_CP1_CI_AS,
			prfid collate SQL_Latin1_General_CP1_CI_AS,
			'FrontArenaDb' as source_file,
			NULL as source_date,
			position as QUANTITY,
			currency_desc collate SQL_Latin1_General_CP1_CI_AS as CURRENCY,
			insid collate SQL_Latin1_General_CP1_CI_AS as IDENTIFIER,
			position as NOMINAL_VALUE,
			prfid collate SQL_Latin1_General_CP1_CI_AS as PORTFOLIO_NAME
		from (select INSTRUMENT_POSITION.*,
				INSTRUMENT_ADDITIONAL.currency_desc
			from [AM_AdsP].[dbo].INSTRUMENT_POSITION left join [AM_AdsP].dbo.INSTRUMENT_ADDITIONAL
			on INSTRUMENT_POSITION.insaddr = INSTRUMENT_ADDITIONAL.insaddr
			where INSTRUMENT_POSITION.in_scope = 1) as dbholding
) as exports
left join
	AM_AdsP.dbo.INSTRUMENT_POSITION as dbdata
	on dbdata.in_scope=1
	and dbdata.insid = exports.insid collate SQL_Latin1_General_CP1_CI_AS
	and (dbdata.prfid = exports.prfid collate SQL_Latin1_General_CP1_CI_AS or (dbdata.prfid is null and exports.prfid is null)) 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_FA_portfolio_twice 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_FA_portfolio_twice as
select
	exports.*,
	dbdata.portfolio_assinf as db_assinf
from (
		select distinct
			PortfolioName as prfid,
			source_file,
			source_date,
			PortfolioName as [PORTFOLIO_NAME]
		from FA_loan
	union all
		select distinct
			PortfolioName as prfid,
			source_file,
			source_date,
			PortfolioName as [PORTFOLIO_NAME]
		from FA_deriv
	union all
		select distinct
			portfolio_prfid collate SQL_Latin1_General_CP1_CI_AS as prfid,
			'FrontArenaDb' as source_file,
			NULL as source_date,
			portfolio_prfid collate SQL_Latin1_General_CP1_CI_AS as [PORTFOLIO_NAME]
		from AM_AdsP.dbo.PORTFOLIO_ADDITIONAL
) as exports
left join
	AM_AdsP.dbo.PORTFOLIO_ADDITIONAL as dbdata
	on dbdata.portfolio_prfid = exports.prfid collate SQL_Latin1_General_CP1_CI_AS 
```






