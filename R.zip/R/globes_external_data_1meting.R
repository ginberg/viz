#Reads data from locations not managed by git
source("R/config.R")
source("R/source.reat.R")

destination_connect <- function(){db.connect(sourcedata_connection)}

globespath <- function(filename){
  return(file.path(dlam_data_path, "globe$_exports", filename))
}

frmpath <- function(filename){
  return(file.path(dlam_data_path, "FRM_Exports", filename))
}

portiapath <- function(...){
  return(file.path(dlam_data_path, "portia_exports", do.call(file.path, list(...))))
}

# Created by running the fxpms.sql query on the globe$ database in the oracle environment of DeltaLloyd
gl_fxpms<-list(
			destination=destination_connect,
			name="GL_fxpms",
			 origin = globespath("FX-PMS 13-08.csv"),
			 #origin = globespath("oracle_export_FX-PMS.csv"),
			 read=function(x) read.csv2(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			  typechanges=list(
				list(trynumeric=T, Date.format="%d-%m-%Y", col.ignore=c("ACCOUNT_NO","ACCOUNT_NO_1"))
			  ),
			constants = list(source_date = as.Date("2015-08-13"))
)

# Transactions exported from the bloomberg interface
gl_fxbloomberg <- list(
			destination=destination_connect,
			name="GL_fxbloomberg",
			 origin = globespath("fxhb_DLTR_0_20150814_143315.csv"),
			 read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			  typechanges=list( # list of all transformations in order 
				list(trynumeric=T),
				list(POSIXct.format="%m/%d/%Y %H:%M"),
				list(Date.format="%m/%d/%Y")),
			constants = list(source_date = as.Date("2015-08-13"))
)

# Received the RISK  FORWARDS.xls from treasury, exported the sheet 'openstaande fx deals' to a csv file
gl_xls_fxpms <- list(
			destination=destination_connect,
			name="GL_xls_fxpms",
			 origin = globespath("RISK  FORWARDS  2015-12-07_openstaande fxdeals.csv"),
			 read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			  typechanges=list( # list of all transformations in order 
			list(POSIXct.call=list(format="%d-%m-%Y %H:%M:%S"))
			),
			constants = list(source_date = as.Date("2015-08-13"))
)

# Received the RISK  FORWARDS.xls from treasury, exported the sheet forwards' to a csv file
gl_xls_riskforwards <- list(
			destination=destination_connect,
			name="GL_xls_riskforwards",
			 origin = globespath("RISK  FORWARDS  2015-12-07_forwards.csv"),
			 read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			  typechanges=list( # list of all transformations in order 
    			list(POSIXct.format="%d-%m-%Y %H:%M:%S")
			),
			constants = list(source_date = as.Date("2015-08-13"))
)

# Received the RISK  FORWARDS.xls from treasury, exported the sheet 'globescode_to_portia' to a csv file
gl_xls_rf_globescode_to_portia  <- list(
			destination=destination_connect,
			name="GL_xls_rf_globescode_to_portia",
			 origin = globespath("RISK  FORWARDS  2015-12-07_globescode_to_portia.csv"),
			 read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			  typechanges=list( # list of all transformations in order 
			),
										row.names=T,
			constants = list(source_date = as.Date("2015-08-13"))
)

# Received the RISK  FORWARDS.xls from treasury, exported the table  'portfolio_to_typegeld' to a csv file
gl_xls_rf_portfolio_to_typegeld  <- list(
			destination=destination_connect,
			name="GL_xls_rf_portfolio_to_geld",
			 origin = globespath("RISK  FORWARDS  2015-12-07_portfolio_to_typegeld.csv"),
			 read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			  typechanges=list( # list of all transformations in order 
			),
			constants = list(source_date = as.Date("2015-08-13"))
)

# Received the Limieten gesplitst naar Eigen Geld.xls from treasury, exported the sheet 'verzamelrisk' to a csv file
gl_xls_cashrisk  <- list(
			destination=destination_connect,
			name="GL_xls_cashrisk",
			 origin = globespath("Limieten gesplitst naar Eigen Geld 2015-12-07_verzamelrisk.csv"),
			 read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			  typechanges=list( # list of all transformations in order 
						list(trynumeric=T,
                             Date.format="%d-%m-%y")
			),
		  cols.keep=c("DL Asset Type 3"),
			constants = list(source_date = as.Date("2015-08-13"))
)


#--------- Portia FX dumps

# For one currency, the closing rate of many days
gl_fx_gbp <- list(
			destination=destination_connect,
  name = "PO_fx_gbp",
  origin = globespath("hfx-investrant GBP.csv"),
  read = function(x) read.csv(x, skip=2, col.names=c("closing","fxrate"), header=F),
  list(typechanges=list(list(trynumeric=T,
                             Date.format="%d/%m/%Y"))),
			constants = list(source_date = as.Date("2015-03-05"))
)

# For one currency, the closing rate of many days
gl_fx_usd <- list(
			destination=destination_connect,
	name = "PO_fx_usd",
	origin = globespath("hfx-investrant USD.csv"),
	read = function(x) read.csv( x, skip=2, col.names=c("closing","fxrate"), header=F),
	list(typechanges=list(list(trynumeric=T,
                             Date.format="%d/%m/%Y"))),
			constants = list(source_date = as.Date("2015-03-05"))
)

# For one date, the closing rate of many currencies
gl_fxs <- list(
			destination=destination_connect,
    name="GL_exchangerates",
    origin = globespath("FX_02_febr_2015.prn"),
    read = function(x) read.csv(x, 
           skip=1,
           na.strings=c(''),
           header=T),
   typechanges=list(
					list(trynumeric=T, Date.format="%d/%m/%y")
					),
  filter=list(
    list(col.name=c(),
         value=NA,
         type="is.na",
         keep=F)
  ),
			constants = list(source_date = as.Date("2015-02-02"))
)
