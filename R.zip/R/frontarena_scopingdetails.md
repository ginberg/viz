---
title: "Front Arena Scope details"
output: html_document
---









# Front Arena Solvency 2 related Data Element validation






<!-------------------------------------------------------------->

##  Front Arena Loans  ( FA_LosHist )

The following data alements are used for specific FRM data elements (Data elements).  
```r
        Data.element         FA_LosHist
1   ACCRUED_INTEREST AccruedInterestEnd
12         CONVEXITY        ConvexityFI
14           COUNTRY      CountryofRisk
16            COUPON       RecFixedRate
21          CURRENCY           Currency
24 DLAM.Asset.Type.1    DLAMAssetClass1
25 DLAM.Asset.Type.2    DLAMAssetClass2
26 DLAM.Asset.Type.3    DLAMAssetClass3
27 DLAM.Asset.Type.4    DLAMAssetClass4
28       DLAM.RATING         DLAMRating
29      DLAM.Sector1        DLAMSector1
30      DLAM.Sector2        DLAMSector2
31      DLAM.Sector3        DLAMSector3
32      DLAM.Sector4        DLAMSector4
36          DURATION ModifiedDurationFI
43            FXRATE             DispFx
45        IDENTIFIER     InstrumentName
50            ISSUER             Issuer
53      MARKET_VALUE             ValEnd
54          MATURITY       MaturityDate
56     NOMINAL_VALUE               None
61    PORTFOLIO_NAME      PortfolioName
64             PRICE              Price
65           proddat            proddat
70    REPORTING_DATE               Date
89             YIELD            YieldFI
```

This results in the following related risks:  
```r
      Data.element      FA_LosHist Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk in.export
            COUPON    RecFixedRate           0                 1             0           0     FALSE
          CURRENCY        Currency           1                 1             1           0     FALSE
 DLAM.Asset.Type.2 DLAMAssetClass2           0                 0             0           1     FALSE
 DLAM.Asset.Type.3 DLAMAssetClass3           1                 1             1           1     FALSE
       DLAM.RATING      DLAMRating           0                 1             1           0     FALSE
      DLAM.Sector1     DLAMSector1           0                 1             0           1     FALSE
      DLAM.Sector2     DLAMSector2           0                 0             0           1     FALSE
      DLAM.Sector3     DLAMSector3           0                 1             0           0     FALSE
            FXRATE          DispFx           1                 0             0           0     FALSE
        IDENTIFIER  InstrumentName           1                 1             0           1     FALSE
      MARKET_VALUE          ValEnd           0                 1             1           0     FALSE
          MATURITY    MaturityDate           0                 1             0           0     FALSE
     NOMINAL_VALUE            None           1                 1             1           1     FALSE
    PORTFOLIO_NAME   PortfolioName           1                 1             0           1     FALSE
             PRICE           Price           1                 1             0           0     FALSE
           proddat         proddat           1                 0             1           1     FALSE
```

There are  16  data elements in  Front Arena Loans  ( FA_LosHist ) that relate to at least one risk.  

For all columns the risks, if available:  
```r
                    FA_LosHist in.export      Data.element Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk
            AccruedInterestEnd      TRUE              <NA>          NA                NA            NA          NA
                   Cedar_BU_Nr      TRUE              <NA>          NA                NA            NA          NA
                   ConvexityFI      TRUE              <NA>          NA                NA            NA          NA
                      Currency      TRUE          CURRENCY           1                 1             1           0
                          Date      TRUE              <NA>          NA                NA            NA          NA
                     Date_orig      TRUE              <NA>          NA                NA            NA          NA
                        DispFx      TRUE            FXRATE           1                 0             0           0
               DLAMAssetClass1      TRUE              <NA>          NA                NA            NA          NA
               DLAMAssetClass2      TRUE DLAM.Asset.Type.2           0                 0             0           1
               DLAMAssetClass3      TRUE DLAM.Asset.Type.3           1                 1             1           1
               DLAMAssetClass4      TRUE              <NA>          NA                NA            NA          NA
                    DLAMRating      TRUE       DLAM.RATING           0                 1             1           0
                   DLAMSector1      TRUE      DLAM.Sector1           0                 1             0           1
                   DLAMSector2      TRUE      DLAM.Sector2           0                 0             0           1
                   DLAMSector3      TRUE      DLAM.Sector3           0                 1             0           0
                   DLAMSector4      TRUE              <NA>          NA                NA            NA          NA
                   FaceNominal      TRUE              <NA>          NA                NA            NA          NA
                FairValueLevel      TRUE              <NA>          NA                NA            NA          NA
                      IDCodeS2      TRUE              <NA>          NA                NA            NA          NA
                IdentifierType      TRUE              <NA>          NA                NA            NA          NA
                InstrumentName      TRUE        IDENTIFIER           1                 1             0           1
         InstrumentName_Coupon      TRUE              <NA>          NA                NA            NA          NA
 InstrumentName_Coupon_Rounded      TRUE              <NA>          NA                NA            NA          NA
      InstrumentName_CouponNum      TRUE              <NA>          NA                NA            NA          NA
                  MaturityDate      TRUE          MATURITY           0                 1             0           0
             MaturityDate_orig      TRUE              <NA>          NA                NA            NA          NA
            ModifiedDurationFI      TRUE              <NA>          NA                NA            NA          NA
                          None      TRUE     NOMINAL_VALUE           1                 1             1           1
                         PLPos      TRUE              <NA>          NA                NA            NA          NA
                 PortfolioName      TRUE    PORTFOLIO_NAME           1                 1             0           1
                           Pos      TRUE              <NA>          NA                NA            NA          NA
                         Price      TRUE             PRICE           1                 1             0           0
                  RecFixedRate      TRUE            COUPON           0                 1             0           0
                   source_date      TRUE              <NA>          NA                NA            NA          NA
                   source_file      TRUE              <NA>          NA                NA            NA          NA
                     StartDate      TRUE              <NA>          NA                NA            NA          NA
                StartDate_orig      TRUE              <NA>          NA                NA            NA          NA
                        ValEnd      TRUE      MARKET_VALUE           0                 1             1           0
                       YieldFI      TRUE              <NA>          NA                NA            NA          NA
```

Related solvency II descriptions:  
```r
 Number      Data.element
    DE3            COUPON
    DE4          CURRENCY
    DE5 DLAM.Asset.Type.2
    DE6 DLAM.Asset.Type.3
    DE7       DLAM.RATING
    DE8      DLAM.Sector1
    DE9      DLAM.Sector2
   DE10      DLAM.Sector3
   DE12            FXRATE
   DE13        IDENTIFIER
   DE15      MARKET_VALUE
   DE16          MATURITY
   DE17     NOMINAL_VALUE
   DE20    PORTFOLIO_NAME
   DE21             PRICE
   DE22           proddat
                                                                                           Description  Export.element
                                                                   Current coupon rate of Security (%)  Rec.Fixed.Rate
                                                      The currency of the security (ISO Currency Code)        Currency
                    State the asset type of the security (see Appendix E for Asset Tree specification) DLAMAssetClass2
                    State the asset type of the security (see Appendix E for Asset Tree specification) DLAMAssetClass3
                                                                                DLAM Composite rating      DLAM.Rating
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)   DLAM.Sector.1
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)   DLAM.Sector.2
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)   DLAM.Sector.3
                                 The Conversion Rate EUR/Original Currency at T where T is Report Date          DispFx
                                                                              The ISIN of the security Instrument.Name
          The market value of the securities in EUR (including Accrued Interest),Cash Balance for Cash         Val.End
                                                                    Date of expiration of the Security   Maturity.Date
 Nominal value of the Security excluding redemption/amortization, balance for Cash (original currency)            None
                                                                                 Name of the portfolio  Portfolio.Name
                 Close market price of the security at T where T is reporting date (original currency)           Price
                                                                                Run date of the export         proddat
```


<!-------------------------------------------------------------->

##  Front Arena Derivatives  ( FA_DerivativesHist )

The following data alements are used for specific FRM data elements (Data elements).  
```r
        Data.element FA_DerivativesHist
1   ACCRUED_INTEREST            AccSubL
3                BPV                BPV
12         CONVEXITY          Convexity
14           COUNTRY      CountryofRisk
16            COUPON             Coupon
21          CURRENCY           Currency
24 DLAM.Asset.Type.1    DLAMAssetClass1
25 DLAM.Asset.Type.2    DLAMAssetClass2
26 DLAM.Asset.Type.3    DLAMAssetClass3
27 DLAM.Asset.Type.4    DLAMAssetClass4
28       DLAM.RATING         DLAMRating
29      DLAM.Sector1        DLAMSector1
30      DLAM.Sector2        DLAMSector2
31      DLAM.Sector3        DLAMSector3
32      DLAM.Sector4        DLAMSector4
36          DURATION   ModifiedDuration
39        EXPIRATION             Expiry
43            FXRATE             DispFx
45        IDENTIFIER     InstrumentName
49        ISSUE_DATE          StartDate
50            ISSUER             Issuer
53      MARKET_VALUE          ValEndEUR
54          MATURITY       MaturityDate
56     NOMINAL_VALUE         NominalEUR
61    PORTFOLIO_NAME      PortfolioName
64             PRICE              Price
65           proddat            proddat
70    REPORTING_DATE               Date
78            STRIKE             Strike
82              Type               Type
```

This results in the following related risks:  
```r
      Data.element FA_DerivativesHist Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk in.export
            COUPON             Coupon           0                 1             0           0     FALSE
          CURRENCY           Currency           1                 1             1           0     FALSE
 DLAM.Asset.Type.2    DLAMAssetClass2           0                 0             0           1     FALSE
 DLAM.Asset.Type.3    DLAMAssetClass3           1                 1             1           1     FALSE
       DLAM.RATING         DLAMRating           0                 1             1           0     FALSE
      DLAM.Sector1        DLAMSector1           0                 1             0           1     FALSE
      DLAM.Sector2        DLAMSector2           0                 0             0           1     FALSE
      DLAM.Sector3        DLAMSector3           0                 1             0           0     FALSE
        EXPIRATION             Expiry           1                 1             0           0     FALSE
            FXRATE             DispFx           1                 0             0           0     FALSE
        IDENTIFIER     InstrumentName           1                 1             0           1     FALSE
        ISSUE_DATE          StartDate           0                 1             0           0     FALSE
      MARKET_VALUE          ValEndEUR           0                 1             1           0     FALSE
          MATURITY       MaturityDate           0                 1             0           0     FALSE
     NOMINAL_VALUE         NominalEUR           1                 1             1           1     FALSE
    PORTFOLIO_NAME      PortfolioName           1                 1             0           1     FALSE
             PRICE              Price           1                 1             0           0     FALSE
           proddat            proddat           1                 0             1           1     FALSE
            STRIKE             Strike           1                 1             0           0     FALSE
              Type               Type           0                 1             0           0     FALSE
```

There are  20  data elements in  Front Arena Derivatives  ( FA_DerivativesHist ) that relate to at least one risk.  

For all columns the risks, if available:  
```r
            FA_DerivativesHist in.export      Data.element Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk
                       AccSubL      TRUE              <NA>          NA                NA            NA          NA
                           BPV      TRUE              <NA>          NA                NA            NA          NA
                 CountryofRisk      TRUE              <NA>          NA                NA            NA          NA
                        Coupon      TRUE            COUPON           0                 1             0           0
                      Currency      TRUE          CURRENCY           1                 1             1           0
                          Date      TRUE              <NA>          NA                NA            NA          NA
                     Date_orig      TRUE              <NA>          NA                NA            NA          NA
                        DispFx      TRUE            FXRATE           1                 0             0           0
               DLAMAssetClass1      TRUE              <NA>          NA                NA            NA          NA
               DLAMAssetClass2      TRUE DLAM.Asset.Type.2           0                 0             0           1
               DLAMAssetClass3      TRUE DLAM.Asset.Type.3           1                 1             1           1
               DLAMAssetClass4      TRUE              <NA>          NA                NA            NA          NA
                    DLAMRating      TRUE       DLAM.RATING           0                 1             1           0
                   DLAMSector1      TRUE      DLAM.Sector1           0                 1             0           1
                   DLAMSector2      TRUE      DLAM.Sector2           0                 0             0           1
                   DLAMSector3      TRUE      DLAM.Sector3           0                 1             0           0
                   DLAMSector4      TRUE              <NA>          NA                NA            NA          NA
                        Expiry      TRUE        EXPIRATION           1                 1             0           0
                   Expiry_orig      TRUE              <NA>          NA                NA            NA          NA
                InstrumentName      TRUE        IDENTIFIER           1                 1             0           1
         InstrumentName_Coupon      TRUE              <NA>          NA                NA            NA          NA
 InstrumentName_Coupon_Rounded      TRUE              <NA>          NA                NA            NA          NA
      InstrumentName_CouponNum      TRUE              <NA>          NA                NA            NA          NA
                        Issuer      TRUE              <NA>          NA                NA            NA          NA
                  MaturityDate      TRUE          MATURITY           0                 1             0           0
             MaturityDate_orig      TRUE              <NA>          NA                NA            NA          NA
              ModifiedDuration      TRUE              <NA>          NA                NA            NA          NA
         OutstandingNominalEnd      TRUE              <NA>          NA                NA            NA          NA
                  PayFixedRate      TRUE              <NA>          NA                NA            NA          NA
                 PortfolioName      TRUE    PORTFOLIO_NAME           1                 1             0           1
                         Price      TRUE             PRICE           1                 1             0           0
                  RecFixedRate      TRUE              <NA>          NA                NA            NA          NA
                   source_date      TRUE              <NA>          NA                NA            NA          NA
                   source_file      TRUE              <NA>          NA                NA            NA          NA
                     StartDate      TRUE        ISSUE_DATE           0                 1             0           0
              StartDate_failed      TRUE              <NA>          NA                NA            NA          NA
                StartDate_orig      TRUE              <NA>          NA                NA            NA          NA
                        Strike      TRUE            STRIKE           1                 1             0           0
                     ValEndEUR      TRUE      MARKET_VALUE           0                 1             1           0
```

Related solvency II descriptions:  
```r
 Number      Data.element
    DE3            COUPON
    DE4          CURRENCY
    DE5 DLAM.Asset.Type.2
    DE6 DLAM.Asset.Type.3
    DE7       DLAM.RATING
    DE8      DLAM.Sector1
    DE9      DLAM.Sector2
   DE10      DLAM.Sector3
   DE11        EXPIRATION
   DE12            FXRATE
   DE13        IDENTIFIER
   DE14        ISSUE_DATE
   DE15      MARKET_VALUE
   DE16          MATURITY
   DE17     NOMINAL_VALUE
   DE20    PORTFOLIO_NAME
   DE21             PRICE
   DE22           proddat
   DE25            STRIKE
   DE27              Type
                                                                                           Description  Export.element
                                                                   Current coupon rate of Security (%)          Coupon
                                                      The currency of the security (ISO Currency Code)        Currency
                    State the asset type of the security (see Appendix E for Asset Tree specification) DLAMAssetClass2
                    State the asset type of the security (see Appendix E for Asset Tree specification) DLAMAssetClass3
                                                                                DLAM Composite rating      DLAM.Rating
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)   DLAM.Sector.1
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)   DLAM.Sector.2
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)   DLAM.Sector.3
                                             The last day that an options or futures contract is valid          Expiry
                                 The Conversion Rate EUR/Original Currency at T where T is Report Date          DispFx
                                                                              The ISIN of the security Instrument.Name
                                                                    Date on which a security is issued       StartDate
          The market value of the securities in EUR (including Accrued Interest),Cash Balance for Cash   Val.End..EUR.
                                                                    Date of expiration of the Security   Maturity.Date
 Nominal value of the Security excluding redemption/amortization, balance for Cash (original currency)    Nominal.EUR.
                                                                                 Name of the portfolio  Portfolio.Name
                 Close market price of the security at T where T is reporting date (original currency)           Price
                                                                                Run date of the export         proddat
                                    The price at which a specific derivative contract can be exercised          Strike
                                                                                               unknown            Type
```


<!-------------------------------------------------------------->
##  Front Arena   ( database )

The following data alements are used for specific FRM data elements (Data elements).  
```r
        Data.element  Export.element
1             COUPON       coup_rate
2           CURRENCY      curr_insid
3  DLAM.Asset.Type.2 DLAMAssetClass2
4  DLAM.Asset.Type.3 DLAMAssetClass3
5        DLAM.RATING      DLAMRating
6       DLAM.Sector1     DLAMSector1
7       DLAM.Sector2     DLAMSector2
8       DLAM.Sector3     DLAMSector3
9         EXPIRATION         exp_day
10            FXRATE          FXRate
11        IDENTIFIER           insid
12        ISSUE_DATE       issue_day
13      MARKET_VALUE    MARKET_VALUE
14          MATURITY        MATURITY
15     NOMINAL_VALUE   NOMINAL_VALUE
16    PORTFOLIO_NAME           prfid
17             PRICE           PRICE
18           proddat         proddat
19            STRIKE    strike_price
20              Type       CallOrPut
```

This results in the following related risks:  
```r
      Data.element  Export.element Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk
            COUPON       coup_rate           0                 1             0           0
          CURRENCY      curr_insid           1                 1             1           0
 DLAM.Asset.Type.2 DLAMAssetClass2           0                 0             0           1
 DLAM.Asset.Type.3 DLAMAssetClass3           1                 1             1           1
       DLAM.RATING      DLAMRating           0                 1             1           0
      DLAM.Sector1     DLAMSector1           0                 1             0           1
      DLAM.Sector2     DLAMSector2           0                 0             0           1
      DLAM.Sector3     DLAMSector3           0                 1             0           0
        EXPIRATION         exp_day           1                 1             0           0
            FXRATE          FXRate           1                 0             0           0
        IDENTIFIER           insid           1                 1             0           1
        ISSUE_DATE       issue_day           0                 1             0           0
      MARKET_VALUE    MARKET_VALUE           0                 1             1           0
          MATURITY        MATURITY           0                 1             0           0
     NOMINAL_VALUE   NOMINAL_VALUE           1                 1             1           1
    PORTFOLIO_NAME           prfid           1                 1             0           1
             PRICE           PRICE           1                 1             0           0
           proddat         proddat           1                 0             1           1
            STRIKE    strike_price           1                 1             0           0
              Type       CallOrPut           0                 1             0           0
```

There are  20  data elements in  Front Arena   ( database ) that relate to at least one risk.  

Related solvency II descriptions:  
```r
      Data.element  Export.element Number
            COUPON       coup_rate    DE3
          CURRENCY      curr_insid    DE4
 DLAM.Asset.Type.2 DLAMAssetClass2    DE5
 DLAM.Asset.Type.3 DLAMAssetClass3    DE6
       DLAM.RATING      DLAMRating    DE7
      DLAM.Sector1     DLAMSector1    DE8
      DLAM.Sector2     DLAMSector2    DE9
      DLAM.Sector3     DLAMSector3   DE10
        EXPIRATION         exp_day   DE11
            FXRATE          FXRate   DE12
        IDENTIFIER           insid   DE13
        ISSUE_DATE       issue_day   DE14
      MARKET_VALUE    MARKET_VALUE   DE15
          MATURITY        MATURITY   DE16
     NOMINAL_VALUE   NOMINAL_VALUE   DE17
    PORTFOLIO_NAME           prfid   DE20
             PRICE           PRICE   DE21
           proddat         proddat   DE22
            STRIKE    strike_price   DE25
              Type       CallOrPut   DE27
                                                                                           Description
                                                                   Current coupon rate of Security (%)
                                                      The currency of the security (ISO Currency Code)
                    State the asset type of the security (see Appendix E for Asset Tree specification)
                    State the asset type of the security (see Appendix E for Asset Tree specification)
                                                                                DLAM Composite rating 
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
                                             The last day that an options or futures contract is valid
                                 The Conversion Rate EUR/Original Currency at T where T is Report Date
                                                                              The ISIN of the security
                                                                    Date on which a security is issued
          The market value of the securities in EUR (including Accrued Interest),Cash Balance for Cash
                                                                    Date of expiration of the Security
 Nominal value of the Security excluding redemption/amortization, balance for Cash (original currency)
                                                                                 Name of the portfolio
                 Close market price of the security at T where T is reporting date (original currency)
                                                                                Run date of the export
                                    The price at which a specific derivative contract can be exercised
                                                                                               unknown
```
