source("R/config.R")
sourcedata_connect <- function(){db.connect(sourcedata_connection)}
quality_connect <- function(){db.connect(dataquality_connection)}

