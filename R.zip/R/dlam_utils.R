
# uses sql_file_path to create some views and or tables.
# in the dependency list, those views and tables will all depend on both the sql file, and the trasitive dependencies through the dependencies argument
sqlFileDeps <- function(dbhandle_create, sql_file_path, views=NULL, tables=NULL, dependencies=c(), dependency_list=list(), ...){
  prep_query_folder <- file.path("./", "output", "businessrules","preparationqueries")
  dir.create(prep_query_folder, showWarnings = F, recursive=T)
  file.copy(sql_file_path, file.path(prep_query_folder, basename(sql_file_path)), overwrite = T)
  sqlFile(dbhandle_create, sql_file_path, views, tables, ...)
  this_deps <- c(sql_file_path)
  for(other in dependencies)
	  this_deps <- c(this_deps, dependency_list[[other]])
  for(view in views)
    dependency_list[[view]] <- unique(c(this_deps, dependency_list[[view]]))
  for(view in tables)
    dependency_list[[tables]] <- unique(c(this_deps, dependency_list[[tables]]))
  return(dependency_list)
}

# ---------------  Some convenience functions to select relevant rows from frmmap and s2descriptions ----------------
# Given a list of exports, returns a boolean vector indicating which rows of frmmap are relevant
relevantrows <- function(exports){
  if(length(exports)>1){
    rowSums(!is.na(frmmap[,exports]))>0
  }else{
    !is.na(frmmap[,exports])
  }
}
# Given a list of exports, returns the list of [Data.element]s in scope
relevantelements <- function(exports){
  relevant_rows <- relevantrows(exports)
  unique(frmmap$Data.element[relevant_rows])
}
# Given a list of exports, returns the mapping of Data.element to Export.element for the provided exports
relevantmapping <- function(exports){
  relevant_rows <- relevantrows(exports)
  unique(frmmap[relevant_rows,c("Data.element",exports)])
}
# Given a list of exports, returns the part of frmmap (Data.element with risk flags) that relate to the [Data.element]s in scope
relevantrisks <- function(exports){
  relevant_elements <- relevantelements(exports)
  relevant_riskmap <- subset(risks_frm, Data.element%in%relevant_elements)
  unique(relevant_riskmap)
}
# Given a list of exports, returns the solvency 2 descriptions related to the [Data.element]s in scope
relevantdescriptions <- function(exports){
  relevant_elements <- relevantelements(exports)
  relevant_riskmap <- subset(s2Descriptions, Data.element%in%relevant_elements)
  unique(relevant_riskmap)
}


# ---------------  Specific pretty printable or directly usable dataframes, containing risk, data element and/or mapping descriptions ----------------
# Given a list of exports, returns a nice (printable) riskmapping containing a 
# 1 Data.element column, 
# 1 column per export holding the name of the column in the export
# 1 column per risk, with a flag indicating that the risk relates to that data/export element, "" (=empty string) is used to indicate no related risk
subriskmap <- function(exports){
  relevant_riskmap <- merge(relevantrisks(exports), relevantmapping(exports), by.x = "Data.element")
  relevant_riskmap <- relevant_riskmap[,c(exports,names(risks_frm))]
  for(export in exports)
    relevant_riskmap[is.na(relevant_riskmap[,export]),export]<-""
  relevant_riskmap
}
# Given a list of exports, returns a mapping dataframe containing
# 1 Data.element column,
# all columns of s2Descriptions, currently number, description, label,..
# 1 Export.element column holding the columnname in the export. If multiple exports are given, this does NOT result in multiple export columns, but duplicated rows with regard of the descriptions
subdescriptions <- function(exports){
  export_mapping <- melt(relevantmapping(exports), 
                         id.vars="Data.element", 
                         value.name = "Export.element", 
                         na.rm = T, variable.name = "Export")
  relevant_descriptions <- merge(export_mapping, relevantdescriptions(exports), by = "Data.element", all.y=T)
  unique(relevant_descriptions[,c(colnames(s2Descriptions), "Export.element")])
}
# -------------------------------

#functions to retrieve files
commonpath <- function(...){
  return(file.path(common_data_path, do.call(file.path, list(...))))
}

inputpath <- function(...){
  return(file.path(input_data_path, do.call(file.path, list(...))))
}

portiapath <- function(...){
  return(file.path(portia_data_path, do.call(file.path, list(...))))
}

fapath <- function(filename){
  return(file.path(fa_data_path, filename))
}

globespath <- function(filename){
  return(file.path(globes_data_path, filename))
}

vispath <- function(filename){
  return(file.path(vis_data_path, filename))
}

outputpath <- function(filename){
  return(file.path(output_path, filename))
}

datapath <- function(filename){
  return(file.path(data_path, filename))
}

#assert: evaluate an expression and stop with a custom error message if it fails
assert <- function(expr, error_msg){
  if (!expr)
    stop(error_msg, call. = FALSE)
}