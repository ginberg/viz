---
title: "Import business definitions"
output: html_document
---
Business definitions
====================================================




This report has been generated on 2016-04-26 16:01:44.






```
DEBUG [2016-04-26 16:01:44] Saving data to table dataelements
```

```
DEBUG [2016-04-26 16:01:44] Validate, rowcount for dataset dataelements, file: 47, table: 47
DEBUG [2016-04-26 16:01:44] Validate, columncount for dataset dataelements, file: 4, table: 4
DEBUG [2016-04-26 16:01:44] Validate, hashtotal for dataset dataelements, column Number, file: 1128, table: 1128
```


```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
IF object_id(N'InlineMin', N'FN') IS NOT NULL
DROP FUNCTION dbo.InlineMin 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create function [dbo].[InlineMin](@val1 int, @val2 int)
returns int
as
begin
if @val1 < @val2
return @val1
return isnull(@val2,@val1)
end 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
IF object_id(N'InlineMax', N'FN') IS NOT NULL
DROP FUNCTION dbo.InlineMax 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create function dbo.InlineMax(@val1 int, @val2 int)
returns int
as
begin
if @val1 > @val2
return @val1
return isnull(@val2,@val1)
end 
```

```
DEBUG [2016-04-26 16:01:45] Validate, rowcount for dataset PO_dataelements, file: 33, table: 33
DEBUG [2016-04-26 16:01:45] Validate, columncount for dataset PO_dataelements, file: 3, table: 3
DEBUG [2016-04-26 16:01:45] Validate, hashtotal for dataset PO_dataelements, column Number, file: 441, table: 441
```

```
DEBUG [2016-04-26 16:01:47] Validate, rowcount for dataset FA_dataelements, file: 40, table: 40
DEBUG [2016-04-26 16:01:47] Validate, columncount for dataset FA_dataelements, file: 3, table: 3
DEBUG [2016-04-26 16:01:47] Validate, hashtotal for dataset FA_dataelements, column Number, file: 532, table: 532
```

```
DEBUG [2016-04-26 16:01:47] Validate, rowcount for dataset GL_dataelements, file: 18, table: 18
DEBUG [2016-04-26 16:01:47] Validate, columncount for dataset GL_dataelements, file: 3, table: 3
DEBUG [2016-04-26 16:01:47] Validate, hashtotal for dataset GL_dataelements, column Number, file: 257, table: 257
```

```
DEBUG [2016-04-26 16:01:47] Validate, rowcount for dataset VIS_dataelements, file: 15, table: 15
DEBUG [2016-04-26 16:01:47] Validate, columncount for dataset VIS_dataelements, file: 3, table: 3
DEBUG [2016-04-26 16:01:47] Validate, hashtotal for dataset VIS_dataelements, column Number, file: 168, table: 168
```



DEBUG [2016-04-26 16:01:47] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/20151108 Clients.csv
Preprocessing data read from *20151108 Clients.csv*  

```
```
Final column names of original dataframe:  

```
[1] "CLIENTNAAM"
```
DEBUG [2016-04-26 16:01:47] Saving data to table valuerange_clients

```
DEBUG [2016-04-26 16:01:48] Validate, rowcount for dataset valuerange_clients_orig, file: 275, table: 275
DEBUG [2016-04-26 16:01:48] Validate, columncount for dataset valuerange_clients_orig, file: 1, table: 1
DEBUG [2016-04-26 16:01:48] Validate, hashtotal for dataset valuerange_clients_orig, column CLIENTNAAM, file: 3651, table: 3651
DEBUG [2016-04-26 16:01:48] Validate, rowcount for dataset valuerange_clients, file: 275, table: 275
DEBUG [2016-04-26 16:01:48] Validate, columncount for dataset valuerange_clients, file: 2, table: 2
DEBUG [2016-04-26 16:01:48] Validate, hashtotal for dataset valuerange_clients, column CLIENTNAAM, file: 3651, table: 3651

```

Saved processed file originating from  *20151108 Clients.csv* in the database as table named  **valuerange_clients**   


DEBUG [2016-04-26 16:01:48] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/dlam_asset_class_tree.csv
Preprocessing data read from *dlam_asset_class_tree.csv*  

```
```
Final column names of original dataframe:  

```
[1] "DLAMAssetClass1" "DLAMAssetClass2" "DLAMAssetClass3" "DLAMAssetClass4"
```
DEBUG [2016-04-26 16:01:48] Saving data to table valuerange_assetclass

```
DEBUG [2016-04-26 16:01:51] Validate, rowcount for dataset valuerange_assetclass_orig, file: 102, table: 102
DEBUG [2016-04-26 16:01:51] Validate, columncount for dataset valuerange_assetclass_orig, file: 4, table: 4
DEBUG [2016-04-26 16:01:51] Validate, hashtotal for dataset valuerange_assetclass_orig, column DLAMAssetClass1, file: 1018, table: 1018
DEBUG [2016-04-26 16:01:51] Validate, rowcount for dataset valuerange_assetclass, file: 102, table: 102
DEBUG [2016-04-26 16:01:51] Validate, columncount for dataset valuerange_assetclass, file: 6, table: 6
DEBUG [2016-04-26 16:01:51] Validate, hashtotal for dataset valuerange_assetclass, column DLAMAssetClass1, file: 1018, table: 1018

```

Saved processed file originating from  *dlam_asset_class_tree.csv* in the database as table named  **valuerange_assetclass**   

DEBUG [2016-04-26 16:01:51] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/dlam_sector_tree.csv
Preprocessing data read from *dlam_sector_tree.csv*  

```
```
Final column names of original dataframe:  

```
[1] "DLSector1" "DLSector2" "DLSector3" "DLSector4"
```
DEBUG [2016-04-26 16:01:51] Saving data to table valuerange_sector

```
DEBUG [2016-04-26 16:01:54] Validate, rowcount for dataset valuerange_sector_orig, file: 204, table: 204
DEBUG [2016-04-26 16:01:54] Validate, columncount for dataset valuerange_sector_orig, file: 4, table: 4
DEBUG [2016-04-26 16:01:54] Validate, hashtotal for dataset valuerange_sector_orig, column DLSector1, file: 2449, table: 2449
DEBUG [2016-04-26 16:01:54] Validate, rowcount for dataset valuerange_sector, file: 204, table: 204
DEBUG [2016-04-26 16:01:54] Validate, columncount for dataset valuerange_sector, file: 6, table: 6
DEBUG [2016-04-26 16:01:54] Validate, hashtotal for dataset valuerange_sector, column DLSector1, file: 2449, table: 2449

```

Saved processed file originating from  *dlam_sector_tree.csv* in the database as table named  **valuerange_sector**   

DEBUG [2016-04-26 16:01:54] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/ratingmap.csv
Preprocessing data read from *ratingmap.csv*  

```
```
Final column names of original dataframe:  

```
[1] "MoodyRatin"       "SPRating"         "FitchRatin"       "RatingLevel"      "DLAMRating"       "SIIRating"       
[7] "SolvencyIIRating" "RatingLabel"     
```
DEBUG [2016-04-26 16:01:54] Saving data to table map_ratings

```
DEBUG [2016-04-26 16:01:54] Validate, rowcount for dataset map_ratings_orig, file: 28, table: 28
DEBUG [2016-04-26 16:01:54] Validate, columncount for dataset map_ratings_orig, file: 8, table: 8
DEBUG [2016-04-26 16:01:54] Validate, hashtotal for dataset map_ratings_orig, column RatingLevel, file: 42, table: 42
DEBUG [2016-04-26 16:01:57] Validate, rowcount for dataset map_ratings, file: 28, table: 28
DEBUG [2016-04-26 16:01:57] Validate, columncount for dataset map_ratings, file: 10, table: 10
DEBUG [2016-04-26 16:01:57] Validate, hashtotal for dataset map_ratings, column RatingLevel, file: 42, table: 42

```

Saved processed file originating from  *ratingmap.csv* in the database as table named  **map_ratings**   


DEBUG [2016-04-26 16:01:57] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/mapping_wft_sector.csv
Preprocessing data read from *mapping_wft_sector.csv*  

```
```
Final column names of original dataframe:  

```
[1] "WFT"              "Sector2NoCountry"
```
DEBUG [2016-04-26 16:01:57] Saving data to table valuewhitelist_wft_sector

```
DEBUG [2016-04-26 16:01:59] Validate, rowcount for dataset valuewhitelist_wft_sector_orig, file: 23, table: 23
DEBUG [2016-04-26 16:01:59] Validate, columncount for dataset valuewhitelist_wft_sector_orig, file: 2, table: 2
DEBUG [2016-04-26 16:01:59] Validate, hashtotal for dataset valuewhitelist_wft_sector_orig, column WFT, file: 609, table: 609
DEBUG [2016-04-26 16:02:00] Validate, rowcount for dataset valuewhitelist_wft_sector, file: 23, table: 23
DEBUG [2016-04-26 16:02:00] Validate, columncount for dataset valuewhitelist_wft_sector, file: 3, table: 3
DEBUG [2016-04-26 16:02:00] Validate, hashtotal for dataset valuewhitelist_wft_sector, column WFT, file: 609, table: 609

```

Saved processed file originating from  *mapping_wft_sector.csv* in the database as table named  **valuewhitelist_wft_sector**   
DEBUG [2016-04-26 16:02:00] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/whitelist_industry_dlamsector3.csv
Preprocessing data read from *whitelist_industry_dlamsector3.csv*  

```
```
Final column names of original dataframe:  

```
[1] "INDUSTRY"    "DLAMSector3"
```
DEBUG [2016-04-26 16:02:00] Saving data to table valuewhitelist_industry_sector

```
DEBUG [2016-04-26 16:02:04] Validate, rowcount for dataset valuewhitelist_industry_sector_orig, file: 68, table: 68
DEBUG [2016-04-26 16:02:04] Validate, columncount for dataset valuewhitelist_industry_sector_orig, file: 2, table: 2
DEBUG [2016-04-26 16:02:04] Validate, hashtotal for dataset valuewhitelist_industry_sector_orig, column INDUSTRY, file: 1424, table: 1424
DEBUG [2016-04-26 16:02:04] Validate, rowcount for dataset valuewhitelist_industry_sector, file: 68, table: 68
DEBUG [2016-04-26 16:02:04] Validate, columncount for dataset valuewhitelist_industry_sector, file: 3, table: 3
DEBUG [2016-04-26 16:02:04] Validate, hashtotal for dataset valuewhitelist_industry_sector, column INDUSTRY, file: 1424, table: 1424

```

Saved processed file originating from  *whitelist_industry_dlamsector3.csv* in the database as table named  **valuewhitelist_industry_sector**   
DEBUG [2016-04-26 16:02:05] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/whitelist_dra_sector.csv
Preprocessing data read from *whitelist_dra_sector.csv*  

```
```
Final column names of original dataframe:  

```
[1] "DRA"              "Sector2NoCountry"
```
DEBUG [2016-04-26 16:02:05] Saving data to table valuewhitelist_dra_sector

```
DEBUG [2016-04-26 16:02:05] Validate, rowcount for dataset valuewhitelist_dra_sector_orig, file: 25, table: 25
DEBUG [2016-04-26 16:02:05] Validate, columncount for dataset valuewhitelist_dra_sector_orig, file: 2, table: 2
DEBUG [2016-04-26 16:02:05] Validate, hashtotal for dataset valuewhitelist_dra_sector_orig, column DRA, file: 626, table: 626
DEBUG [2016-04-26 16:02:05] Validate, rowcount for dataset valuewhitelist_dra_sector, file: 25, table: 25
DEBUG [2016-04-26 16:02:07] Validate, columncount for dataset valuewhitelist_dra_sector, file: 3, table: 3
DEBUG [2016-04-26 16:02:07] Validate, hashtotal for dataset valuewhitelist_dra_sector, column DRA, file: 626, table: 626

```

Saved processed file originating from  *whitelist_dra_sector.csv* in the database as table named  **valuewhitelist_dra_sector**   
DEBUG [2016-04-26 16:02:07] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/whitelist_gics1_dlamsector3.csv
Preprocessing data read from *whitelist_gics1_dlamsector3.csv*  

```
```
Final column names of original dataframe:  

```
[1] "GICS1"       "DLAMSector3"
```
DEBUG [2016-04-26 16:02:07] Saving data to table valuewhitelist_gics1_sector

```
DEBUG [2016-04-26 16:02:07] Validate, rowcount for dataset valuewhitelist_gics1_sector_orig, file: 15, table: 15
DEBUG [2016-04-26 16:02:07] Validate, columncount for dataset valuewhitelist_gics1_sector_orig, file: 2, table: 2
DEBUG [2016-04-26 16:02:07] Validate, hashtotal for dataset valuewhitelist_gics1_sector_orig, column GICS1, file: 200, table: 200
DEBUG [2016-04-26 16:02:09] Validate, rowcount for dataset valuewhitelist_gics1_sector, file: 15, table: 15
DEBUG [2016-04-26 16:02:09] Validate, columncount for dataset valuewhitelist_gics1_sector, file: 3, table: 3
DEBUG [2016-04-26 16:02:09] Validate, hashtotal for dataset valuewhitelist_gics1_sector, column GICS1, file: 200, table: 200

```

Saved processed file originating from  *whitelist_gics1_dlamsector3.csv* in the database as table named  **valuewhitelist_gics1_sector**   
DEBUG [2016-04-26 16:02:09] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/whitelist_cic_assetclass.csv
Preprocessing data read from *whitelist_cic_assetclass.csv*  

```
```
Final column names of original dataframe:  

```
[1] "DLAMAssetClass1" "DLAMAssetClass2" "DLAMAssetClass3" "DLAMAssetClass4" "Combi"           "CIC_Code"       
[7] "CIC_Category"   
```
DEBUG [2016-04-26 16:02:09] Saving data to table valuewhitelist_cic_assetclass

```
DEBUG [2016-04-26 16:02:09] Validate, rowcount for dataset valuewhitelist_cic_assetclass_orig, file: 102, table: 102
DEBUG [2016-04-26 16:02:09] Validate, columncount for dataset valuewhitelist_cic_assetclass_orig, file: 7, table: 7
DEBUG [2016-04-26 16:02:09] Validate, hashtotal for dataset valuewhitelist_cic_assetclass_orig, column CIC_Code, file: 202, table: 202
DEBUG [2016-04-26 16:02:12] Validate, rowcount for dataset valuewhitelist_cic_assetclass, file: 102, table: 102
DEBUG [2016-04-26 16:02:12] Validate, columncount for dataset valuewhitelist_cic_assetclass, file: 8, table: 8
DEBUG [2016-04-26 16:02:12] Validate, hashtotal for dataset valuewhitelist_cic_assetclass, column CIC_Code, file: 202, table: 202

```

Saved processed file originating from  *whitelist_cic_assetclass.csv* in the database as table named  **valuewhitelist_cic_assetclass**   
DEBUG [2016-04-26 16:02:12] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/whitelist_assetclass_cedar.csv
Preprocessing data read from *whitelist_assetclass_cedar.csv*  

```
```
Final column names of original dataframe:  

```
[1] "DLAMAssetClass2" "DLAMAssetClass3" "CEDAR"          
```
DEBUG [2016-04-26 16:02:12] Saving data to table valuewhitelist_cedar_assetclass

```
DEBUG [2016-04-26 16:02:14] Validate, rowcount for dataset valuewhitelist_cedar_assetclass_orig, file: 57, table: 57
DEBUG [2016-04-26 16:02:14] Validate, columncount for dataset valuewhitelist_cedar_assetclass_orig, file: 3, table: 3
DEBUG [2016-04-26 16:02:14] Validate, hashtotal for dataset valuewhitelist_cedar_assetclass_orig, column DLAMAssetClass2, file: 645, table: 645
DEBUG [2016-04-26 16:02:14] Validate, rowcount for dataset valuewhitelist_cedar_assetclass, file: 57, table: 57
DEBUG [2016-04-26 16:02:14] Validate, columncount for dataset valuewhitelist_cedar_assetclass, file: 4, table: 4
DEBUG [2016-04-26 16:02:14] Validate, hashtotal for dataset valuewhitelist_cedar_assetclass, column DLAMAssetClass2, file: 645, table: 645

```

Saved processed file originating from  *whitelist_assetclass_cedar.csv* in the database as table named  **valuewhitelist_cedar_assetclass**   
DEBUG [2016-04-26 16:02:14] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/whitelist_assetclass_dbinstype.csv
Preprocessing data read from *whitelist_assetclass_dbinstype.csv*  

```
```
Final column names of original dataframe:  

```
[1] "DLAMAssetClass1" "DLAMAssetClass2" "DLAMAssetClass3" "db_instype_desc"
```
DEBUG [2016-04-26 16:02:17] Saving data to table valuewhitelist_assetclass_dbinstype

```
DEBUG [2016-04-26 16:02:17] Validate, rowcount for dataset valuewhitelist_assetclass_dbinstype_orig, file: 6, table: 6
DEBUG [2016-04-26 16:02:17] Validate, columncount for dataset valuewhitelist_assetclass_dbinstype_orig, file: 4, table: 4
DEBUG [2016-04-26 16:02:17] Validate, hashtotal for dataset valuewhitelist_assetclass_dbinstype_orig, column DLAMAssetClass1, file: 64, table: 64
DEBUG [2016-04-26 16:02:17] Validate, rowcount for dataset valuewhitelist_assetclass_dbinstype, file: 6, table: 6
DEBUG [2016-04-26 16:02:17] Validate, columncount for dataset valuewhitelist_assetclass_dbinstype, file: 5, table: 5
DEBUG [2016-04-26 16:02:17] Validate, hashtotal for dataset valuewhitelist_assetclass_dbinstype, column DLAMAssetClass1, file: 64, table: 64

```

Saved processed file originating from  *whitelist_assetclass_dbinstype.csv* in the database as table named  **valuewhitelist_assetclass_dbinstype**   

DEBUG [2016-04-26 16:02:19] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/fndstt_known_mismatches.csv
Preprocessing data read from *fndstt_known_mismatches.csv*  

```
```
Final column names of original dataframe:  

```
[1] "BR"      "insid"   "prfid"   "fxid"    "tradeid" "owner"   "date"    "reason" 
```
Converted column date to Date (format=%m/%d/%Y)  with no failures on 53 nonempty values.  
DEBUG [2016-04-26 16:02:19] Saving data to table PO_fndstt_known_mismatches

```
DEBUG [2016-04-26 16:02:19] Validate, rowcount for dataset PO_fndstt_known_mismatches_orig, file: 53, table: 53
DEBUG [2016-04-26 16:02:22] Validate, columncount for dataset PO_fndstt_known_mismatches_orig, file: 8, table: 8
DEBUG [2016-04-26 16:02:22] Validate, hashtotal for dataset PO_fndstt_known_mismatches_orig, column BR, file: 4240, table: 4240
[1] "Column 'source_date\": Mean absolute differenc not found in target."
DEBUG [2016-04-26 16:02:22] Validate, rowcount for dataset PO_fndstt_known_mismatches, file: 53, table: 53
DEBUG [2016-04-26 16:02:22] Validate, columncount for dataset PO_fndstt_known_mismatches, file: 11, table: 11
DEBUG [2016-04-26 16:02:22] Validate, hashtotal for dataset PO_fndstt_known_mismatches, column BR, file: 4240, table: 4240

```

Saved processed file originating from  *fndstt_known_mismatches.csv* in the database as table named  **PO_fndstt_known_mismatches**   
