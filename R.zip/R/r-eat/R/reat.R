# Package to easily read and interpret data from disk to save them into a sql database

## Loading data from file to database table
# Steps
# --setting up 'orig' dataset
# 1: read raw data from disk
# 2: annotate raw data: assign (unique) column names
# --setting up 'prep' dataset
# 3: clean unusable data : remove empty rows & cols
# 4: interpret data types
# 5: filter out unwanted rows
# --storing the prep dataset
# 6: save the rows
load.data <- function(datadef, connector, echo.Rmd=T, save=T){
  stopifnot(!is.null(datadef))

  flog.debug("loading data file %s", datadef$origin)
  # Read data from the origin
  # Takes care of disk IO, determines HEADER(colnames), rows and values
  if(!is.null(datadef$origin)){
	  if(is.null(datadef$read)){
		  stop("No 'read' function provided in the datadef to read from the origin.")
	  }
	  datadef$file <- basename(datadef$origin)
 	  datadef$path <- datadef$origin # as long as not everything is refactored
	  datadef$orig <- datadef$read(datadef$origin)
	  if(is.null(datadef$meta) & !is.null(datadef$read.meta)){
	    datadef$meta <- datadef$read.meta(datadef$origin)
	  }
  }

  # Prepare the raw data from the origin
  # Remove unused columns/rows, create valid colnames
  datadef <- prepare.data(datadef, cols.keep=datadef$cols.keep, cols.map=datadef$cols.map, cols.drop=datadef$cols.drop, drop.cols=datadef$drop.cols)
  # Transform the prepared frame (infer types)
  if(length(datadef$typechanges)>0){
    if(echo.Rmd){
      flog.trace("## Data preparation (standardization)")
      flog.trace("The following other data type changes have been applied")
    }
    for(prepargs in datadef$typechanges){
      datadef$prep <- do.call(prepare.types, args = c(list(x=datadef$prep), prepargs))
      flog.trace(datadef$prep)
    }
  }
  if(length(datadef$transforms)>0){
	  if(echo.Rmd){
	    flog.trace("## Data transforms and enrichments")
	  }
	  for(transforms in datadef$transforms){
		  datadef$prep <- transforms(datadef$prep)
		  flog.trace(datadef$prep)
	  }
  }

  # Filter rows
  if(length(datadef$filter)>0){
    if(echo.Rmd){
      flog.trace("The following filters have been applied:")
    }
    for(filterargs in datadef$filter){
      requireInSet(c("col.name","value","type","keep"), names(filterargs))
      if(length(filterargs$col.name)==0){
        # if no names provided, use all names except the _orig _failed ones.
        used_names <- colnames(datadef$prep)
        used_names <- used_names[!grepl("_orig", used_names, fixed=T)]
        used_names <- used_names[!grepl("_failed", used_names, fixed=T)]
        filterargs$col.name <- used_names
      }
      rows_before <- nrow(datadef$prep)
      datadef$prep <- do.call(filter.rows, args = c(list(x=datadef$prep), filterargs))
      rows_after <- nrow(datadef$prep)
      
      action<-
        if(filterargs$keep)
          paste0("Keeping ", rows_after)
        else
          paste0("Dropping ", rows_before-rows_after)
      filter_text <- paste0(action, "rows for which",
                            paste0("'",filterargs$col.name,"'"),
                            "matches ",
                            paste0("'",filterargs$value,"'"),
                            "using",
                            filterargs$type,
                            ". This results in ",
                            rows_after,
                            "rows out of the initial",
                            rows_before)
      flog.trace(filter_text)
    }
  }

  if(echo.Rmd){
    flog.trace("Resulting data characteristics:")
    flog.trace(summary(datadef$prep))
  }

	default_constants <- as.data.frame(list(source_file=datadef$file))
	if(!is.null(datadef$constants)){
	  datadef$constants<-cbind(as.data.frame(datadef$constants),
							   default_constants
							   )
	}else{
	  datadef$constants <- default_constants
	}
	colnames(datadef$constants) <- names(datadef$constants)
	if(echo.Rmd){
	  flog.trace("Adding the following constants to all rows:")
	  flog.trace(datadef$constants)
	}
	if(nrow(datadef$prep)>0)
		datadef$prep<-merge(datadef$prep, datadef$constants, by=c())
	else
		datadef$prep <- cbind(datadef$prep, datadef$constants[c(),])
	colnames(datadef$prep)[ncol(datadef$prep)-col(datadef$constants)+(1:ncol(datadef$constants))] <- colnames(datadef$constants)

  # Enrich dataframe with constant meta data
  if(!is.null(datadef$meta)){
    if(echo.Rmd){
      flog.trace("Got the following meta data constant for all rows:")
      flog.trace(datadef$meta)
    }
    datadef$prep<-merge(datadef$prep, datadef$meta, by=c())
  }

  # Write the prepared data to the destination
  if(is.null(datadef$destination)){
	  datadef$destination <- connector
  }
  
  if(save){
	  save.data(datadef, echo.Rmd)
  }
  return(datadef)
}

#save datadef to database
save.data <- function(datadef, echo.Rmd=T){
	if(echo.Rmd){
		flog.debug("Saving data to table %s", datadef$name)
	}
	if(is.null(datadef$row.names)){
		datadef$row.names<-FALSE
	}
	if(is.null(datadef$destination)){
	  flog.error("No database connector stored in the datadefs 'destination'")
		stop("No database connector stored in the datadefs 'destination'")
	}
  save.prepared(datadef, datadef$destination, datadef$name, echo.Rmd=T, row.names=datadef$row.names)
}
