#data validation

#' Validate loading of a dataframe to a database table. Function has as arguments the original
#  dataframe and the one retrieved from db after loading.
validateLoading <- function(df_orig, df_fetch, name, validationColumn){
  if (!grepl("rule_failures_details", name)){
    flog.debug("Validate, rowcount for dataset %s, file: %s, table: %s", name, nrow(df_orig), nrow(df_fetch))
    assert(nrow(df_orig) == nrow(df_fetch), "number of rows original df is not equal to fetched df")
    
    flog.debug("Validate, columncount for dataset %s, file: %s, table: %s", name, ncol(df_orig), ncol(df_fetch))
    assert(ncol(df_orig) == ncol(df_fetch), "number of columns original df is not equal to fetched df")
  
    #compare hash totals if validation column is available
    if (!is.null(validationColumn)){
      valColumnOrig <- processValidationColumn(validationColumn, TRUE, name)
      colInputOrig <- getColumnInput(df_orig, valColumnOrig, name)
      hashTotalOrig <- calculateHashTotal(colInputOrig)
      
      valColumnFetched <- processValidationColumn(validationColumn, FALSE, name)
      colInputFetched <- getColumnInput(df_fetch, valColumnFetched, name)
      hashTotalFetched <- calculateHashTotal(colInputFetched)
      
      flog.debug("Validate, hashtotal for dataset %s, column %s, file: %s, table: %s", 
                 name, colInputOrig$colName, hashTotalOrig, hashTotalFetched)
      
      assert(hashTotalOrig == hashTotalFetched, "hashtotal not the same!")
      if(hashTotalOrig == 0){
        flog.warn(paste0("Calculated hash is zero ", name))
      }
    }
    else{
      flog.warn(paste0("validateLoading: no validation column specified for ", name))
    }
  }
}

#remove spaces
processValidationColumn <- function(colName, isOrig, name){
  if (isOrig != TRUE | !grepl("_orig", name)){
    colName <- gsub(" ","", colName)
  }
  return(colName)
}

#'calculate a hash total for given values column name
# depending on a column some preprocessing has to be done
calculateHashTotal <- function(colInput){
  colValues <- colInput$colValues
  colName <- colInput$colName
  if (colName == "Number"){
    hashTotal <- sum(strtoi(gsub("DE", "", colValues)), na.rm = TRUE)
  }
  else if (colName == "BR"){
    colValues <- gsub("PO_", "", colValues)
    colValues <- gsub("FA_", "", colValues)
    colValues <- gsub("GL_BR", "", colValues)
    colValues <- gsub("VIS_", "", colValues)
    hashTotal <- sum(strtoi(colValues), na.rm = TRUE)
  }
  else if (colName %in% c("interestrate", "quantity", "Price", "COUPON", "Rate", "FXRATE",  "Koers", "KOERS", 
                          "BUY_AMOUNT", "abs_rate", "WISSELKOERS", "LD_DAT_ID", "MY_ID", "CMPLX_ID")){
    if (class(colValues) == "factor"){
      colValues <- as.numeric(as.character(t(colValues)))
    } else if (class(colValues) == "character"){
        colValues <- as.numeric(colValues)
    }
    hashTotal <- sum(colValues, na.rm = TRUE)
  }
  #in case of a character column, count the number of characters
  else if (colName %in% c("DLAMAssetClass1", "DLAMAssetClass2", "DLSector1", "CLIENTNAAM", "CIC_Code", 
                          "RatingLevel", "WFT", "INDUSTRY", "DRA", "GICS1", "PORTFOLIO", "V1", "V6", 
                          "Typegeld", "Portiacode", "Portia code", "Trader", "portfolio", "ID")){
    hashTotal <- Reduce("+", lapply(colValues, nchar))
  }
  else{
    flog.error(paste0("calculateHashTotal: unknown column name!", colName))
  }
  return(hashTotal)
}

#get column values based on df, colName and table name
getColumnInput <- function(df, colName, name){
  len <- length(colName)
  assert(len == 1 | len == 2, "getColumnValues should have 1 or 2 column name(s) as input")
  if(len == 1){
    colNameUsed <- colName
  } else{
    if (grepl("_orig", name)){
      colNameUsed <- colName[1]
    } else{
      colNameUsed <- colName[2]
    }
  }
  colValues <- df[[colNameUsed]] 
  result <- list(
    colValues = colValues,
    colName = colNameUsed
  )
  return(result)
}

#debug
#debug(validateLoading)