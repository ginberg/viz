## dashboard.R ##
library(shiny)
library(shinydashboard)
library(ggplot2)
library(scales)
library(plyr)
#library(googleVis)

#configuration
dashboard_input_path <- "Z:/Shared Data/5501_ProjectDataQuality/3_Output Data/dashboard"
portia_files <- c("Portia_del4a_dqa.csv","Portia_del4b_dqa.csv")
portia_current_date <- "2016-04-12"
fa_files <- c("FrontArena_del4b_dqa.csv") #"FrontArena_del4a_dqa.csv", 
fa_current_date <- "2016-04-13"
globes_files <- c("Globe$_del4b_dqa.csv")
globes_current_date <- "2016-21-22"
vis_files <- c("VIS_del4b_dqa.csv")
vis_current_date <- "2016-02-19"

ui <- dashboardPage(
  dashboardHeader(title = "DQSS dashboard"),
  dashboardSidebar(sidebarMenu
                   (
                   menuItem("Portia", tabName = "po", icon = icon("dashboard")),
                   menuItem("Front Arena", tabName = "fa", icon = icon("th")),
                   menuItem("Globe$", tabName = "gl", icon = icon("dollar")),
                   menuItem("VIS", tabName = "vis", icon = icon("cc-visa"))
                   ),
                   width = 150),
  dashboardBody(
    tabItems(
      # po
      tabItem(tabName = "po",
              # Boxes need to be put in a row (or column)
              fluidRow(
                column(width = 3, textOutput("summaryBR_po")),
                column(width = 9, uiOutput("sliderBR_po"))
              ),
              fluidRow(
                box(plotOutput("totalBR_po", height = 300, width = 1200))
              ),
              fluidRow(
                column(width = 3, textOutput("summaryDE_po")),
                column(width = 9, uiOutput("sliderDE_po"))
              ),
              fluidRow(
                box(plotOutput("totalDE_po", height = 300, width = 1200))
              ),
              fluidRow(
                box(plotOutput("plotBR_po", height = 250)),
                box(uiOutput("selectBR_po"))
              ),
              fluidRow(
                box(plotOutput("plotDE_po", height = 250)),
                box(uiOutput("selectDE_po"))
              )
      ),#end portia
      tabItem(tabName = "fa",
              fluidRow(
                column(width = 3, textOutput("summaryBR_fa")),
                column(width = 9, uiOutput("sliderBR_fa"))
              ),
              fluidRow(
                box(plotOutput("totalBR_fa", height = 300, width = 1200))
              ),
              fluidRow(
                column(width = 3, textOutput("summaryDE_fa")),
                column(width = 9, uiOutput("sliderDE_fa"))
              ),
              fluidRow(
                box(plotOutput("totalDE_fa", height = 300, width = 1200))
              )
              #fluidRow(
              #  box(plotOutput("plotBR_fa", height = 250)),
              #  box(uiOutput("selectBR_fa"))
              #),
              #fluidRow(
              #  box(plotOutput("plotDE_fa", height = 250)),
              #  box(uiOutput("selectDE_fa"))
              #)
      ),#end FA
      # tabItem(tabName = "gl",
      #         fluidRow(
      #           column(width = 3, textOutput("summaryBR_gl")),
      #           column(width = 9, uiOutput("sliderBR_gl"))
      #         ),
      #         fluidRow(
      #           box(plotOutput("totalBR_gl", height = 300, width = 1200))
      #         )
      # ),#end globes
      tabItem(tabName = "vis",
              fluidRow(
                column(width = 3, textOutput("summaryBR_vis")),
                column(width = 9, uiOutput("sliderBR_vis"))
              ),
              fluidRow(
                box(plotOutput("totalBR_vis", height = 300, width = 1200))
              )
      )#end vis
    )
  )
)

server <- function(input, output) {
  #PORTIA
  po_failed <- getDFFailed(dashboard_input_path, portia_files)
  po_current_failed <- getDFFailedByDate(po_failed, portia_current_date)
  
  #get unique BRs and DEs
  BRsPO <- getSortedBRs(po_current_failed)
  DEsPO <- getSortedDEs(po_current_failed)
  
  #Business rules section
  output$summaryBR_po <- renderText({ 
    getSummaryTextBR(po_current_failed, BRsPO)
  })
  output$sliderBR_po <- renderUI({
    createBRSliderInput(BRsPO, "sliderBR_po")
  })
  #totalBR with ggplot
  output$totalBR_po <- renderPlot({
    createTotalBRPlot(po_current_failed, input$sliderBR_po)
  })
  #DE section
  output$summaryDE_po <- renderText({ 
    getSummaryDEText(po_current_failed, DEsPO)
  })
  output$sliderDE_po <- renderUI({
    createDESliderInput(DEsPO, "sliderDE_po")
  })
  output$totalDE_po <- renderPlot({
    createTotalDEPlot(po_current_failed, input$sliderDE_po)
  })
  
  #time series BR
  output$selectBR_po <- renderUI({
    selectInput("selectBR_po", "selectBR", as.list(BRsPO))
  })
  output$plotBR_po <- renderPlot({
    createBRDiffPlot(po_failed, input$selectBR_po)
  })
  
  #time series DE
  output$selectDE_po <- renderUI({
    selectInput("selectDE", "selectDE", as.list(DEsPO))
  })
  output$plotDE_po <- renderPlot({
    createDEDiffPlot(po_failed, input$selectDE)
  })
  
  #FRONT ARENA
  fa_failed <- getDFFailed(dashboard_input_path, fa_files)
  fa_current_failed <- getDFFailedByDate(fa_failed, fa_current_date)
  BRsFA <- getSortedBRs(fa_current_failed)
  DEsFA <- getSortedDEs(fa_current_failed)
  
  output$summaryBR_fa <- renderText({ 
    getSummaryTextBR(fa_current_failed, BRsFA)
  })
  output$sliderBR_fa <- renderUI({
    createBRSliderInput(BRsFA, "sliderBR_fa")
  })
  #totalBR with ggplot
  output$totalBR_fa <- renderPlot({
    createTotalBRPlot(fa_current_failed, input$sliderBR_fa)
  })
  #DE section
  output$summaryDE_fa <- renderText({ 
    getSummaryDEText(fa_current_failed, DEsFA)
  })
  output$sliderDE_fa <- renderUI({
    createDESliderInput(DEsFA, "sliderDE_fa")
  })
  output$totalDE_fa <- renderPlot({
    createTotalDEPlot(fa_current_failed, input$sliderDE_fa)
  })
  
  #time series BR
  #output$selectBR_fa <- renderUI({
  #  selectInput("selectBR_fa", "selectBR", as.list(BRsFA))
  #})
  #output$plotBR_fa <- renderPlot({
  #  createBRDiffPlot(fa_failed, input$selectBR_fa)
  #})
  
  #time series DE
  #output$selectDE_fa <- renderUI({
  #  selectInput("selectDE_fa", "selectDE", as.list(DEsFA))
  #})
  #output$plotDE_fa <- renderPlot({
  #  createDEDiffPlot(fa_failed, input$selectDE_fa)
  #})
  
  #GLOBES
  # gl_failed <- getDFFailed(dashboard_input_path, globes_files)
  # gl_current_failed <- getDFFailedByDate(gl_failed, globes_current_date)
  # BRsGL <- getSortedBRs(gl_current_failed)
  # 
  # output$summary_gl <- renderText({ 
  #   getSummaryTextBR(gl_current_failed, BRsGL)
  # })
  # output$sliderBR_gl <- renderUI({
  #   createBRSliderInput(BRsGL, "sliderBR_gl")
  # })
  # #totalBR with ggplot
  # output$totalBR_gl <- renderPlot({
  #   createTotalBRPlot(gl_current_failed, input$sliderBR_gl)
  # })
  
  #VIS
  vis_failed <- getDFFailed(dashboard_input_path, c("VIS_del4b_dqa.csv"))
  vis_current_failed <- getDFFailedByDate(vis_failed, "2016-02-19")
  BRsVIS <- getSortedBRs(vis_current_failed)
  
  output$summary_vis <- renderText({ 
    getSummaryTextBR(vis_current_failed, BRsVIS)
  })
  output$sliderBR_vis <- renderUI({
    createBRSliderInput(BRsVIS, "sliderBR_vis")
  })
  #totalBR with ggplot
  output$totalBR_vis <- renderPlot({
    createTotalBRPlot(vis_current_failed, input$sliderBR_vis)
  })
}

#get summary text BR
getSummaryTextBR <- function(df, BRs){
  return(paste("Number of failed Business Rules:", length(BRs),
               "Number of failures:", sum(aggregate(df$Failed, by=list(BR=df$BR.number), FUN=mean)$x)))
}

#get summary text DE
getSummaryDEText <- function(df, DEs){
  return(paste("Number of failed Data Elements:", length(DEs),
               "Number of failures:", sum(df$Failed)))
}

#create slider input BR
createBRSliderInput <- function(BRs, sliderName){
  return(sliderInput(sliderName, "Select number of failed BR in plot:", min=1, max=length(BRs), value=length(BRs), step=1))
}

#create slider input DE
createDESliderInput <- function(DEs, sliderName){
  return(sliderInput(sliderName, "Select number of failed DE in plot:", min=1, max=length(DEs), value=length(DEs), step=1))
}

#create time series plot of BR
createBRDiffPlot <- function(df, selectInput){
  if(is.null(selectInput))
    return()
  dfSelected <- df[df$BR.number == selectInput,]
  dfSelected <- rename(dfSelected, c("Source.Date" = "Date", "Failed" = "failures"))
  if(nrow(df) >0){
    return(ggplot(data=dfSelected, aes(x=Date, y=failures, group = 1)) + geom_point() + geom_line() + ggtitle(paste("Failures over time", selectInput)) +
             scale_x_date(labels = date_format("%b-%Y")))
  } else{
    return()
  }
}

#create time series plot of DE
createDEDiffPlot <- function(df, selectInput){
  if(is.null(selectInput))
    return()
  dfSelected <- df[df$Data.Element == selectInput,]
  dfSelected <- aggregate(dfSelected$Failed, by=list(Date=dfSelected$Source.Date), FUN=sum)
  dfSelected <- rename(dfSelected, c("x" = "failures"))
  if(nrow(dfSelected) >0){
    return(ggplot(data=dfSelected, aes(x=Date, y=failures, group = 1)) + geom_point() + geom_line() + 
             ggtitle(paste("Failures over time", selectInput)) + scale_x_date(labels = date_format("%b-%Y"))) 
  } else{
    return()
  }
}

#create totalBR plot
createTotalBRPlot <- function(df, inputValue){
  dfTot <- aggregateAndSelectBR(df, inputValue)
  if(nrow(dfTot) >0){
    return(ggplot(data=dfTot, aes(reorder(BR, -count), count, group = 1)) + geom_bar(stat="identity") + 
             ggtitle("Total current failures per BR") + xlab("Business Rule number") + ylab("Number of failures"))
  } else{
    return()
  }
  return()
}

createTotalBRPlot2 <- function(df, inputValue){
  dfTot <- aggregateAndSelectBR2(df, inputValue)
  if(nrow(dfTot) >0){
    return(ggplot(data=dfTot, aes(x = BR, y = count)) + geom_bar(aes(fill = category), stat="identity") + 
             ggtitle("Total current failures per BR") + xlab("Business Rule number") + ylab("Number of failures"))
  } else{
    return()
  }
  return()
}

#create totalDE plot
createTotalDEPlot <- function(df, inputValue){
  dfTot <- aggregate(df$Failed, by=list(DE=df$Data.Element), FUN=sum)
  dfTot <- dfTot[order(dfTot$x, decreasing = TRUE),]
  if (!is.null(inputValue)){
    selectedLength <- inputValue
    dfTot <- dfTot[1:selectedLength,]
  }
  if(nrow(dfTot) >0){
    return(ggplot(data=dfTot, aes(reorder(DE, -x), y=x, group = 1)) + geom_bar(stat="identity") + 
             ggtitle("Total current failures per DE") + xlab("Data Element number") + ylab("Number of failures"))
  } else{
    return()
  }
  return()
}

#get failed elements from given files
getDFFailed <- function(path, filenames){
  df <- data.frame()
  for (filename in filenames){
    dfRead <- read.csv(file.path(path, filename), stringsAsFactors = FALSE, header = TRUE)  
    df <- rbind(df, dfRead)
  }
  df_failed <- df[df$Failed > 0,]
  df_failed$Data.Element <- sapply(df_failed$Data.Element, replaceDEString)
  df_failed$Source.Date <- as.Date(df_failed$Source.Date, "%Y-%m-%d")
  return(df_failed)
}

#get df elements for given date
getDFFailedByDate <- function(df, sourceDate){
  df_failed <- df[df$Failed > 0,]
  df_failed$Data.Element <- sapply(df_failed$Data.Element, replaceDEString)
  df_current_failed <- subset(df_failed, Source.Date == as.Date(sourceDate))
  return(df_current_failed)
}

#get unique Business Rules sorted
getSortedBRs <- function(df){
  BRs <- unique(df$BR.number)
  BRs <- BRs[order(BRs)]
  return(BRs)
}

#get unique Data Elements sorted
getSortedDEs <- function(df){
  DEs <- unique(df$Data.Element)
  DEs <- DEs[order(DEs)]
  return(DEs)
}

#aggregate failed of DF by BR and select the top x where x is specified in slider
#notice: don' t double count lines for each dataelement, so use mean instead of sum
aggregateAndSelectBR <- function(inputDF, sliderInput){
  df <- aggregate(inputDF$Failed, by=list(BR=inputDF$BR.number), FUN=mean)
  #order by number failed
  df <- df[order(df$x, decreasing = TRUE),]
  if (!is.null(sliderInput)){
    selectedLength <- sliderInput
    df <- df[1:selectedLength,]
  }
  df$BR <- gsub("PO_0", "", df$BR)
  colnames(df) <- c("BR", "count")
  return(df) 
}  

# format Data Element string to be able to sort
replaceDEString <- function(inputString){
  if (nchar(inputString) == 3){
    return(paste0(substring(inputString, 0, 2), "0", substring(inputString, 3, 3)))
  } else{
    return(inputString)
  }
}

#totalBR with googlevis
#fluidRow(
#  htmlOutput("totalBRvis")
#),
#output$totalBRvis <- renderGvis({
#  df <- aggregateAndSelectBR(po_current_failed, input$sliderBR)
#  gvisColumnChart(df, xvar="BR", yvar="count", options=list(
#                  title="Totale huidige uitval per BR", width=1200, height=400,
#                  chartArea="{left:70,top:40,width:'80%',height:'80%'}",
#                  titleTextStyle="{color:'red',fontName:'Courier',fontSize:16}", bar="{groupWidth:'100%'}"))
#})

#create shiny app
shinyApp(ui, server)