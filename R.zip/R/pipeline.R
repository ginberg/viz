##clear workspace
rm(list=ls())
##check if required packages are installed, otherwise install them
source("R\\install_packages.R")

## --- Set workingdir correctly such that the .Rmd files can find sources and datasets
changed_to_subdir <- F
if(!grepl("R$", getwd())) {
  setwd('.\\R') #Move currentwd to the same one as will be used by RStudio when knitr'ing
  changed_to_subdir <- T
}

#initialize logging
library(futile.logger)
flog.threshold(DEBUG)
logfile <- file.path(getwd(), "../logs//pipeline.log")
if (file.exists(logfile)) file.remove(logfile)
void <- flog.appender(appender.tee(logfile))
flog.info("Checked and installed required packages")

#########################################################
### Preparing knitr
#########################################################
library(knitr)
library(tools)

opts_knit$set(root.dir=normalizePath(getwd()))

pb = txtProgressBar(min = 0, max = 100, file = stderr())
all_htmls <- c()
runknit <- function(file, output=NULL, ...){
  # by removing the file from disk and adding it to list of generated htmls, forces failure when html is not fully created
  htmlfile <- if(is.null(output)){
  	paste0(basename(file_path_sans_ext(file)),".html")
  } else {
	  output
  }
  all_htmls <<- c(all_htmls, htmlfile)
  if(file.exists(htmlfile))
    file.remove(htmlfile)
  
  envir = .GlobalEnv
  var_list <- list(...)
  for(n in names(var_list)){
	  assign(n, var_list[[n]], envir)
  }

  knit2html(file, output=output, stylesheet='custom.css', quiet=T, envir=envir, force_v1 = TRUE)
}

#########################################################
### Performing the reproducible research
#########################################################
## ---------- Clearing old business rule results
## When parts of the pipeline (one system) is rerun, its results will be overwritten
## For bigger changes, to start from scratch, remove all previous results
flog.info("Loading config")
setwd('..\\')
source("R\\config.R")
setwd('.\\R')
flog.info("Working directory set to:%s", getwd())

#Copy input files from pipeline to generic input (needed to keep git history of these files)
input_files <- c(portia_rl_file, portia_bl_file, portia_wl_file, portia_4a_file,
                 fa_rl_file, fa_bl_file, fa_wl_file, fa_4a_file,
                 globes_rl_file, globes_bl_file, globes_wl_file, globes_4a_file, 
                 vis_rl_file, vis_bl_file, vis_wl_file, vis_4a_file)
flog.info("copying input files from %s to %s", pipeline_input_path, input_data_path)
file.copy(from=paste(pipeline_input_path, input_files, sep="/"), to=input_data_path, overwrite = TRUE)

## ---------- General data import----------
## First data that relates to multiple systems is preprocesses. Results are stored in the .\output folder
### Requires a correct configuration in config.R which defines absolute paths.
flog.info("Importing scope")
runknit('import_scope.Rmd')
# If it fails with R/r-eat/R/reat.R no such file or directory, you probably didn't update the r-eat submodule.
# You must run two commands: 
# git submodule init to initialize your local configuration file
# git submodule update to fetch all the data from that project and check out the appropriate commit listed in your superproject
flog.info("Importing definitions")
runknit('import_definitions.Rmd')


## ----------The Porta analysis----------
## This is an independent sub-pipeline, which does depend on the general data import, but not on other system's analysis like FA
## --- Data preparation
###       All prepation of all data necessary for portia. 
###       Creates views/tables in the database and stores dataframes in ./output/*.RData files 
###       Uses external data defined in R/portia_external_data.R
if ("portia" %in% run_systems){
  flog.info("Importing portia data")
  runknit('portia_import_data.Rmd')
  
  flog.info("Importing portia rules")
  runknit('standard_import_rules.Rmd',
    system_attr = list(
      BU = "BU Delta Lloyd Asset Management",
      FullName = "Portia",
      Acronym = "PO"
    ),
    'portia_import_rules.html')
}

## ----------The Front Arena analysis----------
## This is an independent sub-pipeline, which does depend on the general data import, but not on other system's analysis like Portia
### --- Data preparation
###       All preparation of all data necessary for portia. 
###       Creates views/tables in the database and stores dataframes in ./output/*.RData files 
###       Uses external data defined in R/frontarena_external_data.R
if ("fa" %in% run_systems){
  flog.info("Importing frontarena data")
  runknit('frontarena_import.Rmd')
  ### --- Verify scoping
  ###       Now analyse the scoping. Compares export elements referred to in the scoping with available columns in the exports
  flog.info("Importing frontarena scoping details")
  runknit('frontarena_scopingdetails.Rmd')
  
  ### --- Business rules on the database
  flog.info("Importing frontarena rules")
  runknit('standard_import_rules.Rmd', 
          system_attr = list(
            BU = "BU Delta Lloyd Asset Management",
            FullName = "FrontArena",
            Acronym = "FA"
          ),
          'frontarena_import_rules.html')
}

## ----------The Globes analysis----------
## This is an independent sub-pipeline, which does depend on the general data import, but not on other system's analysis like Portia
### --- Data preparation
###       All preparation of all data necessary for Globes 
###       Creates views/tables in the database and stores dataframes in ./output/*.RData files 
###       Uses external data defined in R/globes_external_data.R
if ("globes" %in% run_systems){
  flog.info("Importing globes data")
  runknit('globes_import.Rmd')
  
  ### --- Business rules on the database
  flog.info("Importing globes rules")
  runknit('standard_import_rules.Rmd', 
          system_attr = list(
            BU = "BU Delta Lloyd Asset Management",
            FullName = "Globe$",
            Acronym = "GL"
          ),
          'globe$_import_rules.html')
}

## ----------The VIS analysis----------
## This is an independent sub-pipeline, which does depend on the general data import, but not on other system's analysis like Portia
### --- Data preparation
###       All preparation of all data necessary for VIS (SIV) 
###       Creates views/tables in the database and stores dataframes in ./output/*.RData files 
###       Uses external data defined in R/vis_external_data.R
if ("vis" %in% run_systems){
  flog.info("Importing vis data")
  runknit('vis_import.Rmd')
  
  ### --- Business rules on the database
  flog.info("Importing vis rules")
  runknit('standard_import_rules.Rmd', 
          system_attr = list(
            BU = "BU Delta Lloyd Asset Management",
            FullName = "VIS",
            Acronym = "VIS"
          ),
          'vis_import_rules.html')
}

flog.info("Importing final rules")
runknit('final_import_rules.Rmd')

## ------ Runn all rules on all systems -----
flog.info("Run rules")
#runknit('run_rules.Rmd')
runknit('run_rules_no_supersets.Rmd')
flog.info("Rule results")
runknit('rule_results.Rmd')

#runknit('frm_scopingdetails.Rmd')

#########################################################
### Collecting all results
#########################################################
## ---------- Copying all files to the business rules folder ----------
# Copy html results of the Rmd files to one local folder
flog.info("Copy results to output folder %s", "../output/businessrules/")
flist <- paste0("./",unique(all_htmls))
htmlout_folder <- "../output/businessrules/"
copyresult<-file.copy(flist, htmlout_folder, overwrite=T)
print(data.frame(file=flist, destination=htmlout_folder, copied=copyresult))
assert(sum(!copyresult) == 0, "Failed to copy all files")

# Also copy the html results to the google drive
# copyresult<-file.copy(flist, "~/My Tresors/delta-lloyd-asset-management/0. Analysis/ResultsPipeline/", overwrite=T)
# print(data.frame(file=flist, copied=copyresult))
file.copy(logfile, outputpath("pipeline.log"), overwrite=T)

#########################################################
### Wrapping up knitr
#########################################################
# If we changed the working directory in the beginning, restore the original directory
if(changed_to_subdir)
  setwd('../')

close(pb)
