#Copy this file to config.R and modify fr
#This folder is expected to contain at least one subfolder name 'portia_exports'
dlam_data_path<-"d:/dlam_data"

sourcedata_connection <- 'driver={SQL Server};server=TRIFINLDTI12\\SQL2014;database=SourceData;trusted_connection=true'
dataquality_connection <- 'driver={SQL Server};server=TRIFINLDTI11\\SQL2014;database=DataQuality;trusted_connection=true'

has_portia_db <- FALSE # Set to true if you have a portia database dump
portia_connection <- 'driver={SQL Server};server=TRIFINLDTI11\\SQL2014;database=portia;trusted_connection=true'

has_fa_db <- FALSE # Set to true if you have a frontarena (Am_AdsP) database dump loaded
fa_connection <- 'driver={SQL Server};server=TRIFINLDTI11\\SQL2014;database=AM_AdsP;trusted_connection=true'

library(RODBC)
db.connect <- function(...){
  return(odbcDriverConnect(...))
}
