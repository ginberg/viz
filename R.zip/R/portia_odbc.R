source("R/config.R")
source("R/odbc.R")
portia_connect <- function(){db.connect(portia_connection)}
portia_export_connect<-function(){db.connect(portia_exports_connection)}

