<!-- rmarkdown v1 -->

---
title: "Data import"
output: html_document
---




# Data Import

The data can contain the different values indicating one actual value (think of "Y" and "YES", or "-" and "n/a"). This report explains which value inconsistencies were found and how they have been normalized.


```
INFO [2016-04-26 16:01:39] Loading common files
```

```
DEBUG [2016-04-26 16:01:39] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/frm_fields.csv
DEBUG [2016-04-26 16:01:39] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Common Data/20160412/dataelement_descriptions.csv
DEBUG [2016-04-26 16:01:39] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 2 - Front Arena/20160413/fieldmapping_frontarena_db.csv
```

# Solvency2 Data Elements
Output of different source systems (Portia,..) are put in the FRMdb, becoming Solvency II related data elements. To reconstruct and compare data the used mapping is needed. The mapping is constructed using:

* Vanwege oudheid niet uit: 20140919 Gebruikte brondata Internal Model (asset positions)\_FRM.xls
* Internal Model Columns - Positions v1.xls
* Manual mappings for available columnnames in secshld.csv



```
        Data.element    FrontArenaDB
1             COUPON       coup_rate
2           CURRENCY      curr_insid
3  DLAM.Asset.Type.2 DLAMAssetClass2
4  DLAM.Asset.Type.3 DLAMAssetClass3
5        DLAM.RATING      DLAMRating
6       DLAM.Sector1     DLAMSector1
7       DLAM.Sector2     DLAMSector2
8       DLAM.Sector3     DLAMSector3
9         EXPIRATION         exp_day
10            FXRATE          FXRate
11        IDENTIFIER           insid
12        ISSUE_DATE       issue_day
13      MARKET_VALUE    MARKET_VALUE
14          MATURITY        MATURITY
15     NOMINAL_VALUE   NOMINAL_VALUE
16    PORTFOLIO_NAME           prfid
17             PRICE           PRICE
18           proddat         proddat
19            STRIKE    strike_price
20              Type       CallOrPut
  [1] "ACCRUED_INTEREST"       "BOOK_VALUE"             "BPV"                    "BUSINESS_UNITS"        
  [5] "CALL_DATE"              "CALL_FREQUENCY"         "CALL_PRICE"             "Cedar_Classification"  
  [9] "CLIENT_NAME"            "Continent"              "CONVEXITY"              "CounterParty"          
 [13] "COUNTRY"                "COUNTRY"                "Country.Type"           "COUPON"                
 [17] "CURRENCY"               "Current.Spread"         "DESCRIPTION"            "DLAM.Asset.Type.1"     
 [21] "DLAM.Asset.Type.2"      "DLAM.Asset.Type.3"      "DLAM.Asset.Type.4"      "DLAM.RATING"           
 [25] "DLAM.Sector1"           "DLAM.Sector2"           "DLAM.Sector3"           "DLAM.Sector4"          
 [29] "DLAMTheme1"             "DLAMTheme2"             "DURATION"               "ECV"                   
 [33] "EXCHANGE"               "EXPIRATION"             "FAIR_VALUE_LEVEL"       "FITCH.RATING"          
 [37] "FXRATE"                 "FXRATE1"                "IDENTIFIER"             "IDENTIFIER_TYPE"       
 [41] "INDUSTRY"               "Interest.Rate.Duration" "ISSUE_DATE"             "ISSUER"                
 [45] "LISTED"                 "MARKET_VALUE"           "MATURITY"               "MOODYs_RATING"         
 [49] "NOMINAL_VALUE"          "OCCUPATION_RATE"        "OPTION_TYPE"            "PAYMENT_FREQUENCY"     
 [53] "Percent"                "PORTFOLIO_NAME"         "PORTFOLIO_TYPE"         "POSITION"              
 [57] "PRICE"                  "proddat"                "PRODUCT_TYPE"           "QUANTITY"              
 [61] "Rating"                 "REPORTING_DATE"         "RISK_PROFILE"           "SECURITY"              
 [65] "SEDOL"                  "SETTLE_DATE"            "SnP_RATING"             "proddat"               
 [69] "Current.Spread"         "Spread.Duration"        "Stress.Spread"          "STRIKE"                
 [73] "Sub.continent"          "TRADE_DATE"             "Type"                   "Ultimate.Issuer"       
 [77] "UNDERLYING"             "Warf"                   "WorkOutDate"            "YIELD"                 
 [81] "PORTFOLIO_NAME"         "IDENTIFIER"             "CURRENCY"               "MARKET_VALUE"          
 [85] "ISSUE_DATE"             "MATURITY"               "Type"                   "COUPON"                
 [89] "NOMINAL_VALUE"          "PRICE"                  "STRIKE"                 "PAYMENT_FREQUENCY"     
 [93] "DLAM.Asset.Type.3"      "DLAM.Sector1"           "DLAM.Sector3"           "Callable"              
 [97] "WorkOutDate"            "WAL"                    "FL.Spread"              "DLAM.RATING"           
[101] "Spread.Duration"        "EXPIRATION"             "QUANTITY"               "CTD.Maturity"          
[105] "CTD.Coupon"             "CTD.Price"              "CTD.Factor"             "PORTFOLIO_NAME"        
[109] "NOMINAL_VALUE"          "EXPIRATION"             "QUANTITY"               "UNDERLYING"            
[113] "OPTION_TYPE"            "STRIKE"                 "SECURITY"               "IDENTIFIER"            
[117] "proddat"                "UNDERLYING"             "BOOK_VALUE"             "DLAM.Asset.Type.3"     
[121] "CURRENCY"               "FXRATE"                 "PRICE"                  "CLIENT_NAME"           
[125] "PRODUCT_TYPE"           "DLAM.Asset.Type.3"      "MARKET_VALUE"           "NOMINAL_VALUE"         
[129] "CURRENCY"               "proddat"                "CURRENCY"               "DLAM.RATING"           
[133] "RatingClass"            "Drift"                  "Volatility"             "proddat"               
[137] "IDENTIFIER"             "CLIENT_NAME"            "PORTFOLIO_NAME"         "DLAM.Sector1"          
[141] "DLAM.Sector2"           "DLAM.Asset.Type.3"      "DLAM.Asset.Type.2"      "Teller"                
[145] "NOMINAL_VALUE"          "LossFraction"          
```

## Descriptions
The data element's definitions:

```
 Number          Data.element                                                                              Description
    DE1            BOOK_VALUE The value of an asset as it appears on a balance sheet, equal to cost minus accumulated 
    DE2           CLIENT_NAME                                                                       Name of the client
    DE3                COUPON                                                      Current coupon rate of Security (%)
    DE4              CURRENCY                                         The currency of the security (ISO Currency Code)
    DE5     DLAM.Asset.Type.2       State the asset type of the security (see Appendix E for Asset Tree specification)
    DE6     DLAM.Asset.Type.3       State the asset type of the security (see Appendix E for Asset Tree specification)
    DE7           DLAM.RATING                                                                   DLAM Composite rating 
    DE8          DLAM.Sector1                 If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
    DE9          DLAM.Sector2                 If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
   DE10          DLAM.Sector3                 If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
   DE11            EXPIRATION                                The last day that an options or futures contract is valid
   DE12                FXRATE                    The Conversion Rate EUR/Original Currency at T where T is Report Date
   DE13            IDENTIFIER                                                                 The ISIN of the security
   DE14            ISSUE_DATE                                                       Date on which a security is issued
   DE15          MARKET_VALUE The market value of the securities in EUR (including Accrued Interest),Cash Balance for 
   DE16              MATURITY                                                       Date of expiration of the Security
   DE17         NOMINAL_VALUE Nominal value of the Security excluding redemption/amortization, balance for Cash (origi
   DE18           OPTION_TYPE                                                              Type of option, Put or Call
   DE19     PAYMENT_FREQUENCY                             How often a dividend is paid by an individual stock or fund.
   DE20        PORTFOLIO_NAME                                                                    Name of the portfolio
   DE21                 PRICE    Close market price of the security at T where T is reporting date (original currency)
   DE22               proddat                                                                   Run date of the export
   DE23              QUANTITY                                                               Number of securities owned
   DE24              SECURITY                                                                         Identifying name
   DE25                STRIKE                       The price at which a specific derivative contract can be exercised
   DE26            UNDERLYING                                   Asset on which a futures contract or option is written
   DE27                  Type                                                                                  unknown
   DE28 Acrued Interest (Eur)                                                                                  unknown
   DE29           Cedar_BU_Nr                                                                                  unknown
   DE30             CUSTODIAN                                                                                  unknown
   DE31           Description                                                                                  unknown
   DE32       DLAMAssetClass1                                                                                  unknown
   DE33              Duration                                                                                  unknown
   DE34              Exchange                                                                                  unknown
   DE35            Fonds ISIN                                                                                  unknown
   DE36               FVLevel                                                                                  unknown
   DE37       Identifier-Type                                                                                  unknown
   DE38             Issuer-ID                                                                                  unknown
   DE39         IssuerID-Naam                                                                                  unknown
   DE40                Listed                                                                                  unknown
   DE41              Position                                                                                  unknown
   DE42         Purchase Cost                                                                                  unknown
   DE43             Risk Type                                                                                  unknown
   DE44       SecDescription2                                                                                  unknown
   DE45            Trade Date                                                                                  unknown
   DE46         Underlying BB                                                                                  unknown
   DE47             UNIT SIZE                                                                                  unknown
```


## Related Risks


```
      Data.element Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk
        BOOK_VALUE           1                 0             0           0
          Callable           0                 1             0           0
       CLIENT_NAME           0                 0             1           1
            COUPON           0                 1             0           0
        CTD.Coupon           0                 1             0           0
        CTD.Factor           0                 1             0           0
      CTD.Maturity           0                 1             0           0
         CTD.Price           0                 1             0           0
          CURRENCY           1                 1             1           0
 DLAM.Asset.Type.2           0                 0             0           1
 DLAM.Asset.Type.3           1                 1             1           1
       DLAM.RATING           0                 1             1           0
      DLAM.Sector1           0                 1             0           1
      DLAM.Sector2           0                 0             0           1
      DLAM.Sector3           0                 1             0           0
             Drift           0                 0             1           0
        EXPIRATION           1                 1             0           0
         FL.Spread           0                 1             0           0
            FXRATE           1                 0             0           0
        IDENTIFIER           1                 1             0           1
        ISSUE_DATE           0                 1             0           0
      LossFraction           0                 0             0           1
      MARKET_VALUE           0                 1             1           0
          MATURITY           0                 1             0           0
     NOMINAL_VALUE           1                 1             1           1
       OPTION_TYPE           1                 0             0           0
 PAYMENT_FREQUENCY           0                 1             0           0
    PORTFOLIO_NAME           1                 1             0           1
             PRICE           1                 1             0           0
           proddat           1                 0             1           1
      PRODUCT_TYPE           0                 0             1           0
          QUANTITY           1                 1             0           0
       RatingClass           0                 0             1           0
          SECURITY           1                 0             0           0
   Spread.Duration           0                 1             0           0
            STRIKE           1                 1             0           0
            Teller           0                 0             0           1
              Type           0                 1             0           0
        UNDERLYING           1                 0             0           0
        Volatility           0                 0             1           0
               WAL           0                 1             0           0
       WorkOutDate           0                 1             0           0
```
There are 42 fields ('Data elements') used by the FRM stress tools.

Risks are defined in terms of FRM database data elements. Therefore first exported elements have to be mapped to FRM data elements.

All frm data elements used in any risk:

```
 [1] "BOOK_VALUE"        "Callable"          "CLIENT_NAME"       "COUPON"            "CTD.Coupon"       
 [6] "CTD.Factor"        "CTD.Maturity"      "CTD.Price"         "CURRENCY"          "DLAM.Asset.Type.2"
[11] "DLAM.Asset.Type.3" "DLAM.RATING"       "DLAM.Sector1"      "DLAM.Sector2"      "DLAM.Sector3"     
[16] "Drift"             "EXPIRATION"        "FL.Spread"         "FXRATE"            "IDENTIFIER"       
[21] "ISSUE_DATE"        "LossFraction"      "MARKET_VALUE"      "MATURITY"          "NOMINAL_VALUE"    
[26] "OPTION_TYPE"       "PAYMENT_FREQUENCY" "PORTFOLIO_NAME"    "PRICE"             "proddat"          
[31] "PRODUCT_TYPE"      "QUANTITY"          "RatingClass"       "SECURITY"          "Spread.Duration"  
[36] "STRIKE"            "Teller"            "Type"              "UNDERLYING"        "Volatility"       
[41] "WAL"               "WorkOutDate"      
```

There have been made 3 changes to the mapping provided by FRM:

* The FRM Data.element 'Country of Risk' has been renamed to COUNTRY. 
Only 'PositionTotalViewFI' contains both columns, while the other exports's columns with names similar to 'Country of Risk' are mapped to Country.
* 'Spread' has been renamed to 'Current Spread'. It only occurs in Germany_TotalHist and is mapped to 'Current Spread' in PositionTotalViewFI, while the 'Current Spread' Data.element is also mapped to 'Current Spread' in PositionTotalViewFI.
* 'SourceDate' has been renamed to 'proddat'. The columns being mapped to SourceDate are all called proddat, and only PositionTotalViewFI contains a value SourceDate which is mapped to the SourceDate Data.element. In perspective of the FRM the proddat's of the exports are source date's.  




## Portia complete system


There are 26  data elements in Portia (from Portia_SecsHld, Portia_TotalHist, Portia_Total_MonthlyHist) used in any risk:

```
  Portia_SecsHld Portia_TotalHist Portia_Total_MonthlyHist      Data.element Equity.Risk Asset.Stress.Test
                       BOOK_VALUE               BOOK_VALUE        BOOK_VALUE           1                 0
                       CLIENTNAAM               CLIENTNAAM       CLIENT_NAME           0                 0
          COUPON       COUPONRATE               COUPONRATE            COUPON           0                 1
          SYMBOL             MUNT                     MUNT          CURRENCY           1                 1
 DLAMAssetClass2  DLAMAssetClass2          DLAMAssetClass2 DLAM.Asset.Type.2           0                 0
 DLAMAssetClass3  DLAMAssetClass3          DLAMAssetClass3 DLAM.Asset.Type.3           1                 1
      DLAMRating         DLRating                 DLRating       DLAM.RATING           0                 1
     DLAMSector1      DLAMSector1              DLAMSector1      DLAM.Sector1           0                 1
     DLAMSector2      DLAMSector2              DLAMSector2      DLAM.Sector2           0                 0
     DLAMSector3      DLAMSector3              DLAMSector3      DLAM.Sector3           0                 1
                   Expirationdate           Expirationdate        EXPIRATION           1                 1
                           FXRATE                   FXRATE            FXRATE           1                 0
            ISIN             ISIN                     ISIN        IDENTIFIER           1                 1
       IssueDate        Issuedate                Issuedate        ISSUE_DATE           0                 1
                      MWinclLREur              MWinclLREur      MARKET_VALUE           0                 1
       MaturityD     MaturityDate             MaturityDate          MATURITY           0                 1
                      NominaalEur              NominaalEur     NOMINAL_VALUE           1                 1
                      Option_type              Option_type       OPTION_TYPE           1                 0
                 PaymentFrequency         PaymentFrequency PAYMENT_FREQUENCY           0                 1
                    PortfolioNaam            PortfolioNaam    PORTFOLIO_NAME           1                 1
                            KOERS                    KOERS             PRICE           1                 1
         rundate    ReportingDate            ReportingDate           proddat           1                 0
                         QUANTITY                 QUANTITY          QUANTITY           1                 1
            Name     Securitynaam             Securitynaam          SECURITY           1                 0
                           STRIKE                   STRIKE            STRIKE           1                 1
                       UNDERLYING               UNDERLYING        UNDERLYING           1                 0
 Currency.Risk Credit.Risk
             0           0
             1           1
             0           0
             1           0
             0           1
             1           1
             1           0
             0           1
             0           1
             0           0
             0           0
             0           0
             0           1
             0           0
             1           0
             0           0
             1           1
             0           0
             0           0
             0           1
             0           0
             1           1
             0           0
             0           0
             0           0
             0           0
```



## Front Arena
Changes to scoping based on data: 

 - UNDERLYING looks like it is in scope, but it is not, because:
   - While it is contained in the DLDerivativesReportRisk export
   - While it is contained in the DLDerivativesReportRiskHist table of FRM's Load Validation Tool
   - While it is contained in the Dimensions.Security table of FRM's dB
   - While it is marked to be in scope for Portia
   - The Underlying column in FRM's dB contains only NULLs for records originating from FA
 - TYPE as defined in the scope by FRM actually does not exist in the FA\_DerivativesHist export, it is in another file named DLDerivativesReportRisk2015-01-08.csv, with header CallOrPut. It contains only Payer, Receiver or an empty string.
   
The following mapping from data element to database column is used. This is based on column names, database meta-structure, information from the business and contents. For further details see frontarena_scopingdetails.html. 

```
      Data.element  Export.element
            COUPON       coup_rate
          CURRENCY      curr_insid
 DLAM.Asset.Type.2 DLAMAssetClass2
 DLAM.Asset.Type.3 DLAMAssetClass3
       DLAM.RATING      DLAMRating
      DLAM.Sector1     DLAMSector1
      DLAM.Sector2     DLAMSector2
      DLAM.Sector3     DLAMSector3
        EXPIRATION         exp_day
            FXRATE          FXRate
        IDENTIFIER           insid
        ISSUE_DATE       issue_day
      MARKET_VALUE    MARKET_VALUE
          MATURITY        MATURITY
     NOMINAL_VALUE   NOMINAL_VALUE
    PORTFOLIO_NAME           prfid
             PRICE           PRICE
           proddat         proddat
            STRIKE    strike_price
              Type       CallOrPut
```


There are 20  data elements in Front Arena (from FA_LosHist, FA_DerivativesHist, FrontArenaDB) used in any risk:

```
      FA_LosHist FA_DerivativesHist    FrontArenaDB      Data.element Equity.Risk Asset.Stress.Test Currency.Risk
  Rec.Fixed.Rate             Coupon       coup_rate            COUPON           0                 1             0
        Currency           Currency      curr_insid          CURRENCY           1                 1             1
 DLAMAssetClass2    DLAMAssetClass2 DLAMAssetClass2 DLAM.Asset.Type.2           0                 0             0
 DLAMAssetClass3    DLAMAssetClass3 DLAMAssetClass3 DLAM.Asset.Type.3           1                 1             1
     DLAM.Rating        DLAM.Rating      DLAMRating       DLAM.RATING           0                 1             1
   DLAM.Sector.1      DLAM.Sector.1     DLAMSector1      DLAM.Sector1           0                 1             0
   DLAM.Sector.2      DLAM.Sector.2     DLAMSector2      DLAM.Sector2           0                 0             0
   DLAM.Sector.3      DLAM.Sector.3     DLAMSector3      DLAM.Sector3           0                 1             0
                             Expiry         exp_day        EXPIRATION           1                 1             0
          DispFx             DispFx          FXRate            FXRATE           1                 0             0
 Instrument.Name    Instrument.Name           insid        IDENTIFIER           1                 1             0
                          StartDate       issue_day        ISSUE_DATE           0                 1             0
         Val.End      Val.End..EUR.    MARKET_VALUE      MARKET_VALUE           0                 1             1
   Maturity.Date      Maturity.Date        MATURITY          MATURITY           0                 1             0
            None       Nominal.EUR.   NOMINAL_VALUE     NOMINAL_VALUE           1                 1             1
  Portfolio.Name     Portfolio.Name           prfid    PORTFOLIO_NAME           1                 1             0
           Price              Price           PRICE             PRICE           1                 1             0
         proddat            proddat         proddat           proddat           1                 0             1
                             Strike    strike_price            STRIKE           1                 1             0
                               Type       CallOrPut              Type           0                 1             0
 Credit.Risk
           0
           0
           1
           1
           0
           1
           1
           0
           0
           0
           1
           0
           0
           0
           1
           1
           0
           1
           0
           0
```




## Globe$ complete system


There are 16  data elements in Globe\$ (from Cash_TotalHist, ForwardsHist) used in any risk:

```
   Cash_TotalHist      ForwardsHist      Data.element Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk
         Currency          Currency          CURRENCY           1                 1             1           0
  DL.Asset.Type.2   DL.Asset.Type.2 DLAM.Asset.Type.2           0                 0             0           1
  DL.Asset.Type.3   DL.Asset.Type.3 DLAM.Asset.Type.3           1                 1             1           1
      DL.Sector.1       DL.Sector.1      DLAM.Sector1           0                 1             0           1
      DL.Sector.2       DL.Sector.2      DLAM.Sector2           0                 0             0           1
      DL.Sector.3       DL.Sector.3      DLAM.Sector3           0                 1             0           0
                          spot.rate            FXRATE           1                 0             0           0
               ID                ID        IDENTIFIER           1                 1             0           1
 Bedrag.in.EURO.S      Mktval..EUR.      MARKET_VALUE           0                 1             1           0
                        Settle.date          MATURITY           0                 1             0           0
 Bedrag.in.EURO.S   Nominal..local.     NOMINAL_VALUE           1                 1             1           1
 Portfolio_portia  Portfolio_portia    PORTFOLIO_NAME           1                 1             0           1
                  spot.rate..trade.             PRICE           1                 1             0           0
          proddat           proddat           proddat           1                 0             1           1
                    Nominal..local.          QUANTITY           1                 1             0           0
                        Description          SECURITY           1                 0             0           0
```



## VIS complete system


There are 15  data elements in VIS (from PropertyHist) used in any risk:

```
    PropertyHist      Data.element Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk
      BOOK_VALUE        BOOK_VALUE           1                 0             0           0
     CLIENT_NAME       CLIENT_NAME           0                 0             1           1
        CURRENCY          CURRENCY           1                 1             1           0
 DL.Asset.Type.2 DLAM.Asset.Type.2           0                 0             0           1
 DL.Asset.Type.3 DLAM.Asset.Type.3           1                 1             1           1
     DL.Sector.1      DLAM.Sector1           0                 1             0           1
     DL.Sector.2      DLAM.Sector2           0                 0             0           1
     DL.Sector.3      DLAM.Sector3           0                 1             0           0
          FXRATE            FXRATE           1                 0             0           0
      IDENTIFIER        IDENTIFIER           1                 1             0           1
    MARKET_VALUE      MARKET_VALUE           0                 1             1           0
   NOMINAL_VALUE     NOMINAL_VALUE           1                 1             1           1
  PORTFOLIO_NAME    PORTFOLIO_NAME           1                 1             0           1
         proddat           proddat           1                 0             1           1
        SECURITY          SECURITY           1                 0             0           0
```



## Other fields related to risks

There are 5 exports not mentioned in the complete system's risks (PosType, Germany_TotalHist, Private_EquityHist, ScalediBoxxEURView, PositionTotalViewFI).

There are 15  data elements related to risks that are not in any previous export:

```
    Data.element Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk
        Callable           0                 1             0           0
      CTD.Coupon           0                 1             0           0
      CTD.Factor           0                 1             0           0
    CTD.Maturity           0                 1             0           0
       CTD.Price           0                 1             0           0
           Drift           0                 0             1           0
       FL.Spread           0                 1             0           0
    LossFraction           0                 0             0           1
    PRODUCT_TYPE           0                 0             1           0
     RatingClass           0                 0             1           0
 Spread.Duration           0                 1             0           0
          Teller           0                 0             0           1
      Volatility           0                 0             1           0
             WAL           0                 1             0           0
     WorkOutDate           0                 1             0           0
```
The following risks have been defined:

```
      Data.element n_risks Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk
        BOOK_VALUE       1           1                 0             0           0
          Callable       1           0                 1             0           0
       CLIENT_NAME       2           0                 0             1           1
            COUPON       1           0                 1             0           0
        CTD.Coupon       1           0                 1             0           0
        CTD.Factor       1           0                 1             0           0
      CTD.Maturity       1           0                 1             0           0
         CTD.Price       1           0                 1             0           0
          CURRENCY       3           1                 1             1           0
 DLAM.Asset.Type.2       1           0                 0             0           1
 DLAM.Asset.Type.3       4           1                 1             1           1
       DLAM.RATING       2           0                 1             1           0
      DLAM.Sector1       2           0                 1             0           1
      DLAM.Sector2       1           0                 0             0           1
      DLAM.Sector3       1           0                 1             0           0
             Drift       1           0                 0             1           0
        EXPIRATION       2           1                 1             0           0
         FL.Spread       1           0                 1             0           0
            FXRATE       1           1                 0             0           0
        IDENTIFIER       3           1                 1             0           1
        ISSUE_DATE       1           0                 1             0           0
      LossFraction       1           0                 0             0           1
      MARKET_VALUE       2           0                 1             1           0
          MATURITY       1           0                 1             0           0
     NOMINAL_VALUE       4           1                 1             1           1
       OPTION_TYPE       1           1                 0             0           0
 PAYMENT_FREQUENCY       1           0                 1             0           0
    PORTFOLIO_NAME       3           1                 1             0           1
             PRICE       2           1                 1             0           0
           proddat       3           1                 0             1           1
      PRODUCT_TYPE       1           0                 0             1           0
          QUANTITY       2           1                 1             0           0
       RatingClass       1           0                 0             1           0
          SECURITY       1           1                 0             0           0
   Spread.Duration       1           0                 1             0           0
            STRIKE       2           1                 1             0           0
            Teller       1           0                 0             0           1
              Type       1           0                 1             0           0
        UNDERLYING       1           1                 0             0           0
        Volatility       1           0                 0             1           0
               WAL       1           0                 1             0           0
       WorkOutDate       1           0                 1             0           0
```







