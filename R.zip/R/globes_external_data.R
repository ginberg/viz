#Reads data from locations not managed by git
source("R/config.R")
source("R/source.reat.R")

destination_connect <- function(){db.connect(sourcedata_connection)}

# Created by running the fxpms.sql query on the globe$ database in the oracle environment of DeltaLloyd
gl_fxpms<-list(
			destination=destination_connect,
			name="GL_fxpms",
			origin = globespath(globes_fx_pms_file),
			read=function(x) read.csv2(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			  typechanges=list(
			  list(trynumeric=T, Date.format="%d-%m-%Y", col.ignore=c("ACCOUNT_NO","ACCOUNT_NO_1"))
			),
			constants = list(source_date = as.Date(source_date_gl_f)),
			val_col = "BUY_AMOUNT"
)

# Transactions exported from the bloomberg interface
gl_fxbloomberg <- list(
			destination=destination_connect,
			name="GL_fxbloomberg",
			origin = globespath(globes_fx_hb_file),
			read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			  typechanges=list( # list of all transformations in order 
				list(trynumeric=T),
				list(POSIXct.format="%m/%d/%Y %H:%M"),
				list(Date.format="%m/%d/%Y")),
			constants = list(source_date = as.Date(source_date_gl_f)),
			val_col = "Trader"
)

# Received the RISK  FORWARDS.xls from treasury, exported the sheet 'openstaande fx deals' to a csv file
gl_xls_fxpms <- list(
			destination=destination_connect,
			name="GL_xls_fxpms",
			origin = globespath(globes_risk_ff_deals_file),
			read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			typechanges=list( # list of all transformations in order 
			  list(POSIXct.call=list(format="%d-%m-%Y %H:%M:%S"))
			),
			constants = list(source_date = as.Date(source_date_gl_f)),
			val_col = "abs_rate"
)

# Received the RISK  FORWARDS.xls from treasury, exported the sheet forwards' to a csv file
gl_xls_riskforwards <- list(
			destination=destination_connect,
			name="GL_xls_riskforwards",
			origin = globespath(globes_risk_ff_file),
			read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			  typechanges=list( # list of all transformations in order 
    			list(POSIXct.format="%d-%m-%Y %H:%M:%S")
			  ),
			constants = list(source_date = as.Date(source_date_gl_f)),
			val_col = "portfolio"
)

# Received the RISK  FORWARDS.xls from treasury, exported the sheet 'globescode_to_portia' to a csv file
gl_xls_rf_globescode_to_portia  <- list(
			destination=destination_connect,
			name="GL_xls_rf_globescode_to_portia",
			origin = globespath(globes_risk_ff_code_file),
			read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			typechanges=list( # list of all transformations in order 
			),
			row.names=T,
			constants = list(source_date = as.Date(source_date_gl_f)),
			val_col = "Portia code"
)

# Received the RISK  FORWARDS.xls from treasury, exported the table  'portfolio_to_typegeld' to a csv file
gl_xls_rf_portfolio_to_typegeld  <- list(
			destination=destination_connect,
			name="GL_xls_rf_portfolio_to_geld",
			origin = globespath(globes_risk_ff_type_file),
			read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			typechanges=list( # list of all transformations in order 
			),
			constants = list(source_date = as.Date(source_date_gl_f)),
			val_col = "Typegeld"
)

# Received the Limieten gesplitst naar Eigen Geld.xls from treasury, exported the sheet 'verzamelrisk' to a csv file
gl_xls_cashrisk  <- list(
			destination=destination_connect,
			name="GL_xls_cashrisk",
			origin = globespath(globes_limit_file),
			read=function(x) read.csv(x, na.strings=c(), stringsAsFactors = FALSE, check.names=F),
			typechanges=list( # list of all transformations in order 
			  list(trynumeric=T,Date.format="%d-%m-%y")
			),
		  cols.keep=c("DL Asset Type 3"),
			constants = list(source_date = as.Date(source_date_gl_f)),
			val_col = "ID"
)

# For one date, the closing rate of many currencies
gl_fxs <- list(
		destination=destination_connect,
    name="GL_exchangerates",
    origin = globespath(globes_fx_file),
    read = function(x) read.csv(x, na.strings=c(''), header=T),
    typechanges=list(
					list(trynumeric=T, Date.format="%d/%m/%y")
					),
    filter=list(
      list(col.name=c(),
         value=NA,
         type="is.na",
         keep=F)
    ),
		constants = list(source_date = as.Date(source_date_gl_f)),
		val_col = "WISSELKOERS"
)
