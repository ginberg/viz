#Reads data from locations not managed by git
source("R/config.R")

destination_connect <- function(){db.connect(sourcedata_connection)}

vispath <- function(filename){
  return(file.path(dlam_data_path, "VIS_exports", filename))
}

vis_d_vgd_cmplx_def <-list(
			destination=destination_connect,
			name="VIS_DM_D_VGD_CMPLX",
			 origin = vispath("DM_D_VGD_CMPLX 20151209.csv"),
			 read=function(x) read.csv2(x, sep="|", na.strings=c(), stringsAsFactors = TRUE, check.names=F),
			  typechanges=list(
				list(trynumeric=T, col.ignore="KDSTR_NR_OMS"),
				list(POSIXct.format= "%d-%m-%y")
			  ),
			constants = list(source_date = as.Date("2015-07-31"))
)

vis_d_vgd_my_def <- list(
			destination=destination_connect,
			name = "VIS_DM_D_VGD_MY",
			 origin = vispath("DM_D_VGD_MY 20151209.csv"),
			 read=function(x) read.csv2(x, sep="|", na.strings=c(), stringsAsFactors = TRUE, check.names=F),
			  typechanges=list(
				list(trynumeric=T),
				list(POSIXct.format= "%d-%m-%y")
			  ),
			constants = list(source_date = as.Date("2015-01-31"))
			)

vis_f_vgd_fin_gev_def <- list(
			destination = destination_connect,
			name = "VIS_DM_F_VGD_FIN_GEV",
			origin = vispath("DM_F_VGD_FIN_GEV 20151209.csv"),
			read = function(x) read.csv2(x, sep="|", na.strings=c(), stringsAsFactors = TRUE, check.names=F),
			typechanges = list(
				list(trynumeric = T),
				list(POSIXct.format = "%d-%m-%y")
							   ),
			constants = list(source_date = as.Date("2015-01-31"))
			)

vis_d_vgd_rap_maand_def <- list(
			destination = destination_connect,
			name = "VIS_DM_V_VGD_RAP_MAAND",
			origin = vispath("DM_V_VGD_RAP_MAAND 20151209.csv"),
			read = function(x) read.csv(x, sep="|", na.strings=c(), stringsAsFactors = TRUE, check.names=F),
			typechanges = list(
				list(trynumeric = T),
				list(POSIXct.format = "%d-%m-%y")
				),
			constants = list(source_date = as.Date("2015-01-31"))
			)

vis_directproperty_def <- list(
			destination = destination_connect,
			name = "VIS_DL_Direct_Property",
			#origin = vispath("DL Direct Property 2015-07-31 Solvency.csv"),
      origin = vispath("DL Direct Property 2015-11-30 Solvency.csv"),
      read = function(x) read.csv(x, na.strings=c(), stringsAsFactors = TRUE, check.names=F, strip.white=T),
			typechanges = list(
				list(trynumeric = T),
				list(POSIXct.format = "%d-%m-%Y")
				),
			constants = list(source_date = as.Date("2015-11-31"))
			)

