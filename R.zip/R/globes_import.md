---
title: "Globe\$ import"
output: html_document
---




# Data Import

The data can contain the different values indicating one actual value (think of "Y" and "YES", or "-" and "n/a"). This report explains which value inconsistencies were found and how they have been normalized.





# RiskForwards

```r
void <-globes.load(gl_fxpms)
```

DEBUG [2016-04-25 14:20:14] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 3 - Globe$/20160426/fxpms.csv
Preprocessing data read from *fxpms.csv*  

```
[1] "Columns with only <NA> values are removed : CODE_6"
```
Final column names of original dataframe:  

```
 [1] "TRADING_DATE"    "CODE"            "CODE_1"          "NAME"            "SETTLEMENT_DATE" "BUY_AMOUNT"     
 [7] "CODE_2"          "ACCOUNT_NO"      "CODE_3"          "SELL_AMOUNT"     "CODE_4"          "ACCOUNT_NO_1"   
[13] "CODE_5"          "SPOT_RATE"       "POINTS"          "ABS_RATE"        "NAME_1"          "CODE_6"         
[19] "AUTHORIZE_FLAG"  "GENERALLEDGER"   "TIME_STAMP"     
```
Converted column TRADING_DATE to Date (format=%d-%m-%Y)  with no failures on 253 nonempty values.  
Converted column SETTLEMENT_DATE to Date (format=%d-%m-%Y)  with no failures on 253 nonempty values.  
Converted column TIME_STAMP to Date (format=%d-%m-%Y)  with no failures on 253 nonempty values.  
DEBUG [2016-04-25 14:20:14] Saving data to table GL_fxpms

```
DEBUG [2016-04-25 14:20:15] Validate, rowcount for dataset GL_fxpms_orig, file: 253, table: 253
DEBUG [2016-04-25 14:20:15] Validate, columncount for dataset GL_fxpms_orig, file: 21, table: 21
DEBUG [2016-04-25 14:20:15] Validate, hashtotal for dataset GL_fxpms_orig, column BUY_AMOUNT, file: 52899946349.0708, table: 52899946349.0708
DEBUG [2016-04-25 14:20:15] Validate, rowcount for dataset GL_fxpms, file: 253, table: 253
DEBUG [2016-04-25 14:20:15] Validate, columncount for dataset GL_fxpms, file: 25, table: 25
DEBUG [2016-04-25 14:20:15] Validate, hashtotal for dataset GL_fxpms, column BUY_AMOUNT, file: 52899946349.0708, table: 52899946349.0708

```

Saved processed file originating from  *fxpms.csv* in the database as table named  **GL_fxpms**   

# BloomBerg reference data

```r
void <-globes.load(gl_fxbloomberg)
```

DEBUG [2016-04-25 14:20:15] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 3 - Globe$/20160426/fxhb.csv
Preprocessing data read from *fxhb.csv*  

```
There are 5 columns with name 'account', they have been given numeric suffixes.  
There are 4 columns with name 'account number', they have been given numeric suffixes.  
There are 6 columns with name 'all-in rate', they have been given numeric suffixes.  
There are 5 columns with name 'amount', they have been given numeric suffixes.  
There are 4 columns with name 'bank', they have been given numeric suffixes.  
There are 4 columns with name 'beneficiary', they have been given numeric suffixes.  
There are 4 columns with name 'branch', they have been given numeric suffixes.  
There are 5 columns with name 'cost savings', they have been given numeric suffixes.  
There are 6 columns with name 'counterparty', they have been given numeric suffixes.  
There are 4 columns with name 'custodian', they have been given numeric suffixes.  
There are 5 columns with name 'far all-in', they have been given numeric suffixes.  
There are 5 columns with name 'far points', they have been given numeric suffixes.  
There are 6 columns with name 'gross rate', they have been given numeric suffixes.  
There are 5 columns with name 'nts all-in', they have been given numeric suffixes.  
There are 5 columns with name 'nts far all-in', they have been given numeric suffixes.  
There are 5 columns with name 'nts far points', they have been given numeric suffixes.  
There are 5 columns with name 'nts gross rate', they have been given numeric suffixes.  
There are 5 columns with name 'nts points', they have been given numeric suffixes.  
There are 5 columns with name 'nts profit sharing ratio', they have been given numeric suffixes.  
There are 5 columns with name 'nts spot rate', they have been given numeric suffixes.  
There are 5 columns with name 'points', they have been given numeric suffixes.  
There are 4 columns with name 'prime broker', they have been given numeric suffixes.  
There are 6 columns with name 'profit sharing ratio', they have been given numeric suffixes.  
There are 5 columns with name 'side', they have been given numeric suffixes.  
There are 4 columns with name 'special instructions', they have been given numeric suffixes.  
There are 6 columns with name 'spot rate', they have been given numeric suffixes.  
There are 4 columns with name 'swift / aba code', they have been given numeric suffixes.  
There are 5 columns with name 'uti id', they have been given numeric suffixes.  
There are 5 columns with name 'uti prefix', they have been given numeric suffixes.  
[1] "Columns with only <NA> values are removed : Salesperson, Ctpy ID 1, Ctpy ID 2, Ctpy ID 3, Ctpy ID 4, Exec ID, Order Type, Order Strategy, Rate Type, Early Withdrawals, Maker Notes, ACC End Date, ACE End Date, Net Value, Profit Amount, gross rate1, profit sharing ratio1, Split Tenor Ccy1, Split Value Date Ccy1, Split Tenor Ccy2, Split Value Date Ccy2, Trader LEI Name, Ctpy LEI Name, Block Trade, Banknotes Rate Type, Commission, Delivery Date, Denomination/Quality, Delivery Details, Inception Fixing Date, custom1, custom2, custom3, custom4, custom5, prime broker1, swift / aba code1, branch1, prime broker2, swift / aba code2, account number2, bank2, branch2, beneficiary2, special instructions2, account4, amount4, side4, custodian3, prime broker3, swift / aba code3, account number3, bank3, branch3, beneficiary3, special instructions3, uti prefix4, uti id4, account5, amount5, side5, custodian4, prime broker4, swift / aba code4, account number4, bank4, branch4, beneficiary4, special instructions4, uti prefix5, uti id5, gross rate2, profit sharing ratio2, nts far points1, nts far all-in1, nts gross rate1, nts profit sharing ratio1, cost savings1, far points2, far all-in2, gross rate3, profit sharing ratio3, nts far points2, nts far all-in2, nts gross rate2, nts profit sharing ratio2, far points3, far all-in3, gross rate4, profit sharing ratio4, nts far points3, nts far all-in3, nts gross rate3, nts profit sharing ratio3, far points4, far all-in4, gross rate5, profit sharing ratio5, nts far points4, nts far all-in4, nts gross rate4, nts profit sharing ratio4, spot rate6, points5, all-in rate6, far points5, far all-in5, gross rate6, profit sharing ratio6, nts spot rate5, nts points5, nts all-in5, nts far points5, nts far all-in5, nts gross rate5, nts profit sharing ratio5"
```
Final column names of original dataframe:  

```
  [1] "Date/Time"                     "Trader"                        "Ccys"                         
  [4] "side1"                         "Tenor"                         "Value Date"                   
  [7] "Ccy"                           "amount1"                       "Deal Code"                    
 [10] "all-in rate1"                  "Allocated"                     "Notes"                        
 [13] "Amount Ccy1"                   "Amount Ccy2"                   "Days"                         
 [16] "BB Ind Rate (Traded Side)"     "BB Ind Rate (Non Traded Side)" "BB Mid Rate"                  
 [19] "Mid Market Rate"               "Trade ID"                      "Interest"                     
 [22] "counterparty1"                 "Salesperson"                   "Ctpy ID 1"                    
 [25] "Ctpy ID 2"                     "Ctpy ID 3"                     "Ctpy ID 4"                    
 [28] "Ctpy Side"                     "account1"                      "Exec ID"                      
 [31] "Extern Ref ID"                 "Fixing Date"                   "Set Ccy"                      
 [34] "Swap Points"                   "spot rate1"                    "New/Roll"                     
 [37] "Instrx"                        "Deal Type"                     "Role"                         
 [40] "Trade Date"                    "Status"                        "Fwd Points"                   
 [43] "Order Type"                    "Order Strategy"                "Rate Type"                    
 [46] "Early Withdrawals"             "Start Date"                    "End Date"                     
 [49] "uti prefix1"                   "uti id1"                       "Route Time"                   
 [52] "Staged Time"                   "Product"                       "Ctpy Trader"                  
 [55] "Deal Subtype"                  "Maker Notes"                   "ACC Days"                     
 [58] "ACC End Date"                  "ACE Days"                      "ACE End Date"                 
 [61] "Net Value"                     "FX Rate"                       "Profit Amount"                
 [64] "gross rate1"                   "profit sharing ratio1"         "TCA Ref Rate"                 
 [67] "Added Value"                   "Added Value (USD)"             "Split Tenor Ccy1"             
 [70] "Split Value Date Ccy1"         "Split Tenor Ccy2"              "Split Value Date Ccy2"        
 [73] "Market Type Ccy1"              "Market Type Ccy2"              "Amount Ccy1 (USD)"            
 [76] "Amount Ccy2 (USD)"             "Trader LEI Name"               "Ctpy LEI Name"                
 [79] "SEF Trade"                     "Block Trade"                   "Leg ID"                       
 [82] "Banknotes Rate Type"           "Commission"                    "Delivery Date"                
 [85] "Denomination/Quality"          "Delivery Details"              "Start Tenor"                  
 [88] "End Tenor"                     "Fixing Source"                 "Inception Fixing Date"        
 [91] "Inception Fixing Source"       "Contra Ccy"                    "Contra Amount"                
 [94] "custom1"                       "custom2"                       "custom3"                      
 [97] "custom4"                       "custom5"                       "account2"                     
[100] "amount2"                       "side2"                         "custodian1"                   
[103] "prime broker1"                 "swift / aba code1"             "account number1"              
[106] "bank1"                         "branch1"                       "beneficiary1"                 
[109] "special instructions1"         "uti prefix2"                   "uti id2"                      
[112] "account3"                      "amount3"                       "side3"                        
[115] "custodian2"                    "prime broker2"                 "swift / aba code2"            
[118] "account number2"               "bank2"                         "branch2"                      
[121] "beneficiary2"                  "special instructions2"         "uti prefix3"                  
[124] "uti id3"                       "account4"                      "amount4"                      
[127] "side4"                         "custodian3"                    "prime broker3"                
[130] "swift / aba code3"             "account number3"               "bank3"                        
[133] "branch3"                       "beneficiary3"                  "special instructions3"        
[136] "uti prefix4"                   "uti id4"                       "account5"                     
[139] "amount5"                       "side5"                         "custodian4"                   
[142] "prime broker4"                 "swift / aba code4"             "account number4"              
[145] "bank4"                         "branch4"                       "beneficiary4"                 
[148] "special instructions4"         "uti prefix5"                   "uti id5"                      
[151] "counterparty2"                 "spot rate2"                    "points1"                      
[154] "all-in rate2"                  "far points1"                   "far all-in1"                  
[157] "gross rate2"                   "profit sharing ratio2"         "nts spot rate1"               
[160] "nts points1"                   "nts all-in1"                   "nts far points1"              
[163] "nts far all-in1"               "nts gross rate1"               "nts profit sharing ratio1"    
[166] "cost savings1"                 "counterparty3"                 "spot rate3"                   
[169] "points2"                       "all-in rate3"                  "far points2"                  
[172] "far all-in2"                   "gross rate3"                   "profit sharing ratio3"        
[175] "nts spot rate2"                "nts points2"                   "nts all-in2"                  
[178] "nts far points2"               "nts far all-in2"               "nts gross rate2"              
[181] "nts profit sharing ratio2"     "cost savings2"                 "counterparty4"                
[184] "spot rate4"                    "points3"                       "all-in rate4"                 
[187] "far points3"                   "far all-in3"                   "gross rate4"                  
[190] "profit sharing ratio4"         "nts spot rate3"                "nts points3"                  
[193] "nts all-in3"                   "nts far points3"               "nts far all-in3"              
[196] "nts gross rate3"               "nts profit sharing ratio3"     "cost savings3"                
[199] "counterparty5"                 "spot rate5"                    "points4"                      
[202] "all-in rate5"                  "far points4"                   "far all-in4"                  
[205] "gross rate5"                   "profit sharing ratio5"         "nts spot rate4"               
[208] "nts points4"                   "nts all-in4"                   "nts far points4"              
[211] "nts far all-in4"               "nts gross rate4"               "nts profit sharing ratio4"    
[214] "cost savings4"                 "counterparty6"                 "spot rate6"                   
[217] "points5"                       "all-in rate6"                  "far points5"                  
[220] "far all-in5"                   "gross rate6"                   "profit sharing ratio6"        
[223] "nts spot rate5"                "nts points5"                   "nts all-in5"                  
[226] "nts far points5"               "nts far all-in5"               "nts gross rate5"              
[229] "nts profit sharing ratio5"     "cost savings5"                
```
Converted column allinrate1 to numeric  but had 27 failed conversions. The unique values:'-0.19%','-0.18%','-1.18%','-0.52%','-0.17%','-0.16%'
Converted column Notes to numeric  but had 68 failed conversions. The unique values:'sell 13mln hkd to buy eur in apf','sell 250mln jpy to buy eur in apf','sell 1.9mln nzd to buy eur in apf.','DSTA leent van Delta Loyd Tre','sell 10mln hkd to buy aud in apf','sell 10mln hkd to buy jpy in apf','sell 5mln nzd to buy eur in adf','sell 12mln hkd to buy jpy in adf','sell 20mln hkd to buy eur in adf','sell 2mln usd to buy jpy in apf','SELL 1.2MLN USD TO BUY JPY IN APF','#N/A','sell 19mln hkd to buy eur in apf','sell 70mln hkd to buy eur in adf','sell usd to buy 5mln eur in apf','sell 5mln usd to buy eur in adf','sell 11mln nzd to buy eur in adf','sell aud to buy 1.5mln eur in adf','sell 5mln usd to buy eur in apf','sell 70mln hkd to buy eur in apf','USD account: 228354013,EUR acc 223501751','sell 2mln usd to buy jpy for adf','delta lloyd Treasury','DL Treasury','convert AUD to 2mln eur in apf','buy 1.5mln sgd for apf','XDELDLC','DL Treasury BV lends Barclays Bnk PLC Ln','buy 2mln eur for adf','buy 9mln eur for adf','buy 9mln eur for apf','buy 150mln twd for adf','Account PFCBH','DL Treasury BV lends Dutch State Treasur','dsta leent van DL-TREASURY'
DEBUG [2016-04-25 14:20:18] Saving data to table GL_fxbloomberg

```
DEBUG [2016-04-25 14:20:27] Validate, rowcount for dataset GL_fxbloomberg_orig, file: 2052, table: 2052
DEBUG [2016-04-25 14:20:27] Validate, columncount for dataset GL_fxbloomberg_orig, file: 230, table: 230
DEBUG [2016-04-25 14:20:27] Validate, hashtotal for dataset GL_fxbloomberg_orig, column Trader, file: 18717, table: 18717
DEBUG [2016-04-25 14:20:33] Validate, rowcount for dataset GL_fxbloomberg, file: 2052, table: 2052
DEBUG [2016-04-25 14:20:33] Validate, columncount for dataset GL_fxbloomberg, file: 116, table: 116
DEBUG [2016-04-25 14:20:33] Validate, hashtotal for dataset GL_fxbloomberg, column Trader, file: 18717, table: 18717

```

Saved processed file originating from  *fxhb.csv* in the database as table named  **GL_fxbloomberg**   

# RISK FORWARDS xls - openstaande FX deals

```r
void <-globes.load(gl_xls_fxpms)
```

DEBUG [2016-04-25 14:20:35] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 3 - Globe$/20160426/RISK  FORWARDS_openstaande fxdeals.csv
Preprocessing data read from *RISK  FORWARDS_openstaande fxdeals.csv*  

```
Thera are 1 empty column names at indices 20, they have been given name X with numeric sufixes:
There are 2 columns with name 'account_no', they have been given numeric suffixes.  
There are 6 columns with name 'code', they have been given numeric suffixes.  
There are 2 columns with name 'generalledger', they have been given numeric suffixes.  
There are 2 columns with name 'id type', they have been given numeric suffixes.  
There are 2 columns with name 'name', they have been given numeric suffixes.  
[1] "Columns with only <NA> values are removed : code6, X1"
```
Final column names of original dataframe:  

```
 [1] "trading_date"         "code1"                "code2"                "name1"                "settlement_date"     
 [6] "buy_amount"           "code3"                "account_no1"          "code4"                "sell_amount"         
[11] "code5"                "account_no2"          "abs_rate"             "name2"                "code6"               
[16] "authorize_flag"       "generalledger1"       "xcomment"             "id type1"             "X1"                  
[21] "Globescode"           "portfolio"            "Type geld"            "PortfolioName"        "Trade date"          
[26] "Settle date"          "Deal code"            "Tegenpartij"          "Description"          "ID Buy"              
[31] "Nominal Buy (local)"  "CCYBuy"               "spot rate Buy"        "Mktval Buy (EUR)"     "ID Sell"             
[36] "Nominal Sell (local)" "CCYSell"              "spot rate Sell"       "Mktval Sell (EUR)"    "spot rate (trade)"   
[41] "DL Asset Type 1"      "DL Asset Type 2"      "DL Asset Type 3"      "DL Sector 1"          "DL Sector 2"         
[46] "DL Sector 3"          "DL Sector 4"          "generalledger2"       "id type2"            
```
Converted column trading_date to POSIXct (format=%d-%m-%Y %H:%M:%S)  with no failures on 223 nonempty values.  
Converted column settlement_date to POSIXct (format=%d-%m-%Y %H:%M:%S)  with no failures on 223 nonempty values.  
Converted column Tradedate to POSIXct (format=%d-%m-%Y %H:%M:%S)  with no failures on 223 nonempty values.  
Converted column Settledate to POSIXct (format=%d-%m-%Y %H:%M:%S)  with no failures on 223 nonempty values.  
DEBUG [2016-04-25 14:20:35] Saving data to table GL_xls_fxpms

```
DEBUG [2016-04-25 14:20:36] Validate, rowcount for dataset GL_xls_fxpms_orig, file: 223, table: 223
DEBUG [2016-04-25 14:20:36] Validate, columncount for dataset GL_xls_fxpms_orig, file: 49, table: 49
DEBUG [2016-04-25 14:20:36] Validate, hashtotal for dataset GL_xls_fxpms_orig, column abs_rate, file: 16345.51462266, table: 16345.51462266
DEBUG [2016-04-25 14:20:37] Validate, rowcount for dataset GL_xls_fxpms, file: 223, table: 223
DEBUG [2016-04-25 14:20:37] Validate, columncount for dataset GL_xls_fxpms, file: 53, table: 53
DEBUG [2016-04-25 14:20:37] Validate, hashtotal for dataset GL_xls_fxpms, column abs_rate, file: 16345.51462266, table: 16345.51462266

```

Saved processed file originating from  *RISK  FORWARDS_openstaande fxdeals.csv* in the database as table named  **GL_xls_fxpms**   

# RISK FORWARDS xls - globes code to portia portfolio code

```r
void <-globes.load(gl_xls_rf_globescode_to_portia)
```

DEBUG [2016-04-25 14:20:38] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 3 - Globe$/20160426/RISK  FORWARDS_globescode_to_portia.csv
Preprocessing data read from *RISK  FORWARDS_globescode_to_portia.csv*  

```
```
Final column names of original dataframe:  

```
[1] "Globes 5-code" "Portia code"  
```
DEBUG [2016-04-25 14:20:38] Saving data to table GL_xls_rf_globescode_to_portia

```
DEBUG [2016-04-25 14:20:39] Validate, rowcount for dataset GL_xls_rf_globescode_to_portia_orig, file: 497, table: 497
DEBUG [2016-04-25 14:20:39] Validate, columncount for dataset GL_xls_rf_globescode_to_portia_orig, file: 2, table: 2
DEBUG [2016-04-25 14:20:39] Validate, hashtotal for dataset GL_xls_rf_globescode_to_portia_orig, column Portia code, file: 6432, table: 6432
DEBUG [2016-04-25 14:20:40] Validate, rowcount for dataset GL_xls_rf_globescode_to_portia, file: 497, table: 497
DEBUG [2016-04-25 14:20:40] Validate, columncount for dataset GL_xls_rf_globescode_to_portia, file: 4, table: 4
DEBUG [2016-04-25 14:20:40] Validate, hashtotal for dataset GL_xls_rf_globescode_to_portia, column Portiacode, file: 6432, table: 6432

```

Saved processed file originating from  *RISK  FORWARDS_globescode_to_portia.csv* in the database as table named  **GL_xls_rf_globescode_to_portia**   

# RISK FORWARDS xls - portfolio to typegeld

```r
 void <-globes.load(gl_xls_rf_portfolio_to_typegeld)
```

DEBUG [2016-04-25 14:20:40] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 3 - Globe$/20160426/RISK  FORWARDS_portfolio_to_typegeld.csv
Preprocessing data read from *RISK  FORWARDS_portfolio_to_typegeld.csv*  

```
```
Final column names of original dataframe:  

```
[1] "Portfolio" "Typegeld" 
```
DEBUG [2016-04-25 14:20:40] Saving data to table GL_xls_rf_portfolio_to_geld

```
DEBUG [2016-04-25 14:20:42] Validate, rowcount for dataset GL_xls_rf_portfolio_to_geld_orig, file: 248, table: 248
DEBUG [2016-04-25 14:20:43] Validate, columncount for dataset GL_xls_rf_portfolio_to_geld_orig, file: 2, table: 2
DEBUG [2016-04-25 14:20:43] Validate, hashtotal for dataset GL_xls_rf_portfolio_to_geld_orig, column Typegeld, file: 503, table: 503
DEBUG [2016-04-25 14:20:43] Validate, rowcount for dataset GL_xls_rf_portfolio_to_geld, file: 248, table: 248
DEBUG [2016-04-25 14:20:43] Validate, columncount for dataset GL_xls_rf_portfolio_to_geld, file: 4, table: 4
DEBUG [2016-04-25 14:20:43] Validate, hashtotal for dataset GL_xls_rf_portfolio_to_geld, column Typegeld, file: 503, table: 503

```

Saved processed file originating from  *RISK  FORWARDS_portfolio_to_typegeld.csv* in the database as table named  **GL_xls_rf_portfolio_to_geld**   

# RISK FORWARDS xls - forwards

```r
void <-globes.load(gl_xls_riskforwards)
```

DEBUG [2016-04-25 14:20:43] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 3 - Globe$/20160426/RISK  FORWARDS_forwards.csv
Preprocessing data read from *RISK  FORWARDS_forwards.csv*  

```
```
Final column names of original dataframe:  

```
 [1] "Globescode"        "portfolio"         "Type geld"         "PortfolioName"     "Trade date"       
 [6] "Settle date"       "Deal code"         "Tegenpartij"       "Description"       "ID"               
[11] "Nominal (local)"   "Currency"          "spot rate"         "Mktval (EUR)"      "spot rate (trade)"
[16] "DL Asset Type 1"   "DL Asset Type 2"   "DL Asset Type 3"   "DL Sector 1"       "DL Sector 2"      
[21] "DL Sector 3"       "DL Sector 4"       "GeneralLedger"     "ID Type"          
```
Converted column Tradedate to POSIXct (format=%d-%m-%Y %H:%M:%S)  with no failures on 446 nonempty values.  
Converted column Settledate to POSIXct (format=%d-%m-%Y %H:%M:%S)  with no failures on 446 nonempty values.  
DEBUG [2016-04-25 14:20:45] Saving data to table GL_xls_riskforwards

```
DEBUG [2016-04-25 14:20:47] Validate, rowcount for dataset GL_xls_riskforwards_orig, file: 446, table: 446
DEBUG [2016-04-25 14:20:47] Validate, columncount for dataset GL_xls_riskforwards_orig, file: 24, table: 24
DEBUG [2016-04-25 14:20:47] Validate, hashtotal for dataset GL_xls_riskforwards_orig, column portfolio, file: 1338, table: 1338
DEBUG [2016-04-25 14:20:48] Validate, rowcount for dataset GL_xls_riskforwards, file: 446, table: 446
DEBUG [2016-04-25 14:20:48] Validate, columncount for dataset GL_xls_riskforwards, file: 28, table: 28
DEBUG [2016-04-25 14:20:48] Validate, hashtotal for dataset GL_xls_riskforwards, column portfolio, file: 1338, table: 1338

```

Saved processed file originating from  *RISK  FORWARDS_forwards.csv* in the database as table named  **GL_xls_riskforwards**   

# Limieten gesplitst naar eigen geld xls (Cash Total Risk) - verzamelrisk

```r
void <-globes.load(gl_xls_cashrisk)
```

DEBUG [2016-04-25 14:20:48] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 3 - Globe$/20160426/Limieten gesplitst naar Eigen Geld.csv
Preprocessing data read from *Limieten gesplitst naar Eigen Geld.csv*  

```
[1] "Columns 'DL Asset Type 3' only contain <NA> values but are not removed because they are overruled."
```
Final column names of original dataframe:  

```
 [1] "Globescode"       "portfolio"        "Type geld"        "PortfolioName"    "Start date"       "End date"        
 [7] "Deal code"        "Tegenpartij"      "Bedrag vv"        "Currency"         "Bedrag in EURO'S" "DL Asset Type 1" 
[13] "DL Asset Type 2"  "DL Asset Type 3"  "DL Sector 1"      "DL Sector 2"      "DL Sector 3"      "DL Sector 4"     
[19] "ID"              
```
Converted column Startdate to Date (format=%d-%m-%y)  with no failures on 49 nonempty values.   All unique failures: ''.  
Converted column Enddate to Date (format=%d-%m-%y)  with no failures on 47 nonempty values.   All unique failures: ''.  
DEBUG [2016-04-25 14:20:48] Saving data to table GL_xls_cashrisk

```
DEBUG [2016-04-25 14:20:50] Validate, rowcount for dataset GL_xls_cashrisk_orig, file: 1047, table: 1047
DEBUG [2016-04-25 14:20:50] Validate, columncount for dataset GL_xls_cashrisk_orig, file: 19, table: 19
DEBUG [2016-04-25 14:20:50] Validate, hashtotal for dataset GL_xls_cashrisk_orig, column ID, file: 22151, table: 22151
DEBUG [2016-04-25 14:20:52] Validate, rowcount for dataset GL_xls_cashrisk, file: 1047, table: 1047
DEBUG [2016-04-25 14:20:52] Validate, columncount for dataset GL_xls_cashrisk, file: 25, table: 25
DEBUG [2016-04-25 14:20:52] Validate, hashtotal for dataset GL_xls_cashrisk, column ID, file: 22151, table: 22151

```

Saved processed file originating from  *Limieten gesplitst naar Eigen Geld.csv* in the database as table named  **GL_xls_cashrisk**   

# Limieten gesplitst naar eigen geld xls - Call uit globes (mm_mat_d)

```r
#void <-globes.load(gl_xls_cashcalls)
```

# Limieten gesplitst naar eigen geld xls - Dep uit globes (mm_dlt_grt_dan_t query)

```r
#void <-globes.load(gl_xls_cashdeposits)
```

# Limieten gesplitst naar eigen geld xls - Bankst uit globes (globe$ query)

```r
#void <-globes.load(gl_xls_bankstanden)
```

# Limieten gesplitst naar eigen geld xls  - REPO

```r
#void <- globes.load(gl_xls_repo)
```

# Limieten gesplitst naar eigen geld xls  - Collateral

```r
#void <-globes.load(gl_xls_collateral)
```

# Limieten gesplitst naar eigen geld xls  - Mapping Globescode to counterparty (from bankst uit globes sheet)

```r
#void <-globes.load(gl_xls_bankst_globes_to_counterparty)
```

# Limieten gesplitst naar eigen geld xls  - Mapping Globescode to counterparty (from static data sheet)

```r
#void <-globes.load(gl_xls_stat_globes_to_counterparty)
```

# Limieten gesplitst naar eigen geld xls  - Mapping Globes portfolio code to portfolioname

```r
#void <-globes.load(gl_xls_lm_portfolio_to_portfolioname)
```

# Limieten gesplitst naar eigen geld xls  - Mapping Globes portfolio code to type geld (from Rekeningen sheet)

```r
#void <-globes.load(gl_xls_rek_portfolio_to_typegeld)
```

# Limieten gesplitst naar eigen geld xls  - Mapping Globes portfolio code to type geld (from Static data sheet)

```r
#void <-globes.load(gl_xls_stat_portfolio_to_typegeld)
```

# Limieten gesplitst naar eigen geld xls  - Mapping globes code to rekeningen

```r
#void <-globes.load(gl_xls_globes_to_rekening)
```

# Limieten gesplitst naar eigen geld xls  - Mapping bank code to bank name (from static data sheet)

```r
#void <-globes.load(gl_xls_bankcode_to_bankname)
```

# Limieten gesplitst naar eigen geld xls  - List of intercompany funds (from static data sheet)

```r
#void <-globes.load(gl_xls_intercompanyfunds)
```

# FRM Data base export of ForwardsHist

```r
#void  <- globes.load(gl_frm_forwards)
```

# FRM Data base export of CashHist

```r
#void  <- globes.load(gl_frm_cash)
```

# FX rates as of 2 februari

```r
void <- globes.load(gl_fxs)
```

DEBUG [2016-04-25 14:20:53] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps//Prio 3 - Globe$/20160426/fx.prn
Preprocessing data read from *fx.prn*  

```
```
Final column names of original dataframe:  

```
[1] "VALUTAS"     "CODE"        "WISSELKOERS" "DATUM"       "INVERSE"    
```
Converted column DATUM to Date (format=%d/%m/%y)  with no failures on 57 nonempty values.  
DEBUG [2016-04-25 14:20:53] Saving data to table GL_exchangerates

```
DEBUG [2016-04-25 14:20:55] Validate, rowcount for dataset GL_exchangerates_orig, file: 57, table: 57
DEBUG [2016-04-25 14:20:55] Validate, columncount for dataset GL_exchangerates_orig, file: 5, table: 5
DEBUG [2016-04-25 14:20:55] Validate, hashtotal for dataset GL_exchangerates_orig, column WISSELKOERS, file: 19.1647129601, table: 19.1647129601
DEBUG [2016-04-25 14:20:55] Validate, rowcount for dataset GL_exchangerates, file: 57, table: 57
DEBUG [2016-04-25 14:20:55] Validate, columncount for dataset GL_exchangerates, file: 8, table: 8
DEBUG [2016-04-25 14:20:55] Validate, hashtotal for dataset GL_exchangerates, column WISSELKOERS, file: 19.1647129601, table: 19.1647129601

```

Saved processed file originating from  *fx.prn* in the database as table named  **GL_exchangerates**   

# Resulting table mapping

```
                                 filename                      tablename
                                fxpms.csv                       GL_fxpms
                                 fxhb.csv                 GL_fxbloomberg
   RISK  FORWARDS_openstaande fxdeals.csv                   GL_xls_fxpms
  RISK  FORWARDS_globescode_to_portia.csv GL_xls_rf_globescode_to_portia
 RISK  FORWARDS_portfolio_to_typegeld.csv    GL_xls_rf_portfolio_to_geld
              RISK  FORWARDS_forwards.csv            GL_xls_riskforwards
   Limieten gesplitst naar Eigen Geld.csv                GL_xls_cashrisk
                                   fx.prn               GL_exchangerates
```

# Database enrichments

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW GL_vx_fxbloomberg 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
CREATE  View [dbo].[GL_vx_fxbloomberg] as
 Select
		[Buyamount]*buy_premium_factor as BuyAmount_premiumed,
		[Sellamount]*sell_premium_factor as SellAmount_premiumed,
		case when BuyCcy=Ccy1
			 then AllInRate*sell_premium_factor/buy_premium_factor
			 else AllInRate*buy_premium_factor/sell_premium_factor
			 end as AllInRate_premiumed,
		case when BuyCcy=Ccy1
			 then SpotRate*sell_premium_factor/buy_premium_factor
			 else SpotRate*buy_premium_factor/sell_premium_factor
			 end as SpotRate_premiumed
		 , *
	FROM(	SELECT
				case when BB_trades.Counterparty1='BANQUE DE LUXEMBOURG FX TRADING, LUXEMBOURG'
						  and (
								([BuyCcy]='EUR' and [Buyamount]<1000000)
								OR
								([SellCcy]!='EUR' and [BuyCcy]!='EUR' and [BuyCcy]='USD' and [Buyamount]<1010000)
								)
					 then (1-0.00015)
					 else 1
					 end as buy_premium_factor,
				case when BB_trades.Counterparty1='BANQUE DE LUXEMBOURG FX TRADING, LUXEMBOURG'
						  and (
								([SellCcy]='EUR' and [Sellamount]<1000000)
								OR
								([SellCcy]!='EUR' and [BuyCcy]!='EUR' and [SellCcy]='USD' and [Sellamount]<1010000)
								)
					 then 1/(1-0.00015)
					 else 1
					 end as sell_premium_factor,
				BB_trades.*
			from	(select
						*,
						Case
							When Side1 = 'DLTR Buy'
							Then BB_raw.[Ccy]
							Else BB_raw.[CcyOther]
							End As BuyCcy,
						Case
							When Side1 = 'DLTR Sell'
							Then BB_raw.[Ccy]
							Else BB_raw.[CcyOther]
							End As SellCcy,
						Case
							When Side1 = 'DLTR Buy'
							Then BB_raw.[AmountCcy]
							Else BB_raw.[AmountCcyOther]
							End As Buyamount ,
						Case
							When Side1 = 'DLTR Sell'
							Then BB_raw.[AmountCcy]
							Else BB_raw.[AmountCcyOther]
							End As Sellamount,
						Substring(Account1, 3, 3) As Portfolio ,
						BB_raw.[AccountNumber1] As AccountNo
					From	(SELECT
								case when Ccy1 = Ccy
									 then Ccy2
									 else Ccy1
									 end as CcyOther,
								case when Ccy1 = Ccy
									 then AmountCcy1
									 else AmountCcy2
									 end as AmountCcy,
								case when Ccy1 = Ccy
									 then AmountCcy2
									 else AmountCcy1
									 end as AmountCcyOther,
								*
							FROM (	SELECT
									   [TradeID]
									  ,CONVERT(date,[TradeDate],105) AS TradeDate
									  ,[LegID]
									  ,[Ccys]
									  ,[AmountCcy1]
									  ,[AmountCcy2]
									  ,[side1]
									  ,[Tenor]
									  ,CONVERT(date,ValueDate,105) AS [ValueDate]
									  ,[Ccy]
									  ,[amount1]
									  ,[DealCode]
									  ,[counterparty1]
									  ,[CtpySide]
									  ,[account1]
									  ,[DealType]
									  ,[account2]
									  ,[amount2]
									  ,[side2]
									  ,[accountnumber1]
									  ,[counterparty2]
									  ,[spotrate1]
									  ,[spotrate2]
									  ,[Points1] as NearPoints
									  ,[allinrate1]
									  ,[SwapPoints]
									  ,[FwdPoints]
									  ,[farpoints1] as farpoints
									  ,[FarAllin1] AS FarAllin
									  ,[source_date]
									  ,[source_file]
									  ,SUBSTRING(Ccys, 1, 3) as Ccy1
									  ,SUBSTRING(Ccys, 5, 3) as Ccy2
									  ,CASE WHEN LegID = 1 THEN spotrate1 ELSE spotrate2 END AS spotrate
									  ,CASE WHEN LegID = 1 THEN points1 ELSE farpoints1 END AS points
									  ,CASE WHEN LegID = 1 THEN allinrate1 ELSE allinrate1 END AS allinrate
									FROM	SourceData.Dbo.GL_fxbloomberg
									WHERE   Status != 'CANC'
									)
											as BB_with_currencies)
							as BB_raw)
					as BB_trades)
		 as BB_trades 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW GL_vx_fxdeals 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
CREATE VIEW [dbo].[GL_vx_fxdeals] AS
Select
	fxdeals.*
	,typegeld.Typegeld
FROM
(Select
	FX.[CODE_3] as Globescode,
	SUBSTRING(Fx.[CODE_3],3,3) as portfolio,
	Fx.NAME as [PortfolioName],
	Fx.[TRADING_DATE] as TradeDate,
	Fx.[SETTLEMENT_DATE] as SettleDate,
	Fx.CODE as [DealCode],
	Fx.NAME_1 as TegenPartij,
	Fx.SPOT_RATE as [SpotRate],
	FX.POINTS	 as [Points],
	FX.ABS_RATE	 as [AbsoluteRate],
	'Cash' as [DLAssetType1],
	'FX Derivative' as [DLAssetType2],
	'FX Forward' as [DLAssetType3],
	'Corporates' as [DLSector1],
	'Financials' as [DLSector2],
	'Financials' as [DLSector3],
	'Banks' as [DLSector4],
	SUBSTRING(Fx.[CODE],1,4) as DealType,
	SUBSTRING(Fx.[CODE_3],1,2) as BankCode,
	CASE when SETTLEMENT_DATE<= dateadd("day", 4, TRADING_DATE) then 1
	else 2 END AS [Leg],
	CASE when SETTLEMENT_DATE<= dateadd("day", 4, TRADING_DATE) then Fx.BUY_AMOUNT/Fx.SELL_AMOUNT
	else Fx.SELL_AMOUNT/Fx.BUY_AMOUNT END AS [AllInRate],
	Fx.ACCOUNT_NO						As [AccountNo] ,
	Fx.CODE_3							AS [AccountCode],
	Fx.NAME_1							as [CounterPortfolioName],
	Fx.ACCOUNT_NO_1 					as [CounterAccountNo],
	Fx.CODE_5							as [CounterAccountCode],
	Fx.BUY_AMOUNT						As Buyamount,
	Fx.SELL_AMOUNT						As Sellamount,
	Fx.CODE_2							As BuyCurrency,
	CASE WHEN Fx.CODE_2 = 'Eur'
			 THEN '1'
			 ELSE  fxratebuy.WISSELKOERS
		END								AS BuyFxRate,
	Fx.CODE_4							As SellCurrency,
	CASE WHEN Fx.CODE_4 = 'Eur'
			THEN '1'
			ELSE fxratesell.WISSELKOERS
		END								AS SellFxRate,
	[CODE_1]							as [AUTHORIZE_FLAG],
	[GENERALLEDGER]
From
	SourceData.Dbo.GL_fxpms Fx
LEFT JOIN
		SourceData.dbo.GL_exchangerates as fxratebuy
		on fx.CODE_2 = fxratebuy.CODE
LEFT JOIN
		SourceData.dbo.GL_exchangerates as fxratesell
		on fx.CODE_4 = fxratesell.CODE )	as fxdeals
LEFT JOIN
		(SELECT DISTINCT * FROM SourceData.dbo.GL_xls_rf_portfolio_to_geld) AS typegeld
		on fxdeals.portfolio = typegeld.Portfolio 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW GL_vx_xls_fxpms 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
CREATE VIEW GL_vx_xls_fxpms AS
	SELECT
		 [trading_date]
		,[code1]
      ,[code2]
      ,[name1]
      , [settlement_date]
      ,[buy_amount]
      ,[code3]
      ,[account_no1]
      ,[code4]
      ,[sell_amount]
      ,[code5]
      ,[account_no2]
      ,[abs_rate]
      ,[name2]
      ,[authorize_flag]
      ,[generalledger1]
      ,[xcomment]
      ,[Globescode]
      ,[portfolio]
      ,[Typegeld]
      ,[PortfolioName]
      , [Tradedate]
      ,[Settledate]
      ,[Dealcode]
      ,[Tegenpartij]
      ,[Description]
      ,[IDBuy]
      ,[NominalBuylocal]
      ,[CCYBuy]
      ,[spotrateBuy]
      ,[MktvalBuyEUR]
      ,[IDSell]
      ,[NominalSelllocal]
      ,[CCYSell]
      ,[spotrateSell]
      ,[MktvalSellEUR]
      ,[spotratetrade]
      ,[DLAssetType1]
      ,[DLAssetType2]
      ,[DLAssetType3]
      ,[DLSector1]
      ,[DLSector2]
      ,[DLSector3]
      ,[DLSector4]
      ,[generalledger2]
      ,[trading_date_orig]
      ,[settlement_date_orig]
      ,[Tradedate_orig]
      ,[Settledate_orig]
  FROM [SourceData].[dbo].[GL_xls_fxpms] 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW GL_vx_riskforwards 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
CREATE VIEW GL_vx_riskforwards AS
select
	deallegs.*,
	CONCAT(UPPER(Typegeld), [DealCode], [TegenPartij], [Currency]) as ID,
	globescode_to_portia.Portiacode as Portfolio_portia
FROM
((
	SELECT
		   [Globescode]
		  ,[portfolio]
		  ,[PortfolioName]
		  ,[TradeDate]
		  ,[SettleDate]
		  ,[DealCode]
		  ,[TegenPartij]
		  ,CONCAT('FX Buy ', BuyCurrency, CAST( CAST(Buyamount as bigint) as varchar), ' Sell ',SellCurrency, CAST(CAST(Buyamount*BuyFxRate as bigint) as varchar)) as [Description]
		  ,[Buyamount]				as NominalLocal
		  ,[Buyamount]*BuyFxRate	as MktValEur
		  ,BuyFxRate				as FXRate
		  ,[BuyCurrency]			as Currency
		  ,[BuyCurrency]
		  ,[SellCurrency]
		  ,[SpotRate]
		  ,[Buyamount] as Amount
		  ,'Buy' as Side
		  ,[Leg]
		  ,[DLAssetType1]
		  ,[DLAssetType2]
		  ,[DLAssetType3]
		  ,[DLSector1]
		  ,[DLSector2]
		  ,[DLSector3]
		  ,[DLSector4]
		  ,[DealType]
		  ,[BankCode]
		  ,[AllInRate]
		  ,[AccountNo]
		  ,[AccountCode]
		  ,[CounterPortfolioName]
		  ,[CounterAccountNo]
		  ,[CounterAccountCode]
		  ,[AUTHORIZE_FLAG]
		  ,[GENERALLEDGER]
		  ,typeGeld
	  FROM SourceData.dbo.[GL_vx_fxdeals]
) UNION (
	SELECT
		   [Globescode]
		  ,[portfolio]
		  ,[PortfolioName]
		  ,[TradeDate]
		  ,[SettleDate]
		  ,[DealCode]
		  ,[TegenPartij]
		  ,CONCAT('FX Buy ', BuyCurrency, CAST( CAST(Buyamount as bigint) as varchar), ' Sell ',SellCurrency, CAST(CAST(Buyamount*BuyFxRate as bigint) as varchar)) as [Description]
		  ,-[Sellamount]				as NominalLocal
		  ,-[Sellamount]*SellFxRate		as MktvalEur
		  ,SellFxRate					as FXRate
		  ,[SellCurrency]				as Currency
		  ,[BuyCurrency]
		  ,[SellCurrency]
		  ,[SpotRate]
		  ,-[Sellamount] as Amount
		  ,'Sell' as Side
		  ,[Leg]
		  ,[DLAssetType1]
		  ,[DLAssetType2]
		  ,[DLAssetType3]
		  ,[DLSector1]
		  ,[DLSector2]
		  ,[DLSector3]
		  ,[DLSector4]
		  ,[DealType]
		  ,[BankCode]
		  ,[AllInRate]
		  ,[AccountNo]
		  ,[AccountCode]
		  ,[CounterPortfolioName]
		  ,[CounterAccountNo]
		  ,[CounterAccountCode]
		  ,[AUTHORIZE_FLAG]
		  ,[GENERALLEDGER]
		  ,Typegeld
	  FROM SourceData.dbo.[GL_vx_fxdeals]
)) AS deallegs
	  LEFT JOIN
		(
		select
			details.Globes5code,
			details.portiacode
		from
			(
			select
				Globes5code, min(cast([rownames] as int)) as rownames
			 from
				SourceData.dbo.[GL_xls_rf_globescode_to_portia]
			 group by
				Globes5code
			) as groups
			left join
				SourceData.dbo.[GL_xls_rf_globescode_to_portia] as details
				on details.Globes5code=groups.Globes5code
				and details.rownames=groups.rownames
		) as globescode_to_portia
		 on LEFT(deallegs.Globescode, 5)=globescode_to_portia.Globes5code 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW GL_vx_fxdeals_bloomberg_matching 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view GL_vx_fxdeals_bloomberg_matching AS
select
	[buy_premium_factor]							AS GL_buy_premium_factor,
	[sell_premium_factor]							AS GL_sell_premium_factor,
	ISNULL(GL.TradeDate, BB.TradeDate)				AS TheDate,
	ISNULL(GL.SettleDate, BB.ValueDate)				as TheSettleDate,
	ISNULL(GL.BuyCurrency, BB.BuyCcy)				as TheBuyCcy,
	ISNULL(GL.SellCurrency, BB.SellCcy)				as TheSellCcy,
	ISNULL(GL.BuyAmount, BB.BuyAmount_premiumed)	as TheBuyAmount,
	ISNULL(GL.SellAmount, BB.SellAmount_premiumed)	as TheSellAmount,
	CONCAT(	case when BB.SellAmount is not null then 'BB' else '' end,
			case when GL.SellAmount is not null then 'GL' else '' end) as TheSystem,
	BB.TradeId										as BB_TradeId,
	GL.DealCode										AS GL_DealCode,
	CONCAT(UPPER(GL.Typegeld), GL.DealCode, [TegenPartij], GL.BuyCurrency) as ID,
	BB.Side1										as BB_Side,
	BB.TradeDate									as BB_TradeDate,
	GL.TradeDate									as GL_TradeDate,
	BB.ValueDate									as BB_SettleDate,
	GL.SettleDate									as GL_SettleDate,
	[BuyCcy]										as BB_BuyCurrency,
	GL.BuyCurrency									as GL_BuyCurrency,
    [SellCcy]										as BB_SellCurrency,
	GL.SellCurrency									as GL_SellCurrency,
	BB.[Buyamount]									as BB_BuyAmount,
	GL.BuyAmount									as GL_BuyAmount,
	BB.[Sellamount]									as BB_SellAmount,
	GL.SellAmount									as GL_SellAmount,
	BB.AllInRate_premiumed							AS BB_AllInRate_premiumed,
	BB.SpotRate_premiumed							AS BB_SpotRate_premiumed,
	GL.SpotRate										as GL_SpotRate,
	BB.spotrate										as BB_SpotRate,
	GL.Points										as GL_Points,
	BB.points										as BB_Points,
	GL.AbsoluteRate									as GL_allinrate,
	BB.allinrate									AS BB_allinrate,
	BB.Portfolio									as BB_Portfolio,
	GL.portfolio									AS GL_Portfolio,
	GL.PortfolioName								AS GL_PortfolioName,
	BB.AccountNo									as BB_AccountNo,
	GL.AccountNo									as GL_AccountNo,
	BB.Counterparty1								as BB_Tegenpartij,
	GL.TegenPartij									AS GL_TegenPartij,
	BB.LegID										as BB_Leg,
	GL.Leg											AS GL_Leg,
	BB.DealType										as BB_DealType,
	GL.DealType										as GL_DealType
from
  (SELECT * FROM SourceData.dbo.GL_vx_fxbloomberg WHERE ValueDate > source_date) as BB full outer join SourceData.dbo.GL_vx_fxdeals GL
	on  BB.TradeDate = GL.TradeDate
	and (
			( buy_premium_factor!=1
			 AND
			 ABS(BB.[BuyAmount_premiumed]-GL.BuyAmount)<0.03
			 )
		OR (
			ABS(BB.[BuyAmount_premiumed]-GL.BuyAmount)<0.01
			)
		)
	and (
			( sell_premium_factor!=1
			 AND
			 ABS(BB.[SellAmount_premiumed]-GL.SellAmount)<0.03
			 )
		OR (
			ABS(BB.[SellAmount_premiumed]-GL.SellAmount)<0.01
			)
		)
	and (UPPER(SUBSTRING(BB.Counterparty1,1,8))=UPPER(SUBSTRING(GL.TegenPartij,1,8))
		OR (BB.Counterparty1='BANK OF NEW YORK MELLON' AND GL.TegenPartij='ABN Amro Mellon')
		)
	and (BB.AccountNo=GL.AccountNo or BB.AccountNo is null)
where
	(GL.TradeDate is null or GL.TradeDate >= (select min(TradeDate) from SourceData.dbo.GL_vx_fxbloomberg))
	and (GL.TradeDate is null or GL.TradeDate <= (select max(TradeDate) from SourceData.dbo.GL_vx_fxbloomberg))
	and (BB.TradeDate is null or BB.TradeDate >= (select min(TradeDate) from GL_vx_fxdeals))
	and (BB.TradeDate is null or BB.TradeDate <= (select max(TradeDate) from GL_vx_fxdeals))
	and (Side1 is null or Side1!='DLTR Depo') -- These are not available in the fxpms table (through vx_fxdeals) 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW GL_vx_riskforwards_xls_matching 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
CREATE VIEW [dbo].[GL_vx_riskforwards_xls_matching] AS
SELECT
	ISNULL(db.ID, xls.ID) as theID,
	ISNULL(db.Description, xls.Description) as theDescription,
	ISNULL(db.DealCode, xls.DealCode) as theDealCode,
	ISNULL(db.TradeDate, xls.TradeDate) as theTradeDate,
	ISNULL(db.SettleDate, xls.SettleDate) as theSettleDate,
	ISNULL(db.Currency, xls.Currency) as theCurrency,
	ISNULL(db.GlobesCode, xls.GlobesCode) as theGlobesCode,
	CONCAT(case when db.DealCode is not null then 'DB' else '' end,
			case when xls.DealCode is not null then 'XL' else '' end) as TheSystem,
	db.ID as [db_ID],
	xls.ID,
	db.[Description] as db_Description,
	xls.[Description],
	db.DealCode as db_DealCode,
	xls.Dealcode,
	db.TradeDate as db_TradeDate,
	xls.Tradedate,
	db.SettleDate as db_SettleDate,
	xls.Settledate,
	db.NominalLocal as db_NominalLocal,
	xls.Nominallocal,
	db.Amount as db_Amount,
	db.FXRate as db_FXRate,
	xls.spotrate as FXRate,
	db.MktvalEUR as db_Mktval,
	xls.MktvalEUR,
	db.Currency as db_Currency,
	xls.Currency,
	db.SpotRate as db_SpotRate,
	xls.spotratetrade as SpotRate,
	db.portfolio as db_Portfolio,
	xls.portfolio as Portfolio,
	db.PortfolioName as db_GlobesPortfolioName,
	db.Portfolio_portia as db_Portfolio_portia,
	xls.PortfolioName as PortfolioName,
	db.Globescode as db_Globescode,
	xls.Globescode
from
	GL_vx_riskforwards as db
	full outer join
	GL_xls_riskforwards as xls
		on db.SettleDate = xls.Settledate
		and db.TradeDate = xls.Tradedate
		and db.DealCode = xls.Dealcode
		and db.Currency = xls.Currency
		and db.GlobesCode = xls.Globescode
where
	db.SettleDate>=(select min(SettleDate) from GL_xls_riskforwards)
	and
	db.TradeDate<=(select max(TradeDate) from GL_xls_riskforwards) 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
```


```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_GL_instrument 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_GL_instrument as
	select distinct
		ID					AS insid,
		ID					AS IDENTIFIER,
		[Description]		AS [SECURITY],
		Currency			AS [CURRENCY],
		DLAssetType1		AS [DLAMAssetClass1],
		DLAssetType2		AS [DLAMAssetClass2],
		DLAssetType3		AS [DLAMAssetClass3],
		DLSector1			AS [DLAMSector1],
		DLSector2			AS [DLAMSector2],
		DLSector3			AS [DLAMSector3],
		DLSector4			AS [DLAMSector4],
		spotrate			AS [FXRATE],
		Settledate			AS [MATURITY],
		spotratetrade		AS [PRICE],
		NULL as startdate,
		Typegeld,
		Dealcode,
		GlobesCode,
		ID,
		Tegenpartij,
		source_date,
		source_file
	from GL_xls_riskforwards
	union all
	select distinct
		ID					AS insid,
		ID					AS [IDENTIFIER],
		NULL				AS [SECURITY],
		Currency			AS [CURRENCY],
		DLAssetType1		AS [DLAMAssetClass1],
		DLAssetType2		AS [DLAMAssetClass2],
		STR(DLAssetType3)	AS [DLAMAssetClass3],
		DLSector1			AS [DLAMSector1],
		DLSector2			AS [DLAMSector2],
		DLSector3			AS [DLAMSector3],
		DLSector4			AS [DLAMSector4],
		NULL				AS [FXRATE],
		CASE WHEN Enddate = '' THEN NULL
			ELSE CONVERT(date, Enddate, 105) END 				AS [MATURITY],
		NULL				AS [PRICE],
		CASE WHEN startdate = '' THEN NULL
			ELSE CONVERT(date, startdate, 105) END AS Startdate,
		NULL				AS Typegeld,
		Dealcode,
		Globescode,
		ID,
		Tegenpartij,
		source_date,
		source_file
	from
		GL_xls_cashrisk 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_GL_trade 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_GL_trade as
	select distinct
		Dealcode			as tradeid,
		ID					AS ref_insid,
		portfolio			AS ref_prfid,
		ID					AS IDENTIFIER,
		[Description]		AS [SECURITY],
		Currency			AS [CURRENCY],
		DLAssetType1		AS [DLAMAssetClass1],
		DLAssetType2		AS [DLAMAssetClass2],
		DLAssetType3		AS [DLAMAssetClass3],
		DLSector1			AS [DLAMSector1],
		DLSector2			AS [DLAMSector2],
		DLSector3			AS [DLAMSector3],
		DLSector4			AS [DLAMSector4],
		spotrate			AS [FXRATE],
		Settledate			AS [MATURITY],
		spotratetrade		AS [PRICE],
		MktvalEUR			AS [MARKET_VALUE],
		Nominallocal		AS [NOMINAL_VALUE],
		PortfolioName		AS [PORTFOLIO_NAME],
		Nominallocal		AS [QUANTITY],
		NULL as startdate,
		Typegeld,
		Dealcode,
		GlobesCode,
		ID,
		Tegenpartij,
		source_date,
		source_file
	from GL_xls_riskforwards
UNION ALL
	select distinct
		Dealcode			as tradeid,
		ID					AS ref_insid,
		portfolio			AS ref_prfid,
		ID					AS [IDENTIFIER],
		NULL				AS [SECURITY],
		Currency			AS [CURRENCY],
		DLAssetType1		AS [DLAMAssetClass1],
		DLAssetType2		AS [DLAMAssetClass2],
		STR(DLAssetType3)	AS [DLAMAssetClass3],
		DLSector1			AS [DLAMSector1],
		DLSector2			AS [DLAMSector2],
		DLSector3			AS [DLAMSector3],
		DLSector4			AS [DLAMSector4],
		NULL				AS [FXRATE],
		CASE WHEN enddate = '' THEN NULL
			ELSE CONVERT(date, enddate, 105) END				AS [MATURITY],
		NULL				AS [PRICE],
		BedraginEUROS		AS [MARKET_VALUE],
		BedraginEUROS		AS [NOMINAL_VALUE],
		PortfolioName		AS [PORTFOLIO_NAME],
		BedraginEUROS		AS [QUANTITY],
		CASE WHEN startdate = '' THEN NULL
			ELSE CONVERT(date, startdate, 105) END as Startdate,
		NULL				AS Typegeld,
		Dealcode,
		Globescode,
		ID,
		Tegenpartij,
		source_date,
		source_file
	from
		GL_xls_cashrisk 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_GL_holding 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_GL_holding as
	select distinct
		ID					AS insid,
		portfolio			AS prfid,
		ID					AS IDENTIFIER,
		[Description]		AS [SECURITY],
		Currency			AS [CURRENCY],
		DLAssetType1		AS [DLAMAssetClass1],
		DLAssetType2		AS [DLAMAssetClass2],
		DLAssetType3		AS [DLAMAssetClass3],
		DLSector1			AS [DLAMSector1],
		DLSector2			AS [DLAMSector2],
		DLSector3			AS [DLAMSector3],
		DLSector4			AS [DLAMSector4],
		spotrate			AS [FXRATE],
		Settledate			AS [MATURITY],
		spotratetrade		AS [PRICE],
		Nominallocal		AS [NOMINAL_VALUE],
		MktvalEUR			AS [MARKET_VALUE],
		PortfolioName		AS [PORTFOLIO_NAME],
		Nominallocal		AS [QUANTITY],
		NULL as startdate,
		Typegeld,
		Dealcode,
		GlobesCode,
		ID,
		Tegenpartij,
		source_date,
		source_file
	from GL_xls_riskforwards
UNION ALL
	select distinct
		ID					AS insid,
		portfolio			AS prfid,
		ID					AS [IDENTIFIER],
		NULL				AS [SECURITY],
		Currency			AS [CURRENCY],
		DLAssetType1		AS [DLAMAssetClass1],
		DLAssetType2		AS [DLAMAssetClass2],
		STR(DLAssetType3)	AS [DLAMAssetClass3],
		DLSector1			AS [DLAMSector1],
		DLSector2			AS [DLAMSector2],
		DLSector3			AS [DLAMSector3],
		DLSector4			AS [DLAMSector4],
		NULL				AS [FXRATE],
		CASE WHEN Enddate = '' THEN NULL
			ELSE CONVERT(date, Enddate, 105) END				AS [MATURITY],
		NULL				AS [PRICE],
		BedraginEUROS		AS [NOMINAL_VALUE],
		BedraginEUROS		AS [MARKET_VALUE],
		PortfolioName		AS [PORTFOLIO_NAME],
		BedraginEUROS		AS [QUANTITY],
		CASE WHEN startdate = '' THEN NULL
			ELSE CONVERT(date, startdate, 105) END AS Startdate,
		NULL				AS Typegeld,
		Dealcode,
		Globescode,
		ID,
		Tegenpartij,
		source_date,
		source_file
	from
		GL_xls_cashrisk 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_GL_currency 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_GL_currency as
	select distinct
		Currency			AS fxid,
		Currency			AS [CURRENCY],
		spotrate			AS [FXRATE],
		source_date,
		source_file
	from GL_xls_riskforwards
UNION ALL
	select distinct
		Currency			AS fxid,
		Currency			AS [CURRENCY],
		NULL				AS [FXRATE],
		source_date,
		source_file
	from
		GL_xls_cashrisk 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_GL_portfolio 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_GL_portfolio as
select
	prfs.*,
	Typegeld
FROM
	(
	select distinct
			portfolio as prfid,
			portfolio,
			PortfolioName as [PORTFOLIO_NAME],
			source_date
		from GL_xls_cashrisk
	union all
		select distinct
			portfolio as prfid,
			portfolio,
			PortfolioName as [PORTFOLIO_NAME],
			source_date
		from GL_xls_riskforwards
	) as prfs
	left join (select distinct portfolio, Typegeld from GL_xls_riskforwards) as forwards
	on prfs.portfolio = forwards.portfolio 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_GL_entities 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_GL_entities AS
	SELECT
	  'instrument' as entitytype
	  ,[insid]
	  ,NULL as prfid
	  ,NULL as fxid
	  ,NULL as [tradeid]
      ,[source_file]
      ,[source_date]
      ,[CURRENCY]
      ,[DLAMAssetClass1]
      ,[DLAMAssetClass2]
      ,[DLAMAssetClass3]
      ,[DLAMSector1]
      ,[DLAMSector2]
      ,[DLAMSector3]
      ,[DLAMSector4]
      ,[FXRATE]
     ,[IDENTIFIER]
	  ,NULL AS [MARKET_VALUE]
      ,[MATURITY]
      ,NULL AS [NOMINAL_VALUE]
     ,NULL AS [PORTFOLIO_NAME]
      ,[PRICE]
	  ,NULL AS [QUANTITY]
	  ,[SECURITY]
  FROM [SourceData].[dbo].[vx_GL_instrument]
union all
	SELECT
	  'holding' as entitytype
	  ,[insid]
	  ,prfid
	  ,NULL as fxid
	  ,NULL as [tradeid]
      ,[source_file]
      ,[source_date]
      ,[CURRENCY]
      ,[DLAMAssetClass1]
      ,[DLAMAssetClass2]
      ,[DLAMAssetClass3]
      ,[DLAMSector1]
      ,[DLAMSector2]
      ,[DLAMSector3]
      ,[DLAMSector4]
      ,[FXRATE]
      ,[IDENTIFIER]
	  ,[MARKET_VALUE]
      ,[MATURITY]
      ,[NOMINAL_VALUE]
      ,[PORTFOLIO_NAME]
      ,[PRICE]
	  ,[QUANTITY]
	  ,[SECURITY]
  FROM [SourceData].[dbo].[vx_GL_holding]
union all
	SELECT
	  'portfolio' as entitytype
	  ,NULL AS [insid]
	  ,prfid
	  ,NULL as fxid
	  ,NULL as [tradeid]
      ,NULL as [source_file]
      ,[source_date]
      ,NULL as [CURRENCY]
      ,NULL as [DLAMAssetClass1]
      ,NULL as [DLAMAssetClass2]
      ,NULL as [DLAMAssetClass3]
      ,NULL as [DLAMSector1]
      ,NULL as [DLAMSector2]
      ,NULL as [DLAMSector3]
      ,NULL as [DLAMSector4]
      ,NULL as [FXRATE]
      ,NULL as [IDENTIFIER]
	  ,NULL AS [MARKET_VALUE]
      ,NULL as [MATURITY]
      ,NULL as [NOMINAL_VALUE]
      ,[PORTFOLIO_NAME]
      ,NULL as [PRICE]
	  ,NULL as [QUANTITY]
	  ,NULL as [SECURITY]
  FROM [SourceData].[dbo].[vx_GL_portfolio]
union all
	SELECT
	  'trade' as entitytype
	  ,NULL AS [insid]
	  ,NULL AS prfid
	  ,NULL as fxid
	  ,[tradeid]
      ,[source_file]
      ,[source_date]
      ,[CURRENCY]
      ,[DLAMAssetClass1]
      ,[DLAMAssetClass2]
      ,[DLAMAssetClass3]
      ,[DLAMSector1]
      ,[DLAMSector2]
      ,[DLAMSector3]
      ,[DLAMSector4]
      ,[FXRATE]
      ,[IDENTIFIER]
	  ,[MARKET_VALUE]
      ,[MATURITY]
      ,[NOMINAL_VALUE]
      ,[PORTFOLIO_NAME]
      ,[PRICE]
	  ,[QUANTITY]
	  ,[SECURITY]
  FROM [SourceData].[dbo].[vx_GL_trade]
union all
	SELECT
	  'currency' as entitytype
	  ,NULL AS [insid]
	  ,NULL as prfid
	  ,fxid
	  ,NULL as [tradeid]
      ,[source_file]
      ,[source_date]
      ,[CURRENCY]
      ,NULL AS [DLAMAssetClass1]
      ,NULL AS [DLAMAssetClass2]
      ,NULL AS [DLAMAssetClass3]
      ,NULL AS [DLAMSector1]
      ,NULL AS [DLAMSector2]
      ,NULL AS [DLAMSector3]
      ,NULL AS [DLAMSector4]
      ,[FXRATE]
      ,NULL AS [IDENTIFIER]
	  ,NULL AS [MARKET_VALUE]
      ,NULL AS [MATURITY]
      ,NULL AS [NOMINAL_VALUE]
      ,NULL AS [PORTFOLIO_NAME]
      ,NULL AS [PRICE]
	  ,NULL AS [QUANTITY]
	  ,NULL AS [SECURITY]
  FROM [SourceData].[dbo].[vx_GL_currency] 
```





