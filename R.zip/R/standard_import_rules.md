
---
title: "FrontArena Arena Database business rules"
output: html_document
---
FrontArena Database business rules
====================================================




This report has been generated on 2016-04-26 16:07:05.



DEBUG [2016-04-26 16:07:07] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Input/20160412/frontarena_rules.csv
Preprocessing data read from *frontarena_rules.csv*  

```
Renaming column DataElements to dataelements
Renaming column EntityType to entitytype
```
Final column names of original dataframe:  

```
 [1] "BR"                 "entitytype"         "Depth"              "Importance"         "ErrorCause"        
 [6] "modificationDate"   "ruleOwner"          "approvedBy"         "ApprovedDate"       "resultApprovalDate"
[11] "dataelements"       "datasource"         "referencedata"      "en"                 "nl"                
[16] "rule"               "condition"          "Feedback"          
```
Converted column modificationDate to Date (format=%d-%m-%Y)  with no failures on 73 nonempty values.  
Converted column ApprovedDate to Date (format=%d-%m-%Y)  with no failures on 73 nonempty values.  
Converted column resultApprovalDate to Date (format=%d-%m-%Y)  with no failures on 0 nonempty values.  
DEBUG [2016-04-26 16:07:07] Saving data to table FA_rules

```
[1] "Differences in 'rule'"
        BR
25 FA_0036
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        rule
25 One whould expect the quantity times the price to be the market value. \n\n\nHowever the definition of 'MW incl LR (Eur)' also contains the LR (lopende rente), which is the Acrued Interest. \n\n\nSpecific bonds are inflation linked, which' principal should also be added to the market value\n\n\nThese bonds however do not occur in the FrontArena system (they do exist in Portia)\n\n\nThe actual calculation thus is (quantity * clean_europrice  + accrued interest) == market value\n\n\nAlso units of both quantity and price needs to be taken care of. For example, bonds are priced at 100 to indicate 100%\n\n\nVerified relation: For all instruments: ((KOERS/FXRATE)*QUANTITY*UNIT.PRICE + AcruedInterest.Eur.) == MW.incl.LR..Eur\n\n\nwhere UNIT.PRICE is 0.01 for all instruments in FrontArena \nThis rule is similar to FA_0074, but only returns significant differences (>0.00001 * QUANTITY)
        BR
25 FA_0036
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       rule
25 One whould expect the quantity times the price to be the market value. \n\n\nHowever the definition of 'MW incl LR (Eur)' also contains the LR (lopende rente), which is the Acrued Interest. \n\n\nSpecific bonds are inflation linked, which' principal should also be added to the market value\n\n\nThese bonds however do not occur in the FrontArena system (they do exist in Portia)\n\n\nThe actual calculation thus is (quantity * clean_europrice  + accrued interest) == market value\n\n\nAlso units of both quantity and price needs to be taken care of. For example, bonds are priced at 100 to indicate 100%\n\n\nVerified relation: For all instruments: ((KOERS/FXRATE)*QUANTITY*UNIT.PRICE + AcruedInterest.Eur.) == MW.incl.LR..Eur\n\n\nwhere UNIT.PRICE is 0.01 for all instruments in FrontArena \nThis rule is similar to FA_0074, but only returns significant differences (>0.00001 * QUANTITY
   difference
25       <NA>
[1] "Differences in 'condition'"
        BR
22 FA_0028
                                                                                                                                                                                                                                                                                                                                                                                                                                           condition
22 All instruments which are a not a bond or CDS, but do have an available rating\n\n\nThe bonds are defined as instruments with\n\n\n  DLAMAssetClass2 equal to 'Bond' \n\n\n  OR DLAMAssetClass2 equal to 'Credit Default Swap'\n  OR instype_desc equal to 'Bond' or 'CreditDefaultSwap'\n\n\n  but do not have a DLAMAssetClass3 equal to 'LIC'\n\n\nThe ratings is regardes as unavailable when\n\n\n  DLAMRating='-'\n\n\n  OR DLAMRating='NR'
        BR
22 FA_0028
                                                                                                                                                                                                                                                                                                                                                                                                                                          condition
22 All instruments which are a not a bond or CDS, but do have an available rating\n\n\nThe bonds are defined as instruments with\n\n\n  DLAMAssetClass2 equal to 'Bond' \n\n\n  OR DLAMAssetClass2 equal to 'Credit Default Swap'\n  OR instype_desc equal to 'Bond' or 'CreditDefaultSwap'\n\n\n  but do not have a DLAMAssetClass3 equal to 'LIC'\n\n\nThe ratings is regardes as unavailable when\n\n\n  DLAMRating='-'\n\n\n  OR DLAMRating='NR
   difference
22       <NA>
DEBUG [2016-04-26 16:07:09] Validate, rowcount for dataset FA_rules_orig, file: 73, table: 73
DEBUG [2016-04-26 16:07:09] Validate, columncount for dataset FA_rules_orig, file: 18, table: 18
DEBUG [2016-04-26 16:07:09] Validate, hashtotal for dataset FA_rules_orig, column BR, file: 1788, table: 1788
[1] "Column 'resultApprovalDate\": Attributes: < Length not found in target."
[1] "Differences in 'rule'"
        BR
25 FA_0036
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        rule
25 One whould expect the quantity times the price to be the market value. \n\n\nHowever the definition of 'MW incl LR (Eur)' also contains the LR (lopende rente), which is the Acrued Interest. \n\n\nSpecific bonds are inflation linked, which' principal should also be added to the market value\n\n\nThese bonds however do not occur in the FrontArena system (they do exist in Portia)\n\n\nThe actual calculation thus is (quantity * clean_europrice  + accrued interest) == market value\n\n\nAlso units of both quantity and price needs to be taken care of. For example, bonds are priced at 100 to indicate 100%\n\n\nVerified relation: For all instruments: ((KOERS/FXRATE)*QUANTITY*UNIT.PRICE + AcruedInterest.Eur.) == MW.incl.LR..Eur\n\n\nwhere UNIT.PRICE is 0.01 for all instruments in FrontArena \nThis rule is similar to FA_0074, but only returns significant differences (>0.00001 * QUANTITY)
        BR
25 FA_0036
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       rule
25 One whould expect the quantity times the price to be the market value. \n\n\nHowever the definition of 'MW incl LR (Eur)' also contains the LR (lopende rente), which is the Acrued Interest. \n\n\nSpecific bonds are inflation linked, which' principal should also be added to the market value\n\n\nThese bonds however do not occur in the FrontArena system (they do exist in Portia)\n\n\nThe actual calculation thus is (quantity * clean_europrice  + accrued interest) == market value\n\n\nAlso units of both quantity and price needs to be taken care of. For example, bonds are priced at 100 to indicate 100%\n\n\nVerified relation: For all instruments: ((KOERS/FXRATE)*QUANTITY*UNIT.PRICE + AcruedInterest.Eur.) == MW.incl.LR..Eur\n\n\nwhere UNIT.PRICE is 0.01 for all instruments in FrontArena \nThis rule is similar to FA_0074, but only returns significant differences (>0.00001 * QUANTITY
   difference
25       <NA>
[1] "Differences in 'condition'"
        BR
22 FA_0028
                                                                                                                                                                                                                                                                                                                                                                                                                                           condition
22 All instruments which are a not a bond or CDS, but do have an available rating\n\n\nThe bonds are defined as instruments with\n\n\n  DLAMAssetClass2 equal to 'Bond' \n\n\n  OR DLAMAssetClass2 equal to 'Credit Default Swap'\n  OR instype_desc equal to 'Bond' or 'CreditDefaultSwap'\n\n\n  but do not have a DLAMAssetClass3 equal to 'LIC'\n\n\nThe ratings is regardes as unavailable when\n\n\n  DLAMRating='-'\n\n\n  OR DLAMRating='NR'
        BR
22 FA_0028
                                                                                                                                                                                                                                                                                                                                                                                                                                          condition
22 All instruments which are a not a bond or CDS, but do have an available rating\n\n\nThe bonds are defined as instruments with\n\n\n  DLAMAssetClass2 equal to 'Bond' \n\n\n  OR DLAMAssetClass2 equal to 'Credit Default Swap'\n  OR instype_desc equal to 'Bond' or 'CreditDefaultSwap'\n\n\n  but do not have a DLAMAssetClass3 equal to 'LIC'\n\n\nThe ratings is regardes as unavailable when\n\n\n  DLAMRating='-'\n\n\n  OR DLAMRating='NR
   difference
22       <NA>
[1] "Column 'rule_load_date\": Mean absolute differenc not found in target."
DEBUG [2016-04-26 16:07:09] Validate, rowcount for dataset FA_rules, file: 73, table: 73
DEBUG [2016-04-26 16:07:09] Validate, columncount for dataset FA_rules, file: 24, table: 24
DEBUG [2016-04-26 16:07:09] Validate, hashtotal for dataset FA_rules, column BR, file: 1788, table: 1788

```

Saved processed file originating from  *frontarena_rules.csv* in the database as table named  **FA_rules**   

DEBUG [2016-04-26 16:07:09] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Input/20160412/frontarena_whitelist.csv
Preprocessing data read from *frontarena_whitelist.csv*  

```
```
Final column names of original dataframe:  

```
 [1] "BR"            "insid"         "prfid"         "fxid"          "tradeid"       "owner"         "date"         
 [8] "Bevestigddoor" "Bevestigdop"   "reason"       
```
Converted column date to Date (format=%d-%m-%Y)  with no failures on 14 nonempty values.  
DEBUG [2016-04-26 16:07:09] Saving data to table FA_whitelist

```
DEBUG [2016-04-26 16:07:12] Validate, rowcount for dataset FA_whitelist_orig, file: 14, table: 14
DEBUG [2016-04-26 16:07:12] Validate, columncount for dataset FA_whitelist_orig, file: 10, table: 10
DEBUG [2016-04-26 16:07:12] Validate, hashtotal for dataset FA_whitelist_orig, column BR, file: 173, table: 173
[1] "Column 'source_date\": Mean absolute differenc not found in target."
DEBUG [2016-04-26 16:07:12] Validate, rowcount for dataset FA_whitelist, file: 14, table: 14
DEBUG [2016-04-26 16:07:12] Validate, columncount for dataset FA_whitelist, file: 13, table: 13
DEBUG [2016-04-26 16:07:12] Validate, hashtotal for dataset FA_whitelist, column BR, file: 173, table: 173

```

Saved processed file originating from  *frontarena_whitelist.csv* in the database as table named  **FA_whitelist**   

DEBUG [2016-04-26 16:07:12] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Input/20160412/frontarena_blacklist.csv
Preprocessing data read from *frontarena_blacklist.csv*  

```
```
Final column names of original dataframe:  

```
 [1] "BR"         "insid"      "prfid"      "fxid"       "tradeid"    "owner"      "date"       "solver"    
 [9] "reason"     "clean"      "clean_date"
```
Converted column date to Date (format=%d-%m-%Y)  with no failures on 5 nonempty values.  
Converted column clean_date to Date (format=%d-%m-%Y)  with no failures on 0 nonempty values.  
DEBUG [2016-04-26 16:07:14] Saving data to table FA_blacklist

```
DEBUG [2016-04-26 16:07:16] Validate, rowcount for dataset FA_blacklist_orig, file: 15, table: 15
DEBUG [2016-04-26 16:07:16] Validate, columncount for dataset FA_blacklist_orig, file: 11, table: 11
DEBUG [2016-04-26 16:07:16] Validate, hashtotal for dataset FA_blacklist_orig, column BR, file: 502, table: 502
[1] "Column 'source_date\": Mean absolute differenc not found in target."
DEBUG [2016-04-26 16:07:16] Validate, rowcount for dataset FA_blacklist, file: 15, table: 15
DEBUG [2016-04-26 16:07:16] Validate, columncount for dataset FA_blacklist, file: 14, table: 14
DEBUG [2016-04-26 16:07:16] Validate, hashtotal for dataset FA_blacklist, column BR, file: 502, table: 502

```

Saved processed file originating from  *frontarena_blacklist.csv* in the database as table named  **FA_blacklist**   

DEBUG [2016-04-26 16:07:16] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 0 - Input/20160412/frontarena_4a.csv
Preprocessing data read from *frontarena_4a.csv*  

```
```
Final column names of original dataframe:  

```
 [1] "System"                        "ResponsibleBusinessDepartment" "BRDescriptionNativelanguage"  
 [4] "BR"                            "entitytype"                    "insid"                        
 [7] "prfid"                         "fxid"                          "tradeid"                      
[10] "fail_reportname"               "fail_reportdate"               "whitelisted"                  
[13] "confirmed"                     "fail"                          "unhandled"                    
[16] "Notcleaned"                    "Responsibleforcleaning"        "Solverperson"                 
[19] "Solverdepartment"              "reasons"                      
```
Converted column fail_reportdate to Date (format=%d-%m-%Y %H:%M)  but had 363 failed conversions. The unique values:'2015-12-14 22:24:32'
DEBUG [2016-04-26 16:07:18] Saving data to table FA_4A

```
DEBUG [2016-04-26 16:07:21] Validate, rowcount for dataset FA_4A_orig, file: 363, table: 363
DEBUG [2016-04-26 16:07:21] Validate, columncount for dataset FA_4A_orig, file: 20, table: 20
DEBUG [2016-04-26 16:07:21] Validate, hashtotal for dataset FA_4A_orig, column BR, file: 20735, table: 20735
[1] "Column 'fail_reportdate\": Attributes: < Length not found in target."
DEBUG [2016-04-26 16:07:21] Validate, rowcount for dataset FA_4A, file: 363, table: 363
DEBUG [2016-04-26 16:07:21] Validate, columncount for dataset FA_4A, file: 22, table: 22
DEBUG [2016-04-26 16:07:21] Validate, hashtotal for dataset FA_4A, column BR, file: 20735, table: 20735

```

Saved processed file originating from  *frontarena_4a.csv* in the database as table named  **FA_4A**   


```
DEBUG [2016-04-26 16:07:22] Validate, rowcount for dataset FA_rules_dataelements, file: 85, table: 85
DEBUG [2016-04-26 16:07:22] Validate, columncount for dataset FA_rules_dataelements, file: 2, table: 2
DEBUG [2016-04-26 16:07:22] Validate, hashtotal for dataset FA_rules_dataelements, column BR, file: 2039, table: 2039
```

# Verification of rules

```r
verify.entities(rules$prep)
```

# Loading SQL files

```r
verify.BR(rules$prep ,system_attr$Acronym)
```


```
[1] "Differences in 'query'"
        BR
54 FA_0066
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
54 select   distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid, \r\n    DLAMAssetClass1 , \r\n    DLAMAssetClass2 , \r\n    DLAMAssetClass3 , \r\n    db_instype_desc,\r\n\t-- Get string concatenated value of all Sector2NoCountries which are allowed with the provided WFT\r\n\treplace(replace(replace((cast((\r\n\tselect distinct DLAMAssetClass3 as X\r\n\tfrom valuewhitelist_assetclass_dbinstype as inner_list\r\n\twhere inner_list.db_instype_desc = instr.db_instype_desc COLLATE Latin1_General_CI_AS\r\n\tfor xml path('')) as varchar(max))), \r\n\t'</X><X>', ', '),'<X>', ''),'</X>','') as allowed_DLAMAssetClass3_with_db_instype_desc,\r\n\r\n\t-- Get string concatenated value of all WFT which are allowed with the provided Sector2NoCountry\r\n\treplace(replace(replace((cast((\r\n\tselect distinct db_instype_desc as X\r\n\tfrom valuewhitelist_assetclass_dbinstype as inner_list\r\n\twhere inner_list.DLAMAssetClass3 = instr.DLAMAssetClass3 COLLATE Latin1_General_CI_AS\r\n\tfor xml path('')) as varchar(max))), \r\n\t'</X><X>', ', '),'<X>', ''),'</X>','') as allowed_db_instype_desc_with_DLAMAssetClass3\r\nFROM \r\n\tvx_FA_instrument_twice instr\r\nwhere\r\n\t-- set in scope\r\n\tDLAMSector1!='' and DLAMSector1!='-' and db_instype_desc is not null\r\n\t-- and not on the whitelist\r\n\tand not exists (\r\n\t\tselect * from valuewhitelist_assetclass_dbinstype wl where \r\n\t\t\twl.DLAMAssetClass1= instr.DLAMAssetClass1 COLLATE Latin1_General_CI_AS\r\n\t\t\tand wl.DLAMAssetClass2 = instr.DLAMAssetClass2 COLLATE Latin1_General_CI_AS\r\n\t\t\tand wl.DLAMAssetClass3 = instr.DLAMAssetClass3 COLLATE Latin1_General_CI_AS\r\n\t\t\tand wl.db_instype_desc = instr.db_instype_desc COLLATE Latin1_General_CI_AS\r\n\t\t)
        BR
54 FA_0066
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 query
54 select   distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid, \r\n    DLAMAssetClass1 , \r\n    DLAMAssetClass2 , \r\n    DLAMAssetClass3 , \r\n    db_instype_desc,\r\n\t-- Get string concatenated value of all Sector2NoCountries which are allowed with the provided WFT\r\n\treplace(replace(replace((cast((\r\n\tselect distinct DLAMAssetClass3 as X\r\n\tfrom valuewhitelist_assetclass_dbinstype as inner_list\r\n\twhere inner_list.db_instype_desc = instr.db_instype_desc COLLATE Latin1_General_CI_AS\r\n\tfor xml path('')) as varchar(max))), \r\n\t'</X><X>', ', '),'<X>', ''),'</X>','') as allowed_DLAMAssetClass3_with_db_instype_desc,\r\n\r\n\t-- Get string concatenated value of all WFT which are allowed with the provided Sector2NoCountry\r\n\treplace(replace(replace((cast((\r\n\tselect distinct db_instype_desc as X\r\n\tfrom valuewhitelist_assetclass_dbinstype as inner_list\r\n\twhere inner_list.DLAMAssetClass3 = instr.DLAMAssetClass3 COLLATE Latin1_General_CI_AS\r\n\tfor xml path('')) as varchar(max))), \r\n\t'</X><X>', ', '),'<X>', ''),'</X>','') as allowed_db_instype_desc_with_DLAMAssetClass3\r\nFROM \r\n\tvx_FA_instrument_twice instr\r\nwhere\r\n\t-- set in scope\r\n\tDLAMSector1!='' and DLAMSector1!='-' and db_instype_desc is not null\r\n\t-- and not on the whitelist\r\n\tand not exists (\r\n\t\tselect * from valuewhitelist_assetclass_dbinstype wl where \r\n\t\t\twl.DLAMAssetClass1= instr.DLAMAssetClass1 COLLATE Latin1_General_CI_AS\r\n\t\t\tand wl.DLAMAssetClass2 = instr.DLAMAssetClass2 COLLATE Latin1_General_CI_AS\r\n\t\t\tand wl.DLAMAssetClass3 = instr.DLAMAssetClass3 COLLATE Latin1_General_CI_AS\r\n\t\t\tand wl.db_instype_desc = instr.db_instype_desc COLLATE Latin1_General_CI_AS\r\n\t\t
   difference
54       <NA>
DEBUG [2016-04-26 16:07:25] Validate, rowcount for dataset FA_rules_queries, file: 73, table: 73
DEBUG [2016-04-26 16:07:25] Validate, columncount for dataset FA_rules_queries, file: 2, table: 2
DEBUG [2016-04-26 16:07:25] Validate, hashtotal for dataset FA_rules_queries, column BR, file: 1788, table: 1788
```

```
DEBUG [2016-04-26 16:07:26] Validate, rowcount for dataset FA_rules_supersets, file: 73, table: 73
DEBUG [2016-04-26 16:07:26] Validate, columncount for dataset FA_rules_supersets, file: 2, table: 2
DEBUG [2016-04-26 16:07:26] Validate, hashtotal for dataset FA_rules_supersets, column BR, file: 1788, table: 1788
```


