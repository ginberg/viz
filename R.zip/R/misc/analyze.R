#analyze some tables from FA
library(dplyr)
library(RODBC)
library(GGally)

#setup db connection
channel <- odbcDriverConnect('driver={SQL Server};server=ONTW7D00489;database=AM_AdsP;trusted_connection=true')

#get all table names
tables <- sqlQuery(channel, "select * from INFORMATION_SCHEMA.TABLES")

table_names <- tables$TABLE_NAME
for(i in 1:length(table_names)){
  query <- "select count(*) from " + table_names[i]
  print(query)
  df <- sqlFetch(channel, table_names[i], max=100000) 
  print(table_names[i])
  str(df)
}

#get data
instruments <- sqlFetch(channel, "instrument", max=100000) 

fa_loan <- read.csv("file:///Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 2 - Front Arena/20160413/FA_Loan_P_20160414.csv", header = TRUE, stringsAsFactors = FALSE)
ggcorr(fa_loan)

# conDplyr = src_mysql(dbname = "AM_AdsP", host = "localhost", user = "AD\\d941950", password = "Aphajan81@")
# myData <- conDplyr %>%
#   tbl("airlines") %>%
#   select(year, airline, total_delay) %>%
#   filter(year==2010) %>%
#   collect()