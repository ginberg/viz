#########################################################
### Installing and loading required packages
#########################################################
require.installed <- function(p) {
  if (!is.element(p, installed.packages()[,1]))
    install.packages(p, dep = TRUE)
}

require.installed <- function(p) {
}
## All required packages by referenced scripts. If you add a package or get failures because of missing packages, please add them to this list!
required_packages<-c("gplots", "RColorBrewer", "ggplot2", "knitr","gridExtra","lubridate","prob","hash",
                     "plyr","reshape2","futile.logger","stringi","shinydashboard",
                     "caret","randomForest","e1071","gbm",
                     "RODBC","gdata", "rmarkdown","reader")
for(package in required_packages){
  require.installed(package)
}