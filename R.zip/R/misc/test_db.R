library(RODBC)
channel <- odbcDriverConnect('driver={SQL Server};server=ONTW7D00489;database=SourceData;trusted_connection=true')
str(channel)
#result <- sqlFetch(channel, "PO_4A", max=10) 
#print(result)

#query <- "SELECT * from PO_exchangerates" 
lines <- readLines("file:///C:/Beheer/7_Pipeline/SQL/businessrules/PO_0117_instrument_selfconsistent_dlamassetclass_matches_cic_code.sql")
query <- paste(lines, collapse=" ")
query <- gsub("\t","", query)

tryCatch({
  results <- sqlQuery(channel, query, errors = F) #Errors=F to be able to check errors with odbcGetErrMsg
  sql_errors <- odbcGetErrMsg(channel)
},
finally= close(channel)
)
if(length(sql_errors)>0){
  warning(sql_errors)
  stop(paste(sep="\r\n",
             "Failed to execute query:",
             query,
             "RODBC returned the following errors:",
             paste0(collapse="\r\n", sql_errors)))
}
print(results)
