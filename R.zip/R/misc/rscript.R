#!/usr/bin/env Rscript
cat("From command line")