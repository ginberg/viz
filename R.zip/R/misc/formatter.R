file <- portiapath("orig/Valutakoers 19feb.prn")
file2 <- portiapath("hfx_19feb.prn")
read.csv(file, stringsAsFactors=F, strip.white=TRUE, skip=c(1,2,3,4))