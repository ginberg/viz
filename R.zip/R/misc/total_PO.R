#script to add content of multiple BR output to one file
library(gtools)

getIdString <- function(id){
  if (i >= 1 & i<10)
    return(paste("PO_000",as.character(id), sep = ""))
  if (i >= 10 & i<100)
    return(paste("PO_00",as.character(id), sep = ""))
  else
    return(paste("PO_0",as.character(id), sep = ""))
}

getIdCsvString <- function(idString){
  return(paste(idString, ".csv", sep = ""))
}

# initialize
files_dir <- "Z:\\Shared Data\\5501_ProjectDataQuality\\1_Deliverables\\Deliverable - 4a\\Prio 1 - Portia\\Resultaten\\del 4a per 2015-11-03\\br_resultaten"
totalRows = 0
result <- data.frame()
startIndex <- 126
endIndex <- 186

#loop over files
cat("iterate over files in:", files_dir, "\n")
for(i in startIndex:endIndex){
  idString <- getIdString(i)
  idCsvString <- getIdCsvString(idString)
  file <- file.path(files_dir, idCsvString, fsep="\\")
  if (file.exists(file)){
    df <- read.csv(file, header = TRUE)
    rows <- nrow(df)
    if (rows > 0){
      print(i)
      df$BR <- getIdString(i)
      result <- smartbind(result, df)
      #in first iteration, first row is copied twice for some reason..remove it
      if (i == startIndex){
        result <- result[0:rows,]
      }
      totalRows <- totalRows + rows
    }
  }
}

#check total rows
result_rows <- nrow(result)
stopifnot(result_rows == totalRows)

result_file <- file.path(files_dir, "total.csv", fsep="\\")
write.csv(result, result_file, row.names = FALSE)
cat("output written to:", result_file)