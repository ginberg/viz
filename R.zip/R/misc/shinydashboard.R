require(Lahman)  
require(plyr)
require(rCharts)

dat = Teams[,c('yearID', 'name', 'G', 'SO')]
team_data = na.omit(transform(dat, SOG = round(SO/G, 2)))
league_data = ddply(team_data, .(yearID), summarize, SOG = mean(SOG))
THRESHOLD = 30
team_appearances = count(team_data, .(name))
teams_in_menu = subset(team_appearances, freq > THRESHOLD)$name

ui <- dashboardPage(
  dashboardHeader(title = "DQSS dashboard"),
  
  dashboardSidebar(sidebarPanel(
    selectInput(inputId = 'team',
                label = "Strikeouts per team per game",
                choices = teams_in_menu,
                selected = 'Boston Red Sox')
  )),
  
  dashboardBody(
    plotOutput("myChart")
  )
)

server <- function(input, output) {
  output$myChart <- renderChart({
    mytooltip = "function(item){return item.SOG + '\n' + item.name + '\n' + item.yearID}"
    p1 <- rPlot(SOG ~ yearID, data = team_data, type = 'point', 
                size = list(const = 2), color = list(const = '#888'), tooltip = mytooltip)
    p1$layer(data = league_data, type = 'line', color = list(const = 'blue'), 
             copy_layer = T, tooltip = NULL)
    p1$layer(data = team_data[team_data$name == input$team,], 
             color = list(const = 'red'), copy_layer = T)
    p1$set(height = 450)
    p1$guides(x = list(title = ""))
    p1$guides(y = list(title = ""))
    p1$set(title = 'Strikeouts per team per game', dom = 'myChart')
    return(p1)
  })
}

shinyApp(ui, server)
#library(shinyBS)
#bsTooltip("totalBR", "Number of rule failures per business rule")