#########################################################
### Loading packages to run pipeline
#########################################################

## All required packages to execute the pipeline. If you add a package or get failures because of missing packages, please add them to this list!
required_packages<-c("gplots", "RColorBrewer", "ggplot2", "knitr","gridExtra","lubridate","prob","hash",
                     "plyr","reshape2","futile.logger","stringi","shinydashboard",
                     "caret","randomForest","e1071","gbm",
                     "RODBC","gdata", "rmarkdown","reader")

for(package in required_packages){
  library(package, character.only = T)
}