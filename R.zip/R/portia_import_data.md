---
title: "Portia data import to database"
output: html_document
---






# Data Import

The data can contain the different values indicating one actual value (think of "Y" and "YES", or "-" and "n/a"). This report explains which value inconsistencies were found and how they have been normalized.







# Security holdings

```r
po_secshld <- portia.load(po_secshld, save=F)
```

DEBUG [2016-04-26 16:02:25] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 1 - Portia/20160412/DMsecsHLD.csv
Preprocessing data read from *DMsecsHLD.csv*  

```
There are 2 columns with name '5%strategi', they have been given numeric suffixes.  
Removed rows  3675 3676 3677 3678 3679 3680 3681 3682 3683 3684 3685 3686 3687 3688 3689 3690 3691 3692 3693 3694 3695 3696 3697 3698 3699 3700 3701 3702 3703 3704 3705 3706 3707 3708 3709 3710 3711 3712 3713 3714  because they contain only NA and empty values.  
Renaming column DLAMRatingManFlag to CIC
Renaming column GrootboekKlasse to CEDAR
```
Final column names of original dataframe:  

```
 [1] "Name"               "Description1"       "Description2"       "ISIN"               "SecClass"          
 [6] "Listed"             "GrootboekKlasse"    "MoodyRatin"         "S&PRating"          "FitchRatin"        
[11] "DLAMRating"         "DLAMSector1"        "DLAMSector2"        "DLAMSector3"        "DLAMSector4"       
[16] "DLAMAssetClass1"    "DLAMAssetClass2"    "DLAMAssetClass3"    "DLAMAssetClass4"    "CountryName"       
[21] "Exchange"           "INDUSTRY"           "FVLevel"            "DRA"                "WFT"               
[26] "ICBE"               "SecType"            "CIC"                "5%strategi1"        "DLAMCountryofRisk" 
[31] "IntlTax Status"     "Intl Income Type"   "Maturity D"         "Issue Date"         "GICS1"             
[36] "CurrencyIs"         "PriceSymbol"        "Sedol"              "BB Ticker"          "Exception"         
[41] "ISSUER"             "COUPON"             "AutoQuote"          "Frequentie"         "Source"            
[46] "SECURITY TYPE"      "UNIT PRICE"         "UNIT SIZE"          "SYMBOL"             "CountryofInCorpora"
[51] "Odd FirstCpn"       "OddLastCpn"         "run date"           "Run Time"           "Outstanding Sha"   
[56] "Issuer-ID"          "Issuer-Naam"        "RM"                 "5%Fiscaal"          "5%strategi2"       
[61] "5%Kapitaal"         "SIC Code"           "Nominale"           "GepltsKApitaal"     "TotaalStemmen"     
[66] "Stemrecht p/st"     "Register Extern"    "AgncyAvRating"      "AgncyAvPrRating"    "AgncyAvTotRtg"     
[71] "Manual Rating"      "Solvency II Rating" "DLAMRtgExp Date"    "Cusip"              "FranceTax"         
[76] "Sec-ID"             "Calendar MthdMthd"  "PaymentFreq"        "BeginDate(VRSSc"    "EndDate(VRSSchm"   
[81] "VRSSpread"          "VRSIndex"           "Error"              "Reset Frequency"    "Next Reset Date"   
[86] "Next Pay Date"      "Irregular Payments"
```
Did not convert column Description1 to numeric  because of too many failures (3674) compared to successes (0)
Converted column ICBE to numeric  but had 33 failed conversions. The unique values:'-'
Converted column VRSIndex to numeric  but had 113 failed conversions. The unique values:'EUR003M MTGE','EUR003M Index','EUR001M MTGE','US0001M Index','EUR001M Index','EUR012M MTGE','EUR006M MTGE','SNO-DLH PERP','BP0003M Index','CPTFEMUY Index','EUSA10 Index','US0003M MTGE','*7.875 Basis','*9.94 basis','STIB3M Index'
Casted column 'Listed' to boolean.
Casted column 'X5strategi2' to boolean.
Casted column 'X5Kapitaal' to boolean.
Casted column 'RegisterExtern' to boolean.

Additional data preparation (standardization)

```r
secshld<-data.frame(id=1:nrow(po_secshld$prep), po_secshld$prep)
## Dummy/stub/empty values
##
secshld[secshld$Exchange%in%c("-",""), "Exchange"] <- NA
secshld<-transform(secshld, Exchange=Exchange[, drop=TRUE])
##
secshld[secshld$CountryofInCorpora%in%c("-",""),"CountryofInCorpora"]<-NA
secshld<-transform(secshld, Exchange=Exchange[, drop=TRUE])
##
secshld[secshld$DLAMCountryofRisk%in%c("","-"), "DLAMCountryofRisk"] <- NA
secshld<-transform(secshld, DLAMCountryofRisk=DLAMCountryofRisk[, drop=TRUE])

## Normalize CountryName (to allow comparison to other country fields)
secshld$CountryName <- as.character(secshld$CountryName)
secshld$CountryName[secshld$CountryName=="SNAT"]<-"Supranational"
secshld$CountryName[secshld$CountryName=="Russian Federat"]<-"Russian Federation"
secshld$CountryName[secshld$CountryName=='United Arab Emi'] <- "United Arab Emirates"
secshld$CountryName <- as.factor(secshld$CountryName)

secshld$DLAMCountryofRisk<-as.character(secshld$DLAMCountryofRisk)
secshld$DLAMCountryofRisk[secshld$DLAMCountryofRisk=="Russian federation"] <- "Russian Federation"
secshld$DLAMCountryofRisk<- as.factor(secshld$DLAMCountryofRisk)
```

## Enrichments

```r
# Extract parts of the CIC code
secshld <- cbind(secshld, CIC_Country = as.factor(substr(secshld$CIC, 1, 2)))
secshld <- cbind(secshld, CIC_Code = as.factor(substr(secshld$CIC, 3, 4)))
secshld <- cbind(secshld, CIC_Group = as.factor(substr(secshld$CIC, 3, 3)))

## Determine duration at moment of issue
secshld <- transform(secshld, "InitialDurationy"=as.numeric(MaturityD-IssueDate)/365.4)

## Country extracted from DLAMSector, if available
secshld <- transform(secshld, SectorCountry=NA)
selection <- secshld$DLAMSector1=="Sovereigns" & secshld$DLAMSector2!="Other Sovereigns (in local currency)"
secshld[selection,"SectorCountry"]<-as.character(secshld[selection,"DLAMSector2"])

selection <- secshld$DLAMSector2 == "Covered"
secshld$SectorCountry[selection]<-
  sub("US","United States",
  sub("UK","United Kingdom",
  sub(" Covered", "", as.character(secshld$DLAMSector3[selection]))))

selection <- secshld$DLAMSector2=="Other Sovereigns (in foreign currency)" 
secshld[selection,"SectorCountry"]<-as.character(secshld[selection,"DLAMSector3"])
secshld$SectorCountry[secshld$SectorCountry=='Other'] <- NA
secshld[,"SectorCountry"] <- factor(secshld$SectorCountry, levels=sort(unique(secshld$SectorCountry)))

## DLAMSector2, but using DLAMSector1 if it is a country name
secshld <- transform(secshld, Sector2NoCountry=as.character(DLAMSector2), stringsAsFactors=F)
selection <- secshld$DLAMSector1=="Sovereigns" & secshld$DLAMSector2!="Other Sovereigns (in local currency)"
secshld$Sector2NoCountry[selection] <-as.character(secshld$DLAMSector1[selection])
secshld$Sector2NoCountry <- as.factor(secshld$Sector2NoCountry)

## Extracting coupon percentage from Description1
secshld <- transform(secshld, Description1_Coupon = gsub("^(\\d+\\.?,?\\d*%|())(.*)$", "\\1", Description1))
secshld <- transform(secshld, Description1_Coupon = gsub(",", "\\.", Description1_Coupon))

secshld <- transform(secshld, Description1_CouponNum = gsub("^$", "0", Description1_Coupon))
secshld <- transform(secshld, Description1_CouponNum = as.numeric(gsub("%", "", Description1_CouponNum)))

secshld <- transform(secshld, Description1_Coupon_Rounded=round(Description1_CouponNum+0.00000001, 0))# to prevent IEEE rounding
secshld <- transform(secshld, has_coupon=COUPON>0)

## Extracting frequency 
secshld <- transform(secshld, has_frequency=Frequentie!=''& Frequentie != 'Never')

## Mark internal identifiers found in ISIN
secshld <- transform(secshld, ISIN_Internal = grepl("^DLINT\\d+", ISIN))
secshld <- transform(secshld, ISIN_Participation = grepl("^PART\\d+", ISIN))
secshld <- transform(secshld, ISIN_UCode = grepl("^U\\_", ISIN))
secshld <- transform(secshld, ISIN_Empty = ISIN=='')
secshld <- transform(secshld, ISIN_Regular = !ISIN_Internal & 
                                            !ISIN_Participation & 
                                            !ISIN_UCode & 
                                            !ISIN_Empty & 
                                            nchar(as.character(ISIN))==12 &
                                            grepl("^[A-Z]{2}[0-9A-Z]{10}$", ISIN))
secshld <- transform(secshld, FutureSymbol = gsub(" ","",substr(as.character(ISIN),1,2)))
#secshld$FutureSymbol[secshld$SecClass!="Future"] <- NA
secshld <- transform(secshld, FutureMonth = substr(as.character(ISIN),3,3))
#secshld$FutureMonth[secshld$SecClass!="Future"] <- NA
secshld <- transform(secshld, FutureYear = suppressWarnings(as.numeric(substr(as.character(ISIN),4,4))))
#secshld$FutureYear[secshld$SecClass!="Future"] <- NA
secshld <- transform(secshld, ISIN_Future = !ISIN_Internal & 
                                            !ISIN_Participation & 
                                            !ISIN_UCode & 
                                            !ISIN_Empty & 
                                            nchar(as.character(ISIN))==4 &
                                            FutureSymbol%in%isin_future_codes$FutureSymbol &
                                            FutureMonth%in%isin_future_months$FutureMonth &
                                            !is.na(FutureYear))
# Option type: p(ut) / c(all)
secshld <- transform(secshld, OptionType = substr(as.character(ISIN),5,5))
secshld <- transform(secshld, ISIN_Option = !ISIN_Internal & 
                                            !ISIN_Participation & 
                                            !ISIN_UCode & 
                                            !ISIN_Empty & 
                                            FutureSymbol%in%isin_future_codes$FutureSymbol &
                                            FutureMonth%in%isin_future_months$FutureMonth &
                                            OptionType%in%c("P","C") &
                                            nchar(as.character(ISIN))==12)

# ISIN Exchange
secshld <- transform(secshld, ISIN_Exchange = substr(as.character(ISIN),1,2)) # first 2 character
secshld$ISIN_Exchange[!secshld$ISIN_Regular] <- NA
po_secshld$prep <- secshld
```

## Summary
The security holdings dataset contains the following fields:

```
  [1] "id"                          "Name"                        "Description1"               
  [4] "Description2"                "ISIN"                        "SecClass"                   
  [7] "Listed"                      "CEDAR"                       "MoodyRatin"                 
 [10] "SPRating"                    "FitchRatin"                  "DLAMRating"                 
 [13] "DLAMSector1"                 "DLAMSector2"                 "DLAMSector3"                
 [16] "DLAMSector4"                 "DLAMAssetClass1"             "DLAMAssetClass2"            
 [19] "DLAMAssetClass3"             "DLAMAssetClass4"             "CountryName"                
 [22] "Exchange"                    "INDUSTRY"                    "FVLevel"                    
 [25] "DRA"                         "WFT"                         "ICBE"                       
 [28] "SecType"                     "CIC"                         "X5strategi1"                
 [31] "DLAMCountryofRisk"           "IntlTaxStatus"               "IntlIncomeType"             
 [34] "MaturityD"                   "IssueDate"                   "GICS1"                      
 [37] "CurrencyIs"                  "PriceSymbol"                 "Sedol"                      
 [40] "BBTicker"                    "Exception"                   "ISSUER"                     
 [43] "COUPON"                      "AutoQuote"                   "Frequentie"                 
 [46] "Source"                      "SECURITYTYPE"                "UNITPRICE"                  
 [49] "UNITSIZE"                    "SYMBOL"                      "CountryofInCorpora"         
 [52] "OddFirstCpn"                 "OddLastCpn"                  "rundate"                    
 [55] "RunTime"                     "OutstandingSha"              "IssuerID"                   
 [58] "IssuerNaam"                  "RM"                          "X5Fiscaal"                  
 [61] "X5strategi2"                 "X5Kapitaal"                  "SICCode"                    
 [64] "Nominale"                    "GepltsKApitaal"              "TotaalStemmen"              
 [67] "Stemrechtpst"                "RegisterExtern"              "AgncyAvRating"              
 [70] "AgncyAvPrRating"             "AgncyAvTotRtg"               "ManualRating"               
 [73] "SolvencyIIRating"            "DLAMRtgExpDate"              "Cusip"                      
 [76] "FranceTax"                   "SecID"                       "CalendarMthdMthd"           
 [79] "PaymentFreq"                 "BeginDateVRSSc"              "EndDateVRSSchm"             
 [82] "VRSSpread"                   "VRSIndex"                    "Error"                      
 [85] "ResetFrequency"              "NextResetDate"               "NextPayDate"                
 [88] "IrregularPayments"           "source_date"                 "source_file"                
 [91] "CIC_Country"                 "CIC_Code"                    "CIC_Group"                  
 [94] "InitialDurationy"            "SectorCountry"               "Sector2NoCountry"           
 [97] "Description1_Coupon"         "Description1_CouponNum"      "Description1_Coupon_Rounded"
[100] "has_coupon"                  "has_frequency"               "ISIN_Internal"              
[103] "ISIN_Participation"          "ISIN_UCode"                  "ISIN_Empty"                 
[106] "ISIN_Regular"                "FutureSymbol"                "FutureMonth"                
[109] "FutureYear"                  "ISIN_Future"                 "OptionType"                 
[112] "ISIN_Option"                 "ISIN_Exchange"              
```

```
'data.frame':	3674 obs. of  113 variables:
 $ id                         : int  1 2 3 4 5 6 7 8 9 10 ...
 $ Name                       : chr  "3I GROUP PLC" "3M" "8POINT3 ENERGY" "AA GARANT PLUS" ...
 $ Description1               : chr  "3i Group PLC" "3M Co" "8Point3 Energy Partners Lp" "ABN AMRO Garant Plus Fonds" ...
 $ Description2               : chr  "III LN Equity" "MMM US Equity" "CAFD US Equity" "-" ...
 $ ISIN                       : chr  "GB00B1YW4409" "US88579Y1010" "US2825391053" "NL0000230233" ...
 $ SecClass                   : Factor w/ 5 levels "","Bond","Future",..: 5 5 5 5 2 2 2 2 2 5 ...
 $ Listed                     : logi  TRUE TRUE TRUE FALSE FALSE TRUE ...
 $ CEDAR                      : Factor w/ 14 levels "","AAN","DEP",..: 2 2 2 2 9 11 11 11 11 2 ...
 $ MoodyRatin                 : Factor w/ 18 levels "","A1","A2","A3",..: 18 18 18 18 18 13 13 5 5 18 ...
 $ SPRating                   : Factor w/ 18 levels "","A","A-","A+",..: 18 18 18 18 18 10 10 7 7 18 ...
 $ FitchRatin                 : Factor w/ 15 levels "","A","A-","A+",..: 15 15 15 15 15 10 10 15 15 15 ...
 $ DLAMRating                 : Factor w/ 19 levels "","A1","A2","A3",..: 19 19 19 19 19 12 12 5 5 19 ...
 $ DLAMSector1                : Factor w/ 6 levels "","-","Collateralized",..: 4 4 4 2 3 4 4 4 4 4 ...
 $ DLAMSector2                : Factor w/ 46 levels "","-","Agencies",..: 10 23 23 2 37 23 23 23 23 23 ...
 $ DLAMSector3                : Factor w/ 55 levels "","-","ABS","Australia Covered",..: 18 25 55 2 39 6 6 51 51 25 ...
 $ DLAMSector4                : Factor w/ 38 levels "","-","ABS CDO",..: 6 19 38 2 2 7 7 35 35 19 ...
 $ DLAMAssetClass1            : Factor w/ 8 levels "","Alternative",..: 5 5 5 5 6 6 6 6 6 5 ...
 $ DLAMAssetClass2            : Factor w/ 20 levels "","Bond","CDO Equity",..: 14 14 14 7 2 2 2 2 2 14 ...
 $ DLAMAssetClass3            : Factor w/ 33 levels "","-","5% Participation Share",..: 6 6 6 24 15 14 14 14 14 6 ...
 $ DLAMAssetClass4            : Factor w/ 9 levels "","-","5% Participation Share",..: 2 2 2 2 2 2 2 2 2 2 ...
 $ CountryName                : Factor w/ 64 levels "Australia","Austria",..: 62 63 63 39 39 62 62 63 63 57 ...
 $ Exchange                   : Factor w/ 62 levels "AT","AU","AV",..: 35 61 61 NA NA 35 35 17 17 62 ...
 $ INDUSTRY                   : Factor w/ 69 levels "","-","Aerospace & Defense",..: 12 38 37 2 2 2 2 2 2 25 ...
 $ FVLevel                    : int  1 1 1 2 2 1 1 1 1 1 ...
 $ DRA                        : Factor w/ 7 levels "","Niet-financi�le instellingen",..: 4 2 2 6 4 2 2 2 2 2 ...
 $ WFT                        : Factor w/ 8 levels "","Bouwnijverheid",..: 3 7 7 6 3 7 7 7 7 7 ...
 $ ICBE                       : num  1 1 1 1 1 1 1 1 1 1 ...
 $ SecType                    : Factor w/ 68 levels "","!B A/360 P1 T+2",..: 51 55 55 55 6 12 12 12 12 52 ...
 $ CIC                        : Factor w/ 207 levels "","AT11","AT19",..: 81 164 166 196 191 77 77 162 35 27 ...
 $ X5strategi1                : int  0 0 0 0 0 0 0 0 0 0 ...
 $ DLAMCountryofRisk          : Factor w/ 59 levels "Australia","Austria",..: 57 58 58 34 34 57 57 58 58 52 ...
 $ IntlTaxStatus              : Factor w/ 3 levels "","Real Estate",..: 3 3 3 1 1 1 1 1 1 3 ...
 $ IntlIncomeType             : Factor w/ 4 levels "","Coupon","Dividend",..: 3 3 3 3 2 2 2 2 2 3 ...
 $ MaturityD                  : Factor w/ 1240 levels "","1/1/2017",..: 1 1 1 1 406 744 610 259 261 1 ...
 $ IssueDate                  : Factor w/ 1091 levels "","1/1/2010",..: 1 1 1 1 399 661 548 204 204 1 ...
 $ GICS1                      : Factor w/ 12 levels "","-","Consumer Discretionary",..: 6 8 12 2 2 2 2 2 2 8 ...
 $ CurrencyIs                 : Factor w/ 38 levels "","AUD","BRL",..: 12 35 35 10 10 10 10 10 10 5 ...
 $ PriceSymbol                : chr  "III LN" "MMM US" "CAFD US" "" ...
 $ Sedol                      : chr  "B1YW440" "2595708" "BZ0XXJ3" "-" ...
 $ BBTicker                   : chr  "III LN Equity" "MMM US Equity" "CAFD US Equity" "" ...
 $ Exception                  : Factor w/ 7 levels "","Corp. Action",..: 1 1 1 1 1 1 1 1 1 1 ...
 $ ISSUER                     : Factor w/ 834 levels "","3i Group PLC",..: 2 3 1 10 5 1 50 1 1 6 ...
 $ COUPON                     : num  0 0 0 0 0 ...
 $ AutoQuote                  : Factor w/ 3 levels "","No","Yes": 3 3 3 2 2 3 3 3 3 3 ...
 $ Frequentie                 : Factor w/ 6 levels "","Daily","Monthly",..: 1 1 1 2 3 1 1 1 1 1 ...
 $ Source                     : Factor w/ 26 levels "","AIFS Investor",..: 1 1 1 8 12 1 1 1 1 1 ...
 $ SECURITYTYPE               : Factor w/ 58 levels "","!Futr Euro Bund",..: 37 35 35 35 14 24 24 24 24 33 ...
 $ UNITPRICE                  : num  0.01 1 1 1 0.01 0.01 0.01 0.01 0.01 1 ...
 $ UNITSIZE                   : num  1 1 1 1 1 1 1 1 1 1 ...
 $ SYMBOL                     : Factor w/ 35 levels "","AUD","BRL",..: 10 32 32 9 9 9 9 9 9 5 ...
 $ CountryofInCorpora         : Factor w/ 66 levels "","-","Australia",..: 64 65 65 40 40 64 64 65 65 59 ...
 $ OddFirstCpn                : Factor w/ 522 levels "","1/10/2013",..: 1 1 1 1 233 1 251 1 1 1 ...
 $ OddLastCpn                 : Factor w/ 371 levels "","1/10/2022",..: 1 1 1 1 102 1 175 1 1 1 ...
 $ rundate                    : Factor w/ 2 levels "","4/12/2016": 2 2 2 2 2 2 2 2 2 2 ...
 $ RunTime                    : Factor w/ 2 levels "","01:00am": 2 2 2 2 2 2 2 2 2 2 ...
 $ OutstandingSha             : num  9.73e+08 6.06e+08 2.00e+07 0.00 0.00 ...
 $ IssuerID                   : int  154228 101001 44825295 1 1 8064210 8064210 101695 101695 825197 ...
 $ IssuerNaam                 : Factor w/ 2286 levels "","-","3I Group Plc",..: 3 4 5 2 2 130 130 147 147 7 ...
 $ RM                         : int  11982310 12018356 12595719 7600192 13157227 11213977 7175776 11205641 11205634 7320401 ...
 $ X5Fiscaal                  : int  0 0 0 0 0 0 0 0 0 NA ...
 $ X5strategi2                : logi  NA NA NA NA NA NA ...
 $ X5Kapitaal                 : logi  NA NA NA NA NA NA ...
 $ SICCode                    : Factor w/ 2 levels "","DLPR": 1 1 1 2 2 1 1 1 1 1 ...
 $ Nominale                   : num  0e+00 0e+00 0e+00 0e+00 0e+00 1e+05 1e+05 1e+05 1e+05 0e+00 ...
 $ GepltsKApitaal             : num  0 0 0 0 0 750000 750000 1400000 1400000 0 ...
 $ TotaalStemmen              : num  0 0 0 0 0 0 0 0 0 0 ...
 $ Stemrechtpst               : num  0 0 0 0 0 0 0 0 0 0 ...
 $ RegisterExtern             : logi  FALSE FALSE FALSE FALSE FALSE FALSE ...
 $ AgncyAvRating              : Factor w/ 19 levels "","A1","A2","A3",..: 19 19 19 19 19 12 12 5 5 19 ...
 $ AgncyAvPrRating            : Factor w/ 13 levels "","A1","A2","A3",..: 13 13 13 13 13 13 13 13 13 13 ...
 $ AgncyAvTotRtg              : Factor w/ 19 levels "","A1","A2","A3",..: 19 19 19 19 19 12 12 5 5 19 ...
 $ ManualRating               : Factor w/ 13 levels "","A1","A2","A3",..: 13 13 13 13 13 13 13 13 13 13 ...
 $ SolvencyIIRating           : int  9 9 9 9 9 4 4 1 1 9 ...
 $ DLAMRtgExpDate             : Factor w/ 43 levels "","1/1/2030",..: 1 1 1 1 29 1 1 1 1 1 ...
 $ Cusip                      : Factor w/ 713 levels "","00101J106",..: 1 611 181 1 1 1 1 1 1 1 ...
 $ FranceTax                  : Factor w/ 3 levels "","Ja","Nee": 3 3 3 3 3 3 3 3 3 3 ...
 $ SecID                      : int  75317 32805 123746 91615 121887 120084 104617 120064 120066 16291 ...
 $ CalendarMthdMthd           : Factor w/ 6 levels "","30/360","30E/360",..: 2 2 2 2 4 6 6 6 6 2 ...
 $ PaymentFreq                : int  1 1 1 1 12 1 1 1 1 1 ...
 $ BeginDateVRSSc             : Factor w/ 174 levels "","1/10/2013",..: 1 1 1 1 1 1 1 1 1 1 ...
 $ EndDateVRSSchm             : Factor w/ 172 levels "","1/10/2024",..: 1 1 1 1 1 1 1 1 1 1 ...
 $ VRSSpread                  : num  0 0 0 0 0 0 0 0 0 0 ...
 $ VRSIndex                   : num  NA NA NA NA NA NA NA NA NA NA ...
 $ Error                      : Factor w/ 4 levels "","Begin Date",..: 4 4 4 4 3 3 3 3 3 4 ...
 $ ResetFrequency             : Factor w/ 6 levels "","Annually",..: 3 3 3 3 3 3 3 3 3 3 ...
 $ NextResetDate              : Factor w/ 120 levels "","1/10/2017",..: 1 1 1 1 1 1 1 1 1 1 ...
 $ NextPayDate                : Factor w/ 338 levels "","1/10/2017",..: 1 1 1 1 173 186 153 58 58 1 ...
 $ IrregularPayments          : Factor w/ 3 levels "","No","Yes": 2 2 2 2 2 2 2 2 2 2 ...
 $ source_date                : Date, format: "2016-04-12" "2016-04-12" "2016-04-12" "2016-04-12" ...
 $ source_file                : Factor w/ 1 level "DMsecsHLD.csv": 1 1 1 1 1 1 1 1 1 1 ...
 $ CIC_Country                : Factor w/ 45 levels "","AT","AU","BE",..: 16 41 41 44 44 16 16 41 10 7 ...
 $ CIC_Code                   : Factor w/ 35 levels "","11","12","13",..: 11 11 15 16 7 7 7 7 7 11 ...
 $ CIC_Group                  : Factor w/ 11 levels "","1","2","3",..: 4 4 4 5 3 3 3 3 3 4 ...
 $ InitialDurationy           : num  NA NA NA NA NA NA NA NA NA NA ...
 $ SectorCountry              : Factor w/ 45 levels "Australia","Austria",..: NA NA NA NA NA NA NA NA NA NA ...
 $ Sector2NoCountry           : Factor w/ 15 levels "-","Agencies",..: 4 5 5 1 13 5 5 5 5 5 ...
 $ Description1_Coupon        : chr  "" "" "" "" ...
 $ Description1_CouponNum     : num  0 0 0 0 0 ...
 $ Description1_Coupon_Rounded: num  0 0 0 0 0 3 4 1 2 0 ...
  [list output truncated]
```
GICS : Global Industry Classification Standard  
CICS : Solvency II Complementary Identification Code (CIC)  

# Portia Total Holdings


```r
po_portiatotal <- portia.load(po_portiatotal, save=F)
```

```
# DEBUG [2016-04-26 16:02:28] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 1 - Portia/20160412/RM-PortiaTotal_P_20160413.csv
# Preprocessing data read from *RM-PortiaTotal_P_20160413.csv*  
# 
# ```
# [1] "Columns with only <NA> values are removed : CallDate, CallFrequency, CallPrice, Convexity, IdentifierType, UnIdentifierType, PremiumPaid, QuantityTM"
# Renaming column ContractSize to UNIT SIZE
# ```
# Final column names of original dataframe:  
# 
# ```
#  [1] "BusinessUnit"        "CLIENTNAAM"          "PortfolioNaam"       "ReportingDate"       "DLAMAssetClass1"    
#  [6] "DLAMAssetClass2"     "DLAMAssetClass3"     "DLAMAssetClass4"     "Securitynaam"        "Description"        
# [11] "IssuerIDNaam"        "ISIN"                "Sedol"               "PERCENT"             "Exchange"           
# [16] "Issuedate"           "MaturityDate"        "Expirationdate"      "CallDate"            "CallFrequency"      
# [21] "CallPrice"           "PaymentFrequency"    "MUNT"                "FXRATE"              "COUPONRATE"         
# [26] "DLAMCountryofRisk"   "SP"                  "MOODY"               "Fitch"               "DLRating"           
# [31] "INDUSTRY"            "DLAMSector1"         "DLAMSector2"         "DLAMSector3"         "DLAMSector4"        
# [36] "BOOK_VALUE"          "NominaalEur"         "QUANTITY"            "KOERS"               "MWinclLREur"        
# [41] "AcruedInterestEur"   "Yield"               "Duration"            "Convexity"           "Position"           
# [46] "STRIKE"              "Option_type"         "UNDERLYING"          "FVLevel"             "DLAMTheme1"         
# [51] "DLAMTheme2"          "Listed"              "Cedar_Classificatie" "IssuerID"            "SecDescription2"    
# [56] "Cedar_BU_Nr"         "PurchaseCost"        "TradeDate"           "UnderlyingBB"        "RiskType"           
# [61] "FondsISIN"           "ContractSize"        "Custodian"           "CustodianLegalName"  "IdentifierType"     
# [66] "CreditQualityStep"   "SharesOutstanding"   "UnderlIdentifier"    "NumberOfContracts"   "KoersEUR"           
# [71] "UnIdentifierType"    "PremiumPaid"         "PriceUnit"           "InflationFactor"     "QuantityTM"         
# ```
# Did not convert column Description to numeric  because of too many failures (10195) compared to successes (0)
# Did not convert column Sedol to numeric  because of too many failures (8115) compared to successes (2077)
# Converted column ReportingDate to Date (format=%d/%m/%Y)  with no failures on 10195 nonempty values.  
# Converted column Issuedate to Date (format=%d/%m/%Y)  with no failures on 6423 nonempty values.   All unique failures: ''.  
# Converted column MaturityDate to Date (format=%d/%m/%Y)  with no failures on 6423 nonempty values.   All unique failures: ''.  
# Converted column Expirationdate to Date (format=%d/%m/%Y)  with no failures on 102 nonempty values.   All unique failures: ''.  
# Converted column TradeDate to Date (format=%d/%m/%Y)  with no failures on 10195 nonempty values.  
# Casted column 'Listed' to boolean.
```

Data preparation (standardization)

```r
portiatotal <-data.frame(id=1:nrow(po_portiatotal$prep), po_portiatotal$prep)

## Dummy/stub/empty values
##
portiatotal$UNDERLYING <- as.na(portiatotal$UNDERLYING, c("-",""))
##
portiatotal$STRIKE <- as.na(portiatotal$STRIKE, c("-",""))
##
portiatotal$DLAMSector1 <-as.na(portiatotal$DLAMSector1, c(""))
portiatotal$DLAMSector2 <-as.na(portiatotal$DLAMSector2, c(""))
portiatotal$DLAMSector3 <-as.na(portiatotal$DLAMSector3, c(""))
portiatotal$DLAMSector4 <-as.na(portiatotal$DLAMSector4, c(""))
portiatotal$DLAMCountryofRisk <- as.na(portiatotal$DLAMCountryofRisk, c("","-"))

# Option type: p(ut) / c(all)
portiatotal <- transform(portiatotal, OptionType = substr(as.character(ISIN),5,5))
po_portiatotal$prep <- portiatotal
```

<!-- Note, is Issuer.ID constant for same issuer? Description indicates not... -->
## Other views


# Elaboration on normalization

## Exchanges
The following exchanges have been used for the securities:

```
      -  AT  AU  AV  BB  BC  BS  CI CME  CN  DC EUX  FH  FM  FP  GB  GD  GF  GH  GI  GM  GS  GU  GY  HB  HK  HM ICF  ID 
 40 292   1  78  22  63   1   3   1   1  92  20   7  14   2 174  29  91 287   2   5  43 195   1  63   1  56   9   1  75 
 IM  JP  KN  KS  LI LIF  LN  LX  MC  MM  NA  NO  NZ  PL  PM  PW  RE  SB  SE SGX  SJ  SM  SN  SO  SP  SS  SW  TB  TE  TI 
 72 325   1   2   1   1 343 116   1   4 186  10   8  12   1   3   3   4  16   1   7  30  10   2  33  32  16   2  66   3 
 TT  UN  US  VX 
  5  21 679  29 
```

Examples with exchange "":

```
     Description1 Description2 SecClass Listed GrootboekKlasse MoodyRatin Exchange
3675                                                                              
3676                                                                              
3677                                                                              
3678                                                                              
3679                                                                              
3680                                                                              
```

Examples with exchange "-":

```
                             Description1      Description2 SecClass Listed GrootboekKlasse MoodyRatin Exchange
4              ABN AMRO Garant Plus Fonds                 -    Stock    Nee             AAN         NR        -
5          ABN AMRO SME Partcipation B.V.                 -     Bond    Nee             LOS         NR        -
30 Abn Amro Converging Europe Investments                 -    Stock    Nee             AAN         NR        -
47                   PARTICIPATION  ACADE                 -    Stock    Nee             AAN         NR        -
49  FRN Credit Agricole Cib 12-16/10/2017 XS0842954850 Corp     Bond    Nee             OBN         NR        -
56 6.445% Achmea Hypotheekb 97-03/02/2017                 -     Bond    Nee             LOS         NR        -
```

Both "" and "-" are set as NA.

```
  AT   AU   AV   BB   BC   BS   CI  CME   CN   DC  EUX   FH   FM   FP   GB   GD   GF   GH   GI   GM   GS   GU   GY   HB 
   1   78   22   63    1    3    1    1   92   20    7   14    2  174   29   91  287    2    5   43  195    1   63    1 
  HK   HM  ICF   ID   IM   JP   KN   KS   LI  LIF   LN   LX   MC   MM   NA   NO   NZ   PL   PM   PW   RE   SB   SE  SGX 
  56    9    1   75   72  325    1    2    1    1  343  116    1    4  186   10    8   12    1    3    3    4   16    1 
  SJ   SM   SN   SO   SP   SS   SW   TB   TE   TI   TT   UN   US   VX NA's 
   7   30   10    2   33   32   16    2   66    3    5   21  679   29  292 
```

## Ratings

Values used for ratings:

```
 MoodyRatin  SPRating    FitchRatin  DLAMRating  AgncyAvRating AgncyAvPrRating ManualRating SolvencyIIRating
     :   0       :   0       :   0       :   0       :   1         :   1           :   1    Min.   :0.000   
 A1  :  68   A   :  85   A   : 109   A1  :  75   A1  :  73     A1  :   1       A1  :   1    1st Qu.:2.000   
 A2  :  92   A-  :  94   A-  : 107   A2  : 118   A2  : 112     A2  :   4       A2  :   2    Median :9.000   
 A3  :  77   A+  :  96   A+  :  49   A3  : 106   A3  : 100     A3  :   2       A3  :   4    Mean   :6.174   
 Aa1 :  82   AA  :  50   AA  : 148   AA1 : 139   AA1 : 138     AA1 :   1       AA2 :   2    3rd Qu.:9.000   
 Aa2 : 152   AA- :  80   AA- :  55   AA2 : 176   AA2 : 155     AA2 :  19       B1  :   2    Max.   :9.000   
 Aa3 :  48   AA+ :  91   AA+ :  67   AA3 : 115   AA3 : 105     AA3 :  10       BB1 :   5    NA's   :1       
 Aaa : 323   AAA : 158   AAA : 286   AAA : 346   AAA : 311     AAA :  34       BB2 :   1                    
 B2  :   1   B+  :   7   BB  :   4   B1  :   4   B1  :   2     BB1 :   2       BBB1:   8                    
 B3  :   2   BB  :  10   BB+ :  22   B2  :   1   B2  :   1     BB2 :   1       BBB2:  10                    
 Ba1 :  16   BB- :   1   BBB :  59   BB1 :  34   BB1 :  27     BBB1:   6       BBB3:   8                    
 Ba2 :  13   BB+ :  25   BBB-:  45   BB2 :  13   BB2 :  11     BBB2:   5       D   :   8                    
 Ba3 :   4   BBB : 106   BBB+: 142   BB3 :   5   BB3 :   5     NR  :3588       NR  :3622                    
 Baa1: 144   BBB-:  53   CCC+:   1   BBB1: 175   BBB1: 161                                                  
 Baa2: 132   BBB+: 140   NR  :2580   BBB2: 180   BBB2: 165                                                  
 Baa3:  50   CCC :   1               BBB3:  45   BBB3:  37                                                  
 Caa1:   1   D   :   3               CCC1:   1   CCC1:   1                                                  
 NR  :2469   NR  :2674               D   :  11   D   :   3                                                  
                                     NR  :2130   NR  :2266                                                  
 AgncyAvTotRtg
     :   1    
 A1  :  74    
 A2  : 116    
 A3  : 102    
 AA1 : 139    
 AA2 : 174    
 AA3 : 115    
 AAA : 345    
 B1  :   2    
 B2  :   1    
 BB1 :  29    
 BB2 :  12    
 BB3 :   5    
 BBB1: 167    
 BBB2: 170    
 BBB3:  37    
 CCC1:   1    
 D   :   3    
 NR  :2181    
```

Most use NR (No Rating) for unavailable ratings. The first ones with AgncyAvPrRating equal to 'NR':

```
            Name         ISIN SecClass MoodyRatin SPRating FitchRatin DLAMRating AgncyAvRating AgncyAvPrRating
1   3I GROUP PLC GB00B1YW4409    Stock         NR       NR         NR         NR            NR              NR
2             3M US88579Y1010    Stock         NR       NR         NR         NR            NR              NR
3 8POINT3 ENERGY US2825391053    Stock         NR       NR         NR         NR            NR              NR
4 AA GARANT PLUS NL0000230233    Stock         NR       NR         NR         NR            NR              NR
5    AA SME 1225  DLINT006672     Bond         NR       NR         NR         NR            NR              NR
6 AALLN3.25 0423 XS1052677892     Bond        Ba3       BB        BB+        BB2           BB2              NR
  ManualRating SolvencyIIRating AgncyAvTotRtg
1           NR                9            NR
2           NR                9            NR
3           NR                9            NR
4           NR                9            NR
5           NR                9            NR
6           NR                4           BB2
```

Some use "" for unavailable ratings.The first ones with AgncyAvPrRating equal to '':

```
               Name         ISIN SecClass MoodyRatin SPRating FitchRatin DLAMRating AgncyAvRating AgncyAvPrRating
633 CANADA3.50 0120 XS0477543721     Bond        Aaa      AAA        AAA        AAA                              
    ManualRating SolvencyIIRating AgncyAvTotRtg
633                            NA              
```

Ratings with '' or 'NR' are all set to NA 


The corrected original ratings:

```
 MoodyRatin  SPRating    FitchRatin  DLAMRating  AgncyAvRating AgncyAvPrRating ManualRating SolvencyIIRating
     :   0       :   0       :   0       :   0       :   1         :   1           :   1    Min.   :0.000   
 A1  :  68   A   :  85   A   : 109   A1  :  75   A1  :  73     A1  :   1       A1  :   1    1st Qu.:2.000   
 A2  :  92   A-  :  94   A-  : 107   A2  : 118   A2  : 112     A2  :   4       A2  :   2    Median :9.000   
 A3  :  77   A+  :  96   A+  :  49   A3  : 106   A3  : 100     A3  :   2       A3  :   4    Mean   :6.174   
 Aa1 :  82   AA  :  50   AA  : 148   AA1 : 139   AA1 : 138     AA1 :   1       AA2 :   2    3rd Qu.:9.000   
 Aa2 : 152   AA- :  80   AA- :  55   AA2 : 176   AA2 : 155     AA2 :  19       B1  :   2    Max.   :9.000   
 Aa3 :  48   AA+ :  91   AA+ :  67   AA3 : 115   AA3 : 105     AA3 :  10       BB1 :   5    NA's   :1       
 Aaa : 323   AAA : 158   AAA : 286   AAA : 346   AAA : 311     AAA :  34       BB2 :   1                    
 B2  :   1   B+  :   7   BB  :   4   B1  :   4   B1  :   2     BB1 :   2       BBB1:   8                    
 B3  :   2   BB  :  10   BB+ :  22   B2  :   1   B2  :   1     BB2 :   1       BBB2:  10                    
 Ba1 :  16   BB- :   1   BBB :  59   BB1 :  34   BB1 :  27     BBB1:   6       BBB3:   8                    
 Ba2 :  13   BB+ :  25   BBB-:  45   BB2 :  13   BB2 :  11     BBB2:   5       D   :   8                    
 Ba3 :   4   BBB : 106   BBB+: 142   BB3 :   5   BB3 :   5     NR  :3588       NR  :3622                    
 Baa1: 144   BBB-:  53   CCC+:   1   BBB1: 175   BBB1: 161                                                  
 Baa2: 132   BBB+: 140   NR  :2580   BBB2: 180   BBB2: 165                                                  
 Baa3:  50   CCC :   1               BBB3:  45   BBB3:  37                                                  
 Caa1:   1   D   :   3               CCC1:   1   CCC1:   1                                                  
 NR  :2469   NR  :2674               D   :  11   D   :   3                                                  
                                     NR  :2130   NR  :2266                                                  
 AgncyAvTotRtg
     :   1    
 A1  :  74    
 A2  : 116    
 A3  : 102    
 AA1 : 139    
 AA2 : 174    
 AA3 : 115    
 AAA : 345    
 B1  :   2    
 B2  :   1    
 BB1 :  29    
 BB2 :  12    
 BB3 :   5    
 BBB1: 167    
 BBB2: 170    
 BBB3:  37    
 CCC1:   1    
 D   :   3    
 NR  :2181    
```


## Rating normalization
There are 3 source ratings (from Moody, S&P and Fitch), and one internal resulting rating (DLAM) and a manual rating. They use different labels for specific rating levels. To compare their relative distributions we need to map them to one set of values.


All ratings are transformed to a numeric rating rank, and are available both as a wide and a long list.


Some normalized rating levels:

```
   id MoodyRatin SPRating FitchRatin DLAMRating AgncyAvRating AgncyAvPrRating ManualRating SolvencyIIRating
11 11          5        6          6          6             6               0           NA               NA
12 12          1        1          1          1             1               0           NA               NA
13 13          1        1          1          1             1               0           NA               NA
14 14          1        1          1          1             1               0           NA               NA
15 15          1        1          1          1             1               0           NA               NA
16 16          1        1          1          1             1               0           NA               NA
   AgncyAvTotRtg
11             6
12             1
13             1
14             1
15             1
16             1
```

Some normalized rating labels

```
   id MoodyRatin SPRating FitchRatin DLAMRating AgncyAvRating AgncyAvPrRating ManualRating SolvencyIIRating
11 11         A1       A2         A2         A2            A2            <NA>         <NA>             <NA>
12 12        AAA      AAA        AAA        AAA           AAA            <NA>         <NA>             <NA>
13 13        AAA      AAA        AAA        AAA           AAA            <NA>         <NA>             <NA>
14 14        AAA      AAA        AAA        AAA           AAA            <NA>         <NA>             <NA>
15 15        AAA      AAA        AAA        AAA           AAA            <NA>         <NA>             <NA>
16 16        AAA      AAA        AAA        AAA           AAA            <NA>         <NA>             <NA>
   AgncyAvTotRtg
11            A2
12           AAA
13           AAA
14           AAA
15           AAA
16           AAA
```



The number of securities per normalized rating:  

```
 MoodyRatin  SPRating    FitchRatin  DLAMRating  AgncyAvRating AgncyAvPrRating ManualRating SolvencyIIRating
 AAA : 323   AAA : 158   AAA : 286   AAA : 346   AAA : 311     AAA :  34       AAA :   0    AAA :   0       
 AA1 :  82   AA1 :  91   AA1 :  67   AA1 : 139   AA1 : 138     AA1 :   1       AA1 :   0    AA1 :   0       
 AA2 : 152   AA2 :  50   AA2 : 148   AA2 : 176   AA2 : 155     AA2 :  19       AA2 :   0    AA2 :   0       
 AA3 :  48   AA3 :  80   AA3 :  55   AA3 : 115   AA3 : 105     AA3 :  10       AA3 :   0    AA3 :   0       
 A1  :  68   A1  :  96   A1  :  49   A1  :  75   A1  :  73     A1  :   1       A1  :   0    A1  :   0       
 A2  :  92   A2  :  85   A2  : 109   A2  : 118   A2  : 112     A2  :   4       A2  :   0    A2  :   0       
 A3  :  77   A3  :  94   A3  : 107   A3  : 106   A3  : 100     A3  :   2       A3  :   0    A3  :   0       
 BBB1: 144   BBB1: 140   BBB1: 142   BBB1: 175   BBB1: 161     BBB1:   6       BBB1:   0    BBB1:   0       
 BBB2: 132   BBB2: 106   BBB2:  59   BBB2: 180   BBB2: 165     BBB2:   5       BBB2:   0    BBB2:   0       
 BBB3:  50   BBB3:  53   BBB3:  45   BBB3:  45   BBB3:  37     BBB3:   0       BBB3:   0    BBB3:   0       
 BB1 :  16   BB1 :  25   BB1 :  22   BB1 :  34   BB1 :  27     BB1 :   2       BB1 :   0    BB1 :   0       
 BB2 :  13   BB2 :  10   BB2 :   4   BB2 :  13   BB2 :  11     BB2 :   1       BB2 :   0    BB2 :   0       
 BB3 :   4   BB3 :   1   BB3 :   0   BB3 :   5   BB3 :   5     BB3 :   0       BB3 :   0    BB3 :   0       
 B1  :   0   B1  :   7   B1  :   0   B1  :   4   B1  :   2     B1  :   0       B1  :   0    B1  :   0       
 B2  :   1   B2  :   0   B2  :   0   B2  :   1   B2  :   1     B2  :   0       B2  :   0    B2  :   0       
 B3  :   2   B3  :   0   B3  :   0   B3  :   0   B3  :   0     B3  :   0       B3  :   0    B3  :   0       
 CCC :   1   CCC :   1   CCC :   1   CCC :   1   CCC :   1     CCC :   0       CCC :   0    CCC :   0       
 CC  :   0   CC  :   0   CC  :   0   CC  :   0   CC  :   0     CC  :   0       CC  :   0    CC  :   0       
 C   :   0   C   :   0   C   :   0   C   :   0   C   :   0     C   :   0       C   :   0    C   :   0       
 D   :   0   D   :   3   D   :   0   D   :  11   D   :   3     D   :   0       D   :   0    D   :   0       
 NA's:2469   NA's:2674   NA's:2580   NA's:2130   NA's:2267     NA's:3589       NA's:3674    NA's:3674       
 AgncyAvTotRtg
 AAA : 345    
 AA1 : 139    
 AA2 : 174    
 AA3 : 115    
 A1  :  74    
 A2  : 116    
 A3  : 102    
 BBB1: 167    
 BBB2: 170    
 BBB3:  37    
 BB1 :  29    
 BB2 :  12    
 BB3 :   5    
 B1  :   2    
 B2  :   1    
 B3  :   0    
 CCC :   1    
 CC  :   0    
 C   :   0    
 D   :   3    
 NA's:2182    
```


````
DEBUG [2016-04-26 16:02:37] Saving data to table PO_secshld

```
DEBUG [2016-04-26 16:02:45] Validate, rowcount for dataset PO_secshld_orig, file: 3714, table: 3714
DEBUG [2016-04-26 16:02:45] Validate, columncount for dataset PO_secshld_orig, file: 87, table: 87
DEBUG [2016-04-26 16:02:45] Validate, hashtotal for dataset PO_secshld_orig, column COUPON, file: 4770.093, table: 4770.093
DEBUG [2016-04-26 16:02:56] Validate, rowcount for dataset PO_secshld, file: 3674, table: 3674
DEBUG [2016-04-26 16:02:56] Validate, columncount for dataset PO_secshld, file: 122, table: 122
DEBUG [2016-04-26 16:02:56] Validate, hashtotal for dataset PO_secshld, column COUPON, file: 4770.093, table: 4770.093

```

Saved processed file originating from  *DMsecsHLD.csv* in the database as table named  **PO_secshld**   
````


````
DEBUG [2016-04-26 16:03:06] Saving data to table PO_portiatotal

```
DEBUG [2016-04-26 16:03:29] Validate, rowcount for dataset PO_portiatotal_orig, file: 10195, table: 10195
DEBUG [2016-04-26 16:03:29] Validate, columncount for dataset PO_portiatotal_orig, file: 75, table: 75
DEBUG [2016-04-26 16:03:29] Validate, hashtotal for dataset PO_portiatotal_orig, column KOERS, file: 10698164.74, table: 10698164.74
DEBUG [2016-04-26 16:03:52] Validate, rowcount for dataset PO_portiatotal, file: 10195, table: 10195
DEBUG [2016-04-26 16:03:52] Validate, columncount for dataset PO_portiatotal, file: 83, table: 83
DEBUG [2016-04-26 16:03:52] Validate, hashtotal for dataset PO_portiatotal, column KOERS, file: 10698164.74, table: 10698164.74

```

Saved processed file originating from  *RM-PortiaTotal_P_20160413.csv* in the database as table named  **PO_portiatotal**   
````

# Custodian export
DEBUG [2016-04-26 16:04:15] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 1 - Portia/20160412/FNDSTT.dat
Loading fndstt definition file
DEBUG [2016-04-26 16:04:15] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 1 - Portia/20160412/fndstt_description.csv
Preprocessing data read from *fndstt_description.csv*  

```
```
Final column names of original dataframe:  

```
[1] "L"           "Description" "Particulars" "decimals"    "explanation"
```
Loaded fndstt definition file 
Taking care of decimals in following columns:
[1] "nominal.balance.of.bonds.or.number.of.shares" "securites.price"                             
[3] "foreign.exchange.rate"                        "effective.value"                             
[5] "interest.rate"                                "paid.up.amount"                              
[7] "amount.of.distribution"                       "quantity"                                    
[9] "exchange.rate.euro"                          
Current value ranges:
 nominal.balance.of.bonds.or.number.of.shares securites.price     foreign.exchange.rate effective.value    
 Min.   :0.000e+00                            Min.   :0.000e+00   Min.   :        0     Min.   :0.000e+00  
 1st Qu.:5.237e+06                            1st Qu.:7.505e+06   1st Qu.:  1000000     1st Qu.:3.897e+07  
 Median :5.736e+07                            Median :1.023e+07   Median :  1000000     Median :1.115e+08  
 Mean   :5.921e+09                            Mean   :9.209e+07   Mean   :  9094120     Mean   :6.456e+08  
 3rd Qu.:2.300e+08                            3rd Qu.:1.151e+07   3rd Qu.:  1086100     3rd Qu.:3.159e+08  
 Max.   :2.150e+13                            Max.   :5.750e+10   Max.   :784000000     Max.   :2.222e+11  
                                                                                                           
 interest.rate     paid.up.amount amount.of.distribution    quantity         exchange.rate.euro 
 Min.   :      0   Min.   :0      Min.   :0              Min.   :7.000e+06   Min.   :0.000e+00  
 1st Qu.:      0   1st Qu.:0      1st Qu.:0              1st Qu.:5.802e+10   1st Qu.:1.000e+06  
 Median : 130000   Median :0      Median :0              Median :6.000e+11   Median :1.000e+06  
 Mean   : 179761   Mean   :0      Mean   :0              Mean   :5.969e+13   Mean   :1.457e+07  
 3rd Qu.: 325000   3rd Qu.:0      3rd Qu.:0              3rd Qu.:2.364e+12   3rd Qu.:1.086e+06  
 Max.   :1250000   Max.   :0      Max.   :0              Max.   :2.150e+17   Max.   :1.511e+10  
                                                         NA's   :59                             
Final value ranges:
 nominal.balance.of.bonds.or.number.of.shares securites.price    foreign.exchange.rate effective.value    
 Min.   :0.000e+00                            Min.   :     0.0   Min.   :  0.000       Min.   :0.000e+00  
 1st Qu.:5.237e+04                            1st Qu.:    75.0   1st Qu.:  1.000       1st Qu.:3.897e+05  
 Median :5.736e+05                            Median :   102.3   Median :  1.000       Median :1.115e+06  
 Mean   :5.921e+07                            Mean   :   920.9   Mean   :  9.094       Mean   :6.456e+06  
 3rd Qu.:2.300e+06                            3rd Qu.:   115.1   3rd Qu.:  1.086       3rd Qu.:3.159e+06  
 Max.   :2.150e+11                            Max.   :575000.0   Max.   :784.000       Max.   :2.222e+09  
                                                                                                          
 interest.rate    paid.up.amount amount.of.distribution    quantity         exchange.rate.euro 
 Min.   : 0.000   Min.   :0      Min.   :0              Min.   :7.000e+00   Min.   :    0.000  
 1st Qu.: 0.000   1st Qu.:0      1st Qu.:0              1st Qu.:5.802e+04   1st Qu.:    1.000  
 Median : 1.300   Median :0      Median :0              Median :6.000e+05   Median :    1.000  
 Mean   : 1.798   Mean   :0      Mean   :0              Mean   :5.969e+07   Mean   :   14.573  
 3rd Qu.: 3.250   3rd Qu.:0      3rd Qu.:0              3rd Qu.:2.364e+06   3rd Qu.:    1.086  
 Max.   :12.500   Max.   :0      Max.   :0              Max.   :2.150e+11   Max.   :15111.300  
                                                        NA's   :59                             
Preprocessing data read from *FNDSTT.dat*  

```
[1] "Columns with only <NA> values are removed : balancespecificationcode, Filler, codeword"
```
Final column names of original dataframe:  

```
 [1] "totalnumberoflines"                    "transactionreferencenr"               
 [3] "depositaccountnr"                      "asatdate"                             
 [5] "creationdate"                          "typeofsecurities"                     
 [7] "nominalbalanceofbondsornumberofshares" "securityisin"                         
 [9] "securityVvdE"                          "abbreviatenmaeofsecurites"            
[11] "quotation"                             "securitescurrencycode"                
[13] "securitesprice"                        "foreignexchangerate"                  
[15] "effectivevaluecurrencycode"            "effectivevalue"                       
[17] "pricecreationdate"                     "interestrate"                         
[19] "freezecode"                            "cancellationindication"               
[21] "withoutvalueindication"                "specificationcode"                    
[23] "balancespecificationcode"              "lastmovementdate"                     
[25] "foreignexchangeratefactor"             "paymentpercentage"                    
[27] "paidupamount"                          "distriubtionpercentage"               
[29] "amountofdistribution"                  "quantity"                             
[31] "Filler"                                "typeofinvestment"                     
[33] "statementlinenr"                       "abbreviatednameofcustodian"           
[35] "postivenegativebalance"                "subcustodian"                         
[37] "codeword"                              "exchangerateeuro"                     
[39] "biccode"                               "placeofsafekeeping"                   
[41] "Filler1"                              
```
Converted column transactionreferencenr to Date (format=%y%m%d)  with no failures on 7343 nonempty values.  
Converted column asatdate to Date (format=%y%m%d)  with no failures on 7343 nonempty values.  
Converted column creationdate to Date (format=%y%m%d)  with no failures on 7343 nonempty values.  
Did not convert column nominalbalanceofbondsornumberofshares to Date (format=%y%m%d)  because of too many failures (7239) compared to successes (104)
Did not convert column securityVvdE to Date (format=%y%m%d)  because of too many failures (7005) compared to successes (338)
Did not convert column securitesprice to Date (format=%y%m%d)  because of too many failures (7341) compared to successes (2)
Did not convert column effectivevalue to Date (format=%y%m%d)  because of too many failures (7052) compared to successes (291)
Converted column pricecreationdate to Date (format=%y%m%d)  but had 13 failed conversions. The unique values:'90227','20612','90616','20711','50930','50404','60407','41220','10201','30620','30723','90617'
Converted column lastmovementdate to Date (format=%y%m%d)  with no failures on 7284 nonempty values.  
Did not convert column quantity to Date (format=%y%m%d)  because of too many failures (7180) compared to successes (104)
Did not convert column exchangerateeuro to Date (format=%y%m%d)  because of too many failures (7341) compared to successes (2)
DEBUG [2016-04-26 16:04:23] Saving data to table PO_fndstt

```
DEBUG [2016-04-26 16:04:35] Validate, rowcount for dataset PO_fndstt_orig, file: 7343, table: 7343
DEBUG [2016-04-26 16:04:35] Validate, columncount for dataset PO_fndstt_orig, file: 41, table: 41
DEBUG [2016-04-26 16:04:35] Validate, hashtotal for dataset PO_fndstt_orig, column interestrate, file: 13199.82821, table: 13199.82821
DEBUG [2016-04-26 16:04:48] Validate, rowcount for dataset PO_fndstt, file: 7343, table: 7343
DEBUG [2016-04-26 16:04:48] Validate, columncount for dataset PO_fndstt, file: 46, table: 46
DEBUG [2016-04-26 16:04:48] Validate, hashtotal for dataset PO_fndstt, column interestrate, file: 13199.82821, table: 13199.82821

```

Saved processed file originating from  *FNDSTT.dat* in the database as table named  **PO_fndstt**   

# Cedar 
DEBUG [2016-04-26 16:04:51] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 1 - Portia/20160412/cedar.csv
Preprocessing data read from *cedar.csv*  

```
Renaming column V1 to PORTFOLIO
```
Final column names of original dataframe:  

```
[1] "V1"
```
DEBUG [2016-04-26 16:04:51] Saving data to table PO_CEDAR

```
DEBUG [2016-04-26 16:04:54] Validate, rowcount for dataset PO_CEDAR_orig, file: 152, table: 152
DEBUG [2016-04-26 16:04:54] Validate, columncount for dataset PO_CEDAR_orig, file: 1, table: 1
DEBUG [2016-04-26 16:04:54] Validate, hashtotal for dataset PO_CEDAR_orig, column V1, file: 1931, table: 1931
DEBUG [2016-04-26 16:04:54] Validate, rowcount for dataset PO_CEDAR, file: 152, table: 152
DEBUG [2016-04-26 16:04:54] Validate, columncount for dataset PO_CEDAR, file: 3, table: 3
DEBUG [2016-04-26 16:04:54] Validate, hashtotal for dataset PO_CEDAR, column PORTFOLIO, file: 1931, table: 1931

```

Saved processed file originating from  *cedar.csv* in the database as table named  **PO_CEDAR**   

# Settled transactions
DEBUG [2016-04-26 16:04:54] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 1 - Portia/20160412/portsaldo.csv
Preprocessing data read from *portsaldo.csv*  

```
Renaming column V1 to portfolioNaam
Renaming column V2 to ISIN
Renaming column V3 to securityDescription
Renaming column V4 to longQuantity
Renaming column V5 to shortQuantity
Renaming column V6 to quantity
Renaming column V7 to custodian
Renaming column V8 to proddat
```
Final column names of original dataframe:  

```
[1] "V1" "V2" "V3" "V4" "V5" "V6" "V7" "V8"
```
Did not convert column securityDescription to numeric  because of too many failures (9443) compared to successes (0)
Converted column proddat to Date (format=%d/%m/%y)  with no failures on 9443 nonempty values.  
DEBUG [2016-04-26 16:04:57] Saving data to table PO_portsaldo

```
DEBUG [2016-04-26 16:05:08] Validate, rowcount for dataset PO_portsaldo_orig, file: 9443, table: 9443
DEBUG [2016-04-26 16:05:08] Validate, columncount for dataset PO_portsaldo_orig, file: 8, table: 8
DEBUG [2016-04-26 16:05:09] Validate, hashtotal for dataset PO_portsaldo_orig, column V6, file: 54576, table: 54576
DEBUG [2016-04-26 16:05:20] Validate, rowcount for dataset PO_portsaldo, file: 9443, table: 9443
DEBUG [2016-04-26 16:05:20] Validate, columncount for dataset PO_portsaldo, file: 11, table: 11
DEBUG [2016-04-26 16:05:20] Validate, hashtotal for dataset PO_portsaldo, column quantity, file: 434683751995.83, table: 434683751995.83

```

Saved processed file originating from  *portsaldo.csv* in the database as table named  **PO_portsaldo**   

# TIPS rates
DEBUG [2016-04-26 16:05:22] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 1 - Portia/20160412/fb-hist.csv
Preprocessing data read from *fb-hist.csv*  

```
[1] "Columns with only <NA> values are removed : SicCode"
Removing explicitly provided colnames SicCode
```
Final column names of original dataframe:  

```
[1] "ISIN"     "SECURITY" "Source"   "Datum"    "Koers"    "YIELD"    "Exchange" "SicCode"  "SecDesc2"
```
DEBUG [2016-04-26 16:05:22] Saving data to table PO_tips

```
DEBUG [2016-04-26 16:05:25] Validate, rowcount for dataset PO_tips_orig, file: 23, table: 23
DEBUG [2016-04-26 16:05:25] Validate, columncount for dataset PO_tips_orig, file: 9, table: 9
DEBUG [2016-04-26 16:05:25] Validate, hashtotal for dataset PO_tips_orig, column Koers, file: 26.66017, table: 26.66017
DEBUG [2016-04-26 16:05:25] Validate, rowcount for dataset PO_tips, file: 23, table: 23
DEBUG [2016-04-26 16:05:25] Validate, columncount for dataset PO_tips, file: 10, table: 10
DEBUG [2016-04-26 16:05:25] Validate, hashtotal for dataset PO_tips, column Koers, file: 26.66017, table: 26.66017

```

Saved processed file originating from  *fb-hist.csv* in the database as table named  **PO_tips**   

# INFLATION rates
DEBUG [2016-04-26 16:05:25] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 1 - Portia/20160412/fb-hist-inflatie.csv
Preprocessing data read from *fb-hist-inflatie.csv*  

```
Removing explicitly provided colnames SicCode
```
Final column names of original dataframe:  

```
[1] "ISIN"     "SECURITY" "Source"   "Datum"    "Koers"    "YIELD"    "Exchange" "SicCode"  "SecDesc2"
```
DEBUG [2016-04-26 16:05:26] Saving data to table PO_Inflation

```
DEBUG [2016-04-26 16:05:31] Validate, rowcount for dataset PO_Inflation_orig, file: 3480, table: 3480
DEBUG [2016-04-26 16:05:31] Validate, columncount for dataset PO_Inflation_orig, file: 9, table: 9
DEBUG [2016-04-26 16:05:31] Validate, hashtotal for dataset PO_Inflation_orig, column Koers, file: 4542736.508568, table: 4542736.508568
DEBUG [2016-04-26 16:05:35] Validate, rowcount for dataset PO_Inflation, file: 3479, table: 3479
DEBUG [2016-04-26 16:05:35] Validate, columncount for dataset PO_Inflation, file: 10, table: 10
DEBUG [2016-04-26 16:05:35] Validate, hashtotal for dataset PO_Inflation, column Koers, file: 4542736.508568, table: 4542736.508568

```

Saved processed file originating from  *fb-hist-inflatie.csv* in the database as table named  **PO_Inflation**   





# Exchange rates
DEBUG [2016-04-26 16:05:36] loading data file Z:/Shared Data/5501_ProjectDataQuality/2_Input Data/Data Dumps/Prio 1 - Portia/20160412/hfx.csv
Preprocessing data read from *hfx.csv*  

```
Removing explicitly provided colnames RATETYPE
Renaming column NAME to NAME
Renaming column CURRENCY to fxid
Renaming column Rate to FXRATE
Renaming column RATEDATE to ReportingDate
Renaming column EURtoVV to INV_FXRATE
```
Final column names of original dataframe:  

```
[1] "RATETYPE" "CURRENCY" "Rate"     "RATEDATE" "EURtoVV" 
```
Converted column ReportingDate to Date (format=%d/%m/%y)  with no failures on 57 nonempty values.  
DEBUG [2016-04-26 16:05:36] Saving data to table PO_exchangerates

```
DEBUG [2016-04-26 16:05:37] Validate, rowcount for dataset PO_exchangerates_orig, file: 57, table: 57
DEBUG [2016-04-26 16:05:37] Validate, columncount for dataset PO_exchangerates_orig, file: 5, table: 5
DEBUG [2016-04-26 16:05:37] Validate, hashtotal for dataset PO_exchangerates_orig, column Rate, file: 18.5441928535, table: 18.5441928535
DEBUG [2016-04-26 16:05:37] Validate, rowcount for dataset PO_exchangerates, file: 58, table: 58
DEBUG [2016-04-26 16:05:37] Validate, columncount for dataset PO_exchangerates, file: 7, table: 7
DEBUG [2016-04-26 16:05:37] Validate, hashtotal for dataset PO_exchangerates, column FXRATE, file: 19.5441928535, table: 19.5441928535

```

Saved processed file originating from  *hfx.csv* in the database as table named  **PO_exchangerates**   

# Portfolio names


# Solvency 2 Data Elements
## Portia SecsHld


```
  Portia_SecsHld Portia_TotalHist Portia_Total_MonthlyHist      Data.element Equity.Risk Asset.Stress.Test
                       BOOK_VALUE               BOOK_VALUE        BOOK_VALUE           1                 0
                       CLIENTNAAM               CLIENTNAAM       CLIENT_NAME           0                 0
          COUPON       COUPONRATE               COUPONRATE            COUPON           0                 1
          SYMBOL             MUNT                     MUNT          CURRENCY           1                 1
 DLAMAssetClass2  DLAMAssetClass2          DLAMAssetClass2 DLAM.Asset.Type.2           0                 0
 DLAMAssetClass3  DLAMAssetClass3          DLAMAssetClass3 DLAM.Asset.Type.3           1                 1
      DLAMRating         DLRating                 DLRating       DLAM.RATING           0                 1
     DLAMSector1      DLAMSector1              DLAMSector1      DLAM.Sector1           0                 1
     DLAMSector2      DLAMSector2              DLAMSector2      DLAM.Sector2           0                 0
     DLAMSector3      DLAMSector3              DLAMSector3      DLAM.Sector3           0                 1
                   Expirationdate           Expirationdate        EXPIRATION           1                 1
                           FXRATE                   FXRATE            FXRATE           1                 0
            ISIN             ISIN                     ISIN        IDENTIFIER           1                 1
       IssueDate        Issuedate                Issuedate        ISSUE_DATE           0                 1
                      MWinclLREur              MWinclLREur      MARKET_VALUE           0                 1
       MaturityD     MaturityDate             MaturityDate          MATURITY           0                 1
                      NominaalEur              NominaalEur     NOMINAL_VALUE           1                 1
                      Option_type              Option_type       OPTION_TYPE           1                 0
                 PaymentFrequency         PaymentFrequency PAYMENT_FREQUENCY           0                 1
                    PortfolioNaam            PortfolioNaam    PORTFOLIO_NAME           1                 1
                            KOERS                    KOERS             PRICE           1                 1
         rundate    ReportingDate            ReportingDate           proddat           1                 0
                         QUANTITY                 QUANTITY          QUANTITY           1                 1
            Name     Securitynaam             Securitynaam          SECURITY           1                 0
                           STRIKE                   STRIKE            STRIKE           1                 1
                       UNDERLYING               UNDERLYING        UNDERLYING           1                 0
 Currency.Risk Credit.Risk
             0           0
             1           1
             0           0
             1           0
             0           1
             1           1
             1           0
             0           1
             0           1
             0           0
             0           0
             0           0
             0           1
             0           0
             1           0
             0           0
             1           1
             0           0
             0           0
             0           1
             0           0
             1           1
             0           0
             0           0
             0           0
             0           0
```



# Solvency 2 related Data Element validation

## Portia SecsHld
The following secsHld data alements are used for specific FRM data elements (Data elements).

```
         Data.element    Portia_SecsHld
 Cedar_Classification             CEDAR
              COUNTRY DLAMCountryofRisk
               COUPON            COUPON
             CURRENCY            SYMBOL
          DESCRIPTION      Description1
    DLAM.Asset.Type.1   DLAMAssetClass1
    DLAM.Asset.Type.2   DLAMAssetClass2
    DLAM.Asset.Type.3   DLAMAssetClass3
    DLAM.Asset.Type.4   DLAMAssetClass4
          DLAM.RATING        DLAMRating
         DLAM.Sector1       DLAMSector1
         DLAM.Sector2       DLAMSector2
         DLAM.Sector3       DLAMSector3
         DLAM.Sector4       DLAMSector4
             EXCHANGE          Exchange
         FITCH.RATING        FitchRatin
           IDENTIFIER              ISIN
             INDUSTRY          INDUSTRY
           ISSUE_DATE         IssueDate
               ISSUER        IssuerNaam
               LISTED            Listed
             MATURITY         MaturityD
        MOODYs_RATING        MoodyRatin
              proddat           rundate
             SECURITY              Name
           SnP_RATING          SPRating
```

This results in the followin portia secshld related risks:

```
      Data.element  Portia_SecsHld Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk
            COUPON          COUPON           0                 1             0           0
          CURRENCY          SYMBOL           1                 1             1           0
 DLAM.Asset.Type.2 DLAMAssetClass2           0                 0             0           1
 DLAM.Asset.Type.3 DLAMAssetClass3           1                 1             1           1
       DLAM.RATING      DLAMRating           0                 1             1           0
      DLAM.Sector1     DLAMSector1           0                 1             0           1
      DLAM.Sector2     DLAMSector2           0                 0             0           1
      DLAM.Sector3     DLAMSector3           0                 1             0           0
        IDENTIFIER            ISIN           1                 1             0           1
        ISSUE_DATE       IssueDate           0                 1             0           0
          MATURITY       MaturityD           0                 1             0           0
           proddat         rundate           1                 0             1           1
          SECURITY            Name           1                 0             0           0
```
There are 13 data elements in portia secshld that relate to at least one risk.

Mapping from risks to list of fields


Related solvency II descriptions:

```
      Data.element  Export.element Number
            COUPON          COUPON    DE3
          CURRENCY          SYMBOL    DE4
 DLAM.Asset.Type.2 DLAMAssetClass2    DE5
 DLAM.Asset.Type.3 DLAMAssetClass3    DE6
       DLAM.RATING      DLAMRating    DE7
      DLAM.Sector1     DLAMSector1    DE8
      DLAM.Sector2     DLAMSector2    DE9
      DLAM.Sector3     DLAMSector3   DE10
        IDENTIFIER            ISIN   DE13
        ISSUE_DATE       IssueDate   DE14
          MATURITY       MaturityD   DE16
           proddat         rundate   DE22
          SECURITY            Name   DE24
                                                                        Description
                                                Current coupon rate of Security (%)
                                   The currency of the security (ISO Currency Code)
 State the asset type of the security (see Appendix E for Asset Tree specification)
 State the asset type of the security (see Appendix E for Asset Tree specification)
                                                             DLAM Composite rating 
           If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
           If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
           If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
                                                           The ISIN of the security
                                                 Date on which a security is issued
                                                 Date of expiration of the Security
                                                             Run date of the export
                                                                   Identifying name
```

### Mapping validation
The following secshld data elements are not mapped to any FRM data element: (These are implicitly not included in any risk, but could happen due to incomplete mappings)

```
 [1] "id"                          "Description2"                "SecClass"                   
 [4] "CountryName"                 "FVLevel"                     "DRA"                        
 [7] "WFT"                         "ICBE"                        "SecType"                    
[10] "CIC"                         "X5strategi1"                 "IntlTaxStatus"              
[13] "IntlIncomeType"              "GICS1"                       "CurrencyIs"                 
[16] "PriceSymbol"                 "Sedol"                       "BBTicker"                   
[19] "Exception"                   "ISSUER"                      "AutoQuote"                  
[22] "Frequentie"                  "Source"                      "SECURITYTYPE"               
[25] "UNITPRICE"                   "UNITSIZE"                    "CountryofInCorpora"         
[28] "OddFirstCpn"                 "OddLastCpn"                  "RunTime"                    
[31] "OutstandingSha"              "IssuerID"                    "RM"                         
[34] "X5Fiscaal"                   "X5strategi2"                 "X5Kapitaal"                 
[37] "SICCode"                     "Nominale"                    "GepltsKApitaal"             
[40] "TotaalStemmen"               "Stemrechtpst"                "RegisterExtern"             
[43] "AgncyAvRating"               "AgncyAvPrRating"             "AgncyAvTotRtg"              
[46] "ManualRating"                "SolvencyIIRating"            "DLAMRtgExpDate"             
[49] "Cusip"                       "FranceTax"                   "SecID"                      
[52] "CalendarMthdMthd"            "PaymentFreq"                 "BeginDateVRSSc"             
[55] "EndDateVRSSchm"              "VRSSpread"                   "VRSIndex"                   
[58] "Error"                       "ResetFrequency"              "NextResetDate"              
[61] "NextPayDate"                 "IrregularPayments"           "source_date"                
[64] "source_file"                 "CIC_Country"                 "CIC_Code"                   
[67] "CIC_Group"                   "InitialDurationy"            "SectorCountry"              
[70] "Sector2NoCountry"            "Description1_Coupon"         "Description1_CouponNum"     
[73] "Description1_Coupon_Rounded" "has_coupon"                  "has_frequency"              
[76] "ISIN_Internal"               "ISIN_Participation"          "ISIN_UCode"                 
[79] "ISIN_Empty"                  "ISIN_Regular"                "FutureSymbol"               
[82] "FutureMonth"                 "FutureYear"                  "ISIN_Future"                
[85] "OptionType"                  "ISIN_Option"                 "ISIN_Exchange"              
```

The following secshld data elements were expected, but not found as column name to map:

```
[1] "DLAMTheme1" "DLAMTheme2"
```

These last two list could possibly indicate missing/incorrect mappings.

Perhaps a mapping should be defined for the following data elements from Portia that have not been mapped to frm, but used in the FR model:

```
[1] ""
```


The following portia total data alements are used for specific FRM data elements (Data elements).

```
         Data.element        Portia_Total
     ACCRUED_INTEREST   AcruedInterestEur
           BOOK_VALUE          BOOK_VALUE
       BUSINESS_UNITS        BusinessUnit
 Cedar_Classification Cedar_Classificatie
          CLIENT_NAME          CLIENTNAAM
              COUNTRY   DLAMCountryofRisk
               COUPON          COUPONRATE
             CURRENCY                MUNT
          DESCRIPTION         Description
    DLAM.Asset.Type.1     DLAMAssetClass1
    DLAM.Asset.Type.2     DLAMAssetClass2
    DLAM.Asset.Type.3     DLAMAssetClass3
    DLAM.Asset.Type.4     DLAMAssetClass4
          DLAM.RATING            DLRating
         DLAM.Sector1         DLAMSector1
         DLAM.Sector2         DLAMSector2
         DLAM.Sector3         DLAMSector3
         DLAM.Sector4         DLAMSector4
           DLAMTheme1          DLAMTheme1
           DLAMTheme2          DLAMTheme2
             DURATION            Duration
             EXCHANGE            Exchange
           EXPIRATION      Expirationdate
     FAIR_VALUE_LEVEL             FVLevel
         FITCH.RATING               Fitch
               FXRATE              FXRATE
           IDENTIFIER                ISIN
             INDUSTRY            INDUSTRY
           ISSUE_DATE           Issuedate
               ISSUER        IssuerIDNaam
               LISTED              Listed
         MARKET_VALUE         MWinclLREur
             MATURITY        MaturityDate
        MOODYs_RATING               MOODY
        NOMINAL_VALUE         NominaalEur
          OPTION_TYPE         Option_type
    PAYMENT_FREQUENCY    PaymentFrequency
       PORTFOLIO_NAME       PortfolioNaam
             POSITION            Position
                PRICE               KOERS
              proddat       ReportingDate
             QUANTITY            QUANTITY
       REPORTING_DATE       ReportingDate
             SECURITY        Securitynaam
                SEDOL               Sedol
           SnP_RATING                  SP
               STRIKE              STRIKE
           UNDERLYING          UNDERLYING
                YIELD               Yield
```

This results in the following portia secshld related risks:

```
      Data.element     Portia_Total Equity.Risk Asset.Stress.Test Currency.Risk Credit.Risk
        BOOK_VALUE       BOOK_VALUE           1                 0             0           0
       CLIENT_NAME       CLIENTNAAM           0                 0             1           1
            COUPON       COUPONRATE           0                 1             0           0
          CURRENCY             MUNT           1                 1             1           0
 DLAM.Asset.Type.2  DLAMAssetClass2           0                 0             0           1
 DLAM.Asset.Type.3  DLAMAssetClass3           1                 1             1           1
       DLAM.RATING         DLRating           0                 1             1           0
      DLAM.Sector1      DLAMSector1           0                 1             0           1
      DLAM.Sector2      DLAMSector2           0                 0             0           1
      DLAM.Sector3      DLAMSector3           0                 1             0           0
        EXPIRATION   Expirationdate           1                 1             0           0
            FXRATE           FXRATE           1                 0             0           0
        IDENTIFIER             ISIN           1                 1             0           1
        ISSUE_DATE        Issuedate           0                 1             0           0
      MARKET_VALUE      MWinclLREur           0                 1             1           0
          MATURITY     MaturityDate           0                 1             0           0
     NOMINAL_VALUE      NominaalEur           1                 1             1           1
       OPTION_TYPE      Option_type           1                 0             0           0
 PAYMENT_FREQUENCY PaymentFrequency           0                 1             0           0
    PORTFOLIO_NAME    PortfolioNaam           1                 1             0           1
             PRICE            KOERS           1                 1             0           0
           proddat    ReportingDate           1                 0             1           1
          QUANTITY         QUANTITY           1                 1             0           0
          SECURITY     Securitynaam           1                 0             0           0
            STRIKE           STRIKE           1                 1             0           0
        UNDERLYING       UNDERLYING           1                 0             0           0
```
There are 26 data elements in portia that relate to at least one risk.

Related solvency II descriptions:

```
      Data.element   Export.element Number
        BOOK_VALUE       BOOK_VALUE    DE1
       CLIENT_NAME       CLIENTNAAM    DE2
            COUPON       COUPONRATE    DE3
          CURRENCY             MUNT    DE4
 DLAM.Asset.Type.2  DLAMAssetClass2    DE5
 DLAM.Asset.Type.3  DLAMAssetClass3    DE6
       DLAM.RATING         DLRating    DE7
      DLAM.Sector1      DLAMSector1    DE8
      DLAM.Sector2      DLAMSector2    DE9
      DLAM.Sector3      DLAMSector3   DE10
        EXPIRATION   Expirationdate   DE11
            FXRATE           FXRATE   DE12
        IDENTIFIER             ISIN   DE13
        ISSUE_DATE        Issuedate   DE14
      MARKET_VALUE      MWinclLREur   DE15
          MATURITY     MaturityDate   DE16
     NOMINAL_VALUE      NominaalEur   DE17
       OPTION_TYPE      Option_type   DE18
 PAYMENT_FREQUENCY PaymentFrequency   DE19
    PORTFOLIO_NAME    PortfolioNaam   DE20
             PRICE            KOERS   DE21
           proddat    ReportingDate   DE22
          QUANTITY         QUANTITY   DE23
          SECURITY     Securitynaam   DE24
            STRIKE           STRIKE   DE25
        UNDERLYING       UNDERLYING   DE26
                                                                                           Description
  The value of an asset as it appears on a balance sheet, equal to cost minus accumulated depreciation
                                                                                    Name of the client
                                                                   Current coupon rate of Security (%)
                                                      The currency of the security (ISO Currency Code)
                    State the asset type of the security (see Appendix E for Asset Tree specification)
                    State the asset type of the security (see Appendix E for Asset Tree specification)
                                                                                DLAM Composite rating 
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
                              If IBOXX is available, then IBOXX, otherwise use DL Sector (always fill)
                                             The last day that an options or futures contract is valid
                                 The Conversion Rate EUR/Original Currency at T where T is Report Date
                                                                              The ISIN of the security
                                                                    Date on which a security is issued
          The market value of the securities in EUR (including Accrued Interest),Cash Balance for Cash
                                                                    Date of expiration of the Security
 Nominal value of the Security excluding redemption/amortization, balance for Cash (original currency)
                                                                           Type of option, Put or Call
                                          How often a dividend is paid by an individual stock or fund.
                                                                                 Name of the portfolio
                 Close market price of the security at T where T is reporting date (original currency)
                                                                                Run date of the export
                                                                            Number of securities owned
                                                                                      Identifying name
                                    The price at which a specific derivative contract can be exercised
                                                Asset on which a futures contract or option is written
```


### Mapping validation
The following PortiaTotal data elements are not mapped to any FRM data element: (These are implicitly not included in any risk, but could happen due to incomplete mappings)

```
 [1] "id"                    "PERCENT"               "IssuerID"              "SecDescription2"      
 [5] "Cedar_BU_Nr"           "PurchaseCost"          "TradeDate"             "UnderlyingBB"         
 [9] "RiskType"              "FondsISIN"             "UNITSIZE"              "Custodian"            
[13] "CustodianLegalName"    "CreditQualityStep"     "SharesOutstanding"     "UnderlIdentifier"     
[17] "NumberOfContracts"     "KoersEUR"              "PriceUnit"             "InflationFactor"      
[21] "ReportingDate_orig"    "Issuedate_failed"      "Issuedate_orig"        "MaturityDate_failed"  
[25] "MaturityDate_orig"     "Expirationdate_failed" "Expirationdate_orig"   "TradeDate_orig"       
[29] "source_date"           "source_file"           "OptionType"           
```

The following portiatotal data elements were expected, but not found as column name to map:

```
[1] "CallDate"      "CallFrequency" "CallPrice"     "Convexity"     "Percent"      
```

These last two list could possibly indicate missing/incorrect mappings.

Perhaps a mapping should be defined for the following data elements from Portia that have not been mapped to frm, but used in the FR model:


# Completeness validation
There are 3714 rows in the original secshld export, and 3674 in the preprocessed secshld.
There are 10195 rows in the original portiatotal export, and 10195 in the preprocessed portiatotal.

```r
#if(nrow(po_secshld$orig)!=nrow(po_secshld$prep))
#  stop("Number of rows in secshld differ.")
if(nrow(po_portiatotal$orig)!=nrow(po_portiatotal$prep))
  stop("Number of rows in portiatotal differ.")
```

# Database enrichments





```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_PO_portfolio 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
Create view vx_PO_portfolio as
SELECT
	distinct
		 PortfolioNaam as prfid
		,ReportingDate as proddat
		,[source_date]
		,[source_file]
		,PortfolioNaam as PORTFOLIO_NAME
		,[CLIENTNAAM] as CLIENT_NAME
		,ReportingDate
		,CLIENTNAAM
		RiskType,
		Cedar_BU_Nr
	FROM
		PO_portiatotal 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_PO_holding 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
Create view vx_PO_holding as
SELECT
	distinct
		 Securitynaam as insid
		,PortfolioNaam as prfid
		,[source_date]
		,[source_file]
		,MUNT as dep_fxid
		,ReportingDate as proddat
		,Securitynaam as [SECURITY]
		,PortfolioNaam as PORTFOLIO_NAME
		,[PERCENT]
		,[BOOK_VALUE]
		,[NominaalEur] as NOMINAL_VALUE
		,[QUANTITY]
		,[MWinclLREur] as MARKET_VALUE
		,[AcruedInterestEur]
		,[Position]
		,[KOERS] as PRICE
		,[MUNT] as CURRENCY
		,[FXRATE]
		,[MUNT]
		,MWinclLREur
		,[NominaalEur]
		,Securitynaam
		,PortfolioNaam
		,ReportingDate
		,KOERS
		,CUSTODIAN
		,TradeDate
		,UNITSIZE
		,purchaseCost
		,FondsISIN
		,ISIN
		,DLAMAssetClass3
		,Description
FROM
	PO_portiatotal 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_PO_instrument 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
Create view vx_PO_instrument as
SELECT
	distinct
		   Securitynaam as insid
		  ,PO_portiatotal.[source_date]
		  ,PO_portiatotal.[source_file]
		  ,[MUNT] as dep_fxid
		  ,[COUPONRATE] as COUPON
		  ,[MUNT] as CURRENCY
		  ,PO_portiatotal.[DLAMAssetClass1]
		  ,PO_portiatotal.[DLAMAssetClass2]
		  ,PO_portiatotal.[DLAMAssetClass3]
		  ,PO_portiatotal.[DLAMAssetClass4]
		  ,[DLRating] as DLAMRating
		  ,PO_portiatotal.[DLAMSector1]
		  ,PO_portiatotal.[DLAMSector2]
		  ,PO_portiatotal.[DLAMSector3]
		  ,PO_portiatotal.[DLAMSector4]
		  ,[Expirationdate] as [EXPIRATION]
		  ,[FXRATE]
		  ,PO_portiatotal.[ISIN] as [IDENTIFIER]
		  ,PO_portiatotal.[Issuedate] as [ISSUE_DATE]
		  ,[MaturityDate] as [MATURITY]
		  ,[Option_type] as [OPTION_TYPE]
		  ,[PaymentFrequency] as [PAYMENT_FREQUENCY]
		  ,[KOERS] as [PRICE]
		  ,ReportingDate as [proddat]
		  ,[Securitynaam] as [SECURITY]
		  ,[STRIKE]
		  ,[UNDERLYING]
		  ,case when Securitynaam like '*%' then 0 else 1 end as scope_dm
		  ,COUPONRATE
		  ,Expirationdate
		  ,[MUNT]
		  ,PO_portiatotal.[ISIN]
		  ,PO_portiatotal.[Issuedate]
		  ,[MaturityDate]
		  ,[PaymentFrequency]
		  ,[Description]
		  ,[IssuerIDNaam]
		  ,[KOERS]
		  ,ReportingDate
		  ,[Securitynaam]
		  ,PO_portiatotal.[Sedol]
		  ,PO_portiatotal.[Exchange]
		  ,PO_portiatotal.[DLAMCountryofRisk]
		  ,[SP]
		  ,[MOODY]
		  ,[Fitch]
		  ,[DLRating]
		  ,PO_portiatotal.[INDUSTRY]
		  ,[Yield]
		  ,[Duration]
		  ,PO_portiatotal.[FVLevel]
		  ,PO_portiatotal.[DLAMTheme1]
		  ,PO_portiatotal.[DLAMTheme2]
		  ,PO_portiatotal.[Listed]
		  ,[Cedar_Classificatie]
		  ,PO_portiatotal.[IssuerID]
		  ,[SecDescription2]
		  ,PO_portiatotal.[OptionType]
		  ,portiatotal_sp.RatingLevel as SP_level
		  ,portiatotal_moody.RatingLevel as MOODY_level
		  ,portiatotal_fitch.RatingLevel as FITCH_level
		  ,portiatotal_dlam.RatingLevel as DLRating_level
		  ,secshld_agencyav.RatingLevel as secshld_AgncyAvRating_level
      ,[rundate] as secshld_ReportingDate
      ,cast([RunTime] as time) as RunTime
      ,[Name] as secshld_Securitynaam
      ,[Description1]
      ,[Description2]
      ,PO_secshld.[ISIN] as secshld_ISIN
      ,[SecClass]
      ,PO_secshld.[Listed] as secshld_Listed
      ,[CEDAR]
      ,PO_secshld.[MoodyRatin] as secshld_MOODY
      ,PO_secshld.[SPRating] as secshld_SP
      ,PO_secshld.[FitchRatin] as secshld_Fitch
      ,PO_secshld.[DLAMRating] as secshld_DLRating
      ,PO_secshld.[DLAMSector1] as secshld_DLAMSector1
      ,PO_secshld.[DLAMSector2] as secshld_DLAMSector2
      ,PO_secshld.[DLAMSector3] as secshld_DLAMSector3
      ,PO_secshld.[DLAMSector4] as secshld_DLAMSector4
      ,PO_secshld.[DLAMAssetClass1] as secshld_DLAMAssetClass1
      ,PO_secshld.[DLAMAssetClass2] as secshld_DLAMAssetClass2
      ,PO_secshld.[DLAMAssetClass3] as secshld_DLAMAssetClass3
      ,PO_secshld.[DLAMAssetClass4] as secshld_DLAMAssetClass4
      ,[CountryName]
      ,PO_secshld.[Exchange] as secshld_Exchange
      ,PO_secshld.[INDUSTRY] as secshld_INDUSTRY
      ,PO_secshld.[FVLevel] as secshld_FVLevel
      ,[DRA]
      ,[WFT]
      ,[ICBE]
      ,[SecType]
      ,[CIC]
      ,[X5strategi1]
      ,PO_secshld.[DLAMCountryofRisk] as secshld_DLAMCountryofRisk
      ,[IntlTaxStatus]
      ,[IntlIncomeType]
      ,[MaturityD] as secshld_MaturityDate
      ,PO_secshld.[IssueDate] as secshld_IssueDate
      ,[GICS1]
      ,[CurrencyIs]
      ,[PriceSymbol]
      ,PO_secshld.[Sedol] as secshld_Sedol
      ,[BBTicker]
      ,[Exception]
      ,[ISSUER]
      ,[COUPON] as secshld_COUPONRATE
      ,[AutoQuote]
      ,[Frequentie]
      ,[Source]
      ,[SECURITYTYPE]
      ,[UNITPRICE]
      ,PO_secshld.[UNITSIZE] as secshld_UNITSIZE
      ,[SYMBOL] as secshld_MUNT
      ,[CountryofInCorpora]
      ,[OddFirstCpn]
      ,[OddLastCpn]
      ,[OutstandingSha]
      ,PO_secshld.[IssuerID] as secshld_IssuerID
      ,[IssuerNaam]
      ,[RM]
      ,[X5Fiscaal]
      ,[X5strategi2]
      ,[X5Kapitaal]
      ,[SICCode]
      ,[Nominale]
      ,[GepltsKApitaal]
      ,[TotaalStemmen]
      ,[Stemrechtpst]
      ,[RegisterExtern]
      ,[AgncyAvRating] as secshld_AgncyAvRating
      ,[AgncyAvPrRating] as secshld_AgncyAvPrRating
      ,[AgncyAvTotRtg] as secshld_AgncyAvTotRtg
      ,[ManualRating]
      ,PO_secshld.[SolvencyIIRating]
      ,[DLAMRtgExpDate]
      ,[Cusip]
      ,PO_secshld.[source_date] as secshld_source_date
      ,PO_secshld.[source_file] as secshld_source_file
      ,[CIC_Country]
      ,[CIC_Code]
      ,[CIC_Group]
      ,[InitialDurationy]
      ,[SectorCountry]
      ,[Sector2NoCountry]
      ,[Description1_Coupon]
      ,[Description1_CouponNum]
      ,[Description1_Coupon_Rounded]
      ,[has_coupon]
      ,[has_frequency]
      ,[ISIN_Internal]
      ,[ISIN_Participation]
      ,[ISIN_UCode]
      ,[ISIN_Empty]
      ,[ISIN_Regular]
      ,[FutureSymbol]
      ,[FutureMonth]
      ,[FutureYear]
      ,[ISIN_Future]
      ,PO_secshld.[OptionType] as secshld_OptionType
      ,[ISIN_Option]
      ,[ISIN_Exchange],
	  underlyingbb
FROM
	PO_portiatotal
	LEFT JOIN
	PO_secshld on PO_portiatotal.Securitynaam=PO_secshld.Name
	LEFT JOIN
		map_ratings portiatotal_moody on PO_portiatotal.MOODY = portiatotal_moody.MoodyRatin
	LEFT JOIN
		map_ratings portiatotal_fitch on PO_portiatotal.Fitch= portiatotal_fitch.FitchRatin
	LEFT JOIN
		map_ratings portiatotal_sp on PO_portiatotal.SP = portiatotal_sp.SPRating
	LEFT JOIN
		map_ratings portiatotal_dlam on PO_portiatotal.DLRating = portiatotal_dlam.DLAMRating
	LEFT JOIN
		map_ratings secshld_agencyav on PO_secshld.AgncyAvRating = secshld_agencyav.DLAMRating 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_PO_currency 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
Create view vx_PO_currency as
SELECT
	distinct
		 MUNT as fxid
		,[source_date]
		,[source_file]
		,ReportingDate as proddat
		,[MUNT] as CURRENCY
		,[FXRATE]
		,MUNT
		,ReportingDate
FROM
	PO_portiatotal 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_PO_entities 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_PO_entities as
	select
		null as insid,
		null as prfid,
		fxid as fxid,
		null as tradeid,
		'currency' as entitytype,
		source_date,
		source_file,
		null as BOOK_VALUE,
		null as CLIENT_NAME,
		null as COUPON,
		CURRENCY,
		null as DLAMAssetClass1,
		null as DLAMAssetClass2,
		null as DLAMAssetClass3,
		null as DLAMAssetClass4,
		null as DLAMRATING,
		null as DLAMSector1,
		null as DLAMSector2,
		null as DLAMSector3,
		null as DLAMSector4,
		null as EXPIRATION,
		FXRATE,
		null as IDENTIFIER,
		null as ISSUE_DATE,
		null as MARKET_VALUE,
		null as MATURITY,
		null as NOMINAL_VALUE,
		null as OPTION_TYPE,
		null as PAYMENT_FREQUENCY,
		null as PORTFOLIO_NAME,
		null as PRICE,
		proddat,
		null as QUANTITY,
		null as SECURITY,
		null as STRIKE,
		null as UNDERLYING
	from
		vx_PO_currency
UNION ALL
	select
		Securitynaam as insid,
		PortfolioNaam as prfid,
		null as fxid,
		null as tradeid,
		'holding' as entitytype,
		source_date,
		source_file,
		BOOK_VALUE,
		CLIENTNAAM as CLIENT_NAME,
		COUPONRATE as COUPON,
		MUNT as CURRENCY,
		DLAMAssetClass1,
		DLAMAssetClass2,
		DLAMAssetClass3,
		DLAMAssetClass4,
		DLRating as DLAMRATING,
		DLAMSector1,
		DLAMSector2,
		DLAMSector3,
		DLAMSector4,
		Expirationdate as EXPIRATION,
		FXRATE,
		ISIN as IDENTIFIER,
		Issuedate as ISSUE_DATE,
		MWinclLREur as MARKET_VALUE,
		MaturityDate as MATURITY,
		NominaalEur as NOMINAL_VALUE,
		Option_type as OPTION_TYPE,
		PaymentFrequency as PAYMENT_FREQUENCY,
		PortfolioNaam as PORTFOLIO_NAME,
		KOERS as PRICE,
		ReportingDate as proddat,
		QUANTITY,
		Securitynaam as SECURITY,
		STRIKE,
		UNDERLYING
	from
		PO_portiatotal as holdings
UNION ALL
	select
		insid as insid,
		null as prfid,
		null as fxid,
		null as tradeid,
		'instrument' as entitytype,
		source_date,
		source_file,
		null as BOOK_VALUE,
		null as CLIENT_NAME,
		COUPON,
		CURRENCY,
		DLAMAssetClass1,
		DLAMAssetClass2,
		DLAMAssetClass3,
		DLAMAssetClass4,
		DLAMRATING,
		DLAMSector1,
		DLAMSector2,
		DLAMSector3,
		DLAMSector4,
		EXPIRATION,
		FXRATE,
		IDENTIFIER,
		ISSUE_DATE,
		null as MARKET_VALUE,
		MATURITY,
		null as NOMINAL_VALUE,
		OPTION_TYPE,
		PAYMENT_FREQUENCY,
		null as PORTFOLIO_NAME,
		PRICE,
		proddat,
		null as QUANTITY,
		[SECURITY],
		STRIKE,
		UNDERLYING
	from
		vx_PO_instrument
UNION ALL
	select
		null as insid,
		prfid as prfid,
		null as fxid,
		null as tradeid,
		'portfolio' as entitytype,
		source_date,
		source_file,
		null as BOOK_VALUE,
		CLIENT_NAME,
		null as COUPON,
		null as CURRENCY,
		null as DLAMAssetClass1,
		null as DLAMAssetClass2,
		null as DLAMAssetClass3,
		null as DLAMAssetClass4,
		null as DLAMRATING,
		null as DLAMSector1,
		null as DLAMSector2,
		null as DLAMSector3,
		null as DLAMSector4,
		null as EXPIRATION,
		null as FXRATE,
		null as IDENTIFIER,
		null as ISSUE_DATE,
		null as MARKET_VALUE,
		null as MATURITY,
		null as NOMINAL_VALUE,
		null as OPTION_TYPE,
		null as PAYMENT_FREQUENCY,
		PORTFOLIO_NAME,
		null as PRICE,
		proddat,
		null as QUANTITY,
		null as SECURITY,
		null as STRIKE,
		null as UNDERLYING
	from
		vx_PO_portfolio 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_PO_holding_settled 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_PO_holding_settled as
select
	*
from
(
	select
		po_instr.Securitynaam as insid,
		po_saldo.portfolioNaam as prfid,
		po_saldo.*,
		po_instr.Securitynaam,
		po_instr.MUNT as munt
	from
		PO_portsaldo as po_saldo
		left join (
				select
					distinct Securitynaam, Description, isin, munt
				 from PO_portiatotal
				 where isin in
					(select isin
					from (
						select
							distinct Securitynaam, Description, isin, munt
						from PO_portiatotal
						where Description not like '%tbv MIX') as uniques
					group by isin
					having count(*) = 1 )
					and Description not like '%tbv MIX'
		) as po_instr
		on po_saldo.ISIN = po_instr.ISIN
	UNION
		select
			Securitynaam as insid,
			PortfolioNaam as prfid,
			portfolioNaam,
			ISIN,
			Description as securityDescription,
			QUANTITY as longQuantity,
			0 as shortQuantity,
			QUANTITY as quantity,
			'KAS (BUT NOT IN portsaldo)' as custodian,
			PO_portiatotal.ReportingDate as proddat,
			PO_portiatotal.ReportingDate_orig as proddat_orig,
			source_date,
			source_file,
			Securitynaam,
			MUNT
		from
			PO_portiatotal
		where
			QUANTITY > 0
			and (
					(PortfolioNaam not in (select distinct PortfolioNaam from [PO_portsaldo])
					and
					PortfolioNaam like 'coll%'
					)
				OR
					DLAMAssetClass3 = 'LOS'
				)
) all_holding
where
	quantity > 0
	and custodian like 'KAS%'
	and custodian != 'KAS NL (REG)'
	and ISIN not like 'DLINT%'
	and not (len(ISIN)=4 and securityDescription like '%fut%')
	and not (securityDescription like 'call%')
	and not (securityDescription like 'put%') 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_PO_kasbank 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_PO_kasbank as
select
	po_instr.Securitynaam as insid,
	isnull(po_instr.[Description], PO_fndstt.abbreviatenmaeofsecurites) as [Description],
	case
		when PO_fndstt.securitescurrencycode IN ('DEM','NLG')
		then 'EUR'
		else PO_fndstt.securitescurrencycode
		end as munt,
	PO_fndstt.*
from
	PO_fndstt
	left join (select distinct Securitynaam, Description, isin, munt from PO_portiatotal where Description not like '%tbv MIX') as po_instr
	on case
		when PO_fndstt.securitescurrencycode IN ('DEM','NLG')
		then 'EUR'
		else PO_fndstt.securitescurrencycode
		end = po_instr.MUNT
	and PO_fndstt.securityisin = po_instr.ISIN
where
	securityVvde != 0
-- note: some have different currency code, resulting in null insid 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_PO_kasbank_vs_instrument 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_PO_kasbank_vs_instrument as
select
	isnull(po_saldo.Securitynaam, kasbank_total.insid) as insid,
	isnull(po_saldo.quantity, 0) - isnull(kasbank_total.quantity, 0) as instr_diff,
	isnull(po_saldo.ISIN, kasbank_total.securityisin) as isin,
	isnull(po_saldo.securityDescription, kasbank_total.[Description]) as description,
	po_saldo.munt as munt,
	po_saldo.quantity as portia_instr_quantity,
	kasbank_total.quantity as kasbank_instr_quantity,
	portia_total_holding.quantity as portia_isin_quantity,
	kasbank_total_holding.quantity as kasbank_isin_quantity,
	isnull(po_saldo.num_positions, 0) as portia_num_positions,
	isnull(kasbank_total.num_positions, 0) as kasbank_num_positions,
	all_prfids,
	all_depositaccountnr,
	all_custodians
from
	(select
		Securitynaam, securityDescription, ISIN, munt, sum(quantity) as quantity, count(*) as num_positions,
		STUFF(
            (SELECT
                ', '+ details.prfid
                FROM
					SourceData.dbo.vx_PO_holding_settled as details
                WHERE details.Securitynaam=vx_PO_holding_settled.Securitynaam
				and details.securityDescription = vx_PO_holding_settled.securityDescription
				and details.ISIN = vx_PO_holding_settled.ISIN
				and details.munt = vx_PO_holding_settled.munt
                ORDER BY details.prfid
                FOR XML PATH(''), TYPE
            ).value('.','varchar(max)')
            ,1,2, ''
        ) AS "all_prfids",
		STUFF(
            (SELECT
                ', '+ details.custodian
                FROM
					SourceData.dbo.vx_PO_holding_settled as details
                WHERE details.Securitynaam=vx_PO_holding_settled.Securitynaam
				and details.securityDescription = vx_PO_holding_settled.securityDescription
				and details.ISIN = vx_PO_holding_settled.ISIN
				and details.munt = vx_PO_holding_settled.munt
                ORDER BY details.custodian
                FOR XML PATH(''), TYPE
            ).value('.','varchar(max)')
            ,1,2, ''
        ) AS "all_custodians"
	 from
		vx_PO_holding_settled
	 group by
		Securitynaam, securityDescription, ISIN, munt) as po_saldo
	full outer join
	(select
		insid, [Description], abbreviatenmaeofsecurites, securityisin, sum(quantity) as quantity, count(*) as num_positions,
		STUFF(
            (SELECT
                ', '+ STR(details.depositaccountnr)
                FROM
					SourceData.dbo.vx_PO_kasbank as details
                WHERE ((details.insid is null and vx_PO_kasbank.insid is null) OR details.insid=vx_PO_kasbank.insid)
				and details.[Description] = vx_PO_kasbank.[Description]
				and details.abbreviatenmaeofsecurites = vx_PO_kasbank.abbreviatenmaeofsecurites
				and details.securityisin = vx_PO_kasbank.securityisin
                ORDER BY details.depositaccountnr
                FOR XML PATH(''), TYPE
            ).value('.','varchar(max)')
            ,1,2, ''
        ) AS "all_depositaccountnr"
	 from vx_PO_kasbank
	 where securityVvde != 0
	 group by insid, [Description], abbreviatenmaeofsecurites, securityisin
	 ) as kasbank_total
	on po_saldo.ISIN = kasbank_total.securityisin
	left join
	(select
		ISIN, sum(quantity) as quantity
	 from
		vx_PO_holding_settled
	 group by
		ISIN, munt) as portia_total_holding
	on isnull(po_saldo.ISIN, kasbank_total.securityisin) = portia_total_holding.ISIN
	left join
	(select
		securityisin, sum(quantity) as quantity
	 from vx_PO_kasbank
	 where securityVvde != 0
	 group by abbreviatenmaeofsecurites, securityisin
	 ) as kasbank_total_holding
	on isnull(po_saldo.ISIN, kasbank_total.securityisin) = kasbank_total_holding.securityisin 
```

```
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
DROP VIEW vx_PO_kasbank_vs_holding 
[1] "DRIVER=SQL Server;SERVER=ONTW7D00489;UID=;Trusted_Connection=Yes;APP=RStudio;WSID=ONTW7D00489;DATABASE=SourceData"
create view vx_PO_kasbank_vs_holding as
select
	isnull(po_saldo.Securitynaam, kasbank.insid) as insid,
	po_saldo.prfid,
	isnull(po_saldo.quantity, 0) - isnull(kasbank.quantity, 0) as holding_diff,
	isnull(po_saldo.ISIN, kasbank.securityisin) as isin,
	isnull(po_saldo.securityDescription, kasbank.[Description]) as description,
	isnull(po_saldo.munt, kasbank.munt) as munt,
	po_saldo.quantity as portia_quantity,
	kasbank.quantity as kasbank_quantity,
	isnull(portia_isin_holding.quantity, 0) - isnull(kasbank_isin_holding.quantity, 0) as isin_diff,
	portia_isin_holding.quantity as portia_isin_quantity,
	kasbank_isin_holding.quantity as kasbank_isin_quantity,
	kasbank.depositaccountnr,
	po_saldo.custodian
from
	(select
		*
	 from
		vx_PO_holding_settled
	) as po_saldo
	full outer join
	(select * from vx_PO_kasbank where securityVvde != 0
	) as kasbank
	on po_saldo.ISIN=kasbank.securityisin
	and (po_saldo.munt is null or po_saldo.munt = kasbank.munt)
	and abs( po_saldo.QUANTITY - kasbank.quantity ) <= 0.1
	left join
	(select
		ISIN, sum(quantity) as quantity
	 from
		vx_PO_holding_settled
	 group by
		ISIN, munt) as portia_isin_holding
	on isnull(po_saldo.ISIN, kasbank.securityisin) = portia_isin_holding.ISIN
	left join
	(select
		securityisin, sum(quantity) as quantity
	 from vx_PO_kasbank
	 where securityVvde != 0
	 group by securityisin
	 ) as kasbank_isin_holding
	on isnull(po_saldo.ISIN, kasbank.securityisin) = kasbank_isin_holding.securityisin
--order by isnull(po_saldo.ISIN, kasbank.securityisin), isnull(po_saldo.quantity, kasbank.quantity) 
```




