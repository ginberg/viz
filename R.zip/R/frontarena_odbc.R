source("R/config.R")
source("R/source.reat.R")
#fa_export_connect <- function(){db.connect(fa_exports_connection) }
fa_connect <-function(){db.connect(fa_connection) }
#fa_analysis_connect <-function(){ db.connect(fa_analysis_connection) }

