---
title: "Database business rules"
output: html_document
---
Database business rules
====================================================



This report has been generated on 2016-04-26.





# Get the rules







# Preparing tables to store data in




# Run the rules

                               BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
1 BU Delta Lloyd Asset Management FrontArena FA_0001 instrument ValidRange       NEED      Input       2015-06-12
   ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
1 Mid Office Thijs van den Dries   2015-07-16               <NA>   IDENTIFIER
                                                           datasource referencedata                               en
1 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Instrument name should be unique
                                              nl                                                                 rule
1 De naam van een instrument dient uniek te zijn All instruments should have a unique value for their instrument name
                                   condition Feedback      rule_load_date          source_file
1 All instruments sharing an instrument name          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                            query
1 SELECT  distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\t[insid] as insid\r\n\t, COUNT(*) AS n\r\nFROM vx_FA_instrument\r\nGROUP BY source_file, source_date, [insid]  \r\nHAVING COUNT(insid) > 1
                                                                                                                                                                            superset_query
1 SELECT \r\n\tsource_file,\r\n\tsource_date,\r\n\t[insid] as insid\r\n\t, COUNT(*) AS n\r\nFROM vx_FA_instrument\r\nGROUP BY source_file, source_date, [insid]  \r\n--HAVING COUNT(insid) > 1
                               BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
2 BU Delta Lloyd Asset Management FrontArena FA_0004 instrument HasValue       NEED      Input       2015-06-12
             ruleOwner          approvedBy approvedDate resultApprovalDate               dataelements   datasource
2 Yen Hau/Front Office Thijs van den Dries   2015-08-20               <NA> DLAM.Sector1, DLAM.Sector2 FrontArenaDb
  referencedata                                                       en
2               Instruments without underlying should not be derivatives
                                                             nl
2 Instrumenten zonder underlying dienen geen derivative te zijn
                                                                                                                       rule
2 Derivatives have an instrument which they derive. All derivative instruments should therefore have an underlying defined.
                                                                                              condition
2 All instruments which have no underlying defined\nBut have DLAMAssetClass2 == Fixed Income Derivative
                                                                                                                                                                                                                           Feedback
2 Veel uitval, omdat underlying als dusdanig alleen voor swaptions is ingevuld; voor IRS, CDS of wel juiste plek in DB zoeken, of regel inperken. 3/12 in overleg met Thijs & Donald regel aangepast om enkel swaptions te bekijken
       rule_load_date          source_file
2 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        query
2 SELECT  distinct insid , \r\n       [DLAMASSETCLASS1] , \r\n       [DLAMASSETCLASS2], \r\n       [DLAMASSETCLASS3], \r\n       und_instype_desc , \r\n       und_insid , \r\n       instype_desc\r\n  FROM [AM_AdsP].[dbo].INSTRUMENT_ADDITIONAL\r\n  WHERE \r\n\t in_scope=1\r\n\t-- (is swaption) => (has underlying)\r\n\t-- The ones we expect to have an underlying\r\n\t AND DLAMASSETCLASS2 = 'Fixed Income Derivative'\r\n\t \t AND DLAMASSETCLASS3 = 'Swaption'\r\n\t-- But doesnt have an underlying:\r\n\t AND ( und_insid is null)\r\n 
  superset_query
2               
                               BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
3 BU Delta Lloyd Asset Management FrontArena FA_0005 instrument ValidRange       NEED      Input       2015-06-12
             ruleOwner approvedBy approvedDate resultApprovalDate               dataelements   datasource referencedata
3 Yen Hau/Front Office    Yen Hau   2015-08-20               <NA> DLAM.Sector1, DLAM.Sector2 FrontArenaDb              
                                                 en                                                        nl
3 Instruments with underlying should be derivatives Instrumenten met underlying dienen een derivative te zijn
                                                                                                            rule
3 Derivatives have an instrument which they derive. All instruments having an underlying need to be a derivative
                                                                                             condition Feedback
3 All instruments which have nonempty underlying,\nbut have DLAMAssetClass2 != Fixed Income Derivative         
       rule_load_date          source_file
3 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         query
3 SELECT  distinct insid , \r\n       [DLAMASSETCLASS1] , \r\n       [DLAMASSETCLASS2], \r\n       [DLAMASSETCLASS3], \r\n       und_instype_desc , \r\n       und_insid , \r\n       instype_desc\r\n  FROM [AM_AdsP].[dbo].INSTRUMENT_ADDITIONAL --View \r\n  \tWHERE \r\n\tin_scope=1\r\n\t-- The ones with an underlying:\r\n\tand ( und_insid is not null)\r\n\t-- has underlying => is derivative\r\n\t-- The ones which aren't a derivative\r\n\tand NOT DLAMASSETCLASS2 IN( 'Fixed Income Derivative')\r\n --
  superset_query
3               
                               BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
4 BU Delta Lloyd Asset Management FrontArena FA_0006 instrument HasValue       NEED      Input       2015-06-12
   ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
4 Mid Office Thijs van den Dries   2015-07-16               <NA>   IDENTIFIER
                                                           datasource referencedata
4 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                      en                                                             nl
4 All instruments should have a nonempty instrument name Alle instrumenten moeten een niet-lege instrument name hebben.
                                                                rule
4 All instruments should have an non empty, defined, instrument name
                                            condition Feedback      rule_load_date          source_file
4 All instruments which have an empty instrument name          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                  query
4 SELECT  distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\t[insid]\r\nFROM \r\n\tvx_FA_instrument_twice\r\nWHERE \r\n\t[insid] IS NULL or RTRIM([insid])=''
  superset_query
4               
                               BU     system      BR entitytype          Depth Importance ErrorCause modificationDate
5 BU Delta Lloyd Asset Management FrontArena FA_0007 instrument SelfConsistent       NEED      Input       2015-06-12
   ruleOwner          approvedBy approvedDate resultApprovalDate dataelements   datasource referencedata
5 Mid Office Thijs van den Dries   2015-09-24               <NA>   IDENTIFIER FrontArenaDb              
                                                                             en
5 All instrument with equal unhashed instrumentname should have an equal issuer
                                                                                            nl
5 Alle  instrumenten met gelijke ongehashte instrument naam dienen een gelijke uitgever hebben
                                                                                                                                                                                                                                                                                                                                                                                                                    rule
5 The instrument name is proposed by the Front Arena system, resulting in possibly duplicated instrument names for new instruments (contracts).\nThe system solves this by adding a hash(#) with a digit behind it for different versions. These are assumed to all indicate the same instrument, consisting of set of contracts.\nAs they all refer to the same contract package, they should also have the same ISSUER
                                                                                                                                                                                                     condition
5 With\n\n\n insid_nohash as the instrument name without the hash and numeric suffix\n\n\ngrouped by insid_nohash\n\n\nwith\n\n\n num as the number of different issuer parties\n\n\nwhere num is at least two
                               Feedback      rule_load_date          source_file
5 Voor laurent: wat is issuer in de db? 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              query
5 SELECT  distinct\r\n  instr.insid as insid,   \r\n  instr.insid_nohash as insid_nohash,     \r\n  instr.issuer_pty as issuer_pty, \r\n  count_issuer_pty as number_of_issuers\r\nFROM\r\n  (SELECT  \r\n    [insid_nohash]\r\n    ,COUNT(DISTINCT ISNULL([issuer_pty],-1))\t\tAS count_issuer_pty\r\n    FROM [AM_AdsP].[dbo].[INSTRUMENT_ADDITIONAL]\r\n\tWHERE in_scope=1\r\n    GROUP BY [insid_nohash]\r\n    HAVING COUNT(DISTINCT ISNULL([issuer_pty],-1)) > 1\r\n  ) as fails \r\n  LEFT JOIN \r\n    [AM_AdsP].[dbo].[INSTRUMENT_ADDITIONAL] as instr \r\n    on fails.insid_nohash=instr.insid_nohash \r\n\tAND instr.in_scope=1\r\n  order by instr.insid_nohash, insid\r\n
  superset_query
5               
                               BU     system      BR entitytype          Depth Importance ErrorCause modificationDate
6 BU Delta Lloyd Asset Management FrontArena FA_0008 instrument SelfConsistent       NEED      Input       2015-06-12
   ruleOwner          approvedBy approvedDate resultApprovalDate dataelements   datasource referencedata
6 Mid Office Thijs van den Dries   2015-07-16               <NA>   IDENTIFIER FrontArenaDb              
                                                                                en
6 All instrument with equal unhashed instrument name should have an equal CURRENCY
                                                                                        nl
6 Alle  instrumenten met gelijke ongehashte instrument name dienen een gelijke MUNT hebben
                                                                                                                                                                                                                                                                                                                                                                                                                rule
6 The instrument name is proposed by the Front Arena system, resulting in possibly duplicated instrument names for new instruments (contracts).\nThe system solves this by adding a hash(#) with a digit behind it for different versions. These are assumed to all indicate the same instrument, consisting of set of contracts.\nAs they all refer to the same instrument, they should also have the same CURRENCY
                                                                                                                                                                                             condition
6 With\n\n\n insid_nohash as the instrument name without the hash and numeric suffix\n\n\ngrouped by insid_nohash\n\n\nwith\n\n\n num as the number of different CURRENCIES\nwhere num is at least two
  Feedback      rule_load_date          source_file
6          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    query
6 SELECT  distinct\r\n  instr.insid as insid,   \r\n  instr.insid_nohash as insid_nohash,     \r\n  instr.currency_desc as currency_desc, \r\n  count_currency_desc as number_of_currencies\r\nFROM\r\n  (SELECT  \r\n    [insid_nohash]\r\n    ,COUNT(DISTINCT ISNULL([currency_desc],-1))\t\tAS count_currency_desc\r\n    FROM [AM_AdsP].[dbo].[INSTRUMENT_ADDITIONAL]\r\n\twhere in_scope=1\r\n    GROUP BY [insid_nohash]\r\n    HAVING COUNT(DISTINCT ISNULL(currency_desc,-1)) > 1\r\n  ) as fails \r\n  LEFT JOIN \r\n    [AM_AdsP].[dbo].[INSTRUMENT_ADDITIONAL] as instr \r\n    on fails.insid_nohash=instr.insid_nohash \r\n  order by instr.insid_nohash, insid
  superset_query
6               
                               BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
7 BU Delta Lloyd Asset Management FrontArena FA_0009    holding HasValue       NEED      Input       2015-06-12
             ruleOwner  approvedBy approvedDate resultApprovalDate   dataelements
7 Yen Hau/Front Office Ronald Bark   2015-08-10               <NA> PORTFOLIO_NAME
                                                           datasource referencedata
7 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                      en                                         nl
7 Holdings have a defined portfolio name Posities hebben een gedefnieerde portfolio
                                                         rule                              condition
7 All holdings should have a defined non empty portfolio name Holdings with PortfolioNaam NULL or ''
                                                                            Feedback      rule_load_date
7 Ronald Bark heeft aangegeven dat de regel OK is, maar niet DM verantwoordelijkheid 2016-04-26 16:07:05
           source_file
7 frontarena_rules.csv
                                                                                                                                                                                                                                               query
7 SELECT  distinct\r\n\tsource_date,\r\n\tsource_file,\r\n\tprfid,\r\n\tinsid,\r\n\tNOMINAL_VALUE,\r\n\tQuantity,\r\n\tdb_position,\r\n\tPORTFOLIO_NAME,\r\n\tCURRENCY\r\nFROM \r\n\tvx_FA_holding_twice\r\nWHERE \r\n\tprfid IS NULL \r\n\tOR RTRIM(prfid) = ''
  superset_query
7               
                               BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
8 BU Delta Lloyd Asset Management FrontArena FA_0012    holding ValidRange       NEED      Input       2015-06-12
             ruleOwner  approvedBy approvedDate resultApprovalDate               dataelements
8 Yen Hau/Front Office Ronald Bark   2015-08-10               <NA> IDENTIFIER, PORTFOLIO_NAME
                                             datasource referencedata
8 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                                en
8 Portfolio name and instrument identifier combinations are unique
                                                     nl
8 De combinaties van portfolio en instrument zijn uniek
                                                                                                                                                                                                                            rule
8 The unique combinations of Portfolio naam and Security Naam occurring at multiple rows.\n\n\nVerified relation: ( X.(Portfolio.Naam, Security.naam) == Y.(Portfolio.Naam, Security.naam) ) => X==Y, for all postitions X and Y
                                                                                                            condition
8 For all combinations of Security.Naam and Portfolio.Naam\n\n\nhaving more than one row \n\n\nreturn the instruments
                                                                            Feedback      rule_load_date
8 Ronald Bark heeft aangegeven dat de regel OK is, maar niet DM verantwoordelijkheid 2016-04-26 16:07:05
           source_file
8 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                     query
8 select  distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tfails.*\r\nfrom\r\n\t(\r\n\tSELECT \r\n\t\tinsid, \r\n\t\tprfid, \r\n\t\tCOUNT(*) as num\r\n\tFROM vx_FA_holding as exported\r\n\tGROUP BY insid, prfid\r\n\tHAVING COUNT(*)> 1\r\n\t) as fails\r\n\tleft join vx_FA_holding as details\r\n\ton fails.insid = details.insid\r\n\tand fails.prfid = details.prfid
  superset_query
8               
                               BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
9 BU Delta Lloyd Asset Management FrontArena FA_0013 instrument HasValue       NEED      Input       2015-06-12
   ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
9 Mid Office Thijs van den Dries   2015-07-16               <NA>       STRIKE
                                                           datasource referencedata
9 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                    en                                          nl
9 Swaptions should have a strike price Swaptions dienen een strike price te hebben
                                                                                                                                                                                                              rule
9 Swaptions are a derivative instrument. Therefore swaptions should have a strike price.\nThe data load scripts parses the value to a numeric value, any non-numeric value like the empty '' will also become NULL
                                                              condition Feedback      rule_load_date
9 Instruments with \n   DLAMAssetClas3 = 'Swaption'\n   and strike null          2016-04-26 16:07:05
           source_file
9 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                          query
9 SELECT DISTINCT\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid, \r\n    DLAMAssetClass1 , \r\n    DLAMAssetClass2 , \r\n    DLAMAssetClass3 ,\r\n    STRIKE,\r\n\tdb_instype_desc\r\nFROM vx_FA_instrument_twice\r\nWHERE\r\n    -- Equity Derishould have a strike price\r\n      STRIKE IS NULL      \r\n      AND DLAMASSETCLASS3 = 'Swaption'
  superset_query
9               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
10 BU Delta Lloyd Asset Management FrontArena FA_0014 instrument ValidRange       NEED      Input       2015-06-12
              ruleOwner          approvedBy approvedDate resultApprovalDate                         dataelements
10 Yen Hau/Front Office Thijs van den Dries   2015-08-20               <NA> DLAM.Asset.Type.2, DLAM.Asset.Type.3
                                                            datasource referencedata
10 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                     en                                                         nl
10 Instruments with a strike price need to be swaptions Instrumenten met strike price dienen een swaption te zijn.
                                                                                                                                 rule
10 Swaptions are the only derivatives expected in Front Arena. Therfore swaptions should be the only instrument having a strike price
                                                                                condition Feedback      rule_load_date
10 Return all rows/instances of \n\n\n strike price > 0 , and DLAMAssetClass3 != Swaption          2016-04-26 16:07:05
            source_file
10 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        query
10 SELECT DISTINCT \r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid, \r\n    DLAMAssetClass1 , \r\n    DLAMAssetClass2 , \r\n    DLAMAssetClass3 , \r\n    db_instype_desc\t,\r\n    strike\r\nFROM \r\n\tvx_FA_instrument_twice\r\nWHERE  \r\n  (\r\n      -- strike price only for derivatives\r\n      STRIKE > 0 \r\n  \t  AND NOT (\r\n          DLAMASSETCLASS1 = 'Fixed Income'\r\n          AND DLAMASSETCLASS2 = 'Fixed Income Derivative'\r\n          AND DLAMASSETCLASS3  = 'Swaption'\r\n\t\t  )\r\n  ) ;
   superset_query
10               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
11 BU Delta Lloyd Asset Management FrontArena FA_0015 instrument HasValue       NEED      Input       2015-06-12
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
11 Mid Office Thijs van den Dries   2015-07-16               <NA>   EXPIRATION
                                                            datasource referencedata
11 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                              en                                                         nl
11 Derivative instruments should have expiration Afgeleide instrumente dienen een expiration date te hebben
                                                                                                                                                                                                                                                                                                                                                           rule
11 Derivatives only exist temporary. All derivative instruments should therefore have an expiration date defined.\nAs front arena is a system for derivatives, expiration should usually be filled.\nIt however also contains a few bond's. Thus all instruments, except bonds, should have an expiration date defined. The bonds have a maturity date defined.
                                                                            condition Feedback      rule_load_date
11 All instruments which have DLAMAssetClass2 != Bond\nBut have no expiration defined          2016-04-26 16:07:05
            source_file
11 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                      query
11 SELECT  distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid , \r\n    DLAMASSETCLASS1,\r\n\tDLAMASSETCLASS2,\r\n\tDLAMASSETCLASS3,\r\n    Expiration AS expiration_day, \r\n    db_instype_desc\r\nFROM vx_FA_instrument_twice\r\nWHERE \r\n\t DLAMASSETCLASS2 != 'Bond'\r\n\t and \r\n\t Expiration IS NULL
   superset_query
11               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
12 BU Delta Lloyd Asset Management FrontArena FA_0016 instrument ValidRange       NEED      Input       2015-06-12
              ruleOwner          approvedBy approvedDate resultApprovalDate      dataelements
12 Yen Hau/Front Office Thijs van den Dries   2015-08-20               <NA> DLAM.Asset.Type.2
                                                                                                   datasource
12 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv, DLDerivativesReportRisk2015-08-18.csv
   referencedata                                                              en
12               Instruments with an expiration should be derivative instruments
                                                                             nl
12 Instrumenten met een expiration date dienen een afgeleide instrument te zijn
                                                                                                                                                                       rule
12 Derivatives only exist temporary. All derivative instruments should therefore have an expiration date defined. All instruments with an expiration should be derivatives.
                                                                                                condition Feedback
12 All instruments which have an expiration defined\nBut  have DLAMAssetClass2 != Fixed Income Derivative         
        rule_load_date          source_file
12 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                             query
12 SELECT  distinct\r\n\tsource_file,\r\n\tsource_date, \r\n\tinsid , \r\n    DLAMASSETCLASS1,\r\n\tDLAMASSETCLASS2,\r\n\tDLAMASSETCLASS3,\r\n    EXPIRATION, \r\n\tMATURITY,\r\n\tdb_instype_desc\r\nFROM vx_FA_instrument_twice\r\nWHERE \r\n\t EXPIRATION IS NOT NULL\r\n\t and DLAMASSETCLASS2 != 'Fixed Income Derivative'\r\n\t and DLAMAssetClass2 != 'FX Derivative'\r\n\t and DLAMAssetClass2 != 'Equity Derivative'
   superset_query
12               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
13 BU Delta Lloyd Asset Management FrontArena FA_0017 instrument HasValue       NEED      Input       2015-06-30
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
13 Mid Office Thijs van den Dries   2015-07-16               <NA>     CURRENCY
                                                            datasource referencedata                            en
13 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               The currency must be defined.
                             nl                                                      rule
13 De currency moet gevuld zijn All instruments should have a defined, nonempty, currency
                                       condition Feedback      rule_load_date          source_file
13 Instruments with currency equal to NULL or ''          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                query
13 SELECT    distinct\r\n\tsource_date,\r\n\tsource_file, \r\n\t[insid],\r\n\tCURRENCY\r\nFROM vx_FA_instrument_twice\r\nWHERE \r\n  LEN(RTRIM(CURRENCY))=0 -- invalid id\r\n  OR CURRENCY IS NULL -- foreign key failure
   superset_query
13               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
14 BU Delta Lloyd Asset Management FrontArena FA_0018 instrument ValidRange       NEED      Input       2015-06-12
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements   datasource referencedata
14 Mid Office Thijs van den Dries   2015-07-16               <NA>     CURRENCY FrontArenaDb              
                                                              en
14 All instruments should have a currency instrument as currency
                                                             nl
14 Alle instrumenten moeten een munt instrument als munt hebben
                                                                                                                                                                              rule
14 Front Arena links instruments to a currency, which is also registered as a currency.\nThe instruments used as a currency, should be marked in the database as being a currency.
                                                              condition Feedback      rule_load_date
14 Securities which' currency instrument is not marked to be a currency          2016-04-26 16:07:05
            source_file
14 frontarena_rules.csv
                                                                                                                                                                                                                                                      query
14 SELECT  distinct  [insid]\r\n\t\t,[currency_desc]\r\n    ,[currency_instype_desc]\r\nFROM [AM_AdsP].[dbo].[INSTRUMENT_ADDITIONAL]\r\nWHERE \r\n\t[currency_instype_desc] != 'Curr' -- the instrument being referred to is not a currency\r\n\tAND in_scope=1
   superset_query
14               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
15 BU Delta Lloyd Asset Management FrontArena FA_0019 instrument HasValue       NEED      Input       2015-06-12
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
15 Mid Office Thijs van den Dries   2015-09-24               <NA>   ISSUE_DATE
                                                            datasource referencedata
15 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                          en                                                nl
15 All instruments should have an Issue Date Alle instrumenten dienen een issue date te hebben
                                                                                                                                                                                           rule
15 All contracts (instruments) in Front Arena should have an issue date. \nThe only exception is the swaption, which has no Issue date.\nVerified relation: is not a swaption => has Issue Date
                                                                   condition
15 All instruments with \n\n\n-DLAMAssetClass3 not 'Swaption'\n-No issue_day
                                        Feedback      rule_load_date          source_file
15 Laurent: Swaption should have an acquire date 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                 query
15 SELECT    distinct\r\n\tsource_file,\r\n\tsource_date,       \r\n    insid,\r\n    DLAMAssetClass1 , \r\n    DLAMAssetClass2 ,\r\n    DLAMAssetClass3 ,\r\n\tISSUE_DATE\r\nFROM vx_FA_instrument_twice\r\nWHERE \r\n\tDLAMAssetClass3 NOT IN ('Swaption')\r\n    AND ISSUE_DATE IS NULL
   superset_query
15               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
16 BU Delta Lloyd Asset Management FrontArena FA_0021 instrument HasValue       NEED      Input       2015-06-30
         ruleOwner  approvedBy approvedDate resultApprovalDate dataelements
16 Data Management Ronald Bark   2015-08-10               <NA> DLAM.Sector1
                                                            datasource referencedata                     en
16 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Nonempty dlam sector 1
                      nl                                                            rule
16 Gevulde dlam sector 1 All instruments should have a defined, non empty, dlam sector 1
                                            condition Feedback      rule_load_date          source_file
16 Instruments with dlam sector 1 equal to NULL or ''          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                              query
16 SELECT  distinct\r\n\tsource_date,\r\n\tsource_file,\r\n\tinsid , \r\n\tDLAMSector1 , \r\n\tDLAMSector2 , \r\n\tDLAMSector3\r\n  FROM \r\n\tvx_FA_instrument_twice\r\n  WHERE \r\n\t(DLAMsector1 IS NULL OR RTRIM(DLAMSector1) = '')\r\n\r\n\r\n\r\n\r\n
   superset_query
16               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
17 BU Delta Lloyd Asset Management FrontArena FA_0022 instrument HasValue       NEED      Input       2015-06-30
         ruleOwner  approvedBy approvedDate resultApprovalDate dataelements
17 Data Management Ronald Bark   2015-08-10               <NA> DLAM.Sector2
                                                            datasource referencedata                     en
17 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Nonempty dlam sector 2
                      nl                                                            rule
17 Gevulde dlam sector 2 All instruments should have a defined, non empty, dlam sector 2
                                            condition Feedback      rule_load_date          source_file
17 Instruments with dlam sector 2 equal to NULL or ''          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                             query
17 SELECT distinct\r\n\tsource_date,\r\n\tsource_file,\r\n\tinsid , \r\n\tDLAMSector1 , \r\n\tDLAMSector2 , \r\n\tDLAMSector3\r\n  FROM \r\n\tvx_FA_instrument_twice\r\n  WHERE \r\n\t(DLAMsector2 IS NULL OR RTRIM(DLAMSector2) = '')\r\n\r\n\r\n\r\n\r\n
   superset_query
17               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
18 BU Delta Lloyd Asset Management FrontArena FA_0023 instrument HasValue       NEED      Input       2015-06-30
         ruleOwner  approvedBy approvedDate resultApprovalDate dataelements
18 Data Management Ronald Bark   2015-08-10               <NA> DLAM.Sector3
                                                            datasource referencedata                     en
18 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Nonempty dlam sector 3
                      nl                                                            rule
18 Gevulde dlam sector 3 All instruments should have a defined, non empty, dlam sector 3
                                            condition Feedback      rule_load_date          source_file
18 Instruments with dlam sector 3 equal to NULL or ''          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                             query
18 SELECT distinct\r\n\tsource_date,\r\n\tsource_file,\r\n\tinsid , \r\n\tDLAMSector1 , \r\n\tDLAMSector2 , \r\n\tDLAMSector3\r\n  FROM \r\n\tvx_FA_instrument_twice\r\n  WHERE \r\n\t(DLAMsector3 IS NULL OR RTRIM(DLAMSector3) = '')\r\n\r\n\r\n\r\n\r\n
   superset_query
18               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
19 BU Delta Lloyd Asset Management FrontArena FA_0024 instrument HasValue       NEED      Input       2015-06-12
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
19 Mid Office Thijs van den Dries   2015-07-16               <NA>     MATURITY
                                              datasource referencedata                                           en
19 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               All instruments  should have a maturity date
                                                     nl
19 Alle instrumenten dienen een maturity date te hebben
                                                                                                                                                                                                                                                                                                        rule
19 All instruments, all contracts, should have a maturity date. \nFront Arena makes no distinction between maturity date and expiration date. In the export the maturity value is equal to the expiration value in the exports.\nThis rule verifies that all maturity dates are defined, for all instruments
                            condition Feedback      rule_load_date          source_file
19 All bonds  having no maturity date          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                 query
19 SELECT  distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid , \r\n    [MATURITY] , \r\n    DLAMAssetClass2\r\nFROM vx_FA_instrument\r\nWHERE \r\n\tMATURITY IS NULL
   superset_query
19               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
20 BU Delta Lloyd Asset Management FrontArena FA_0026 instrument HasValue       NEED      Input       2015-06-12
   ruleOwner              approvedBy approvedDate resultApprovalDate dataelements
20       FRM Fred Schulte Fischedick   2015-08-13               <NA>  DLAM.RATING
                                                            datasource referencedata
20 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                           en                                                      nl
20 All instruments should have a nonempty dlam rating defined Alle instrumenten dienen een niet lege rating te hebben
                                                                                                            rule
20 All instruments should have a non-empty and non-null dlam rating defined.\nIt could still be for example 'NR'
                                          condition Feedback      rule_load_date          source_file
20 Instruments with dlam rating equal to NULL or ''          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                             query
20 SELECT  distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid\r\n\t,DLAMRating\r\n\t,db_instype_desc\r\n\t,DLAMAssetClass1\r\n\t,DLAMAssetClass2\r\n\t,DLAMAssetClass3\r\n\t,TOTAL_Quantity\r\n\t,TOTAL_NOMINAL_VALUE\r\nFROM vx_FA_instrument_twice \r\nWHERE \r\n\t-- which have an empty rating\r\n\t(DLAMRating IS NULL OR LEN(RTRIM(DLAMRating))=0)\t
   superset_query
20               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
21 BU Delta Lloyd Asset Management FrontArena FA_0027 instrument ValidRange       NEED      Input       2015-06-12
   ruleOwner              approvedBy approvedDate resultApprovalDate dataelements
21       FRM Fred Schulte Fischedick   2015-08-13               <NA>  DLAM.RATING
                                                            datasource referencedata
21 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                                  en
21 All bonds and CDS's should have rating (not equal to 'MR' or '-')
                                                                                    nl
21 Alle obligaties en CDS'en dienen een rating te hebben (niet gelijk aan 'NR' en '-')
                                                                                                                                                                                                                                                                                                                                                                                                                                                                rule
21 All bonds should have a rating (not equal to 'NR' or '-')\nThe LIC bonds are an exception. As they are loans within delta lloyd, no rating is necesary.\n\n\nCredit default swaps (CDS) are also an exception, they should have a rating.\n\n\nAn instrument is regarded as not having a nontrivial rating when its DLAMRating is an empty string, only whitespace, NULL or explicitly 'NR' or '-'\nVerified relation: Is bond or CDS (but not LIC) => Has Rating
                                                                                                                                                                                                                                                                                                                                                                                                                                 condition
21 All instruments which are a bond or CDS, and have no rating\n\n\nThe bonds are defined as instruments with\n\n\n  DLAMAssetClass2 equal to 'Bond' \n\n\n  OR DLAMAssetClass3 equal to 'Credit Default Swap'\n  OR instype_desc equal to 'Bond' or 'CreditDefaultSwap'\n\n\n  but do not have a DLAMAssetClass3 equal to 'LIC'\n\n\nThe ratings is regarded as unavailable when\n\n\n  DLAMRating is null\n\n\n  OR RTRIM(DLAMRating)=''
   Feedback      rule_load_date          source_file
21          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   query
21 SELECT  distinct\r\n\tsource_date,\r\n\tsource_file,\r\n\t insid\r\n\t,DLAMRating\r\n\t,db_instype_desc\r\n\t,DLAMAssetClass1\r\n\t,DLAMAssetClass2\r\n\t,DLAMAssetClass3\r\nFROM vx_FA_instrument_twice\r\nWHERE \r\n\t-- all instruments which should have a rating\r\n\t(DLAMAssetClass2 = 'Bond' \r\n\t\tOR DLAMAssetClass3 = 'Credit Default Swap'\r\n\t\tOR db_instype_desc IN ('Bond', 'CreditDefaultSwap')\r\n\t\t)\r\n\tAND NOT DLAMAssetClass2 = 'LIC'\t\t\t\t\t\t--Exclude intercompany loans\r\n\t-- but which haven't got a rating\r\n\tAND (DLAMRating = 'NR' OR DLAMRating='-' or DLAMRating is NULL)\r\n\t-- rule does not apply to index funds\r\n\tAND insid not like 'iTrx%' 
   superset_query
21               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
22 BU Delta Lloyd Asset Management FrontArena FA_0028 instrument ValidRange       NEED      Input       2015-06-12
   ruleOwner              approvedBy approvedDate resultApprovalDate dataelements
22       FRM Fred Schulte Fischedick   2015-08-13               <NA>  DLAM.RATING
                                                            datasource referencedata
22 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                              en
22 All non bonds should not have a rating (equal to 'NR' or '-')
                                                                           nl
22 Alle niet obligaties dienen geen rating te hebben (gelijk aan 'NR' of '-')
                                                                                                                                                                                                                                                                                                                                                                                                                            rule
22 All non bonds should not have a rating (equal to 'NR' or '-').\n\n\nThe LIC bonds are an exception. As they are loans within delta lloyd, no rating is necesary.\n\n\nCredit default swaps (CDS) are also an exception, they should have a rating.\n\n\nAn instrument is regarded as having a trivial rating when its DLAMRating is explicitly 'NR' or '-'\n\n\nVerified relation: Has Rating => Is bond or CDS (but not LIC)
                                                                                                                                                                                                                                                                                                                                                                                                                                           condition
22 All instruments which are a not a bond or CDS, but do have an available rating\n\n\nThe bonds are defined as instruments with\n\n\n  DLAMAssetClass2 equal to 'Bond' \n\n\n  OR DLAMAssetClass2 equal to 'Credit Default Swap'\n  OR instype_desc equal to 'Bond' or 'CreditDefaultSwap'\n\n\n  but do not have a DLAMAssetClass3 equal to 'LIC'\n\n\nThe ratings is regardes as unavailable when\n\n\n  DLAMRating='-'\n\n\n  OR DLAMRating='NR'
                                                                                                   Feedback
22 Er zijn preference shares die gemodelleerd zijn als een bond die een rating kunnen hebben (check uitval)
        rule_load_date          source_file
22 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                 query
22 SELECT  distinct\r\n\tsource_date,\r\n\tsource_file,\r\n\t insid\r\n\t,DLAMRating\r\n\t,db_instype_desc\r\n\t,DLAMAssetClass1\r\n\t,DLAMAssetClass2\r\n\t,DLAMAssetClass3\r\nFROM \r\n\tvx_FA_instrument_twice\r\nWHERE \r\n\t-- all instruments which are not bonds\r\n\tDLAMAssetClass2 != 'Bond' and DLAMAssetClass3 != 'Credit Default Swap' and DLAMAssetClass2 != 'LIC'\r\n\t-- but which have a rating\r\n\tAND NOT (DLAMRating = 'NR' OR DLAMRating='-')
   superset_query
22               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
23 BU Delta Lloyd Asset Management FrontArena FA_0031 instrument HasValue       NEED      Input       2015-06-12
         ruleOwner  approvedBy approvedDate resultApprovalDate      dataelements
23 Data Management Ronald Bark   2015-08-10               <NA> DLAM.Asset.Type.2
                                                            datasource referencedata                    en
23 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Nonempty asset type 2
                     nl                                                                 rule
23 Gevulde asset type 2 All instruments should hava a defined, non empty, dlam asset class 2
                                                condition Feedback      rule_load_date          source_file
23 Instruments with dlam asset type 2 equal to NULL or ''          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                query
23 SELECT  distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid\r\n\t,DLAMAssetClass2\t  \r\nFROM vx_FA_instrument_twice\r\nWHERE\r\n\t(DLAMAssetClass2 IS NULL OR DLAMAssetClass2 = '')
   superset_query
23               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
24 BU Delta Lloyd Asset Management FrontArena FA_0032 instrument HasValue       NEED      Input       2015-06-12
         ruleOwner  approvedBy approvedDate resultApprovalDate      dataelements
24 Data Management Ronald Bark   2015-08-10               <NA> DLAM.Asset.Type.3
                                                            datasource referencedata                    en
24 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Nonempty asset type 3
                     nl                                                                 rule
24 Gevulde asset type 3 All instruments should have a defined, non empty, dlam asset class 3
                                                condition Feedback      rule_load_date          source_file
24 Instruments with dlam asset type 3 equal to NULL or ''          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                   query
24 SELECT  distinct\r\n\tsource_date,\r\n\tsource_file,\r\n\tinsid\r\n\t,DLAMAssetClass3\r\nFROM \r\n\tvx_FA_instrument_twice\r\nWHERE \r\n\t(DLAMAssetClass3 IS NULL OR DLAMAssetClass3 = '')
   superset_query
24               
                                BU     system      BR entitytype          Depth Importance ErrorCause modificationDate
25 BU Delta Lloyd Asset Management FrontArena FA_0036 instrument SelfConsistent       NEED Definition       2015-06-12
        ruleOwner    approvedBy approvedDate resultApprovalDate        dataelements
25 Valuation Desk Ilona Balvert   2015-08-13               <NA> MARKET_VALUE, PRICE
                                              datasource referencedata
25 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                                                                                    en
25 No significant differences between market value and Quantity times clean price (in eur), plus clean accrued intrest
                                                                                                        nl
25 Geen significante verschillen tussen marktwaarde en hoeveelheid keer prijs (in eur), plus lopende rente
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        rule
25 One whould expect the quantity times the price to be the market value. \n\n\nHowever the definition of 'MW incl LR (Eur)' also contains the LR (lopende rente), which is the Acrued Interest. \n\n\nSpecific bonds are inflation linked, which' principal should also be added to the market value\n\n\nThese bonds however do not occur in the FrontArena system (they do exist in Portia)\n\n\nThe actual calculation thus is (quantity * clean_europrice  + accrued interest) == market value\n\n\nAlso units of both quantity and price needs to be taken care of. For example, bonds are priced at 100 to indicate 100%\n\n\nVerified relation: For all instruments: ((KOERS/FXRATE)*QUANTITY*UNIT.PRICE + AcruedInterest.Eur.) == MW.incl.LR..Eur\n\n\nwhere UNIT.PRICE is 0.01 for all instruments in FrontArena \nThis rule is similar to FA_0074, but only returns significant differences (>0.00001 * QUANTITY)
                                                                                                                                                                                                                                                                                        condition
25 If Quantity equals 0, a MW.incl.LR..Eur. of 0 is expected\n\n\notherwise a MW.incl.LR..Eur. of (KOERS * QUANTITY * 0.01 / FXRATE + AcruedInterest.Eur.) is expected\n\n\nPrice differences of less than 0.01 and 0.00001 * Quantity are ignored. FA_0074 reports those of <=0.00001 * Quantity
   Feedback      rule_load_date          source_file
25          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           query
25 Select  distinct  *\r\n    , RECALC_MARKET_VALUE-MARKET_VALUE  \t\t\tAS DeltaMARKET_VALUE\r\n    , ((RECALC_MARKET_VALUE-MARKET_VALUE)/MARKET_VALUE)*100\t\tAS DeltaPercentMARKET_VALUE\r\n\r\n  FROM (\r\n\tselect\r\n\t\th.source_file,\r\n\t\th.source_date,\r\n\t\th.proddat,\r\n\t\th.insid,\r\n\t\th.prfid,\r\n\t\th.Quantity,\r\n\t\th.Price,\r\n\t\tp.OpenPremiumDiscounted,\r\n\t\th.AccruedInterest,\r\n\t\th.Currency,\r\n\t\th.FxRate,\r\n\t\th.MARKET_VALUE,\r\n\t\t\r\n\t\tCase when h.Quantity = 0 then 0\t\t\t\t\t\t\t--If Quantity equals 0, a MW.incl.LR..Eur. of 0 is expected\r\n\t\t\t  else h.Price*h.Quantity/(h.FxRate*100)+h.AccruedInterest+ISNULL(p.OpenPremiumDiscounted,0) \r\n\t\t\t end As RECALC_MARKET_VALUE\r\n\tfrom\r\n\t\tvx_FA_holding h\r\n\t\tleft join FA_derivreport p\r\n\t\t\ton h.insid = p.Instrument\r\n\t\t\tand h.prfid = p.portfolio \r\n) as all_marketvalues\r\nwhere \r\nABS(RECALC_MARKET_VALUE-MARKET_VALUE) > 0.01 \r\nAND ABS(RECALC_MARKET_VALUE-MARKET_VALUE) > 0.0001 * ABS(Quantity) -- The quantity factor should be equal in rules FA_0036 and FA_0074\r\n\r\n--The failing Instrument Name (7.3% ST. DE SCHORSMOLEN 1997-98/24) has a closed position as per 28-02-2014
   superset_query
25               
                                BU     system      BR entitytype      Depth Importance           ErrorCause
26 BU Delta Lloyd Asset Management FrontArena FA_0037    holding ValidRange       NEED Export Configuration
   modificationDate              ruleOwner             approvedBy approvedDate resultApprovalDate dataelements
26       2015-06-12 Information Management Yen Hau/Nanda Kartaram   2015-10-05               <NA>      proddat
                      datasource referencedata
26 FA_Derivatives_P_20150818.csv              
                                                                            en
26 The proddat is constant for all exported instruments in the fa_deriv export
                                                                nl
26 The proddat is gelijk voor elk instrument in de fa_deriv export
                                                                                                                                                                 rule
26 Securities in the export file should all have the same export date (proddat)\n\n\nLooks similar to FA_0038 but this is on the export FA_Derivatives_P_20150818.csv
                                                                           condition Feedback      rule_load_date
26 All instruments with a run.date which is not equal to the most occurring run.date          2016-04-26 16:07:05
            source_file
26 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                     query
26 DECLARE @CountDate AS INT\r\nSELECT @CountDate = COUNT(DISTINCT Date) FROM fa_deriv\r\n\r\nSELECT  distinct InstrumentName as insid,\r\n\t\tFA_deriv.PortfolioName as prfid,\r\n       [Date] as proddat\r\nFROM (\r\n\tSELECT TOP (@CountDate-1) [Date] AS proddat \r\n\tFROM fa_deriv \r\n\tgroup by [Date] \r\n\torder by count(*) asc) as minorityDates\r\n\tLEFT JOIN fa_deriv on minorityDates.proddat = fa_deriv.[Date]
   superset_query
26               
                                BU     system      BR entitytype      Depth Importance           ErrorCause
27 BU Delta Lloyd Asset Management FrontArena FA_0038    holding ValidRange       NEED Export Configuration
   modificationDate              ruleOwner             approvedBy approvedDate resultApprovalDate dataelements
27       2015-06-12 Information Management Yen Hau/Nanda Kartaram   2015-10-05               <NA>      proddat
               datasource referencedata                                                                     en
27 FA_Loan_P_20150818.csv               The proddat is constant for all exported instruments in fa_loan export
                                                               nl
27 The proddat is gelijk voor elk instrument in de fa_loan export
                                                                                                                                                          rule
27 Securities in the export file should all have the same export date (proddat)\n\n\nLooks similar to FA_0037 but this is on the export FA_Loan_P_20150818.csv
                                                                           condition Feedback      rule_load_date
27 All instruments with a run.date which is not equal to the most occurring run.date          2016-04-26 16:07:05
            source_file
27 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                              query
27 DECLARE @CountDate AS INT\r\nSELECT @CountDate = COUNT(DISTINCT Date) FROM fa_loan\r\n\r\nSELECT  distinct InstrumentName as insid,\r\n\t\tfa_loan.PortfolioName as prfid,\r\n       [Date] as proddat\r\nFROM (SELECT TOP (@CountDate-1) [Date] AS proddat FROM fa_loan group by [Date] order by count(*) asc) as minorityDates\r\n\t  LEFT JOIN fa_loan on minorityDates.proddat = fa_loan.[Date]
   superset_query
27               
                                BU     system      BR entitytype          Depth Importance ErrorCause modificationDate
28 BU Delta Lloyd Asset Management FrontArena FA_0039 instrument SelfConsistent       NEED      Input       2015-06-12
              ruleOwner  approvedBy approvedDate resultApprovalDate      dataelements   datasource referencedata
28 Yen Hau/Front Office Ronald Bark   2015-08-10               <NA> DLAM.Asset.Type.3 FrontArenaDb              
                                                            en                                                   nl
28 Every DLAMAssetClass3 should only have one instrument type  Elke DLAMAssetClass3 komt met 1 instrument type voor
                                                                                                                                                                                        rule
28 The detailed DLAMAssetClass3 categorization should map to one single instrument type (instype_desc).\n\n\nThe instrument type is what is used by FA internally to categorize instruments.
                                                                               condition
28 All instruments which have a DLAMAssetClass3 that occurs with multiple instype_desc's
                                                                             Feedback      rule_load_date
28 Ronald Bark heeft aangegeven dat de regel OK is, maar niet DM verantwoordelijkheid 2016-04-26 16:07:05
            source_file
28 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   query
28 SELECT DISTINCT\r\n\t\t IA.insid\r\n\t\t,IA.DLAMAssetClass3\r\n\t\t,IA.instype_desc\r\n\t\t,IA.exp_day\r\nFROM\r\n\t(SELECT \r\n       COUNT(DISTINCT [instype_desc]) AS CountInsType\r\n      ,[DLAMAssetClass3]\r\n\tFROM [AM_AdsP].[dbo].[INSTRUMENT_ADDITIONAL]\r\n\tWHERE in_scope = 1\r\n\tGROUP BY DLAMAssetClass3\r\n\tHAVING COUNT(DISTINCT [instype_desc]) > 1) \r\n\tAS IT\r\nLEFT JOIN [AM_AdsP].[dbo].[INSTRUMENT_ADDITIONAL] IA\r\n\tON IA.DLAMAssetClass3 = IT.DLAMAssetClass3\r\n\tWHERE in_scope = 1
   superset_query
28               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
29 BU Delta Lloyd Asset Management FrontArena FA_0040 instrument ValidRange       NEED      Input       2015-06-12
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
29 Mid Office Thijs van den Dries   2015-07-16               <NA>   EXPIRATION
                                              datasource referencedata
29 FA_Derivatives_P_20150818.csv, FA_Loan_P_20150818.csv              
                                                   en                                              nl
29 The Expiration date should be after the start date De eind datum dient na de begin datum te liggen
                                                                                                                                                                                                                                                                                                                     rule
29 The fa_loan export does not contain an expiration date, just maturity dates.\n\n\nThe fa_deriv export does not make a distinction between expiration date and maturity date.\n\n\nTherefore Expiration date is not assumed to be filled only in certain cases.\n\n\nIt is always filled, and should be after StartDate
                                                                       condition Feedback      rule_load_date
29 All instruments which have an Expiration Date which is earlier than StartDate          2016-04-26 16:07:05
            source_file
29 frontarena_rules.csv
                                                                                                                                                              query
29 select distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid,\r\n\t[ISSUE_DATE],\r\n\tExpiration\r\nfrom\r\n\tvx_FA_instrument\r\nwhere\r\n\tExpiration <= ISSUE_DATE
   superset_query
29               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
30 BU Delta Lloyd Asset Management FrontArena FA_0041 instrument ValidRange       NEED      Input       2015-06-12
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements                            datasource
30 Mid Office Thijs van den Dries   2015-07-16               <NA>         Type DLDerivativesReportRisk2015-08-18.csv
   referencedata                                                          en
30               All swap instruments should have Payer or Receiver as type.
                                                                   nl
30 Alle swap instrumenten dienen Payer of Receiver als type te hebben
                                                                                           rule
30 All instruments with UnderlyingType equal to Swap should either be marked payer or receiver.
                                                                                                   condition Feedback
30 All instruments with UnderlyingType equal to Swap\n\n\nand CallOrPut neither equal to Payer nor Receiver.         
        rule_load_date          source_file
30 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                         query
30 SELECT  distinct[Instrument] as insid\r\n      ,[Portfolio]\r\n      ,[InstrumentType]\r\n\t  ,[CallOrPut]\r\n\t  ,[UnderlyingType]\r\nFROM [fa_derivreport]\r\nWHERE \r\n\t[UnderlyingType]='Swap' \r\n\tand CallOrPut!='Payer' \r\n\tand CallOrPut!='Receiver'
   superset_query
30               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
31 BU Delta Lloyd Asset Management FrontArena FA_0042 instrument ValidRange       NEED      Input       2015-06-12
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements                            datasource
31 Mid Office Thijs van den Dries   2015-07-16               <NA>         Type DLDerivativesReportRisk2015-08-18.csv
   referencedata                                                            en
31               All Option instruments should have Payer or Receiver as type.
                                                                     nl
31 Alle Option instrumenten dienen Payer of Receiver als type te hebben
                                                                                             rule
31 All instruments with InstrumentType equal to Option should either be marked payer or receiver.
                                                                                                    condition Feedback
31 All instruments with InstrumentType equal to Option\n\n\nand CallOrPut neither equal to Payer nor Receiver         
        rule_load_date          source_file
31 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                            query
31 SELECT  distinct [Instrument] as insid\r\n      ,[Portfolio]\r\n      ,[InstrumentType]\r\n\t  ,[CallOrPut]\r\n\t  ,[UnderlyingType]\r\nFROM [fa_derivreport]\r\nWHERE \r\n\t[InstrumentType]='Option' \r\n\tand CallOrPut!='Payer' \r\n\tand CallOrPut!='Receiver'
   superset_query
31               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
32 BU Delta Lloyd Asset Management FrontArena FA_0043 instrument ValidRange       NEED      Input       2015-06-12
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements                            datasource
32 Mid Office Thijs van den Dries   2015-07-16               <NA>         Type DLDerivativesReportRisk2015-08-18.csv
   referencedata                                                            en
32               PayFloatRateRef is not filled for instruments with type Payer
                                                                nl
32 De PayFloatRateRef is not gevuld for instruments van type Payer
                                                                                                                                                                       rule
32 All instruments having an OptionType being Payer or Receiver, should have \n\n\nPayFloatRateRef empty when it is Payer,\n\n\nPayFloatRateRef filled when it is Receiver.
                                                                                                                   condition
32 All instruments with a filled OptionType (the Payer/Receiver)\n\n\nand not OptionType Payer and empty PayFloatRateRef\n\n
   Feedback      rule_load_date          source_file
32          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                  query
32 SELECT distinct\r\n\t   [Instrument] as insid\r\n      ,[Portfolio]\r\n      ,[InstrumentType]\r\n\t  ,CallOrPut\r\n\t  ,PayFloatRateRef\r\nFROM [fa_derivreport]\r\nWHERE \r\n\tCallOrPut ='Payer'\r\n\tand (PayFloatRateRef != '' or PayFloatRateRef is not NULL)\r\nORDER BY CallorPut
   superset_query
32               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
33 BU Delta Lloyd Asset Management FrontArena FA_0044 instrument ValidRange       NEED      Input       2015-06-12
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements                            datasource
33 Mid Office Thijs van den Dries   2015-07-16               <NA>         Type DLDerivativesReportRisk2015-08-18.csv
   referencedata                                                           en
33               PayFloatRateRef is filled for instruments with type Receiver
                                                               nl
33 De PayFloatRateRef is gevuld for instruments van type Receiver
                                                                                                                                                                       rule
33 All instruments having an OptionType being Payer or Receiver, should have \n\n\nPayFloatRateRef empty when it is Payer,\n\n\nPayFloatRateRef filled when it is Receiver.
                                                                                                               condition
33 All instruments with a filled OptionType (the Payer/Receiver)\n\n\nnot OptionType Receiver and filled PayFloatRateRef
   Feedback      rule_load_date          source_file
33          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                  query
33 SELECT distinct\r\n\t   [Instrument] as insid\r\n      ,[Portfolio]\r\n      ,[InstrumentType]\r\n\t  ,CallOrPut\r\n\t  ,PayFloatRateRef\r\nFROM [fa_derivreport]\r\nWHERE \r\n    CallOrPut='Receiver'\r\n\tand (PayFloatRateRef = '' or PayFloatRateRef is NULL)\r\nORDER BY CallorPut
   superset_query
33               
                                BU     system      BR entitytype      Depth Importance           ErrorCause
34 BU Delta Lloyd Asset Management FrontArena FA_0045   currency ValidRange       NEED Export Configuration
   modificationDate      ruleOwner    approvedBy approvedDate resultApprovalDate dataelements
34       2015-06-12 Valuation Desk Ilona Balvert   2015-08-13               <NA>       FXRATE
                                              datasource referencedata
34 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                                     en
34 The FXRate is defined with 9 decimals precision (FrontArena exports)
                                                                                  nl
34 De FXRate dient met 9 decimale posities gedefinieerd te zijn (FrontArena exports)
                                                                                                                                                                                                             rule
34 The FXRates are downloaded from Bloomberg, and available in FA, with a precision of 9 decimals.\n\n\nThis precision should be used everywhere\n\n\nThe only exception is EUR, which should always be exactly 1
                                                                                                                                 condition
34 All currencies defined with an fxrate which does not change when rounded to 8 decimal places, except for the currency EUR with fxrate 1
   Feedback      rule_load_date          source_file
34          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                  query
34 select distinct\r\n\tfxid,\r\n\tROUND(FXRate,9) as rounded,\r\n\tFXRATE,\r\n\tsource_file, \r\n\tsource_date,\r\n\tCURRENCY,\r\n\tproddat\r\nfrom\r\n\tvx_FA_currency\r\nwhere\r\n\tROUND(FXRate,9)=FXRate\r\n\tand (fxid!='EUR' or FXRate!=1)
   superset_query
34               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
35 BU Delta Lloyd Asset Management FrontArena FA_0046 instrument ValidRange       NEED      Input       2015-06-17
         ruleOwner  approvedBy approvedDate resultApprovalDate                             dataelements
35 Data Management Ronald Bark   2015-08-10               <NA> DLAM.Sector1, DLAM.Sector2, DLAM.Sector3
                                                            datasource        referencedata
35 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv dlam_sector_tree.csv
                                    en                                                                      nl
35 DLAM Sector matches the sector tree De dlam sector 1, 2 en 3 moeten beschikbaar zijn in de dlam sector tree
                                                                                                                                                                                                                                                                     rule
35 A tree of DLAM sectors is defined, mapping each value to a single specific value for one abstraction higher.\nAll found combinations of Dlam sector 1 (the highest abstraction) till 4 (the lowest abstraction) should be available in the predefined sector hierarchy
                                                                                                                  condition
35 Instruments with the combination of DLAMSector 1,2,3,4 \nnot available in all allowed combinations of DLAMSector 1,2,3,4
   Feedback      rule_load_date          source_file
35          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    query
35 SELECT  distinct\r\n\tinstr.source_date,\r\n\tinstr.source_file,\r\n      [insid]\r\n      ,[db_instype_desc]\r\n      ,[DLAMSector1]\r\n      ,[DLAMSector2]\r\n      ,[DLAMSector3]\r\n\t  ,[DLAMSector4]\r\n  FROM SourceData.dbo.vx_FA_instrument_twice as instr\r\n  left join\r\n\tSourceData.dbo.valuerange_sector as def\r\n\ton instr.DLAMSector1 = def.DLSector1 COLLATE DATABASE_DEFAULT\r\n\tand instr.DLAMSector2 = def.DLSector2 COLLATE DATABASE_DEFAULT\r\n\tand instr.DLAMSector3 = def.DLSector3 COLLATE DATABASE_DEFAULT\r\n\tand instr.DLAMSector4 = def.DLSector4 COLLATE DATABASE_DEFAULT\r\nwhere\r\n\tdef.DLSector1 is null -- equals to no match found
   superset_query
35               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
36 BU Delta Lloyd Asset Management FrontArena FA_0047 instrument ValidRange       NEED      Input       2015-06-17
   ruleOwner              approvedBy approvedDate resultApprovalDate dataelements
36       FRM Fred Schulte Fischedick   2015-08-13               <NA>  DLAM.RATING
                                                            datasource referencedata
36 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv ratingmap.csv
                                             en                                                         nl
36 The DLAM rating is one of the allowed values De DLAM Rating dient 1 van de toegestane waarden te hebben
                                                                                  rule
36 The DLAM rating is described by NR (no rating) or one as available in ratingmap.csv
                                                                      condition Feedback      rule_load_date
36 instruments with a dlam rating != NR \n    and not existing in the ratingmap          2016-04-26 16:07:05
            source_file
36 frontarena_rules.csv
                                                                                                                                                                                                                                                                                    query
36 SELECT  distinct\r\n\tsource_date,\r\n\tsource_file,\r\n      [insid]\r\n\t  ,instr.DLAMRating\r\nFROM vx_FA_instrument_twice instr\r\nwhere\r\n\tDLAMRating != 'NR'\r\n\tand DLAMRating not in (select DLAMRating COLLATE DATABASE_DEFAULT from map_ratings where DLAMRating is not NULL) 
   superset_query
36               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
37 BU Delta Lloyd Asset Management FrontArena FA_0048 instrument ValidRange       NEED      Input       2015-06-17
         ruleOwner  approvedBy approvedDate resultApprovalDate                         dataelements
37 Data Management Ronald Bark   2015-08-10               <NA> DLAM.Asset.Type.2, DLAM.Asset.Type.3
                                                            datasource             referencedata
37 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv dlam_asset_class_tree.csv
                                        en                                                              nl
37 DLAM Asset type matches asset type tree De asset type 2 en 3 moeten beschikbaar zijn in asset type tree
                                                                                                                                                                                                                                                                                 rule
37 A tree of DLAM Asset types is defined, mapping each value to a single specific value for one abstraction higher.\nAll found combinations of Dlam asset type 1 (the highest abstraction) till 4 (the lowest abstraction) should be available in the predefined asset type hierarchy
                                                                                                                          condition
37 Instruments with the combination of DLAMAsset type 1,2,3,4 \nnot available in all allowed combinations of DLAMAsset type 1,2,3,4
   Feedback      rule_load_date          source_file
37          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       query
37 SELECT  distinct\r\n\t\tinstr.source_date,\r\n\t\tinstr.source_file,\r\n\t\t[insid],\r\n\t\tinstr.DLAMAssetClass1,\r\n\t\tinstr.DLAMAssetClass2,\r\n\t\tinstr.DLAMAssetClass3,\r\n\t\tinstr.DLAMAssetClass4\r\nFROM vx_FA_instrument_twice instr\r\n\tleft join\r\n\tvaluerange_assetclass as def\r\n\ton instr.DLAMAssetClass1 = def.DLAMAssetClass1 collate SQL_Latin1_General_CP1_CI_AS\r\n\tand instr.DLAMAssetClass2 = def.DLAMAssetClass2 collate SQL_Latin1_General_CP1_CI_AS\r\n\tand instr.DLAMAssetClass3 = def.DLAMAssetClass3 collate SQL_Latin1_General_CP1_CI_AS\r\n\tand instr.DLAMAssetClass4 = def.DLAMAssetClass4 collate SQL_Latin1_General_CP1_CI_AS\r\nwhere\r\n\tdef.DLAMAssetClass1 is null -- equals to no match found
   superset_query
37               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
38 BU Delta Lloyd Asset Management FrontArena FA_0049 instrument ValidRange       NEED      Input       2015-06-17
         ruleOwner  approvedBy approvedDate resultApprovalDate                             dataelements
38 Data Management Ronald Bark   2015-09-22               <NA> DLAM.Sector1, DLAM.Sector2, DLAM.Sector3
                                                            datasource referencedata
38 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                                                                                                              en
38 For instruments with DLAM AssetClass2 equal to Bond, Fixed Income Derivative or FX Derivative should have a sector assigned, which is not '-'
                                                                                                                                                                           nl
38 Voor instrumenten met DLAM AssetClass2 dat gelijk is aan Bond, Fixed Income Derivative of FX Derivative dienen aan een sector te worden toegekend, wat ongelijk is aan '-'
                                                                                                                                                                               rule
38 For instruments with DLAM AssetClass2 equal to Bond, Fixed Income Derivative or FX Derivative which can have a sector assigned should have a sector assigned, different from '-'
                                                                                                                      condition
38 All instruments which have DLAMAssetClass2 IN ('Bond', 'Fixed income derivative', 'FX derivative') and who have a sector='-'
   Feedback      rule_load_date          source_file
38          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                       query
38 SELECT  distinct\r\n\tsource_date,\r\n\tsource_file,\r\n      [insid]\r\n      ,[db_instype_desc]\r\n      ,[DLAMSector1]\r\n      ,[DLAMSector2]\r\n      ,[DLAMSector3]\r\n\t  ,DLAMAssetClass1\r\n\t  ,DLAMAssetClass2\r\n  FROM vx_FA_instrument_twice instr\r\nwhere\r\n\t-- the subset\r\n\tDLAMAssetClass2 IN ('Bond', 'Fixed income derivative', 'FX derivative')\r\n\t-- the failing attributes\r\n\tand DLAMSector1='-'
   superset_query
38               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
39 BU Delta Lloyd Asset Management FrontArena FA_0050   currency HasValue       NEED      Input       2015-06-17
        ruleOwner    approvedBy approvedDate resultApprovalDate dataelements
39 Valuation Desk Ilona Balvert   2015-08-13               <NA>       FXRATE
                                              datasource referencedata               en              nl
39 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Nonempty fx rate Gevulde fx rate
                                                        rule                                   condition Feedback
39 All instruments should have a defined, non empty, fx rate Instruments with fxrate equal to NULL or ''         
        rule_load_date          source_file
39 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                       query
39 select distinct\r\n\tfxid,\r\n\tFXRATE,\r\n\tsource_file, \r\n\tsource_date,\r\n\tCURRENCY,\r\n\tproddat\r\nfrom\r\n\tvx_FA_currency\r\nwhere\r\n\tFXRate=0\r\n\tor FXRate is NULL
   superset_query
39               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
40 BU Delta Lloyd Asset Management FrontArena FA_0051   currency ValidRange       NEED      Input       2015-06-17
        ruleOwner    approvedBy approvedDate resultApprovalDate dataelements
40 Valuation Desk Ilona Balvert   2015-08-13               <NA>       FXRATE
                                              datasource referencedata                                        en
40 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               The FX rate needs to be strictly positive
                                      nl                                                               rule
40 De fx rate dient groter dan 0 te zijn Currencies have a fx rate, which needs to be non zero and positive
                     condition Feedback      rule_load_date          source_file
40 Currencies with fxrate <= 0          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                  query
40 select distinct\r\n\tfxid,\r\n\tFXRATE,\r\n\tsource_file, \r\n\tsource_date,\r\n\tCURRENCY,\r\n\tproddat\r\nfrom\r\n\tvx_FA_currency\r\nwhere\r\n\tFXRate<=0
   superset_query
40               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
41 BU Delta Lloyd Asset Management FrontArena FA_0052   currency ValidRange       NEED      Input       2015-06-17
        ruleOwner    approvedBy approvedDate resultApprovalDate dataelements
41 Valuation Desk Ilona Balvert   2015-08-13               <NA>       FXRATE
                                              datasource referencedata
41 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                     en                                         nl
41 The FX rate needs to be constant per currency symbol De fx rate dient constant te zijn per munt
                                                          rule
41 One currency can only have one fx rate (on a specific date)
                                                                                  condition Feedback
41 Currencies and fx rates grouped by currency symbol\n  having more than 1 distinct fxrate         
        rule_load_date          source_file
41 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              query
41 select distinct\r\n\tdetails.fxid,\r\n\tnum_fxrates,\r\n\tdetails.proddat,\r\n\tdetails.source_file,\r\n\tdetails.source_date,\r\n\tdetails.FXRATE\r\n\r\n, insid as instrument\r\nfrom (\r\n\tselect\r\n\t\tc.fxid,\r\n\t\tc.proddat,\r\n\t\tcount(distinct(c.FXRATE)) as num_fxrates\r\n\tfrom\r\n\t\tvx_FA_currency c\r\n\t\tINNER JOIN vx_FA_instrument i\r\n\t\t\tON c.fxid = i.CURRENCY\r\n\t\t\tand c.fxrate = i.fxrate \r\n\t\t\tand c.source_file = i.source_file\r\n\t\t\tLEFT JOIN FA_whitelist w\r\n\t\t\t\tON i.insid = w.insid\r\n\t\t\t\tAND w.BR = 'FA_0052'\r\n\tWHERE w.BR IS NULL\r\n\tgroup by\r\n\t\tc.fxid, c.proddat\r\n\thaving\r\n\t\tcount(distinct(c.FXRATE)) > 1\r\n\t) as errors\r\n\tleft join vx_FA_currency as details\r\n\ton errors.fxid = details.fxid\r\n\tand errors.proddat = details.proddat\r\n\tleft join (SELECT distinct insid, currency, fxrate, source_file FROM vx_FA_instrument\r\n\t\t\t\tunion all\r\n\t\t\t\tSELECT  distinct InstrumentName, currency, dispfx as fxrate, source_file FROM FA_deriv ) i\r\n\t\tON i.currency = details.currency\r\n\t\t\tand i.fxrate = details.fxrate \r\n\t\t\tand i.source_file = details.source_file\r\n\r\n
   superset_query
41               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
42 BU Delta Lloyd Asset Management FrontArena FA_0053 instrument ValidRange       NEED      Input       2015-06-12
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
42 Mid Office Thijs van den Dries   2015-07-16               <NA>     CURRENCY
                                                             datasource referencedata
42 FrontArenaDb,  FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                              en
42 Instruments should have currencies of 3 upper case characters
                                                        nl
42 Instrumenten hebben een munt symbool van 3 hoofdletters
                                                                       rule
42 A currency symbol should always be 3 characters which are all upper case
                                                               condition Feedback      rule_load_date
42 Instruments with \n  stringlength munt != 3\n  or upper(MUNT) != MUNT          2016-04-26 16:07:05
            source_file
42 frontarena_rules.csv
                                                                                                                                                                                                                                                                   query
42 SELECT   distinct\r\n\t\tsource_date,\r\n\t\tsource_file,\r\n\t\t[insid]\r\n\t\t,CURRENCY\r\nFROM vx_FA_instrument_twice\r\nWHERE \r\n  LEN(RTRIM(CURRENCY)) != 3 -- invalid id\r\n  or UPPER(CURRENCY) COLLATE Latin1_General_CS_AS != CURRENCY COLLATE Latin1_General_CS_AS
   superset_query
42               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
43 BU Delta Lloyd Asset Management FrontArena FA_0054 instrument ValidRange       NEED      Input       2015-06-17
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
43 Mid Office Thijs van den Dries   2015-07-16               <NA>     MATURITY
                                                            datasource referencedata
43 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                 en                                                  nl
43 The Maturity date should be after the start date De maturity datum dient na de begin datum te liggen
                                                                                                                                                                                                                                                                                                                     rule
43 The fa_loan export does not contain an expiration date, just maturity dates.\n\n\nThe fa_deriv export does not make a distinction between expiration date and maturity date.\n\n\nTherefore Expiration date is not assumed to be filled only in certain cases.\n\n\nIt is always filled, and should be after StartDate
                                                                    condition Feedback      rule_load_date
43 All instruments which have a Maturity Date which is earlier than StartDate          2016-04-26 16:07:05
            source_file
43 frontarena_rules.csv
                                                                                                                                                                query
43 select distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid,\r\n\t[ISSUE_DATE],\r\n\tMATURITY\r\nfrom\r\n\tvx_FA_instrument_twice\r\nwhere\r\n\tMATURITY <= ISSUE_DATE
   superset_query
43               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
44 BU Delta Lloyd Asset Management FrontArena FA_0055 instrument HasValue       NEED      Input       2015-06-30
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
44 Mid Office Thijs van den Dries   2015-07-16               <NA>       COUPON
                                              datasource referencedata                                en
44 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Nonempty numeric coupon for loans
                             nl                                    rule
44 Gevulde coupon voor leningen All loans should have a defined coupon.
                                                                                         condition Feedback
44 Instruments with coupon equal to NULL and  DLAMAssetClass2 one of LIC, Bond, Other Fixed Income         
        rule_load_date          source_file
44 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                query
44 SELECT distinct\r\n\tinsid,\r\n    COUPON,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2\r\nFROM\r\n    vx_FA_instrument\r\nWHERE\r\n\tDLAMAssetClass2 in ('LIC', 'Bond', 'Other Fixed Income')\r\n    and COUPON is NULL
   superset_query
44               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
45 BU Delta Lloyd Asset Management FrontArena FA_0056 instrument HasValue       NEED      Input       2015-06-30
    ruleOwner          approvedBy approvedDate resultApprovalDate dataelements
45 Mid Office Thijs van den Dries   2015-07-16               <NA>       COUPON
                                              datasource referencedata                                           en
45 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               FX Swaps and Swaptions should have no coupon
                                                   nl                                                             rule
45 FX Swaps en swaptions dienen geen coupon te hebben In front arena FX Swaps and swaptions should not have a coupon. 
                                                                                       condition Feedback
45 Instruments with coupon not equal to NULL and  \n  DLAMAssetClass3 in ('FX Swap', 'Swaption')         
        rule_load_date          source_file
45 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                query
45 SELECT distinct\r\n\tinsid,\r\n    COUPON,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nFROM\r\n    vx_FA_instrument\r\nWHERE\r\n\tDLAMAssetClass3 in ('FX Swap', 'Swaption')\r\n    and COUPON is not NULL\r\n\t
   superset_query
45               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate
46 BU Delta Lloyd Asset Management FrontArena FA_0057 instrument HasValue       NEED      Input       2015-06-30
    ruleOwner     approvedBy approvedDate resultApprovalDate dataelements
46 Mid Office Kristine Prahl   2015-08-12               <NA>       COUPON
                                              datasource referencedata                                 en
46 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               No coupon for FX rate and swaption
                                     nl
46 Geen coupon voor FX rate en swaption
                                                                                   rule
46 Coupons are not applicable to FX rates and swaption, and therefore should not exist.
                                                                                     condition Feedback
46 Instruments with\n   DLAMAssetClass2 IN ('FX Swap' , 'Swaption')\n   and coupon is not null         
        rule_load_date          source_file
46 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                       query
46 select distinct\r\n\tinsid\r\n\t, COUPON\r\n\t, DLAMAssetClass1\r\n\t, DLAMAssetClass2\r\n\t, DLAMAssetClass3\r\n\t, DLAMAssetClass4\r\nfrom\r\n\tvx_FA_instrument\r\nwhere\r\n\t-- the subset for which the requirement holds\r\n\tDLAMAssetClass3 IN ('FX Swap' , 'Swaption')\r\n\t-- the ones failing the requirement\r\n\tand coupon is not null
   superset_query
46               
                                BU     system      BR entitytype          Depth Importance ErrorCause modificationDate
47 BU Delta Lloyd Asset Management FrontArena FA_0059 instrument SelfConsistent       NEED      Input       2015-06-30
    ruleOwner     approvedBy approvedDate resultApprovalDate dataelements
47 Mid Office Kristine Prahl   2015-08-12               <NA>       COUPON
                                              datasource referencedata
47 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                                               en
47 Bonds (/LOS) with zero coupon should have the coupon 0.00 in the security name
                                                                          nl
47 Obligaties zonder coupon dienen de coupon 0.00 in de naam te hebben staan
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                rule
47 bonds (/LOS) with a 0 couponrate should have that coupon explicitly in the security name except for Floating rate notes. Floating rate notes should have no coupon in its description.\n\n\nVerified relation: (Zero coupon & is Bond) =>  There is a coupon of zero in description\nNote that the focus for this relation is that a coupon of zero should be in the name where only Floating Rate Notes are allowed to have no description to implicitly indicate a zero coupon.
                                                                                                                                                                                           condition
47 All instruments with\n-DLAMAssetClass1='Fixed Income' \n-COUPON==0\n\n\n- DLAMAssetClass3!='Floating Rate Note'\n-no coupon in the securityname or a coupon not equal to zero in the securityname
   Feedback      rule_load_date          source_file
47          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                query
47 select distinct\r\n\tinsid,\r\n\tCOUPON,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tIDENTIFIER_Coupon,\r\n\tIDENTIFIER_CouponNum,\r\n\tIDENTIFIER\r\nfrom vx_FA_instrument\r\nwhere\r\n\t-- the zero coupon bonds that should have zero coupon in the description\r\n\tDLAMAssetClass1='Fixed Income' \r\n\tand COUPON=0\r\n\tand DLAMAssetClass3!='Floating Rate Note'\r\n\t-- the ones not having a coupon in the description, or the wrong one\r\n\tand (len(IDENTIFIER_Coupon)=0 or IDENTIFIER_CouponNum!=0)\r\n
   superset_query
47               
                                BU     system      BR entitytype          Depth Importance ErrorCause modificationDate
48 BU Delta Lloyd Asset Management FrontArena FA_0060 instrument SelfConsistent       NEED      Input       2015-06-30
    ruleOwner     approvedBy approvedDate resultApprovalDate dataelements
48 Mid Office Kristine Prahl   2015-08-12               <NA>       COUPON
                                              datasource referencedata
48 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                                              en
48 Bonds (/LOS) with nonzero coupon should have that coupon in the security name
                                                                   nl
48 Obligaties met coupon dienen die coupon in de naam te hebben staan
                                                                                                                                                                                                                                                                                                                    rule
48 bonds (/LOS) with a nonzero couponrate should have that coupon explicitly in the name, except for Floating rate and fixed to floaters.\nVerified relation: (Nonzero coupon & is Bond) =>  The same coupon in name\nNote that the focus for this relation is that a coupon of nonzero should be explicitly in the name
                                                                                                                                                                                                                             condition
48 All instruments with\n-DLAMAssetClass1='Fixed Income'  \n\n\n-COUPON!=0\n\n\n- DLAMAssetClass3!='Floating Rate Note'\n- DLAMAssetClass3!='Fixed to floater'\n-no coupon in the name or a coupon not equal to the COUPON in the name
   Feedback      rule_load_date          source_file
48          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           query
48 select  distinct\r\n\tinsid,\r\n\tCOUPON,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tIDENTIFIER_Coupon,\r\n\tIDENTIFIER_CouponNum,\r\n\tIDENTIFIER\r\nfrom vx_FA_instrument\r\nwhere\r\n\t-- the nonzero coupon bonds that should have that coupon in the description\r\n\tDLAMAssetClass1='Fixed Income'\r\n\t--and COUPON!=0\r\n\tand DLAMAssetClass3 not in ('Floating Rate Note', 'Fix to Floater', 'Inflation Linked Swap') --same set as used in FA_0061\r\n\t-- where the description doesn't match the couponrate\r\n\tand IDENTIFIER_CouponNum!=COUPON
   superset_query
48               
                                BU     system      BR entitytype          Depth Importance ErrorCause modificationDate
49 BU Delta Lloyd Asset Management FrontArena FA_0061 instrument SelfConsistent       NEED      Input       2015-06-30
    ruleOwner     approvedBy approvedDate resultApprovalDate dataelements
49 Mid Office Kristine Prahl   2015-08-12               <NA>       COUPON
                                              datasource referencedata
49 FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                      en
49 Floating rate bonds should have no coupon in the name
                                                                        nl
49 Floating rate obligaties dienen geen coupon in hun naam te hebben staan
                                                                                                                                                                                                                                                                                                                                                                                           rule
49 Floating rate notes should have no coupon in its name\nIf there is a coupon in its description it should be 0, or the coupon should be equal to the actual used couponrate\nVerified relation: (Floating rate note)=>(No coupon in the Description)\nFA_0060 expects for all but some assetclasses a coupon in the name, this rule verfies that those 'some' never have a coupon in the name
                                                                                                                                                                                                                         condition
49 All instruments with\n-DLAMAssetClass1='Fixed Income'  \n- DLAMAssetClass3='Floating Rate Note' or  'Fixed to floater' or 'Inflation Linked Swap'\n-and a coupon in the description\n-description coupon != coupon, or coupon=0
   Feedback      rule_load_date          source_file
49          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
49 select distinct\r\n\tinsid,\r\n\tCOUPON,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tIDENTIFIER_Coupon,\r\n\tIDENTIFIER_CouponNum,\r\n\tIDENTIFIER\r\nfrom SourceData.dbo.vx_FA_instrument\r\nwhere\r\n\t-- the bonds that should not have a coupon in the description\r\n\tDLAMAssetClass1='Fixed Income'\r\n\tand DLAMAssetClass3 in ('Floating Rate Note', 'Fix to Floater', 'Inflation Linked Swap') --same set as used in FA_0060\r\n\t-- the ones having a coupon in the description\r\n\tand len(IDENTIFIER_Coupon) > 0 \r\n\tand (COUPON!=IDENTIFIER_CouponNum or COUPON=0)\r\n
   superset_query
49               
                                BU     system      BR entitytype      Depth Importance           ErrorCause
50 BU Delta Lloyd Asset Management FrontArena FA_0062 instrument ValidRange       NEED Export Configuration
   modificationDate  ruleOwner     approvedBy approvedDate resultApprovalDate dataelements
50       2015-06-30 Mid Office Kristine Prahl   2015-08-12               <NA>     CURRENCY
                                                             datasource                referencedata
50 FrontArenaDb,  FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv exchangerates_2014_09_29.csv
                                                                                   en
50 Instruments have one of the available currencies, available in FA (except for CDS)
                                                                                              nl
50 Instrumenten hebben een van de beschikbare munt symbolen, beschikbaar in FA. (Except for CDS)
                                                                                                                                               rule
50 A currency symbol should always be one of the available/known currencies.\nThe available currencies are taken from the same system (Front Arena)
                                                            condition Feedback      rule_load_date          source_file
50 Instruments with\n  munt not in any symbol of exchangerates export          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                            query
50 select distinct\r\n\tinsid\r\n\t,CURRENCY\r\nfrom\r\n\tvx_FA_instrument_twice\r\nwhere\r\n\tCURRENCY not in (select fxid COLLATE Latin1_General_CI_AS  from FA_exchangerates) \r\n
   superset_query
50               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
51 BU Delta Lloyd Asset Management FrontArena FA_0063   currency ValidRange       NEED      Input       2015-06-30
    ruleOwner     approvedBy approvedDate resultApprovalDate dataelements
51 Mid Office Kristine Prahl   2015-08-12               <NA>     CURRENCY
                                                             datasource referencedata
51 FrontArenaDb,  FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                       en                                nl
51 Currencies are 3 upper case characters Munt symbolen zijn 3 hoofdletters
                                                                       rule
51 A currency symbol should always be 3 characters which are all upper case
                                                              condition Feedback      rule_load_date
51 currencies with \n  stringlength munt != 3\n  or upper(MUNT) != MUNT          2016-04-26 16:07:05
            source_file
51 frontarena_rules.csv
                                                                                                                                                                                          query
51 select distinct\r\n\tfxid\r\n\t,CURRENCY\r\nfrom\r\n\tvx_FA_currency\r\nwhere\r\n\tlen(CURRENCY)!=3\r\n\tor UPPER(CURRENCY) COLLATE Latin1_General_CS_AS != CURRENCY COLLATE Latin1_General_CS_AS
   superset_query
51               
                                BU     system      BR entitytype      Depth Importance           ErrorCause
52 BU Delta Lloyd Asset Management FrontArena FA_0064   currency ValidRange       NEED Export Configuration
   modificationDate  ruleOwner     approvedBy approvedDate resultApprovalDate dataelements
52       2015-06-30 Mid Office Kristine Prahl   2015-08-12               <NA>     CURRENCY
                                                             datasource                referencedata
52 FrontArenaDb,  FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv exchangerates_2014_09_29.csv
                                                             en
52 Currency is one of the available currencies, available in FA
                                                                       nl
52 Het munt symbool is een van de beschikbare symbolen, beschikbaar in FA
                                                                                                                              rule
52 A currency symbol should always be one of the available/known currencies.\nThe available currencies are taken from Front Arena.
                                                           condition Feedback      rule_load_date          source_file
52 currencies with\n  munt not in any symbol of exchangerates export          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                            query
52 select distinct\r\n\tfxid\r\n\t,CURRENCY\r\nfrom\r\n\tSourceData.dbo.vx_FA_currency\r\nwhere\r\n\tCURRENCY not in (select fxid COLLATE Latin1_General_CI_AS  from SourceData.dbo.FA_exchangerates)
   superset_query
52               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate
53 BU Delta Lloyd Asset Management FrontArena FA_0065 instrument ValidRange       NEED      Input       2015-06-30
         ruleOwner  approvedBy approvedDate resultApprovalDate      dataelements
53 Data Management Ronald Bark   2015-08-10               <NA> DLAM.Asset.Type.2
                                                             datasource referencedata                     en
53 FrontArenaDb,  FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Nontrivial asset class
                          nl                                                 rule
53 Niet triviale asset class All instruments should have an asset class assigned.
                                               condition Feedback      rule_load_date          source_file
53 All instruments which have \n and DLAMAssetClass2='-'          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                         query
53 select distinct\r\n\tinsid,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2\r\nfrom\r\n\tvx_FA_instrument_twice\r\nwhere\r\n\tDLAMAssetClass2='-'\r\n
   superset_query
53               
                                BU     system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
54 BU Delta Lloyd Asset Management FrontArena FA_0066 instrument SelfConsistent       NICE      Input       2015-06-30 Data Management Ronald Bark   2015-08-10
   resultApprovalDate                         dataelements                                                          datasource                      referencedata
54               <NA> DLAM.Asset.Type.2, DLAM.Asset.Type.3 FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv whitelist_assetclass_dbinstype.csv
                                                                       en                                                                                    nl
54 Only whitelisted combinations of Asset class and db_instype_desc occur Alleen verwachte combinaties van Asset class en db_instype_desc dienen voor te komen.
                                                                                                                                                                                                                                        rule
54 Only whitelisted combinations of Asset class and db_instype_desc occur. The db_insype_desc is the instrument type descriptio nin the database.\nVerified relation db_instype_desc <=> (DLAMAssetClass1, DLAMAssetClass2, DLAMAssetClass3)
                                                                                                                          condition Feedback      rule_load_date
54 All instruments that \n\n\nhave a combination of DLAMAssetClass1, 2 and 3 and the db_instype_desc\nwhich is not on the whitelist          2016-04-26 16:07:05
            source_file
54 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
54 select   distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid, \r\n    DLAMAssetClass1 , \r\n    DLAMAssetClass2 , \r\n    DLAMAssetClass3 , \r\n    db_instype_desc,\r\n\t-- Get string concatenated value of all Sector2NoCountries which are allowed with the provided WFT\r\n\treplace(replace(replace((cast((\r\n\tselect distinct DLAMAssetClass3 as X\r\n\tfrom valuewhitelist_assetclass_dbinstype as inner_list\r\n\twhere inner_list.db_instype_desc = instr.db_instype_desc COLLATE Latin1_General_CI_AS\r\n\tfor xml path('')) as varchar(max))), \r\n\t'</X><X>', ', '),'<X>', ''),'</X>','') as allowed_DLAMAssetClass3_with_db_instype_desc,\r\n\r\n\t-- Get string concatenated value of all WFT which are allowed with the provided Sector2NoCountry\r\n\treplace(replace(replace((cast((\r\n\tselect distinct db_instype_desc as X\r\n\tfrom valuewhitelist_assetclass_dbinstype as inner_list\r\n\twhere inner_list.DLAMAssetClass3 = instr.DLAMAssetClass3 COLLATE Latin1_General_CI_AS\r\n\tfor xml path('')) as varchar(max))), \r\n\t'</X><X>', ', '),'<X>', ''),'</X>','') as allowed_db_instype_desc_with_DLAMAssetClass3\r\nFROM \r\n\tvx_FA_instrument_twice instr\r\nwhere\r\n\t-- set in scope\r\n\tDLAMSector1!='' and DLAMSector1!='-' and db_instype_desc is not null\r\n\t-- and not on the whitelist\r\n\tand not exists (\r\n\t\tselect * from valuewhitelist_assetclass_dbinstype wl where \r\n\t\t\twl.DLAMAssetClass1= instr.DLAMAssetClass1 COLLATE Latin1_General_CI_AS\r\n\t\t\tand wl.DLAMAssetClass2 = instr.DLAMAssetClass2 COLLATE Latin1_General_CI_AS\r\n\t\t\tand wl.DLAMAssetClass3 = instr.DLAMAssetClass3 COLLATE Latin1_General_CI_AS\r\n\t\t\tand wl.db_instype_desc = instr.db_instype_desc COLLATE Latin1_General_CI_AS\r\n\t\t)
   superset_query
54               
                                BU     system      BR entitytype           Depth Importance           ErrorCause modificationDate      ruleOwner    approvedBy
55 BU Delta Lloyd Asset Management FrontArena FA_0067   currency OtherConsistent       NEED Export Configuration       2015-06-30 Valuation Desk Ilona Balvert
   approvedDate resultApprovalDate dataelements                                            datasource     referencedata
55   2015-09-15               <NA>       FXRATE FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv exchangerates.csv
                                                  en                                                        nl
55 The FXRate corresponds with portia exported rates De FXRate is gelijk aan de gedetailleerde portia fx rate.
                                                                                                                                                                                                                rule
55 The FXRate should be equal to the closing foreign exchange rate\n\n in portia\nTo have correct FX calculations the full available precision should be used.\n\n\nVerified relation: MUNT => FXRATE.orig == FXRATE
                                                                                                            condition
55 All currencies that have an exchange rate which does not match exactly with the specific exchangerate from portia.
                                                                                                                            Feedback      rule_load_date
55 Should get Fxrates out of portia for same day as the FA exports (resultset now also contains fxrates which could not be compared) 2016-04-26 16:07:05
            source_file
55 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        query
55 select distinct\r\n\t--vx_FA_currency.source_file,: don't display source file, because otherwise it would double the amount of failures\r\n\tvx_FA_currency.source_date,\r\n\tvx_FA_currency.fxid,\r\n\tvx_FA_currency.FXRATE,\r\n\tFA_exchangerates.INV_FXRATE as FXRATE_expected,\r\n\ti.insid as instrument\r\n\t,CONVERT(date,vx_FA_currency.proddat)\r\n\t,CONVERT(date,dateadd(dd,1,vx_FA_currency.proddat))\r\n\t,FA_exchangerates.ReportingDate\r\n\t,FA_exchangerates.*\r\nfrom\r\n\tvx_FA_currency\r\n\tleft join\r\n\t[FA_exchangerates] FA_exchangerates\r\n\t\ton vx_FA_currency.fxid = FA_exchangerates.fxid COLLATE DATABASE_DEFAULT \r\n\t\tand vx_FA_currency.proddat = FA_exchangerates.ReportingDate\r\n\t\r\n\tleft join (SELECT distinct insid, currency, fxrate, source_file FROM vx_FA_instrument\r\n\t\t\t\tunion all\r\n\t\t\t\tSELECT  distinct instrument, currency, dispfx as fxrate, source_file FROM FA_derivreport ) i\r\n\t\tON i.currency = vx_FA_currency.currency\r\n\t\t\tand i.fxrate = vx_FA_currency.fxrate \r\n\t\t\tand i.source_file = vx_FA_currency.source_file\r\nwhere\r\n\tvx_FA_currency.FXRATE != FA_exchangerates.INV_FXRATE\r\n\tor FA_exchangerates.FXRATE is null -- Could not match with FA_exchangerates
   superset_query
55               
 names_orig names_sql_expected names_sql
                             X        V6
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
56 BU Delta Lloyd Asset Management FrontArena FA_0068   currency ValidRange       NEED      Input       2015-06-30 Valuation Desk Ilona Balvert   2015-08-13
   resultApprovalDate dataelements                                            datasource referencedata               en                           nl
56               <NA>       FXRATE FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               EUR has fxrate 1 De FXRate is 1 voor munt EUR
                                                              rule                           condition Feedback      rule_load_date          source_file
56 The FXRate has unit EUR, therefore the EUR should have FXRate 1 The currency EUR , with FXRATE != 1          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                query
56 select distinct\r\n\t--c.source_file: don't display source file, because otherwise it would double the amount of failures\r\n\tsource_date,\r\n\tinsid,\r\n\tfxid,\r\n\tproddat,\r\n\tc.CURRENCY,\r\n\tc.FXRATE\r\nfrom\r\n\tvx_FA_currency c\r\n\tinner join (SELECT distinct insid, currency, fxrate, source_file FROM vx_FA_instrument\r\n\t\t\t\tunion all\r\n\t\t\t\tSELECT  distinct instrument, currency, dispfx as fxrate, source_file FROM FA_derivreport ) i\r\n\t\tON i.currency = c.currency\r\n\t\t\tand i.fxrate = c.fxrate \r\n\t\t\tand i.source_file = c.source_file\r\nwhere\r\n\tc.CURRENCY = 'EUR'\r\n\tand c.FXRATE != 1
   superset_query
56               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate  ruleOwner          approvedBy approvedDate
57 BU Delta Lloyd Asset Management FrontArena FA_0069 instrument HasValue       NEED      Input       2015-06-30 Mid Office Thijs van den Dries   2015-09-29
   resultApprovalDate dataelements                                                          datasource referencedata                               en
57               <NA>   ISSUE_DATE FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               All swaptions have no issue date
                                                nl
57 Alle swaptions horen geen issue date te hebben.
                                                                                                                                                         rule
57 All nonloans (LIC, Bonds and other fixed income's) should not have a defined, non empty, issue date\nVerified relation: is not a Bond => has no Issue Date
                                                                     condition                             Feedback      rule_load_date          source_file
57 Instruments with \n  DLAMAssetClass3 = 'Swaption'\n  and issuedate not NULL Laurent: Issue date vs. Acquire Date 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                query
57 SELECT    distinct\r\n\tsource_file,\r\n\tsource_date,       \r\n    insid,\r\n    DLAMAssetClass1 , \r\n    DLAMAssetClass2 ,\r\n    DLAMAssetClass3 ,\r\n\tISSUE_DATE\r\nFROM vx_FA_instrument_twice\r\nWHERE \r\n\tDLAMAssetClass3 IN ('Swaption')\r\n\tAND ISSUE_DATE IS NOT NULL ;
   superset_query
57               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner          approvedBy approvedDate
58 BU Delta Lloyd Asset Management FrontArena FA_0070 instrument ValidRange       NEED      Input       2015-07-01 Mid Office Thijs van den Dries   2015-09-24
   resultApprovalDate dataelements                                            datasource referencedata
58               <NA>   ISSUE_DATE FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                                              en                                                         nl
58 The issue date needs to fall within T+4 days, excepts for Interest Rate Swaps De issue date dient binnen T+4 te liggen, behalve voor IRS
                                                                                                                                                                                                                                                                                                                                         rule
58 Instruments having an issue date, should have an issue date in the past.\nNewly issued instruments can have an issue date in the future, but these should not exist in the portiatotal export as they have no holding. \nExceptionally there can already be a position ahead of issueing. This will usually not be more than 10 days ahead
                                                   condition                             Feedback      rule_load_date          source_file
58 instruments with\n  issue date > reporting date + 10 days Laurent: Issue date vs. Acquire Date 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                    query
58 select distinct\r\n\tsource_date,\r\n\tsource_file,\r\n\tinsid,\r\n\tISSUE_DATE,\r\n\tproddat,\r\n\tvx_FA_instrument.IDENTIFIER,\r\n\tExpiration,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nfrom\r\n\tvx_FA_instrument\r\nwhere\r\n\tISSUE_DATE > DateAdd(day, 4, proddat)\r\n\tand DLAMAssetClass3!='Interest Rate Swap'
   superset_query
58               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
59 BU Delta Lloyd Asset Management FrontArena FA_0071    holding HasValue       NEED      Input       2015-07-01 Valuation Desk Ilona Balvert   2015-08-13
   resultApprovalDate dataelements                                            datasource referencedata                    en                  nl
59               <NA> MARKET_VALUE FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Nonempty market value Gevulde marktwaarde
                                                                                                                                                                       rule
59 All holdings should have a defined marketvalue\nThe data load scripts parses the value to a numeric value, any non-numeric value like the empty '' will also become NULL
                                    condition Feedback      rule_load_date          source_file
59 Holdings with\n   martket value NULL or ''          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                         query
59 SELECT distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid, \r\n\tprfid,\r\n\tMARKET_VALUE\r\nFROM\r\n    vx_FA_holding\r\nWHERE\r\n    MARKET_VALUE is NULL
   superset_query
59               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
60 BU Delta Lloyd Asset Management FrontArena FA_0072    holding ValidRange       NEED      Input       2015-07-01 Valuation Desk Ilona Balvert   2015-09-15
   resultApprovalDate dataelements                                            datasource referencedata                               en
60               <NA> MARKET_VALUE FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Marketvalue for nonzero quantity
                                           nl                                                                                           rule
60 Marktwaarde bij hoeveelheid ongelijk aan 0 Als de marktwaarde en het aantal ongelijk is aan 0 dan moet de prijs ook ongelijk zijn aan nul
                                                                                                                                                     condition Feedback
60 Holdings where quantity!=0 \n   and ( (marketvalue = 0 and price!=0)\n             or marketvalue!=0 and sign(quantity)*sign(price)!=sign(marketvalue)\n  )         
        rule_load_date          source_file
60 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                         query
60 select distinct\r\n\tvx_FA_holding.source_file,\r\n\tvx_FA_holding.source_date,\r\n\tvx_FA_holding.insid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tPRICE,\r\n\tMARKET_VALUE\r\nfrom\r\n\tvx_FA_holding\r\nwhere\r\n\t-- applicable set\r\n\tQUANTITY != 0\r\n\tAND MARKET_VALUE!=0\r\n\tAND Price=0\r\n-- FB Ilona: Als Quantity en Market value beide 0 zijn moet de prijs ook 0 zijn (maw, uitvallen op prijs =0 in dat geval)
   superset_query
60               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
61 BU Delta Lloyd Asset Management FrontArena FA_0073    holding ValidRange       NEED      Input       2015-07-01 Valuation Desk Ilona Balvert   2015-08-13
   resultApprovalDate dataelements                                            datasource referencedata                                 en
61               <NA> MARKET_VALUE FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Zero marketvalue for zero quantity
                                   nl                                                           rule                                           condition Feedback
61 Geen marktwaarde bij hoeveelheid 0 All holdings with zero quantity  should have zero marketvalue. Holdings where quantity=0 \n   and marketvalue != 0         
        rule_load_date          source_file
61 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                       query
61 select distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tPRICE,\r\n\tMARKET_VALUE\r\nfrom\r\n\tvx_FA_holding\r\nwhere\r\n\t-- applicable set\r\n\tQUANTITY = 0\r\n\t-- failure filter\r\n\tand MARKET_VALUE!=0
   superset_query
61               
                                BU     system      BR entitytype          Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
62 BU Delta Lloyd Asset Management FrontArena FA_0074 instrument SelfConsistent       NEED Definition       2015-06-12 Valuation Desk Ilona Balvert   2015-09-15
   resultApprovalDate        dataelements                                            datasource referencedata
62               <NA> MARKET_VALUE, PRICE FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                                                                              en
62 No small differences between market value and Quantity times clean price (in eur), plus clean accrued intrest
                                                                                                  nl
62 Geen kleine verschillen tussen marktwaarde en hoeveelheid keer prijs (in eur), plus lopende rente
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   rule
62 One whould expect the quantity times the price to be the market value. \n\n\nHowever the definition of 'MW incl LR (Eur)' also contains the LR (lopende rente), which is the Acrued Interest. \n\n\nSpecific bonds are inflation linked, which' principal should also be added to the market value\n\n\nThese bonds however do not occur in the FrontArena system (they do exist in Portia)\n\n\nThe actual calculation thus is (quantity * clean_europrice  + accrued interest) == market value\n\n\nAlso units of both quantity and price needs to be taken care of. For example, bonds are priced at 100 to indicate 100%\n\n\nVerified relation: For all instruments: ((KOERS/FXRATE)*QUANTITY*UNIT.PRICE + AcruedInterest.Eur.) == MW.incl.LR..Eur\n\n\nwhere UNIT.PRICE is 0.01 for all instruments in FrontArena \nThis rule is similar to FA_0074, but only returns small differences (<=0.00001 * QUANTITY)
                                                                                                                                                                                                                                                                                      condition
62 If Quantity equals 0, a MW.incl.LR..Eur. of 0 is expected\n\n\notherwise a MW.incl.LR..Eur. of (KOERS * QUANTITY * 0.01 / FXRATE + AcruedInterest.Eur.) is expected\n\n\nPrice differences of less than 0.01 and BIGGER THAN 0.00001 * Quantity are ignored. (those are reported by FA_0036)
   Feedback      rule_load_date          source_file
62          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         query
62 Select distinct *\r\n    , RECALC_MARKET_VALUE-MARKET_VALUE  \t\t\tAS DeltaMARKET_VALUE\r\n    , ((RECALC_MARKET_VALUE-MARKET_VALUE)/MARKET_VALUE)*100\t\tAS DeltaPercentMARKET_VALUE\r\n  FROM (\r\n\tselect\r\n\t\th.source_file,\r\n\t\th.source_date,\r\n\t\tproddat,\r\n\t\tinsid,\r\n\t\tprfid,\r\n\t\tQuantity,\r\n\t\th.Price,\r\n\t\tp.OpenPremiumDiscounted,\r\n\t\tAccruedInterest,\r\n\t\th.Currency,\r\n\t\tFxRate,\r\n\t\tMARKET_VALUE,\r\n\t\tCase when Quantity = 0 then 0\t\t\t\t\t\t\t--If Quantity equals 0, a MW.incl.LR..Eur. of 0 is expected\r\n\t\t\t  else h.Price*Quantity/(FxRate*100)+AccruedInterest\r\n\t\t\t end As RECALC_MARKET_VALUE\r\n\tfrom\r\n\t\tvx_FA_holding h\r\n\t\tleft join FA_derivreport p\r\n\t\t\ton h.insid = p.Instrument\r\n\t\t\tand h.prfid = p.portfolio \r\n\t\t) as all_marketvalues\r\nwhere \r\nABS(RECALC_MARKET_VALUE-MARKET_VALUE) > 0.01 \r\nAND ABS(RECALC_MARKET_VALUE-MARKET_VALUE) <= 0.0001 * ABS(Quantity) -- The quantity factor should be equal in rules FA_0036 and FA_0074\r\n\r\n--The failing Instrument Name (7.3% ST. DE SCHORSMOLEN 1997-98/24) has a closed position as per 28-02-2014
   superset_query
62               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
63 BU Delta Lloyd Asset Management FrontArena FA_0076    holding HasValue       NEED      Input       2015-07-02 Mid Office Kristine Prahl   2015-08-12
   resultApprovalDate  dataelements                                                          datasource referencedata                                    en
63               <NA> NOMINAL_VALUE FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Holdings have a defined nominal value
                      nl
63 Gevulde nominal value
                                                                                                                                                                         rule
63 All holdings should have a defined nominal value\nThe data load scripts parses the value to a numeric value, any non-numeric value like the empty '' will also become NULL
                              condition Feedback      rule_load_date          source_file
63 Holdings with\n   nominal value NULL          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                query
63 SELECT distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid,\r\n\tprfid,\r\n\tNOMINAL_VALUE\r\nFROM\r\n    vx_FA_holding_twice\r\nWHERE\r\n    NOMINAL_VALUE is NULL
   superset_query
63               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
64 BU Delta Lloyd Asset Management FrontArena FA_0077    holding ValidRange       NEED      Input       2015-07-02 Mid Office Kristine Prahl   2015-08-12
   resultApprovalDate  dataelements                                                          datasource referencedata                                 en
64               <NA> NOMINAL_VALUE FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Nominal value for nonzero quantity
                                               nl                                                                                              rule
64 Nominale waarde bij hoeveelheid ongelijk aan 0 All holdings with nonzero quantity should have a nominal value with the same sign as the quantity
                                                                                                                                 condition Feedback      rule_load_date
64 Holdings where quantity!=0 \n   and (nominal value = 0\n              or nominal value != 0 and sign(quantity) != sign (nominal value))          2016-04-26 16:07:05
            source_file
64 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                 query
64 select distinct\r\n\tholding.source_file,\r\n\tholding.source_date,\r\n\tholding.insid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tCURRENCY,\r\n\tNOMINAL_VALUE\r\nfrom\r\n\tvx_FA_holding_twice as holding\r\nwhere\r\n\t-- applicable set\r\n\tQUANTITY != 0\r\n\t-- failure filter\r\n\tand (NOMINAL_VALUE=0\r\n\t\tOR (NOMINAL_VALUE !=0 and SIGN(QUANTITY)!=SIGN(NOMINAL_VALUE)\r\n\t\t))
   superset_query
64               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
65 BU Delta Lloyd Asset Management FrontArena FA_0078    holding ValidRange       NEED      Input       2015-07-02 Mid Office Kristine Prahl   2015-08-12
   resultApprovalDate  dataelements                                                          datasource referencedata                             en
65               <NA> NOMINAL_VALUE FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Zero nominal for zero quantity
                                       nl                                                           rule                                             condition
65 Geen nominale waarde bij hoeveelheid 0 All holdings with zero quantity should have zero nominal value Holdings where quantity=0 \n   and nominal value != 0
                                  Feedback      rule_load_date          source_file
65 whitelist:  Stichting WELSAEN 9/04/2015 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                query
65 select distinct\r\n\tinsid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tCURRENCY,\r\n\tNOMINAL_VALUE\r\nfrom\r\n\tvx_FA_holding_twice\r\nwhere\r\n\t-- applicable set\r\n\tQUANTITY = 0\r\n\t-- failure filter\r\n\tand NOMINAL_VALUE!=0
   superset_query
65               
                                BU     system      BR entitytype          Depth Importance ErrorCause modificationDate  ruleOwner          approvedBy approvedDate
66 BU Delta Lloyd Asset Management FrontArena FA_0079    holding SelfConsistent       NEED Definition       2015-07-02 Mid Office Thijs van den Dries   2015-09-24
   resultApprovalDate  dataelements                                                          datasource referencedata
66               <NA> NOMINAL_VALUE FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                                                               en
66 When quantity not zero, nominal value (eur) should be TIPS * fxrate * quantity
                                                                                                        nl
66 Bij een hoeveelheid ongelijk aan nul, dient nominale waarde gelijk te zijn aan TIPS * fxrate * quantity
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               rule
66 Nominal value (eur) should be equal to quantity * fxrate * tips\n\n\nFor instruments which are not tips, a tips rate of 1 should be used\n\n\nAll holdings where the difference between nominal value (eur) and expected_Nominal is more than 1e-4 per quantity\n\n\n1e-4 is used as accuracy threshold because of numeric precisions of underlying values (FXRATE, the issue with rounded FXRate's is covered by rule PO_0111\nThe nominal value is rounded to integers, which it shouldn't be.
                                                                                                                                                                                                                                                                                                                               condition
66 For inflation protected instruments, take their TIPS rate\n\n\nFor other instruments, take 1 as TIPS rate\n\n\nAll instruments where the absolute difference between \n\n\n  quantity * fxrate * tips (the expected nominal) \n\n\nand \n\n\n  Nominaal (eur) (the actual nominal)\n\n\nthe difference is more than 1e-4 per quantity
                                                                               Feedback      rule_load_date          source_file
66 Check a specific exception; rule might be cancelled: CAD/IRS/CD-F/141014-181014/1.69 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        query
66 select distinct\r\n\t*,\r\n\t-- the absolute difference between expected and found marketvalue\r\n\tNOMINAL_VALUE_expected - NOMINAL_VALUE as delta_abs,\r\n\tcase when NOMINAL_VALUE = 0 \r\n\tthen NULL\r\n\telse 100*(NOMINAL_VALUE_expected - NOMINAL_VALUE)/NOMINAL_VALUE \r\n\tend as delta_abs_percent\r\nfrom\r\n\t(\r\n\tselect\r\n\t\tvx_FA_holding.insid,\r\n\t\tprfid,\r\n\t\t\r\n\t\tNOMINAL_VALUE,\r\n\t\tFXRATE * QUANTITY as NOMINAL_VALUE_expected,\r\n\t\tQUANTITY,\r\n\t\tFXRATE as FXRate,\r\n\t\tCURRENCY\r\n\tfrom\r\n\t\tvx_FA_holding\r\n) as holding_extra\r\nwhere\r\n\tabs(NOMINAL_VALUE_expected - NOMINAL_VALUE) >= 0.0001 * abs(QUANTITY)
   superset_query
66               
                                BU     system      BR entitytype      Depth Importance   ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
67 BU Delta Lloyd Asset Management FrontArena FA_0081    holding ValidRange       NEED System setup       2015-07-01 Data Management Ronald Bark   2015-08-10
   resultApprovalDate   dataelements                                            datasource referencedata                                                      en
67               <NA> PORTFOLIO_NAME FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Portfolio name and Securitynaam combinations are unique
                                                             nl
67 De combinaties van portfolio naam en Securitynaam zijn uniek
                                                                                                                                                                                                                         rule
67 The unique combinations of Portfolio naam and Security Naam occurring at multiple rows.\n\n\nVerified relation: ( X.(PortfolioNaam, Securitynaam) == Y.(PortfolioNaam, Securitynaam) ) => X==Y, for all postitions X and Y
                                                                                                                                      condition Feedback
67 For all combinations of Security.Naam and PortfolioNaam\n\n\nhaving more than one rows (instruments) occurrences\n\n\nreturn the instruments         
        rule_load_date          source_file
67 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                        query superset_query
67 select distinct\r\n\tinsid,\r\n\tprfid,\r\n\tcount(*) as num\r\nfrom\r\n\tvx_FA_holding\r\ngroup by\r\n\tinsid, prfid\r\nhaving \r\n\tcount(*)>1               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
68 BU Delta Lloyd Asset Management FrontArena FA_0082 instrument HasValue       NEED      Input       2015-07-01 Valuation Desk Ilona Balvert   2015-08-13
   resultApprovalDate dataelements                                            datasource referencedata                                     en
68               <NA>        PRICE FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Instruments have defined numeric price
                                                     nl
68 Instrumenten hebben een gedefineerde numerieke prijs
                                                                                                                                                                     rule
68 All instruments should have a numeric price.\nThe data load scripts parses the value to a numeric value, any non-numeric value like the empty '' will also become NULL
                     condition Feedback      rule_load_date          source_file
68 instruments with koers NULL          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                              query superset_query
68 select distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid,\r\n\tPRICE\r\nfrom \r\n\tvx_FA_instrument\r\nwhere \r\n\tPRICE is NULL               
                                BU     system      BR entitytype    Depth Importance           ErrorCause modificationDate              ruleOwner
69 BU Delta Lloyd Asset Management FrontArena FA_0084    holding HasValue       NEED Export Configuration       2015-07-01 Information Management
               approvedBy approvedDate resultApprovalDate dataelements                                            datasource referencedata
69 Yen Hau/Nanda Kartaram   2015-10-05               <NA>      proddat FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv              
                                    en                                      nl
69 Export has export date on each line Export heeft export datum op elke regel
                                                                                                                                                                       rule
69 All lines in the export should have a defined export date.\nThe data load scripts parses the value to a date, any non-date value like the empty '' will also become NULL
                                               condition Feedback      rule_load_date          source_file
69 Holdings (the reported lines) with ReportingDate NULL          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                              query superset_query
69 SELECT distinct\r\n\tsource_date,\r\n\tsource_file,\r\n\tinsid,\r\n\tprfid,\r\n\tproddat\r\nFROM\r\n    vx_FA_holding\r\nWHERE\r\n    proddat is null               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
70 BU Delta Lloyd Asset Management FrontArena FA_0088 instrument HasValue       NEED      Input       2015-07-02 Mid Office Kristine Prahl   2015-08-12
   resultApprovalDate dataelements                                                          datasource referencedata                                           en
70               <NA>       STRIKE FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Non Swaptions should not have a strike price
                                                  nl
70 Niet-Swaptions dienen geen strike price te hebben
                                                                                                                                                                                                                                                                                                            rule
70 Swaptions are a derivative instrument. Therefore swaptions should have a strike price. All other non deriviative instruments, the non swaptions, should have an empty strike price.\nThe data load scripts parses the value to a numeric value, any non-numeric value like the empty '' will also become NULL
                                                                    condition Feedback      rule_load_date          source_file
70 Instruments with \n   DLAMAssetClas3 != 'Swaption'\n   and strike not null          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                                                                                                                query
70 SELECT DISTINCT\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid, \r\n    DLAMAssetClass1 , \r\n    DLAMAssetClass2 , \r\n    DLAMAssetClass3 ,\r\n    STRIKE,\r\n\tdb_instype_desc\r\nFROM vx_FA_instrument_twice\r\nWHERE\r\n    -- Equity Derishould have a strike price\r\n      STRIKE IS not NULL      \r\n      AND DLAMASSETCLASS3 != 'Swaption'
   superset_query
70               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
71 BU Delta Lloyd Asset Management FrontArena FA_0089 instrument ValidRange       NEED      Input       2015-07-02 Mid Office Kristine Prahl   2015-08-12
   resultApprovalDate dataelements                                                          datasource referencedata                                            en
71               <NA>       STRIKE FrontArenaDb, FA_Loan_P_20150818.csv, FA_Derivatives_P_20150818.csv               Available strike prices are strictly positive
                                         nl                                                  rule                                     condition Feedback
71 Beschikbare strike prijzen zijn positief The strike price, if any, should be strictly positive all instruments with strike non null and <= 0         
        rule_load_date          source_file
71 2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                                     query
71 select distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid,\r\n\tSTRIKE,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nfrom\r\n\tvx_FA_instrument_twice\r\nWHERE\r\n\tnot (STRIKE is NULL or LEN(LTRIM(STRIKE))=0)\r\n\tand STRIKE <=0 
   superset_query
71               
                                BU     system      BR entitytype    Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
72 BU Delta Lloyd Asset Management FrontArena FA_0090 instrument HasValue       NEED      Input       2015-07-02 Mid Office Kristine Prahl   2015-08-12
   resultApprovalDate dataelements                            datasource referencedata                     en                       nl
72               <NA>         Type DLDerivativesReportRisk2015-08-18.csv               Available (option)type Beschikbare (optie) type
                                                      rule                              condition Feedback      rule_load_date          source_file
72 The (option)type (payer/receiver) should never be NULL. All instruments with (option)type NULL          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                         query
72 select distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid,\r\n\tIDENTIFIER,\r\n\tType,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nfrom\r\n\tvx_FA_instrument\r\nWHERE\r\n\tType is NULL
   superset_query
72               
                                BU     system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
73 BU Delta Lloyd Asset Management FrontArena FA_0091 instrument ValidRange       NEED      Input       2015-07-02 Mid Office Kristine Prahl   2015-08-12
   resultApprovalDate dataelements                            datasource referencedata                                                  en
73               <NA>         Type DLDerivativesReportRisk2015-08-18.csv               The (option) type is one of '', 'Payer', 'Receiver'
                                                  nl                                                                                       rule
73 De (optie)type is een van '', 'Payer', 'Receiver' The (option)type (payer/receiver) should can be either Payer, Receiver or the empty string
                                                              condition Feedback      rule_load_date          source_file
73 All instruments with (option)type not one of 'Payer', 'Receiver', ''          2016-04-26 16:07:05 frontarena_rules.csv
                                                                                                                                                                                                                                  query
73 select distinct\r\n\tsource_file,\r\n\tsource_date,\r\n\tinsid,\r\n\tIDENTIFIER,\r\n\tType,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nfrom\r\n\tvx_FA_instrument\r\nWHERE\r\n\tType not in ('Payer', 'Receiver', '')
   superset_query
73               
                                BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner     approvedBy approvedDate resultApprovalDate
74 BU Delta Lloyd Asset Management Globe$ GL_BR0001      trade HasValue       NEED      Input             <NA>  Treasury Maarten Troost         <NA>               <NA>
   dataelements       datasource referencedata                              en                                                              nl
74 MARKET_VALUE riskforwards.xls             0 MarketValue should not be empty Marktwaarde en Nominale waarde dienen ongelijk aan NULL te zijn
                                                                                                                       rule
74 MarketValue  should not be equal to NULL, MarketValue should not be equal to an empty string/string with only whitespace
                                                                                                 condition
74 Instruments where MarketValue and are equal to NULL or an empty string or a string with only whitespace
                                                                                                   Feedback      rule_load_date      source_file
74 An account can have Zero value but not n/a values\nFor fx_deals, an amount of zero or null is unaccepted 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                          query
74 \r\nSELECT  \r\n\t\tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\t\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\t\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\t\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tMktvalEur\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS MARKET_VALUE\r\nFROM [SourceData].[dbo].GL_xls_riskforwards\r\nWHERE MktvalEur IS NULL OR LEN(RTRIM(MktvalEur)) = 0
                                                                                                                                                                                                                                                                                                                                                                                 superset_query
74 \r\nSELECT  \r\n\t\tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\t\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\t\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\t\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tMktvalEur\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS MARKET_VALUE\r\nFROM [SourceData].[dbo].GL_xls_riskforwards\r\nWHERE MktvalEur IS NULL OR LEN(RTRIM(MktvalEur)) = 0
                                BU system        BR entitytype    Depth Importance           ErrorCause modificationDate ruleOwner
75 BU Delta Lloyd Asset Management Globe$ GL_BR0002      trade HasValue       NEED Export Configuration             <NA>  Treasury
                                              approvedBy approvedDate resultApprovalDate      dataelements       datasource referencedata
75 Afhankelijk van discussies asset tree (status Donald)         <NA>               <NA> DLAM.Asset.Type.2 riskforwards.xls             0
                                    en                              nl
75 DLAMAssetType2  should not be empty DLAMAssetType2 moet gevuld zijn
                                                                                                                       rule
75  DLAMAsset Type2 should have a value, DLAMAsset Type2 should not be equal to an empty string/string with only whitespace
                                                                               condition Feedback      rule_load_date      source_file
75 DLAMAsset Type 2 with NULL Values or an empty string or a string with only whitespace        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                          query
75 SELECT \r\n\tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tDLAssetType1,\r\n\tDLAssetType2,\r\n\tDLAssetType3 \r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE DLAssetType2 IS NULL OR LEN(RTRIM(DLAssetType2)) = 0
   superset_query
75               
                                BU system        BR entitytype    Depth Importance           ErrorCause modificationDate ruleOwner
76 BU Delta Lloyd Asset Management Globe$ GL_BR0003      trade HasValue       NEED Export Configuration             <NA>  Treasury
                              approvedBy approvedDate resultApprovalDate      dataelements       datasource referencedata                                  en
76 Afhankelijk van discussies asset tree         <NA>               <NA> DLAM.Asset.Type.3 riskforwards.xls             0 DLAMAsset Type3 should not be empty
                                nl                                                                                                                      rule
76 DLAMAssetType3 moet gevuld zijn DLAMAsset Type3 should have a value, DLAMAsset Type 3  should not be equal to an empty string/string with only whitespace
                                                                            condition Feedback      rule_load_date      source_file
76 DLAMAsset Type 3 with NULL Values an empty string or a string with only whitespace        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                            query
76 SELECT \r\n \tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tDLAssetType1,\r\n\tDLAssetType2,\r\n\tDLAssetType3 \r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE DLAssetType3 IS NULL AND LEN(RTRIM(DLAssetType3)) = 0
   superset_query
76               
                                BU system        BR entitytype    Depth Importance           ErrorCause modificationDate ruleOwner
77 BU Delta Lloyd Asset Management Globe$ GL_BR0004      trade HasValue       NEED Export Configuration             <NA>  Treasury
                              approvedBy approvedDate resultApprovalDate dataelements       datasource referencedata                              en
77 Afhankelijk van discussies asset tree         <NA>               <NA> DLAM.Sector1 riskforwards.xls             0 DLAMSector1 should not be empty
                             nl                                                                                                              rule
77 DLAMSector1 moet gevuld zijn DLAMSector 1 should have a value, DLAMSector1  should not be equal to an empty string/string with only whitespace
                                                                          condition Feedback      rule_load_date      source_file
77 DLAMSector1 with NULL Values or an empty string or a string with only whitespace        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                               query
77 SELECT \r\n\tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tDLSector1,\r\n\tDLSector2,\r\n\tDLSector3\r\nFROM [SourceData].[dbo].[GL_xls_riskforwards]\r\nWHERE DLSector1 IS NULL OR LEN(RTRIM(DLSector1)) =0
   superset_query
77               
                                BU system        BR entitytype    Depth Importance           ErrorCause modificationDate ruleOwner
78 BU Delta Lloyd Asset Management Globe$ GL_BR0005      trade HasValue       NEED Export Configuration             <NA>  Treasury
                              approvedBy approvedDate resultApprovalDate dataelements       datasource referencedata                              en
78 Afhankelijk van discussies asset tree         <NA>               <NA> DLAM.Sector2 riskforwards.xls             0 DLAMSector2 should not be empty
                             nl                                                                                                             rule
78 DLAMSector2 moet gevuld zijn DLAMSector2 should have a value, DLAMSector2  should not be equal to an empty string/string with only whitespace
                                                                          condition Feedback      rule_load_date      source_file
78 DLAMSector2 with NULL Values or an empty string or a string with only whitespace        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                              query
78 SELECT \r\n\tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tDLSector1,\r\n\tDLSector2,\r\n\tDLSector3\r\nFROM [SourceData].[dbo].GL_xls_riskforwards\r\nWHERE DLSector2 IS NULL OR  LEN(RTRIM(DLSector2))= 0
   superset_query
78               
                                BU system        BR entitytype    Depth Importance           ErrorCause modificationDate ruleOwner
79 BU Delta Lloyd Asset Management Globe$ GL_BR0006      trade HasValue       NEED Export Configuration             <NA>  Treasury
                              approvedBy approvedDate resultApprovalDate dataelements       datasource referencedata                              en
79 Afhankelijk van discussies asset tree         <NA>               <NA> DLAM.Sector3 riskforwards.xls             0 DLAMSector3 should not be empty
                            nl                                                                                                             rule
79 DLAMSector3 moe gevuld zijn DLAMSector3 should have a value, DLAMSector3  should not be equal to an empty string/string with only whitespace
                                                                          condition Feedback      rule_load_date      source_file
79 DLAMSector3 with NULL Values or an empty string or a string with only whitespace        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                        query
79 SELECT\t\r\n\tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tDLSector1,\r\n\tDLSector2,\r\n\tDLSector3\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE DLSector3 IS NULL OR LEN(RTRIM(DLSector3))=0
   superset_query
79               
                                BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner     approvedBy approvedDate resultApprovalDate
80 BU Delta Lloyd Asset Management Globe$ GL_BR0007      trade HasValue       NEED      Input             <NA>  Treasury Maarten Troost         <NA>               <NA>
   dataelements       datasource referencedata                        en                     nl
80        PRICE riskforwards.xls             0 Price should not be empty Prijs moet gevuld zijn
                                                                                                  rule
80 Price should have a value, Price should not be equal to an empty string/string with only whitespace
                                                                    condition Feedback      rule_load_date      source_file
80 Price with NULL Values or an empty string or a string with only whitespace        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                              query
80 SELECT\r\n\tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tspotratetrade\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS PRICE\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE spotratetrade IS NULL OR LEN(RTRIM(spotratetrade)) =0
   superset_query
80               
                                BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner     approvedBy approvedDate resultApprovalDate
81 BU Delta Lloyd Asset Management Globe$ GL_BR0008      trade HasValue       NEED      Input             <NA>  Treasury Maarten Troost         <NA>               <NA>
   dataelements       datasource referencedata                             en                          nl
81   IDENTIFIER riskforwards.xls             0 Identifier should not be empty Identifier moet gevuld zijn
                                                                                                 rule
81 The ID should have a value, ID  should not be equal to an empty string/string with only whitespace
                                                                 condition Feedback      rule_load_date      source_file
81 ID equals to  NULL  or an empty string or a string with only whitespace        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                              query
81 SELECT \r\n\tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE ID IS NULL OR LEN(RTRIM(ID)) =0
   superset_query
81               
                                BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner     approvedBy approvedDate resultApprovalDate
82 BU Delta Lloyd Asset Management Globe$ GL_BR0009      trade HasValue       NEED      Input             <NA>  Treasury Maarten Troost         <NA>               <NA>
   dataelements       datasource referencedata                           en                        nl
82     MATURITY riskforwards.xls             0 Maturity should not be empty Maturity moet gevuld zijn
                                                                                                            rule
82 Maturity  should have a value and it should not be equal to the emtpy string or a string with only whitespace
                                                                                                                          condition Feedback      rule_load_date
82 Maturity is called settledate in the database:\nSettle Date with NULL Values or an empty string or a string with only whitespace        0 2016-04-25 14:20:58
        source_file
82 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                            query
82 SELECT \r\n\tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tSettledate\t\t\tAS MATURITY\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE Settledate IS NULL OR LEN(RTRIM(Settledate)) =0
   superset_query
82               
                                BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner     approvedBy approvedDate resultApprovalDate
83 BU Delta Lloyd Asset Management Globe$ GL_BR0011      trade HasValue       NEED      Input             <NA>  Treasury Maarten Troost         <NA>               <NA>
   dataelements       datasource referencedata                           en                       nl
83    QUANTITY  riskforwards.xls             0 Quantity should not be empty Quantity moe gevuld zijn
                                                                                                           rule
83 QUANTITY should have a value and it should not be equal to the emtpy string or a string with only whitespace
                                                                                                                          condition Feedback      rule_load_date
83 Quantity is called NominalLocal in the database\nAll trades with NULL QUANTITY or empty string or a string with only whitespace         0 2016-04-25 14:20:58
        source_file
83 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                   query
83 SELECT \r\n\tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tNominallocal\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS QUANTITY,\r\n\tMktvalEUR\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE Nominallocal IS NULL OR LEN(RTRIM(Nominallocal)) = 0\r\n
   superset_query
83               
                                BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner     approvedBy approvedDate resultApprovalDate
84 BU Delta Lloyd Asset Management Globe$ GL_BR0012      trade HasValue       NEED      Input             <NA>  Treasury Maarten Troost         <NA>               <NA>
   dataelements       datasource referencedata                                           en                        nl
84     SECURITY riskforwards.xls             0 The description/security should not be empty Security moet gevuld zijn
                                                                                                           rule
84 The description is created by concatenating sell,buy, buy currency and sell currency and should have a value
                                                                                                                     condition Feedback      rule_load_date
84 Security is called description in the database\nAll descriptions with NULL or empty string or a string with only whitespace        0 2016-04-25 14:20:58
        source_file
84 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                query
84 SELECT \r\n\tDealCode\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\t\t\r\n\tCurrency+'|'+Tegenpartij+'|'+CAST(CONVERT(date,Tradedate,104) AS varchar)\tAS insid,\r\n\tID\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t[Description]\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS [SECURITY],\r\n\tPortfolioName\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tAS PORTFOLIO_NAME\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE [Description] IS NULL \tOR LEN(RTRIM(Description)) = 0\r\n\r\n
   superset_query
84               
                                BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner   approvedBy approvedDate resultApprovalDate
85 BU Delta Lloyd Asset Management Globe$ GL_BR0013      trade HasValue       NEED      Input             <NA>  Treasury Ramon Roos           <NA>               <NA>
   dataelements       datasource referencedata                               en                                                   nl
85     CURRENCY riskforwards.xls             0 The Currency should not be empty Elke trade dient een Currency gedefinieerd te hebben
                                                                                                           rule
85 Each fx trade should trade actual currencies.\nThis rule verifies that those currencies are actually filled.
                                                                                                                    condition
85 All fx trades having a currency with  null value  i.e. must not be empty  or empty string or a string with only whitespace
                                                                                               Feedback      rule_load_date      source_file
85 It is imperative that all fxtrades should have a currency value else, the transaction doesn't hold.  2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                        query
85 SELECT\r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDealCode,\r\n\t\tCurrency\r\nFROM\r\n  SourceData.dbo.GL_vx_riskforwards\r\nWHERE \r\n  Currency is null OR  LEN(RTRIM(Currency)) = 0\r\n
   superset_query
85               
                                BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate resultApprovalDate
86 BU Delta Lloyd Asset Management Globe$ GL_BR0014  portfolio HasValue       NEED      Input             <NA>  Treasury Ramon Roos         <NA>               <NA>
      dataelements       datasource referencedata                                                  en
86 PORTFOLIO_NAME  riskforwards.xls             0 The riskforwards report have defined PortfolioNames
                                                                        nl
86 Het RiskForwards raport dient alleen ingevulde PortfolioNames te hebben
                                                                                                                                                                                                           rule
86 The report is generated within excel by macros, based upon an export on Globe$\nThe excel macros map globe$ codes to portia portfolio names.\nThis businessrule verifies that the resulting value is filled.
                                                                  condition
86 All transactions (both legs) that have a defined non null portfolio name
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              Feedback
86 Mapping of portfolio name(s) from Globe$ to BloomBerg is done by Globe$ code to blomberg account number\nThe portfolio name should not be NULL -> Standard Rule on Globe$ system. In blomberg, the verification of Globe$ portfolio \nname is done by mapping the bloomberg account number to the Globe$ code or alternatively, a manual static data list with all blooberg codes. A new inititaive to align the portfolio values for consistentency sake and ease of modification within all source systems is currently being implemented by Ramon to avoid tensions between Trade & FRM dept. respectively.\nRequired Standard:\nPortfolio: For investment, first two characters of the Globe$ code = Custodian Value\nLast three characters = Currency\nMid three characters = Portfolio Name\n
        rule_load_date      source_file
86 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                      query
86 SELECT \r\n\tportfolio\t\t\t\tAS prfid,\r\n\tID\t\t\t\t\t\tAS IDENTIFIER,\r\n\tPortfolioName\t\t\tAS PORTFOLIO_NAME \r\nFROM \r\n\tSourceData.dbo.GL_xls_riskforwards\r\nWHERE \r\n\tPortfolioName=NULL OR LEN(RTRIM(PortfolioName))=0\r\n
   superset_query
86               
                                BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner         approvedBy approvedDate
87 BU Delta Lloyd Asset Management Globe$ GL_BR0015 instrument ValidRange       NEED Export Configuration             <NA>  Treasury regel niet correct         <NA>
   resultApprovalDate dataelements                        datasource referencedata                                                                            en
87               <NA>   IDENTIFIER riskforwards.xls, GL_xls_cashrisk             0 Each dealcode has only one identifier, each identifier has only one dealcode.
                                                                                                                           nl
87 Elke dealcode heeft maar ��n mogelijke waarde als identifier, elke identifier heeft maar ��n mogelijke waarde als dealcode
                                                                                                         rule
87 riskforwards:\n An ID occurs with at most 1 dealcode.\nA dealcode and settlementdate can have at most 1 ID
                                                                                                                                                                                                                                            condition
87 All dealcodes, except 'cash' for whom the number of different identifiers is greater then 1 in either cashrisk of riskforwards. \nAll identifiers for whom the number of different dealcodes is greater then 1 in either cashrisk or riskforwards.
   Feedback      rule_load_date      source_file
87 Approved 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           query
87 SELECT\r\n\tID as insid,\r\n\tID as IDENTIFIER,\r\n\tNULL as tradeid,\r\n\tnull as prfid,\r\n\tNULL as settledate,\r\n\tcount(distinct dealcode)\r\nFROM\r\n\t[SourceData].[dbo].GL_xls_riskforwards\r\nGROUP BY\r\n\tID\r\nHAVING count(distinct dealcode) > 2\r\nUNION ALL\r\nSELECT\r\n\tNULL as insid,\r\n\tNULL AS identifier,\r\n\tdealcode as tradeid,\r\n\tnull as prfid,\r\n\tsettledate,\r\n\tcount(distinct ID)\r\nFROM [SourceData].[dbo].GL_xls_riskforwards\r\nGROUP BY dealcode, settledate\r\nHAVING COUNT(distinct ID) > 2
   superset_query
87               
 names_orig names_sql_expected names_sql
                             X        V6
                                BU system        BR entitytype      Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
88 BU Delta Lloyd Asset Management Globe$ GL_BR0016   currency ValidRange       NEED      Input             <NA>  Treasury Ramon Roos, Fred         <NA>
   resultApprovalDate dataelements      datasource referencedata                                                         en
88               <NA>     CURRENCY GL_xls_cashrisk             0 All currencies should have length three and be capitalized
                                                                               nl                                                       rule
88 Alle wisselkoersen dienen lengte drie te hebben en uit hoofdletters te bestaan All currencies should have length three and be capitalized
                                                                                 condition                                 Feedback      rule_load_date
88 All instruments where currency has a different length then three and is not capitalized Rule approved by Ramon.Validated by Fred 2016-04-25 14:20:58
        source_file
88 globe$_rules.csv
                                                                                                                                                                                                                                                                       query
88 SELECT \r\n\t\tCurrency\t\t\tAS fxid,\r\n\t\tID\t\t\t\t\tAS IDENTIFIER,\r\n\t\tCurrency\r\nFROM [SourceData].[dbo].GL_xls_cashrisk\r\nWHERE LEN(ISNULL(Currency,'')) != 3 OR UPPER(Currency) != Currency;  --ISNULL surrounding string being tested to avoid bugs due to NULL value\r\n
   superset_query
88               
                                BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
89 BU Delta Lloyd Asset Management Globe$ GL_BR0017      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
   resultApprovalDate dataelements      datasource referencedata                                           en                                                 nl
89               <NA> DLAM.Sector1 GL_xls_cashrisk             0 DLAM.Sector1 should be equal to 'Corporates' DLAM.Sector1 dient gelijk te zijn aan 'Corporates'
                                           rule                                                    condition
89 DLAM.Sector1 should be equal to 'Corporates' Instruments where DLAM.Sector1 is not equal to 'Corporates' 
                                                                                                                                                               Feedback
89 Rule approved by Ramon, (23-6-2015) Fred: Approved according to Ramon's knowledge of the DLAM.Sector Class(es) levels. The sector value is needed for every position
        rule_load_date      source_file
89 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                             query
89 SELECT \r\n\t\tDealcode\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLSector1,\r\n\t\tDLSector2,\r\n\t\tDLSector3\r\nFROM SourceData.[dbo].GL_xls_cashrisk\r\nWHERE ISNULL(DLSector1,'') != 'Corporates'  --ISNULL sourrounding string being tested to avoid bugs due to string is NULL
   superset_query
89               
                                BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
90 BU Delta Lloyd Asset Management Globe$ GL_BR0018      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
   resultApprovalDate dataelements      datasource referencedata                                           en                                                 nl
90               <NA> DLAM.Sector2 GL_xls_cashrisk             0 DLAM.Sector2 should be equal to 'Financials' DLAM.Sector2 dient gelijk te zijn aan 'Financials'
                                           rule                                                   condition
90 DLAM.Sector2 should be equal to 'Financials' Instruments where DLAM.Sector2 is not equal to 'Financials'
                                                                                                                                                              Feedback
90 Rule approved by Ramon, (23-6-2015 Fred): Approved according to Ramon's knowledge of the DLAM.Sector Class(es) levels.The sector value is needed for every position
        rule_load_date      source_file
90 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                        query
90 SELECT \r\n\t\tDealcode\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\tAS prfid,\r\n\t\tDLSector1,\r\n\t\tDLSector2,\r\n\t\tDLSector3\r\nFROM [SourceData].[dbo].GL_xls_cashrisk\r\nWHERE ISNULL(DLSector2, '') != 'Financials';  --ISNULL sourrounding string being tested to avoid bugs due to string is NULL\r\n
   superset_query
90               
                                BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
91 BU Delta Lloyd Asset Management Globe$ GL_BR0019      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
   resultApprovalDate dataelements      datasource referencedata                                           en                                                 nl
91               <NA> DLAM.Sector3 GL_xls_cashrisk             0 DLAM.Sector3 should be equal to 'Financials' DLAM.Sector3 dient gelijk te zijn aan 'Financials'
                                           rule                                                   condition
91 DLAM.Sector3 should be equal to 'Financials' Instruments where DLAM.Sector3 is not equal to 'Financials'
                                                                                                                                                             Feedback
91 Rule approved by Ramon. (23-6-2015 Fred) Approved according to Ramon's knowledge of the DLAM.Sector Class(es) levels.The sector value is needed for every position
        rule_load_date      source_file
91 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                      query
91 SELECT \r\n\t\tDealcode\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLSector1,\r\n\t\tDLSector2,\r\n\t\tDLSector3\r\nFROM [SourceData].[dbo].[GL_xls_cashrisk]\r\nWHERE ISNULL(DLSector3, '') != 'Financials'; --ISNULL sourrounding string being tested to avoid bugs due to string is NULL\r\n
   superset_query
91               
                                BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
92 BU Delta Lloyd Asset Management Globe$ GL_BR0020      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
   resultApprovalDate      dataelements      datasource referencedata                                     en                                           nl
92               <NA> DLAM.Asset.Type.3 GL_xls_cashrisk             0 DLAM AssetType3 should be equal to '-' DLAM AssetType3 dient gelijk te zijn aan '-'
                                                    rule                                condition                    Feedback      rule_load_date      source_file
92 Instruments where DLAM AssetType3 in not equal to '-' Instruments where relation does not hold Rule approved by Ramon Roos 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      query
92 SELECT\r\n\t\tDealcode\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLAssetType1,\r\n\t\tDLAssetType2,\r\n\t\tDLAssetType3\r\nFROM [SourceData].[dbo].GL_xls_cashrisk\r\nWHERE ISNULL(CAST(DLAssetType3 AS varchar), 'NO VALUE') != '-' \r\n\t-- if DLAssetType3 is NULL the condition would never be true. Solveable by surrounding the \r\n\t-- potentially NULL field by ISNULL with a value that will trigger the condition\r\n
   superset_query
92               
                                BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner      approvedBy approvedDate
93 BU Delta Lloyd Asset Management Globe$ GL_BR0021  portfolio ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos,Fred         <NA>
   resultApprovalDate   dataelements      datasource referencedata                                      en                                         nl
93               <NA> PORTFOLIO_NAME GL_xls_cashrisk             0 Portfolio should not be equal to '#N/A' Portfolio dient ongelijk aan 'N/A' te zijn
                                      rule                                            condition
93 Portfolio should not be equal to '#N/A' Instruments where Portfolio_portia is equal to '#N/A
                                                                                                                                                                                                                                                                                 Feedback
93 Rule approved by Fred, (23-6-2015) The portfolio shouldn't  have 'N/A' values. The values for portfolio are derived from Globe$ code & if no mapping from Globe$ code to portfolio name based on unavailability of Globe$ code, the portfolio value is derived from the portfolio name
        rule_load_date      source_file
93 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                     query
93 SELECT \r\n\t\tportfolio\t\t\t\t\t\t\t\t\t\tAS prfid,\r\n\t\tPortfolioName\t\t\t\t\t\t\t\t\tAS Portfolio_portia,\r\n\t\tID,\r\n\t\tportfolio\t\t\t\t\t\t\t\t\t\tAS Globes_Portfolio\r\nFROM SourceData.dbo.GL_xls_cashrisk\r\nWHERE ISNULL(PortfolioName, '#N/A') = '#N/A' --ISNULL sourrounding string being tested to avoid bugs due to string is NULL\r\n
   superset_query
93               
                                BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
94 BU Delta Lloyd Asset Management Globe$ GL_BR0023  portfolio ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
   resultApprovalDate   dataelements          datasource referencedata                                     en                                         nl
94               <NA> PORTFOLIO_NAME GL_xls_riskforwards             0 Portfolio should not be equal to 'N/A' Portfolio dient ongelijk aan 'N/A' te zijn
                                     rule                                            condition Feedback      rule_load_date      source_file
94 Portfolio should not be equal to 'N/A' Instruments where Portfolio_portia is equal to '#N/A        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                              query
94 SELECT \r\n\t\tportfolio\t\t\t\t\t\t\t\t\t\tAS prfid,\r\n\t\tPortfolioName\t\t\t\t\t\t\t\t\tAS Portfolio_portia,\r\n\t\tID,\r\n\t\tportfolio\t\t\t\t\t\t\t\t\t\tAS Globes_Portfolio\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE ISNULL(PortfolioName, '#N/A') = '#N/A'  --ISNULL sourrounding string being tested to avoid bugs due to string is NULL\r\n\r\n
   superset_query
94               
                                BU system        BR entitytype      Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate resultApprovalDate
95 BU Delta Lloyd Asset Management Globe$ GL_BR0024      trade ValidRange       NEED      Input             <NA>  Treasury Ramon Roos         <NA>               <NA>
             dataelements      datasource referencedata                                             en                                                     nl
95 NOMINAL_VALUE,QUANTITY GL_vx_xls_fxpms             0 Buy & Sell Amounts should be greater than zero Aan en verkoop aantallen dienen groter dan nul te zijn
                                                                                                                                                                                                                                                                                                                                                          rule
95 The buy and sell amounts should be bigger than zero, as a positive amount of money is transferred.\nIn the export the buy amount is transferred to an instrument with positive Nominal Local\nIn the export the sell amount is transferred to an instrument with negative Nominal Local\nThis thus verifies Nominal Local by checking the underlying fields
                             condition
95 All Buy and Sell amount values <= 0
                                                                                                                                                             Feedback
95 Approved, else transaction won't hold. Ramon gave an example by initiating a trade with both a negative and 0 value for buy & sell amount which resulted to errors
        rule_load_date      source_file
95 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                            query
95 SELECT \r\n\tDealCode\t\t\t\t\tAS tradeid, \r\n\tIDBuy\t\t\t\t\t\tAS insid,\r\n\tPortfolioName\t\t\t\tAS prfid,\r\n\tDealCode , \r\n\tIDBuy,\r\n\tIDSell,\r\n\tbuy_amount ,\r\n\tsell_amount,\r\n\tTradedate,\r\n\t[Description]\r\nFROM\r\n\tSourceData.dbo.GL_vx_xls_fxpms  \r\nWHERE\r\n\tbuy_amount<=0   --ISNULL sourrounding string being tested to avoid bugs due to string is NULL\r\n\tor sell_amount<=0;   --ISNULL sourrounding string being tested to avoid bugs due to string is NULL\r\n\r\n
   superset_query
95               
                                BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
96 BU Delta Lloyd Asset Management Globe$ GL_BR0025      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
   resultApprovalDate      dataelements          datasource referencedata                                                             en
96               <NA> DLAM.Asset.Type.2 GL_xls_riskforwards             0 The fx forwards should all have DLAMAssetType2 'Fx Derivative'
                                                                        nl
96 De fx forwards dienen allemaal DLAMAssetType2 'FX Derivative' te hebben
                                                                                                                                                rule
96 The FX Forwards is based on the fxpms export, \nwhich exports all cash trades with a settledate in the future.This makes them all FX Derivatives.
                                         condition
96 All trades having DLAssetType2 != Fx Derivative
                                                                                                                                                    Feedback
96 Approved, based on underlying Instrument and assetclass derivative. Verify all static data fields with Fred(since he created the Macros based on Vlookup.
        rule_load_date      source_file
96 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                   query
96 SELECT \r\n\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\tID\t\t\t\t\t\t\t\tAS insid,\r\n\tPortfolioName\t\t\t\t\tAS prfid,\r\n\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t[PortfolioName],\r\n\t[DLAssetType1],\r\n\t[DLAssetType2]\r\nFROM \r\n[SourceData].dbo.GL_xls_riskforwards\r\nWHERE \r\n\t\t--ISNULL sourrounding string being tested to avoid bugs due to string is NULL\r\n\tISNULL(DLAssetType2, '') != 'FX Derivative';
   superset_query
96               
                                BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
97 BU Delta Lloyd Asset Management Globe$ GL_BR0026      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
   resultApprovalDate      dataelements          datasource referencedata                                                          en
97               <NA> DLAM.Asset.Type.3 GL_xsl_riskforwards             0 The fx forwards should all have DLAMAssetType3 'FX Forward'
                                                                     nl
97 De fx forwards dienen allemaal DLAMAssetType3 'FX Forward' te hebben
                                                                                                                                           rule
97 The FX Forwards is based on the fxpms export, which exports all cash trades with a settledate in the future.This makes them all FX Forwards.
                                      condition
97 All trades having DLAssetType3 != FX Forward
                                                                                                                                                    Feedback
97 Approved, based on underlying Instrument and assetclass derivative. Verify all static data fields with Fred(since he created the Macros based on Vlookup.
        rule_load_date      source_file
97 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                         query
97 SELECT \r\n\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\tID\t\t\t\t\t\t\t\tAS insid,\r\n\tPortfolioName\t\t\t\t\tAS prfid,\r\n\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t[PortfolioName],\r\n\t[DLAssetType1],\r\n\t[DLAssetType2]\r\nFROM \r\n\t[SourceData].dbo.GL_xls_riskforwards\r\nWHERE \r\n\tISNULL(DLAssetType3, 'NO VALUE') != 'FX Forward' \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t
   superset_query
97               
                                BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
98 BU Delta Lloyd Asset Management Globe$ GL_BR0027      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
   resultApprovalDate dataelements          datasource referencedata                                                     en
98               <NA> DLAM.Sector1 GL_xsl_riskforwards             0 The fx forwards should all have DLSector1 'Corporates'
                                                                nl
98 De fx forwards dienen allemaal DLSector1 'Corporates' te hebben
                                                                                                                                            rule
98 The FX Forwards is based on the fxpms export, which exports all cash trades with a settledate in the future.\nThis makes them all Corporates.
                                      condition                                                            Feedback      rule_load_date      source_file
98 All trades having DLSector1 != FX Corporates Approved, based on underlying Instrument and sector tree derivative 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                  query
98 SELECT \r\n\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\tID\t\t\t\t\t\t\t\tAS insid,\r\n\tPortfolioName\t\t\t\t\tAS prfid,\r\n\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tPortfolioname, \r\n\tDlsector1, \r\n\tDlsector2, \r\n\tDLSector3, \r\n\tDlsector4\r\nFROM \r\n\tSourcedata.Dbo.Gl_Xls_Riskforwards\r\nWHERE ISNULL(Dlsector1, 'NO VALUE')\t!='Corporates'; 
   superset_query
98               
                                BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
99 BU Delta Lloyd Asset Management Globe$ GL_BR0028      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
   resultApprovalDate dataelements          datasource referencedata                                                     en
99               <NA> DLAM.Sector2 GL_xsl_riskforwards             0 The fx forwards should all have DLSector2 'Financials'
                                                                nl
99 De fx forwards dienen allemaal DLSector2 'Financials' te hebben
                                                                                                                                            rule
99 The FX Forwards is based on the fxpms export, \nwhich exports all cash trades with a settledate in the future.This makes them all Financials.
                                      condition                                                            Feedback      rule_load_date      source_file
99 All trades having DLSector2 != FX Financials Approved, based on underlying Instrument and sector tree derivative 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                            query
99 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\t[PortfolioName],\r\n\t\tDLSector1,\r\n\t\tDLSector2\r\n\t\tDLSector3,\r\n        DLSector4\r\n  FROM \t[SourceData].dbo.GL_xls_riskforwards\r\n\t\twhere ISNULL(DLSector2, '') != 'Financials' \r\n
   superset_query
99               
                                 BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
100 BU Delta Lloyd Asset Management Globe$ GL_BR0029      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements          datasource referencedata                                                     en
100               <NA> DLAM.Sector3 GL_xsl_riskforwards             0 The fx forwards should all have DLSector3 'Financials'
                                                                 nl
100 De fx forwards dienen allemaal DLSector3 'Financials' te hebben
                                                                                                                                             rule
100 The FX Forwards is based on the fxpms export, which exports all cash trades with a settledate in the future.\nThis makes them all Financials.
                                       condition                                                            Feedback      rule_load_date      source_file
100 All trades having DLSector3 != FX Financials Approved, based on underlying Instrument and sector tree derivative 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                            query
100 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\t[PortfolioName],\r\n\t    [DLSector1],\r\n\t    [DLSector2],\r\n\t\t[DLSector3],\r\n\t\t[DLSector4]\r\nFROM [SourceData].dbo.GL_xls_riskforwards\r\nwhere ISNULL(DLSector3,'') != 'Financials' 
    superset_query
100               
                                 BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
101 BU Delta Lloyd Asset Management Globe$ GL_BR0030   currency ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements          datasource referencedata                                                          en
101               <NA>      FXRATE  GL_xsl_riskforwards             0 The fx forwards should have constant spotrates per currency
                                                                          nl
101 De fx forwards dienen allemaal een constante spotrate per munt te hebben
                                                                                                                                      rule
101 The FX Forwards contains the current sportrate of the currencies to determine the value.This spotrate should be constant per currency.
                                                                      condition
101 All FX Forwards which have more then one spotrate across the entire dataset
                                                                                                                                                                                                                               Feedback
101 Approved, every counterparty(tegenpartij) has its own spote rate based on the market price of the particular currency at that point in time. Every deal code has its own unique spot rate which is determined by the counterparty .
         rule_load_date      source_file
101 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         query
101 SELECT\r\n\tsingles.Currency\tAS fxid,\r\n\tsingles.Currency, \r\n\tSpotrate, \r\n\tnum_rates\r\nFROM \r\n\t(\r\n\t\tSELECT Currency, COUNT(distinct spotrate)\tAS num_rates\r\n\t\tFROM SourceData.dbo.GL_xls_riskforwards\t\tAS b_riskforwards\r\n\t\tGROUP BY Currency\r\n\t\tHAVING COUNT(DISTINCT spotrate)>1\r\n    ) AS multiples\r\n\tleft join (\r\n\t\tSELECT DISTINCT Currency, spotrate\r\n\t\tFROM SourceData.dbo.GL_xls_riskforwards\r\n\t) AS singles\r\n\tON multiples.Currency = singles.Currency
    superset_query
101               
                                 BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
102 BU Delta Lloyd Asset Management Globe$ GL_BR0031      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate                     dataelements                      datasource referencedata
102               <NA> CURRENCY,\nIDENTIFIER,\nMATURITY GL_vx_riskforwards_xls_matching             0
                                                                      en                                                                        nl
102 The riskforwards report should have deals matching with the database Het RiskForwards raport dient deals te hebben die met de database matchen
                                                                                                                                                                                                                                                                                                                                               rule
102 The report is generated within excel by macros, based upon an export on Globe$\nThis businessrule verifies that all rows in the database are actually available in the report,and that all rows in the report are also available in the database.Because the dealdcode is part of the id, it is also indirectly verified by this business rule.
                                                                       condition
102 All transactions (both legs) in the excel report that do not exist in the db
                                                                                                                                                    Feedback
102 Rule approved by Ramon Roos: Logically Approved. Risk forwards and DB must have matching deals. Verification and validation with Ilona (Validation Desk)
         rule_load_date      source_file
102 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          query
102 SELECT\r\n\ttheDealCode\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\tAS prfid,\r\n\ttheID\t\t\t\t\t\t\t\tAS insid,\r\n\tTheSystem,\r\n\ttheDealCode\t\t\t\t\t\t\tAS DealCode,\r\n\ttheDescription\t\t\t\t\t\tAS [Description],\r\n\ttheTradeDate\t\t\t\t\t\tAS TradeDate,\r\n\ttheSettleDate\t\t\t\t\t\tAS SettleDate,\r\n\ttheCurrency\t\t\t\t\t\t\tAS Currency,\r\n\ttheGlobesCode\t\t\t\t\t\tAS GlobesCode,\r\n\tdb_NominalLocal,\r\n\tNominallocal,\r\n\ttheID\t\t\t\t\t\t\t\tAS IDENTIFIER\r\nFROM\r\n\tSourceData.dbo.GL_vx_riskforwards_xls_matching\r\nWHERE\r\n\tdb_DealCode is NULL or\r\n\tDealcode is NULL\r\nORDER BY \r\n\ttheDealCode,\r\n\ttheTradeDate,\r\n\ttheSettleDate\r\n\r\n\r\n
    superset_query
102               
                                 BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
103 BU Delta Lloyd Asset Management Globe$ GL_BR0032      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate             dataelements                                     datasource referencedata
103               <NA> NOMINAL_VALUE,\nQUANTITY SourceData.dbo.GL_vx_riskforwards_xls_matching             0
                                                                                   en                                                                               nl
103 The riskforwards report should have the same nominal local values as the database Het RiskForwards raport dient gelijke nominale waarden te hebben als de database
                                                                                                                                                                                                                                              rule
103 The report is generated within excel by macros, based upon an export on Globe$.This businessrule verifies those rows that are available in both the database and the excel report.These rows are verified to have an equal nominal local value
                                                                                                               condition
103 All transactions (both legs) that exist both in the excel report and the database which have unequal nominal values.
                                                                                                                       Feedback      rule_load_date      source_file
103 Logically Approved. Risk forwards and DB must have matching deals. Verification and validation with Ilona (Validation Desk) 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          query
103 SELECT\r\n\ttheDealCode\t\t\tAS tradeid,\r\n\ttheID\t\t\t\tAS insid,\r\n\tdb_NominalLocal,\r\n\tNominalLocal,\r\n\tround(db_NominalLocal,2) AS db_NominalLocal_rounded,\r\n\tround(Nominallocal,2) AS Nominallocal_rounded,\r\n\tPortfolioname\t\tAS prfid,\r\n\ttheID\t\t\t\tAS IDENTIFIER,\r\n\ttheDescription\t\tAS Description,\r\n\ttheTradeDate\t\tAS TradeDate,\r\n\ttheSettleDate\t\tAS SettleDate\r\n\r\nFROM\r\n\tSourceData.dbo.GL_vx_riskforwards_xls_matching\r\nWHERE\r\n\tTheSystem='DBXL' and\r\n\tROUND(db_NominalLocal, 2) != ROUND(Nominallocal, 2)\r\nORDER BY \r\n\ttheDealCode,\r\n\ttheTradeDate,\r\n\ttheSettleDate\r\n
    superset_query
103               
                                 BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
104 BU Delta Lloyd Asset Management Globe$ GL_BR0033      trade ValidRange       NICE Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements                      datasource referencedata                                                                       en
104               <NA>     SECURITY GL_vx_riskforwards_xls_matching             0 The riskforwards report should have the same Description as the database
                                                                             nl
104 Het RiskForwards raport dient gelijke Description te hebben als de database
                                                                                                                                                                                                                                       rule
104 The report is generated within excel by macros, based upon an export on Globe$.This businessrule verifies those rows that are available in both the database and the excel report. These rows are verified to have an equal Description
                                                                                                            condition
104 All transactions (both legs) that exist both in the excel report and the database which have unequal Description.
                                                                                                                                                    Feedback
104 Rule approved by Ramon Roos: Logically Approved. Risk forwards and DB must have matching deals. Verification and validation with Ilona (Validation Desk)
         rule_load_date      source_file
104 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
104 SELECT\r\n\ttheDealCode\t\t\tAS tradeid,\r\n\ttheID\t\t\t\tAS insid,\r\n\tPortfolioname\t\tAS prfid,\r\n\ttheID\t\t\t\tAS IDENTIFIER,\r\n\tTheSystem,\r\n\ttheDealCode\t\t\tAS DealCode,\r\n\ttheTradeDate\t\tAS TradeDate,\r\n\ttheSettleDate\t\tAS SettleDate,\r\n\ttheCurrency\t\t\tAS Currency,\r\n\tdb_Description, \r\n\tDescription\r\nFROM\r\n\tSourceData.dbo.GL_vx_riskforwards_xls_matching\r\nWHERE\r\n\tISNULL(TheSystem, 'DBXL') ='DBXL' and\r\n\tISNULL(db_Description, 'NO VALUE') != ISNULL(Description, 'NO VALUE2')\r\nORDER BY \r\n\ttheDealCode,\r\n\ttheTradeDate,\r\n\ttheSettleDate
    superset_query
104               
                                 BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
105 BU Delta Lloyd Asset Management Globe$ GL_BR0034      trade ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements                      datasource referencedata                                                                        en
105               <NA> MARKET_VALUE GL_vx_riskforwards_xls_matching             0 The riskforwards report should have the same Mktval..EUR. as the database
                                                                              nl
105 Het RiskForwards raport dient gelijke Mktval..EUR. te hebben als de database
                                                                                                                                                                                                                                                                                                                             rule
105 The report is generated within excel by macros, based upon an export on Globe$.This businessrule verifies those rows that are available in both the database and the excel report.These rows are verified to have an equal Mktval..EUR.The differences are caused by the rounding of spotrate to 4 digits in the excel sheet.
                                                                                                             condition
105 All transactions (both legs) that exist both in the excel report and the database which have unequal Mktval..EUR..
                                                                                                                                                   Feedback
105 Rule approvd by Ramon Roos: Logically Approved. Risk forwards and DB must have matching deals. Verification and validation with Ilona (Validation Desk)
         rule_load_date      source_file
105 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              query
105 SELECT\r\n\ttheDealCode\t\t\tAS tradeid,\r\n\ttheID\t\t\t\tAS insid,\r\n\tPortfolioname\t\tAS prfid,\r\n\ttheID\t\t\t\tAS IDENTIFIER,\r\n\tTheSystem,\r\n\tTheDescription\t\tAS Description,\r\n\ttheDealCode\t\t\tAS DealCode,\r\n\ttheTradeDate\t\tAS TradeDate,\r\n\ttheSettleDate\t\tAS SettleDate,\r\n\ttheCurrency\t\t\tAS Currency,\r\n\tMktvalEUR,\r\n\tdb_Mktval,\r\n\tNominallocal,\r\n\tdb_NominalLocal,\r\n\tdb_Amount,\r\n\tSpotRate,\r\n\tdb_SpotRate,\r\n\tROUND(db_Mktval - MktvalEUR, 3) AS delta\r\nFROM\r\n\tSourceData.dbo.GL_vx_riskforwards_xls_matching\r\nWHERE\r\n\tISNULL(TheSystem, 'DBXL') ='DBXL' and\r\n\tROUND(db_Mktval - MktvalEUR,2) != 0\r\nORDER BY \r\n\ttheDealCode,\r\n\ttheTradeDate,\r\n\ttheSettleDate
    superset_query
105               
                                 BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
106 BU Delta Lloyd Asset Management Globe$ GL_BR0035  portfolio ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate    dataelements                     datasource referencedata
106               <NA> PORTFOLIO_NAME  GL_xls_rf_globescode_to_portia             0
                                                                                                en
106 The riskforwards report should be based on a unique mapping of globescode to portia portfolio.
                                                                                                             nl
106 Het RiskForwards raport dient gebaseerd te zijn op een unieke mapping van globescode naar portia portfolio.
                                                                                                                                                                                                                 rule
106 The report is generated within excel by macros, based upon an export on Globe$.\nThis businessrule verifies that the mapping from globescode to portia portfolio, as used by the macro, defines a unique mapping.
                                                        condition
106 All globescode's that are mapped to multiple portfolio names.
                                                                                                                                                                                 Feedback
106 Mapping between Globe$ and Portia based on portfolio name values doesn't have consistency since Ramon doesn't get updated on portfolio changes in Portia. Ideally, they should match.
         rule_load_date      source_file
106 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
106 SELECT \r\n\tdetails.Portiacode as prfid,\r\n\tunique5codes.Globes5code, \r\n\tnum_portia_portfolio, details.Portiacode as PortfolioName\r\nFROM\r\n\t(select \r\n\t\tGlobes5code, count(distinct(Portiacode)) as num_portia_portfolio\r\n\tfrom\r\n\t\tSourceData.dbo.GL_xls_rf_globescode_to_portia\r\n\tgroup by\r\n\t\tGlobes5code\r\n\t)as unique5codes\r\n\tleft join\r\n\tSourceData.dbo.GL_xls_rf_globescode_to_portia as details\r\n\ton\r\n\t\tunique5codes.Globes5code=details.Globes5code\r\nwhere \r\n\tnum_portia_portfolio > 1\r\norder by\r\n\tunique5codes.Globes5code
    superset_query
106               
                                 BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
107 BU Delta Lloyd Asset Management Globe$ GL_BR0036  portfolio ValidRange       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate    dataelements                      datasource referencedata                                                                         en
107               <NA> PORTFOLIO_NAME  GL_vx_riskforwards_xls_matching             0 The riskforwards report should have the same PortfolioName as the database
                                                                               nl
107 Het RiskForwards raport dient gelijke PortfolioName te hebben als de database
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            rule
107 The report is generated within excel by macros, based upon an export on Globe$ .This businessrule verifies those rows that are available in both the database and the excel report. These rows are verified to have an equal PortfolioName. A problem is that the mapping of Globe$code to Portfolioname contains multiple different values for a single Globe$code. This comparison uses the first availabe mapping to determine the correct portia portfolioname. Business rule GL-BR0137 verifies that the mapping should contain only one value per key.
                                                                                                              condition Feedback      rule_load_date      source_file
107 All transactions (both legs) that exist both in the excel report and the database which have unequal PortfolioName.        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    query
107 SELECT\r\n\tDealCode\t\t\t\t\tAS tradeid,\r\n\ttheID\t\t\t\t\t\tAS insid,\r\n\tdb_GlobesPortfolioName\t\tAS prfid,\r\n\ttheID\t\t\t\t\t\tAS IDENTIFIER,\r\n\tTheSystem,\r\n\tTheDescription\t\t\t\tAS Description,\r\n\ttheDealCode\t\t\t\t\tAS DealCode,\r\n\ttheTradeDate\t\t\t\tAS TradeDate,\r\n\ttheSettleDate\t\t\t\tAS SettleDate,\r\n\ttheCurrency\t\t\t\t\tAS Currency,\r\n\tdb_Portfolio,\r\n\tPortfolio,\r\n\tdb_GlobesPortfolioName,\r\n\tdb_Portfolio_portia, \r\n\tPortfolioName\r\nFROM\r\n\tSourceData.dbo.GL_vx_riskforwards_xls_matching\r\nWHERE\r\n\tISNULL(TheSystem, 'DBXL') ='DBXL' and\r\n\t(ISNULL(db_Portfolio_portia, 'NO VALUE') != ISNULL(PortfolioName, 'NO VALUE2') \r\n\t\tor\r\n\t db_Portfolio_portia is null)\r\nORDER BY \r\n\ttheDealCode,\r\n\ttheTradeDate,\r\n\ttheSettleDate;
    superset_query
107               
                                 BU system        BR entitytype      Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate resultApprovalDate
108 BU Delta Lloyd Asset Management Globe$ GL_BR0037  portfolio ValidRange       NEED      Input             <NA>  Treasury Ramon Roos         <NA>               <NA>
       dataelements       datasource referencedata                                                                       en
108 PORTFOLIO_NAME  xls_riskforwards             0 The riskforwards report have a PortfolioName which is not marked deleted
                                                                                    nl
108 Het RiskForwards raport dient alleen PortfolioNamen te hebben die in gebruik zijn.
                                                                                                                                                                                                                                                                                        rule
108 The report is generated within excel by macros, based upon an export on Globe$. The excel macros map globe$ codes to portia portfolio names.\nIn portia removed portfolio names are marked with a *.\nThis businessrule verifies that the result of the mapping does not start with a *.
                                                                    condition
108 All transactions (both legs) that have a portfolio name starting with a *
                                                                                                              Feedback      rule_load_date      source_file
108 Unused portfolio names in Globe$ which are mapped with portia portfolio names are allowed for historical purposes. 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                      query superset_query
108 SELECT \r\n\tPortfolioName\t\tAS prfid, \r\n\tPortfolioName\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE PortfolioName LIKE '*%'\r\n               
                                 BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
109 BU Delta Lloyd Asset Management Globe$ GL_BR0038      trade ValidRange       NICE Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements          datasource referencedata                                                                  en
109               <NA>    SECURITY  GL_Xls_Riskforwards             0 The riskforwards report should use a single description for each ID
                                                                   nl
109 Het RiskForwards raport dient een Description te gebruiken per ID
                                                                                                                                                                                                                                                                                  rule
109 The report has a more descriptive description in field 'Description'.\nThese elaborate on the identifying ID. \nAs ID is the identifier, the description should be constant for multiple rows with the same ID.\nThis rule verifies the relation:\nIDs equal => Descriptions equal
                                                                    condition
109 All IDs and Descriptions pairs in which one ID has multiple Descriptions.
                                                                                                                                       Feedback      rule_load_date
109 The description is not always unique per ID due to multiple deal code(s) for the same counterparty or porfolio.Needs verification with Fred 2016-04-25 14:20:58
         source_file
109 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                query
109 SELECT \r\n\tdetails.ID\t\t\t\t\tAS insid,\r\n\tdetails.Dealcode\t\t\tAS tradeid,\r\n\tdetails.PortfolioName\t\tAS prfid,\r\n\tdetails.ID, \r\n\tnum_descriptions, \r\n\tdetails.[Description], \r\n\tcount(*) as num_trades\r\nFROM (\r\n\tSelect \r\n\t\tID, \r\n\t\tCount(DISTINCT([Description])) as num_descriptions\r\n\tFrom\r\n\t\tSourceData.Dbo.GL_Xls_Riskforwards\r\n\tGroup by \r\n\t\tID\r\n\tHaving\r\n\t\tCount(DISTINCT([Description])) > 1\r\n) as multiple_descriptions \r\nleft join \r\n\tSourceData.dbo.GL_Xls_Riskforwards as details\r\non details.ID=multiple_descriptions.ID\r\nGROUP BY\r\n\tdetails.ID, details.[Description], num_descriptions, details.Dealcode, details.PortfolioName\r\nORDER BY\r\n\tID, [Description]\r\n\r\n\r\n
    superset_query
109               
                                 BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
110 BU Delta Lloyd Asset Management Globe$ GL_BR0039 instrument ValidRange       NICE Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements          datasource referencedata                                                                  en
110               <NA>   IDENTIFIER GL_Xls_Riskforwards             0 The riskforwards report should use a single ID for each Description
                                                                      nl
110 Het RiskForwards raport dient een ID te hebben voor elke Description
                                                                                                                                                                                                                                                                                             rule
110 The report has a more descriptive description in field 'Description'.\nThese elaborate on the identifying ID.As ID is the identifier, and Description the elaboration,\ngiven the Description one should only find one ID.\nThis rule verifies the relation:\nDescriptions equal => IDs equal
                                                                    condition
110 All IDs and Descriptions pairs in which one Description has multiple IDs.
                                                                                                    Feedback      rule_load_date      source_file
110 The outliers has to do with the dealcode inconsistency issue (same deal code for multple legs/positions) 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
110 SELECT \r\n\tdetails.id as insid,\r\n\tdetails.[Description], \r\n\tnum_ids, \r\n\tdetails.ID, \r\n\tcount(*) as num_trades\r\nFROM (\r\n\tSelect \r\n\t\t[Description], \r\n\t\tCount(DISTINCT(ID)) as num_ids\r\n\tFrom\r\n\t\tSourceData.dbo.GL_Xls_Riskforwards\r\n\tGroup by \r\n\t\t[Description]\r\n\tHaving\r\n\t\tCount(DISTINCT([ID])) > 1\r\n\t) as multiple_ids\r\nleft join \r\n\tSourceData.Dbo.GL_Xls_Riskforwards as details\r\non details.[Description]=multiple_ids.[Description]\r\nGROUP BY\r\n\tdetails.ID, details.[Description], num_ids\r\nORDER BY\r\n\t[Description], ID\r\n\r\n
    superset_query
110               
                                 BU system        BR entitytype      Depth Importance           ErrorCause modificationDate ruleOwner         approvedBy approvedDate
111 BU Delta Lloyd Asset Management Globe$ GL_BR0040   currency ValidRange       NEED Export Configuration             <NA>  Treasury NEEDS RE-APPROVING         <NA>
    resultApprovalDate dataelements                      datasource referencedata                                                       en
111               <NA>      FXRATE  GL_vx_riskforwards_xls_matching             0 The FXRate is defined with 9 decimals precision (Globe$)
                                                   nl
111 De Fxrate maakt gebruik van 9 cijfers na de komma
                                                                                                                                                                                                           rule
111 The FXRates are downloaded from Bloomberg, and available in Portia, with a precision of 9 decimals.\nThis precision should be used everywhere\nThe only exception is EUR, which should always be exactly 1.
                                                                                        condition
111 All currencies defined with an fxrate which does not change when rounded to 8 decimal places.
                                                                                                   Feedback      rule_load_date      source_file
111 When a trade is initiated, the market standard is 4 - 5 decimal points. Max decimal points allowed is 9 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                     query
111 select\r\n\tCurrency\t\t\t\t\t\t\t\tAS fxid,\r\n\tCurrency,\r\n\tspotrate\t\t\t\t\t\t\t\tAS export_spotrate,\r\n\tdb_spotrate\t\t\t\t\t\t\t\tAS database_spotrate\r\nfrom\r\n\tSourceData.dbo.GL_vx_riskforwards_xls_matching\r\ngroup by\r\n\tCurrency, spotrate, db_SpotRate\r\nHaving\r\n\tdb_SpotRate != SpotRate
    superset_query
111               
                                 BU system        BR entitytype      Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate resultApprovalDate
112 BU Delta Lloyd Asset Management Globe$ GL_BR0041   currency ValidRange       NEED      Input             <NA>  Treasury Ramon Roos         <NA>               <NA>
    dataelements         datasource referencedata                                                                        en
112     CURRENCY GL_vx_riskforwards             0 All fxtrades currencies should have a standard length of three characters
                                                                         nl
112 Alle fxtrade currencies hebben een (standaard)lengte van drie chracters
                                                                                                                                                   rule
112 Each fx trade currency has a standard three character length. This rule verifies that the currency values have the specified three character length
                                                   condition Feedback      rule_load_date      source_file
112 All fx trades having a Currency with length other than 3 Approved 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                           query
112 SELECT\r\n\tCurrency\t\tAS fxid,\r\n\tID\t\t\t\tAS IDENTIFIER,\r\n\tDealCode,\r\n\tCurrency\r\nFROM\r\n  SourceData.dbo.GL_vx_riskforwards\r\nWHERE LEN(Currency) != 3 OR UPPER(Currency) != Currency;
    superset_query
112               
                                 BU system        BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate
113 BU Delta Lloyd Asset Management Globe$ GL_BR0043      trade SelfConsistent       NEED      Input             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate      dataelements      datasource referencedata                                        en
113               <NA> DLAM.Asset.Type.2 GL_xls_cashrisk             0 DLAM AssetType2 should relate to DealCode
                                                           nl
113 DLAM AssetType2 dient gerelateerd te zijn aan de DealCode
                                                                                                                                                                                               rule
113 WHEN Dealcode = 'cash'    THEN 'Cash' \nWHEN Dealcode = 'Repo'   THEN 'Repo'\nWHEN Dealcode = 'Collateral' THEN 'Collateral'\nWHEN SUBSTRING(Dealcode,1,2) IN ('DP', 'CM', 'SL') THEN 'Deposit'
                                   condition
113 Instruments where relation does not hold
                                                                                                                                                                                                                                                                                                                          Feedback
113 Fred:Approved, seems logical, check with Ramon (substring values). Ramon: The substring should take 3 characters and not two in order to match the DLAM.Asset.Type.2 values with its corresponding dealcode. Other values should also be included in the substring condition such as values for CMT (call money taken), e.t.c.
         rule_load_date      source_file
113 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       query
113 SELECT\r\n\t\tAST2.*\r\nFROM\r\n(SELECT  \r\n\t\tID\t\t\t\t\t\tAS insid,\r\n\t\tDealcode\t\t\t\tAS tradeid,\r\n\t\tPortfolioName\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDealcode,\r\n\t\tDLAssetType2,\r\n\t\tCASE \r\n\t\t\tWHEN Dealcode = 'cash'\t\t\tTHEN 'Cash' \r\n\t\t\tWHEN Dealcode = 'Repo'\t\t\tTHEN 'Repo'\r\n\t\t\tWHEN Dealcode = 'Collateral'\tTHEN 'Collateral'\r\n\t\t\tWHEN SUBSTRING(Dealcode,1,2) IN ('DP', 'CM', 'SL') THEN 'Deposit'\r\n\t\tEND AS DLAssetType2_Derived\t\r\nFROM [SourceData].[dbo].GL_xls_cashrisk)\tAS AST2\r\nWHERE ISNULL(DLAssetType2, 'NO VALUE') != ISNULL(DLAssetType2_Derived, 'NO VALUE2')\r\n
    superset_query
113               
                                 BU system        BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate
114 BU Delta Lloyd Asset Management Globe$ GL_BR0044      trade SelfConsistent       NEED      Input             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate                dataelements           datasource referencedata                                                             en
114               <NA> MARKET_VALUE, NOMINAL_VALUE GL_xls_cashrisk_orig             0 When currency is 'EUR' bedragvv should be equal to MarketValue
                                                                                          nl                                                           rule
114 Wanneer de currency gelijk is aan 'EUR' dient de MarktWaarde gelijk aan bedragvv te zijn When currency is 'EUR' bedragvv should be equal to MarketValue
                                                                                condition                                      Feedback      rule_load_date
114 Instruments where currency is equal to 'EUR' and MarketValue is not equal to bedragvv Fred:Approved, seems logical. Ramon: Approved 2016-04-25 14:20:58
         source_file
114 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                          query
114 SELECT  \r\n\t\tID\t\t\t\t\t\t\t\t\tAS insid,\r\n\t\tDealcode\t\t\t\t\t\t\tAS tradeid,\r\n\t\tPortfolioName\t\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tBedraginEUROS\t\t\t\t\t\tAS MARKET_VALUE,\r\n\t\tBedraginEUROS\t\t\t\t\t\tAS NOMINAL_VALUE,\r\n\t\tBedragvv\r\nFROM [SourceData].[dbo].GL_xls_cashrisk\r\nWHERE BedraginEUROS != Bedragvv AND Currency = 'EUR'\r\n
    superset_query
114               
                                 BU system        BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate
115 BU Delta Lloyd Asset Management Globe$ GL_BR0045      trade SelfConsistent       NEED      Input             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate                dataelements      datasource referencedata                                                                      en
115               <NA> MARKET_VALUE, NOMINAL_VALUE GL_xls_cashrisk             0 When currency is not 'EUR' bedragvv should not  be equal to MarketValue
                                                                                          nl                                                                    rule
115 Wanneer de currency gelijk is aan 'EUR' dient de MarktWaarde gelijk aan bedragvv te zijn When currency is not 'EUR' bedragvv should not  be equal to MarketValue
                                                                                condition
115 Instruments where currency is not equal to 'EUR' and MarketValue is equal to bedragvv
                                                                            Feedback      rule_load_date      source_file
115 Fred:Approved, seems logical; double check on pegged currencies. Ramon: Approved 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                       query
115 SELECT \r\n\tDealcode\t\t\t\t\tAS tradeid, \r\n\tID\t\t\t\t\t\t\tAS insid,\r\n\tPortfolioName\t\t\t\tAS prfid,\r\n\tID\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tBedraginEUROS\t\t\t\tAS MARKET_VALUE,\r\n\tBedraginEUROS\t\t\t\tAS NOMINAL_VALUE,\r\n\tBedragvv\r\nFROM \r\n\t[SourceData].[dbo].GL_xls_cashrisk\r\nWHERE\r\n\tBedraginEUROS = Bedragvv \r\n\tAND ISNULL(Currency, 'NO VALUE') != 'EUR' \r\n\tand ISNULL(Bedragvv, 1) != 0
    superset_query
115               
                                 BU system        BR entitytype          Depth Importance           ErrorCause modificationDate ruleOwner   approvedBy approvedDate
116 BU Delta Lloyd Asset Management Globe$ GL_BR0046      trade SelfConsistent       NICE Export Configuration             <NA>  Treasury Fred Schutle         <NA>
    resultApprovalDate dataelements      datasource referencedata                                                                                                  en
116               <NA>     SECURITY GL_vx_xls_fxpms             0 Description should be concated with values for BuyCurrency, BuyAmount, Sell Currency and SellAmount
                                                                                                           nl
116 Description dient gelijk te zijn aan samenvoeging van BuyCurrency, BuyAmount, Sell Currency en SellAmount
                                                                                    rule
116 The description is created by concatenating sell,buy, buy currency and sell currency
                                                                                condition
116 description does not equal the concatenation sell,buy, buy currency and sell currency
                                                                                                                                                                                                                                                         Feedback
116 Fred: description is missing in the source system. This is a free format field for FRM. The errors derived are due to 'design' issues. No consistent policy regarding the description format. (Is there a solvency II requirement for the description field?)
         rule_load_date      source_file
116 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               query
116 select\t\r\n\t\tDealCode\t\t\t\tAS tradeid,\r\n\t\tIDBuy\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\tAS prfid,\r\n\t\tIDBuy,\r\n\t\tIDSell,\r\n\t\tDealCode,\r\n\t\tExpectedDescription,\r\n\t\t[Description],\r\n\t\tCCYBuy,\r\n\t\tBuy_Amount,\r\n\t\tCCYSell,\r\n\t\tSell_Amount\r\nfrom (\r\n  Select \r\n  \tConcat('FX Buy' , ' ' , CCYBuy , LTRIM(STR(Buy_Amount, 20, 0)) , ' ' , 'Sell' , ' ' , CCYSell , LTRIM(STR(Sell_Amount, 20, 0))) As ExpectedDescription , \r\n    *\r\n  from SourceData.dbo.GL_vx_xls_fxpms\r\n  ) as fxrisk_extra\r\nwhere ISNULL(ExpectedDescription, 'NO VALUE') !=[Description]
    superset_query
116               
                                 BU system        BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate
117 BU Delta Lloyd Asset Management Globe$ GL_BR0048   currency SelfConsistent       NEED      Input             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements                      datasource referencedata                                               en
117               <NA>     CURRENCY GL_vx_riskforwards_xls_matching             0 Buy Currency shouldn't be equal to sell currency
                                                               nl
117 De gekochte munt dient ongelijk te zijn aan de verkochte munt
                                                                                                                                                                                                                                                                                                                            rule
117 This rule verifies that the trade is an actual trade.The bought and sold currency are copied to separate rows in the risk forwards export.To be able to compare the currencies this rule is applied on the underlying fx deal.\nThis rule works on the exports (fxpms) which are the source of the ForwardsHist excel export
                                                      condition                                 Feedback      rule_load_date      source_file
117 All fx deals having a BuyCurrency equal to the SellCurrency Fred:Approved,  logical, Ramon: Approved 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                          query
117 Select \r\n\tBuyCurrency\t\t\tAS fxid,\r\n\tDealCode, \r\n\tBuycurrency, \r\n\tSellcurrency\r\nFrom \r\n  SourceData.dbo.GL_vx_fxdeals\r\nWhere\r\n  Buycurrency=Sellcurrency;\r\n
    superset_query
117               
                                 BU system        BR entitytype          Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
118 BU Delta Lloyd Asset Management Globe$ GL_BR0049      trade SelfConsistent       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements                      datasource referencedata                                                                                 en
118               <NA>        PRICE GL_vx_riskforwards_xls_matching             0 The riskforwards report should have the same SpotRateTrade as the database(Portia)
                                                                               nl
118 Het RiskForwards raport dient gelijke SpotRateTrade te hebben als de database
                                                                                                                                                                                                                                        rule
118 The report is generated within excel by macros, based upon an export on Globe$.This businessrule verifies those rows that are available in both the database and the excel report.These rows are verified to have an equal SpotRateTrade
                                                                                                               condition
118 All transactions (both legs) that exist both in the excel report and the database which have unequal SpotRateTrades.
                                                                                                                                                                                           Feedback
118 Fred:Approved, seems logical - Check with Ramon. Ramon: Approved, they should be the same. The primary source for the SpotRate trade is from Portia (actual data for is derived from bloomberg)
         rule_load_date      source_file
118 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    query
118 select\r\n\ttheID\t\t\t\t\t\t\t\tAS insid,\r\n\ttheDealCode\t\t\t\t\t\t\tAS tradeid,\r\n\tPortfolioName\t\t\t\t\t\tAS prfid,\r\n\tTheSystem,\r\n\ttheDealCode\t\t\t\t\t\t\tAS DealCode,\r\n\ttheDescription\t\t\t\t\t\tAS Description,\r\n\ttheTradeDate\t\t\t\t\t\tAS TradeDate,\r\n\ttheSettleDate\t\t\t\t\t\tAS SettleDate,\r\n\tdb_SpotRate,\r\n\tSpotRate\r\nfrom\r\n\tSourceData.dbo.GL_vx_riskforwards_xls_matching\r\nwhere\r\n\tTheSystem='DBXL' and\r\n\tdb_SpotRate != SpotRate\r\norder by \r\n\ttheDealCode,\r\n\ttheTradeDate,\r\n\ttheSettleDate\r\n
    superset_query
118               
                                 BU system        BR entitytype          Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
119 BU Delta Lloyd Asset Management Globe$ GL_BR0050 instrument SelfConsistent       NICE Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements                      datasource referencedata                                                                      en
119               <NA>   IDENTIFIER GL_vx_riskforwards_xls_matching             0 The riskforwards report should have the same ID as the database(Globe$)
                                                                    nl
119 Het RiskForwards raport dient gelijke ID te hebben als de database
                                                                                                                                                                                                                               rule
119 The report is generated within excel by macros, based upon an export on Globe$\nThis businessrule verifies those rows that are available in both the database and the excel report. These rows are verified to have an equal ID
                                                                                                                                                                                                               condition
119 All transactions (both legs) that exist both in the excel report and the database which have unequal ID. Matching between excel and the database is done on TradeDate, SettleDate, DealCode, Globescode and Currency
                                         Feedback      rule_load_date      source_file
119 Fred:Approved, seems logical. Ramon: Approved 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         query
119 select\r\n\tDealcode\t\t\t\t\t\t\tAS tradeid,\r\n\tID\t\t\t\t\t\t\t\t\tAS insid,\r\n\tPortfolioName\t\t\t\t\t\tAS prfid,\r\n\tID\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t[db_ID],\r\n\tGlobesCode,\r\n\tdb_GlobesCode,\r\n\tPortfolio,\r\n\tdb_portfolio,\r\n\tTheSystem,\r\n\tTheDescription\t\t\t\t\t\tas Description,\r\n\ttheDealCode\t\t\t\t\t\t\tas DealCode,\r\n\ttheTradeDate\t\t\t\t\t\tas TradeDate,\r\n\ttheSettleDate\t\t\t\t\t\tas SettleDate,\r\n\ttheCurrency\t\t\t\t\t\t\tas CURRENCY\r\nfrom\r\n\tSourceData.dbo.GL_vx_riskforwards_xls_matching\r\nwhere\r\n\tISNULL(TheSystem, 'DBXL') ='DBXL' and\r\n\tISNULL([db_ID], 'NO VALUE') != ID\r\norder by \r\n\ttheDealCode,\r\n\ttheTradeDate,\r\n\ttheSettleDate
    superset_query
119               
                                 BU system        BR entitytype          Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
120 BU Delta Lloyd Asset Management Globe$ GL_BR0051      trade SelfConsistent       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements                      datasource referencedata                                                                  en
120               <NA>       FXRATE GL_vx_riskforwards_xls_matching             0 The riskforwards report should have the same FXrate as the database
                                                                        nl
120 Het RiskForwards raport dient gelijke FXrate te hebben als de database
                                                                                                                                                                                                                                     rule
120 The report is generated within excel by macros, based upon an export on Globe$. This businessrule verifies those rows that are available in both the database and the excel report. These rows are verified to have an equal SpotRate
                                                                                                                                                                                                                     condition
120 All transactions (both legs) that exist both in the excel report and the database which have unequal SpotRate. Matching between excel and the database is done on TradeDate, SettleDate, DealCode, Globescode and Currency
                                         Feedback      rule_load_date      source_file
120 Fred:Approved, seems logical. Ramon: Approved 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        query
120 select\r\n\ttheDealcode\t\t\t\t\t\tAS tradeid,\r\n\ttheID\t\t\t\t\t\t\tAS insid,\r\n\tdb_GlobesPortfolioName\t\t\tAS prfid,\r\n\ttheID\t\t\t\t\t\t\tas IDENTIFIER,\r\n\tTheSystem,\r\n\tTheDescription as Description,\r\n\ttheDealCode as DealCode,\r\n\ttheTradeDate as TradeDate,\r\n\ttheSettleDate as SettleDate,\r\n\ttheCurrency as Currency,\r\n\tdb_FXRate, FXRate,\r\n\tdb_SpotRate, SpotRate\r\nfrom\r\n\tSourceData.dbo.GL_vx_riskforwards_xls_matching\r\nwhere\r\n\tISNULL(TheSystem, 'DBXL') ='DBXL' and\r\n\t(ROUND([db_FXRate], 4) != ROUND(FXRate, 4) OR db_FXRate IS NULL)\r\norder by \r\n\ttheDealCode,\r\n\ttheTradeDate,\r\n\ttheSettleDate
    superset_query
120               
                                 BU system        BR entitytype           Depth Importance           ErrorCause modificationDate ruleOwner
121 BU Delta Lloyd Asset Management Globe$ GL_BR0052      trade OtherConsistent       NEED Export Configuration             <NA>  Treasury
                                                 approvedBy approvedDate resultApprovalDate      dataelements          datasource referencedata
121 Ramon weet niet of regel klopt: samen met Fred nakijken         <NA>               <NA> DLAM.Asset.Type.2 GL_xls_riskforwards             0
                                                                     en                                                  nl
121 DLAM AssetType 2 should not be NULL and be equal to 'FX Derivative' DLAMAssettype2 moet gelijk zijn aan 'FX Derivative'
                                                                                                        rule                                      condition Feedback
121 Based on the underlying asset and asset class tree, DLAM asset class2 should be equal to 'FX Derivative' All DLAM AssetType2 != 'Fx Derivative' or NULL        0
         rule_load_date      source_file
121 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                              query
121 SELECT \r\n\t\tDealcode\t\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLAssetType2,\r\n\t\tDLAssetType3\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE ISNULL(DLAssetType2, 'NO VALUE') != 'FX Derivative'
    superset_query
121               
                                 BU system        BR entitytype           Depth Importance           ErrorCause modificationDate ruleOwner
122 BU Delta Lloyd Asset Management Globe$ GL_BR0053      trade OtherConsistent       NEED Export Configuration             <NA>  Treasury
                                                 approvedBy approvedDate resultApprovalDate      dataelements          datasource referencedata
122 Ramon weet niet of regel klopt: samen met Fred nakijken         <NA>               <NA> DLAM.Asset.Type.3 GL_xls_riskforwards             0
                                                                  en                                               nl
122 DLAM AssetType 3 should not be NULL and be equal to 'FX Forward' DLAMAssettype3 moet gelijk zijn aan 'FX Forward'
                                                                                                     rule                                      condition Feedback
122 Based on the underlying asset and asset class tree, DLAM asset class3 should be equal to 'FX Forward' All DLAM AssetType3 != 'Fx Derivative' or NULL        0
         rule_load_date      source_file
122 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                               query
122 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLAssetType2,\r\n\t\tDLAssetType3\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE ISNULL(DLAssetType3, '') != 'FX Forward'
    superset_query
122               
                                 BU system        BR entitytype           Depth Importance           ErrorCause modificationDate ruleOwner
123 BU Delta Lloyd Asset Management Globe$ GL_BR0054      trade OtherConsistent       NEED Export Configuration             <NA>  Treasury
                                                 approvedBy approvedDate resultApprovalDate dataelements          datasource referencedata
123 Ramon weet niet of regel klopt: samen met Fred nakijken         <NA>               <NA> DLAM.Sector1 GL_xls_riskforwards             0
                                                               en                                            nl
123 DLAM.Sector1 should not  be NULL and be equal to 'Corporates' DLAMSector1 moet gelijk zijn aan 'Corporates'
                                                             rule                                                       condition Feedback      rule_load_date
123 DLAM.Sector1 should not  be NULL and be equal to 'Corporates' DLAM.Sector1 equals  NULL and and does not equals  'Corporates'        0 2016-04-25 14:20:58
         source_file
123 globe$_rules.csv
                                                                                                                                                                                                                                                                              query
123 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLSector1,\r\n\t\tDLSector2,\r\n\t\tDLSector3\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE ISNULL(DLSector1, 'NO VALUE') != 'Corporates'
    superset_query
123               
                                 BU system        BR entitytype           Depth Importance           ErrorCause modificationDate ruleOwner
124 BU Delta Lloyd Asset Management Globe$ GL_BR0055      trade OtherConsistent       NEED Export Configuration             <NA>  Treasury
                                                 approvedBy approvedDate resultApprovalDate dataelements          datasource referencedata
124 Ramon weet niet of regel klopt: samen met Fred nakijken         <NA>               <NA> DLAM.Sector2 GL_xls_riskforwards             0
                                                               en                                            nl
124 DLAM.Sector2 should not  be NULL and be equal to 'Financials' DLAMSector2 moet gelijk zijn aan 'Financials'
                                                             rule                                                       condition Feedback      rule_load_date
124 DLAM.Sector2 should not  be NULL and be equal to 'Financials' DLAM.Sector2 equals  NULL and and does not equals  'Financials'        0 2016-04-25 14:20:58
         source_file
124 globe$_rules.csv
                                                                                                                                                                                                                                                                                  query
124 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLSector1,\r\n\t\tDLSector2,\r\n\t\tDLSector3\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE ISNULL(DLSector2, 'NO VALUE') != 'Financials'\r\n
    superset_query
124               
                                 BU system        BR entitytype           Depth Importance           ErrorCause modificationDate ruleOwner
125 BU Delta Lloyd Asset Management Globe$ GL_BR0056      trade OtherConsistent       NEED Export Configuration             <NA>  Treasury
                                                 approvedBy approvedDate resultApprovalDate dataelements          datasource referencedata
125 Ramon weet niet of regel klopt: samen met Fred nakijken         <NA>               <NA> DLAM.Sector3 GL_xls_riskforwards             0
                                                               en                                            nl
125 DLAM.Sector3 should not  be NULL and be equal to 'Financials' DLAMSector3 moet gelijk zijn aan 'Financials'
                                                             rule                                                       condition Feedback      rule_load_date
125 DLAM.Sector3 should not  be NULL and be equal to 'Financials' DLAM.Sector3 equals  NULL and and does not equals  'Financials'        0 2016-04-25 14:20:58
         source_file
125 globe$_rules.csv
                                                                                                                                                                                                                                                                                  query
125 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLSector1,\r\n\t\tDLSector2,\r\n\t\tDLSector3\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE ISNULL(DLSector3, 'NO VALUE') != 'Financials'\r\n
    superset_query
125               
                                 BU system        BR entitytype           Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
126 BU Delta Lloyd Asset Management Globe$ GL_BR0057  portfolio OtherConsistent       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate   dataelements          datasource referencedata                                                                                   en
126               <NA> PORTFOLIO_NAME GL_xls_riskforwards             0 The riskforwards report should only use PortfolioName that actually exist in portia.
                                                                                                     nl
126 Het RiskForwards raport dient alleen PortfolioName te gebruiken die daadwerkelijk in portia bestaat
                                                                                                                                                                                                                       rule
126 The report is generated within excel by macros, based upon an export on Globe$\nThe excel macros map globe$ codes to portia portfolio names.\nThis businessrule verifies the mapped-to values actually exist in portia.
                                                                                              condition                                      Feedback
126 All transactions (both legs) that have a portfolio name that does not exist in the portia database. Fred:Approved, seems logical. Ramon: Approved
         rule_load_date      source_file
126 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
126 \r\nSELECT  DISTINCT\r\n\t  GL.PortfolioName\t\t\t\t\t\tAS prfid\r\n\t  ,GL.[Globescode]\r\n      ,GL.[portfolio]\r\n\t  ,GL.PortfolioName\r\n\t  ,GL.Dealcode\r\n\t  ,GL.Tradedate\r\n\t  ,GL.Settledate\r\n\t  ,GL.Currency\r\n\t  ,GL.[Description]\r\n\t  ,GL.ID\r\n  FROM [GL_xls_riskforwards] as GL\r\n\tleft join vx_PO_portfolio AS PO \r\n\t\ton GL.PortfolioName = PO.PORTFOLIO_NAME COLLATE Latin1_General_CI_AS\r\n  where PO.PORTFOLIO_NAME is null\r\n
    superset_query
126               
                                 BU system        BR entitytype           Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
127 BU Delta Lloyd Asset Management Globe$ GL_BR0058   currency OtherConsistent       NEED Export Configuration             <NA>  Treasury          0         <NA>
    resultApprovalDate dataelements                  datasource referencedata                                                      en
127               <NA>      FXRATE  PO_fxs, GL_xls_riskforwards             0 The spotrate should correspond with the Portia spotrate
                                                            nl
127 De spotrate dient gelijk te zijn aan de spotrate in Portia
                                                                                                                                                                                                                                                                                                                                                                                 rule
127 The FXRates are downloaded from Bloomberg, and available in Portia, with a precision of 10 decimals.\nThe Globe$ macro downloads the inverse (1/fxrate) of these rates to multiply with the values in local currency. It however seems rounded to 4 digits\nThis rule therefore uses the high precision spotrate (WISSELKOERS) and compares it with the values in the excelsheet.
                                                                                                                                                                                                                                                   condition
127 All currencies defined with a spotrate that is different from the wisselkoers as exported from portia. Only differences in the 9 decimal digits are regarded significant.\nTrades in EUR are ignored, and trades where the spotrate = 1 are also ignored
                                         Feedback      rule_load_date      source_file
127 Fred:Approved, seems logical. Ramon: Approved 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        query
127 select\r\n\tCurrency\t\t\t\t\t\t\tAS fxid,\r\n\tCurrency\t\t\t\t\t\t\tAS CURRENCY,\r\n\tspotrate\t\t\t\t\t\t\tAS FXRate,\r\n\tWISSELKOERS,\r\n\tDATUM,\r\n\twisselkoers-spotrate\t\t\t\tas delta\r\nfrom\r\n\t(\r\n\tselect\r\n\t\tCurrency,\r\n\t\tspotrate\r\n\tfrom\r\n\t\tSourceData.dbo.GL_xls_riskforwards\r\n\tgroup by\r\n\t\tCurrency, spotrate\r\n\t) as globes_spotrates\r\n\tleft join\r\n\tSourceData.dbo.GL_exchangerates on globes_spotrates.Currency=GL_exchangerates.CODE\r\nwhere\r\n\tabs(wisselkoers-spotrate)>1e-9\r\n\tand (ISNULL(Currency, 'NO CURRENCY') != 'EUR' OR ISNULL(spotrate,0) !=1) --surrounded fields in comparison with ISNULL to prevent condition falsely being evaluated as false
    superset_query
127               
                                 BU system        BR entitytype                Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate
128 BU Delta Lloyd Asset Management Globe$ GL_BR0059      trade ExternallyConsistent       NEED      Input             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate            dataelements                       datasource referencedata                                                                      en
128               <NA> NOMINAL_VALUE, QUANTITY GL_vx_fxdeals_bloomberg_matching             0 Bloomberg and Globe$ should have at least one matching FX forward trade
                                                                                    nl
128 Bloomberg en Globe$ dienen minstens een overeenkomende FX forward trades te hebben
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           rule
128 The FX trades (swaps, outrights and spots with future settlement dates) in Bloomberg should match with those in Globe$ having the same daterange.A match is based on matching tradedate, buy amount, sellamount, counterparty and account no.Because of the implicit fx rate due to the given buy and sellamount, the currencies do not have to be included in the match filter.NULL values for fields with BB_ prefix indicate that no matching record could be found in BloomBerg.NULL values for fields without BB_ prefix indicate that no matching record could be found in Globe$ because of differences in counterparty descriptions only the first 8 characters are used case insensitive for matching.This rule verifies that each record in Bloomberg has (at least) one matching record in Globe$ and vice-versa.Together with business rule BR0059 it is verified that there is exactly one match.This rule works on the exports (fxpms) which are the source of the ForwardsHist excel export 
                                                                          condition
128 All FX records which either do not exist in Bloomberg or do not exist in Globe$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     Feedback
128 4-6-2015: BR description accepted by Ramon Roos.\nFor validation, it is imperative that matching transaction records exists between Bloomberg and Globe$. \nKristine Prahl ensures the consistency of trade records between Bloomberg and Globe$ on a daily basis.  11-6-2015: Ramon indicated that 'TWD' buy currency is an exception due to the issues regarding trades with that currency. For instance,  Delta Llyod has to make an application to their custodian to initiate an fxtrade since traiding in taiwanese dollar is currently restricted. An exception also applies to all trades with 'Bank de Luxembourg' as counterparty. Nonetheless, Ramon will work on resolving the issues regarding the outliers.
         rule_load_date      source_file
128 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            query
128 select \r\n\tCASE WHEN BB_TradeId IS NULL THEN GL_DealCode\r\n\tELSE ltrim(STR(BB_TradeId))\r\n\tEND\t\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\tCASE WHEN BB_Portfolio IS NULL THEN GL_portfolio\r\n\tELSE BB_Portfolio\t\r\n\tEND\t\t\t\t\t\t\t\t\t\t\t\tAS prfid,\r\n\tTheBuyCcy,\r\n\tTheSellCcy,\r\n\tBB_TradeId,\r\n\tGL_DealCode,\r\n\tBB_TradeDate,\r\n\tGL_TradeDate,\r\n\tBB_BuyAmount,\r\n\tGL_BuyAmount,\r\n--\tBB_BuyAmount_premiumed,\r\n\tBB_SellAmount,\r\n--\tBB_SellAmount_premiumed,\r\n\tGL_SellAmount,\r\n\r\n\tBB_Tegenpartij,\r\n\tGL_TegenPartij\r\n\r\nfrom SourceData.dbo.GL_vx_fxdeals_bloomberg_matching\r\nwhere \r\n\t(\r\n\tGL_DealCode is null -- no exact matching globes record\r\n\tor BB_TradeId is NULL -- no exact matching BB record\r\n\t) \r\n\torder by \r\n\t\tTheDate ASC,\r\n\t\tTheBuyCcy,\r\n\t\tTheSellCcy,\r\n\r\n\t\tTheSellAmount ASC,\r\n\t\tTheBuyAmount ASC,\r\n\r\n\t\tISNULL(BB_Tegenpartij, GL_Tegenpartij) ASC\r\n--\t\tTheMaxAmount ASC
    superset_query
128               
                                 BU system        BR entitytype                Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate
129 BU Delta Lloyd Asset Management Globe$ GL_BR0060      trade ExternallyConsistent       NEED      Input             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate            dataelements                       datasource referencedata                                                                     en
129               <NA> NOMINAL_VALUE,QUANTITY  GL_vx_fxdeals_bloomberg_matching             0 Bloomberg and Globe$ should have at most one matching FX forward trade
                                                                                   nl
129 Bloomberg en Globe$ dienen maximaal een overeenkomende FX forward trade te hebben
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        rule
129 The FX trades (swaps, outrights and spots with future settlement dates) in Bloomberg should match with those in Globe$ having the same daterange.A match is based on matching tradedate, buy amount, sellamount, counterparty and account no.Because of the implicit fx rate due to the given buy and sellamount, the currencies do not have to be included in the match filter.NULL values for fields with BB_ prefix indicate that no matching record could be found in BloomBerg.NULL values for fields without BB_ prefix indicate that no matching record could be found in Globe$ because of differences in counterparty descriptions only the first 8 characters are used case insensitive for matching.This rule verifies that each record in Bloomberg has at most one matching record in Globe$ and vice-versa.Together with business rule BR0060 it is verified that there is exactly one match.This rule works on the exports (fxpms) which are the source of the ForwardsHist excel export.
                                                                  condition
129 All records in Globe$ which have multiple bloomberg ID's attached to it
                                                                                                                                                                                                                                                   Feedback
129 BR description accepted by Ramon Roos.\nFor validation, it is imperative that matching transaction records exists between Bloomberg and Globe$. \nKristine Prahl ensures the consistency of trade records between Bloomberg and Globe$ on a daily basis
         rule_load_date      source_file
129 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 query
129 select \r\n\tBB_TradeId\t\t\t\t\t\tAS tradeid,\r\n\tBB_Portfolio\t\t\t\t\tAS prfid,\r\n\t--all_matches.Description\t\t\tAS insid,\r\n\tnum_BB,\r\n\t--BB_TradeId,\r\n\tall_matches.GL_DealCode,\r\n\tall_matches.GL_BuyAmount,\r\n\tall_matches.GL_SellAmount,\r\n\tall_matches.GL_TradeDate\r\n\t\r\nfrom (\r\n\tselect \r\n\t\tGL_DealCode\t\t\t\t\tas Dup_DealCode, \r\n\t\tGL_BuyAmount\t\t\t\tas Dup_BuyAmount, \r\n\t\tGL_SellAmount\t\t\t\tas Dup_SellAmount, \r\n\t\tGL_TradeDate\t\t\t\tas Dup_TradeDate, \r\n\t\tcount(distinct(BB_TradeId)) as num_BB\r\n\tfrom SourceData.dbo.GL_vx_fxdeals_bloomberg_matching\r\n\twhere BB_TradeId is not NULL and GL_DealCode is not null\r\n\tgroup by GL_DealCode, GL_BuyAmount, GL_SellAmount, GL_TradeDate\r\n\thaving count(distinct(BB_TradeId))>1\r\n\t) as bb_gl_duplicate_matches\r\n\tleft join SourceData.dbo.GL_vx_fxdeals_bloomberg_matching as all_matches\r\n\t\ton bb_gl_duplicate_matches.Dup_DealCode\t\t= all_matches.GL_DealCode\r\n\t\tand bb_gl_duplicate_matches.Dup_BuyAmount\t= all_matches.GL_BuyAmount\r\n\t\tand bb_gl_duplicate_matches.Dup_SellAmount\t= all_matches.GL_SellAmount\r\n\t\tand bb_gl_duplicate_matches.Dup_TradeDate\t= all_matches.GL_TradeDate\r\norder by\r\n\tbb_gl_duplicate_matches.Dup_DealCode asc, BB_TradeId asc\r\n
    superset_query
129               
                                 BU system        BR entitytype                Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate
130 BU Delta Lloyd Asset Management Globe$ GL_BR0061   currency ExternallyConsistent       NEED      Input             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements                       datasource referencedata                                                                   en
130               <NA>    CURRENCY  GL_vx_fxdeals_bloomberg_matching             0 Matching Bloomberg and Globe$ FX trades should have equal currencies
                                                                                  nl
130 Overeenkomende Bloomberg en Globe$ FX trades dienen gelijke currencies te hebben
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 rule
130 The FX trades (swaps, outrights and spots with future settlement dates) in Bloomberg should match with those in Globe$ having the same daterange. A match is based on matching tradedate, buy amount, sellamount, counterparty and account no Because of the implicit fx rate due to the given buy and sellamount, the currencies do not have to be included in the match filter. NULL values for fields with BB_ prefix indicate that no matching record could be found in BloomBerg.NULL values for fields without BB_ prefix indicate that no matching record could be found in Globe$ because of differences in counterparty descriptions only the first 8 characters are used case insensitive for matching.This rule verifies that the implicit currencies are actually equal in Bloomberg and Globe$.fxpms.\nThis rule works on the exports (fxpms) which are the source of the ForwardsHist excel export.
                                                                                                             condition
130 All FX records in Bloomberg and Globe$ that match on date and quantities but do not have matching currency symbols
                                                                                                                                                                                                                                                   Feedback
130 BR description accepted by Ramon Roos.\nFor validation, it is imperative that matching transaction records exists between Bloomberg and Globe$. \nKristine Prahl ensures the consistency of trade records between Bloomberg and Globe$ on a daily basis
         rule_load_date      source_file
130 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   query
130 select \r\n\t\tBB_TradeId\t\t\t\t\t\t\t\t\t\tAS tradeid,\r\n\t\tGL_PortfolioName\t\t\t\t\t\t\t\tAS prfid,\r\n\t\tCONCAT(GL_BuyCurrency,  '', GL_SellCurrency)\tAS fxid,\r\n\t\tBB_TradeId,\r\n\t\tBB_BuyCurrency,\r\n\t\tGL_BuyCurrency,\r\n\t\tBB_SellCurrency,\r\n\t\tGL_SellCurrency\r\nfrom SourceData.dbo.GL_vx_fxdeals_bloomberg_matching\r\nwhere\r\n\t-- matching globes record\r\n\tGL_DealCode is not null \r\n\t-- matching BB record\r\n\tand BB_TradeId is not NULL \r\n\t-- but different currencies\r\n\tand (BB_SellCurrency!=GL_SellCurrency OR BB_BuyCurrency!=GL_BuyCurrency) \r\n\torder by \r\n\t\t--Ordered by date and max ammount such that probable related are next to each other\r\n\t\tTheDate ASC\r\n
    superset_query
130               
                                 BU system        BR entitytype                Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate
131 BU Delta Lloyd Asset Management Globe$ GL_BR0063      trade ExternallyConsistent       NEED      Input             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements                       datasource referencedata                                                                        en
131               <NA>     MATURITY GL_vx_fxdeals_bloomberg_matching             0 Matching Bloomberg and Globe$ FX trades should have equal settlement date
                                                                                        nl
131 Overeenkomende Bloomberg en Globe$ FX trades dienen gelijke settlement datum te hebben
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     rule
131 The FX trades (swaps, outrights and spots with future settlement dates) in Bloomberg should match with those in Globe$ having the same daterange.A match is based on matching tradedate, buy amount, sellamount, counterparty and account no.\nBecause of the implicit fx rate due to the given buy and sellamount, the currencies do not have to be included in the match filter.\nNULL values for fields with BB_ prefix indicate that no matching record could be found in BloomBerg\nNULL values for fields without BB_ prefix indicate that no matching record could be found in Globe$\nBecause of differences in counterparty descriptions only the first 8 characters are used case insensitive for matching.This rule verifies that the settlement date of the trades in Bloomberg and Globe$ are equal.fxpms.[SETTLEMENT_DATE] is used as Globe$' settle date.\nValueDate is used as BloomBerg's settle date\nThis rule works on the exports (fxpms) which are the source of the ForwardsHist excel export.
                                                                                                            condition
131 All FX records in Bloomberg and Globe$ that match on date and quantities but do not have matching settlement date
                                                                                                                                                                                                                                                   Feedback
131 BR description accepted by Ramon Roos.\nFor validation, it is imperative that matching transaction records exists between Bloomberg and Globe$. \nKristine Prahl ensures the consistency of trade records between Bloomberg and Globe$ on a daily basis
         rule_load_date      source_file
131 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               query
131 select \r\n\tGL_Dealcode\t\t\t\t\t\t\tAS tradeid,\r\n\t--Description\t\t\t\t\t\tAS insid,\r\n\tGL_PortfolioName\t\t\t\t\tAS prfid,\r\n\t--Description\t\t\t\t\t\tAS IDENTIFIER,\r\n\tGL_DealCode,\r\n\tGL_TradeDate,\r\n\tGL_SettleDate,\r\n\tBB_SettleDate,\r\n\tGL_BuyCurrency,\r\n\tGL_SellCurrency,\r\n\tGL_BuyAmount,\r\n\tGL_SellAmount,\r\n\tBB_Leg,\r\n\tGL_Leg,\r\n\tBB_DealType,\r\n\tGL_DealType\r\nfrom \r\n\tSourceData.dbo.GL_vx_fxdeals_bloomberg_matching\r\nwhere\r\n\t-- matching globes record\r\n\tGL_DealCode is not null \r\n\t-- matching BB record\r\n\tand BB_TradeId is not NULL \r\n\t-- but not a matching settlement date\r\n\tand ISNULL(GL_SettleDate, '1900-01-01') !=ISNULL(BB_SettleDate, '1900-01-02')\r\n\t--surrounded fields with ISNULL to prevent not triggering due to NULL values\r\norder by \r\n\t--Ordered by date and max ammount such that probable related are next to each other\r\n\tTheDate ASC
    superset_query
131               
                                 BU system        BR entitytype                Depth Importance ErrorCause modificationDate ruleOwner   approvedBy approvedDate
132 BU Delta Lloyd Asset Management Globe$ GL_BR0064  portfolio ExternallyConsistent       NICE      Input             <NA>  Treasury Ramon Roos           <NA>
    resultApprovalDate    dataelements                       datasource referencedata
132               <NA> PORTFOLIO_NAME  GL_Vx_Fxdeals_Bloomberg_Matching             0
                                                                                           en
132 The Globe$ portfolio and Bloomberg portfolio should have matching portfolio abbreviations
                                                                                                nl                                                       rule
132 De Globe$ portfolio en Bloomberg portfolio diene overeenkomende portfolio afkortinge te hebben Globe$ portfolioname should equal  Bloomberg portfolioname
                                                      condition
132 Bloomberg portfolioname does not equal Globe$ portfolioname
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  Feedback
132 4-6-2015: Mapping of portfolio from Globe$ to BloomBerg is done by Globe$ code to blomberg account number.In blomberg, the verification of Globe$ portfolio \nname is done by mapping the bloomberg account number to the Globe$ code and vice versa.In the alternatively, a manual static data list with \nall blooberg codes. A new inititaive to align the portfolio values for consistentency sake and ease of modification within \nall source systems is currently being implemented by Ramon to avoid tensions between Trade & FRM dept. respectively.\nRequired Standard:\nPortfolio: For investment, first two characters of the Globe$ code = Custodian Value\nLast three characters = Currency\nMid three characters = Portfolio Name. 11-6-2015, mapping is somewhat inconsistent and the questions regarding the actual root cause of the portfolio mismatch should be posed to FRM (Abdel or Quan respectively). The mapping between Globe$ and Bloomberg Portfolio name is logically Approved from Ramon's environment.
         rule_load_date      source_file
132 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         query
132 Select \r\n\tGL_Portfolio\t\t\tAS prfid,\r\n\tGL_PortfolioName\t\tAS PORTFOLIONAME,\r\n\tGL_Portfolio\t\t\tAs Globes_Portfolio , \r\n\tBB_Portfolio\t\t\tAs Bloomberg_Portfolio,\r\n\tCount(*)\t\t\t\tAs Num_Trades\r\nFrom \r\n  SourceData.Dbo.GL_Vx_Fxdeals_Bloomberg_Matching\r\nWhere \r\n  Thesystem = 'BBGL'\r\nGroup By \r\n\tGL_PortfolioName,\r\n\tGL_Portfolio, \r\n\tBB_Portfolio\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\nHaving \r\n  ISNULL(GL_Portfolio, 'No Value Portfolio') != ISNULL(Bb_Portfolio, 'No Value Bb_Portfolio')\r\nOrder By\r\n\tGL_Portfolio,\r\n\tBB_Portfolio
    superset_query
132               
                                 BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner approvedBy approvedDate resultApprovalDate
133 BU Delta Lloyd Asset Management Globe$ GL_BR0065      trade HasValue       NEED      Input             <NA>  Treasury Ramon Roos         <NA>               <NA>
    dataelements              datasource referencedata                               en                                                              nl
133 MARKET_VALUE limieten eigen geld.xls             0 Market_Value should not be empty Marktwaarde en Nominale waarde dienen ongelijk aan NULL te zijn
                                                                                                       rule
133 MarketValue should have a value and MarketValue should not be equal to the empty string or to a string 
                                                                                                                                                          condition
133 Instruments where MarketValue and NominalValue are equal to NULL or are equal to the empty string or are equal to a string that contaisn nothing but whitespace
                                                                                                    Feedback      rule_load_date      source_file
133 An account can have Zero value but not n/a values\nFor fx_deals, an amount of zero or null is unaccepted 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                         query
133 SELECT  \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tBedraginEUROS\t\t\t\t\tAS MARKET_VALUE,\r\n\t\tCurrency\t\t\t\t\t\tAS CURRENCY,\r\n\t\tTegenpartij\t\t\t\t\t\tAS COUNTERPARTY\r\nFROM [SourceData].[dbo].GL_xls_cashrisk\r\nWHERE BedraginEUROS IS NULL OR LEN(RTRIM(BedraginEUROS))=0\r\n
    superset_query
133               
                                 BU system        BR entitytype    Depth Importance           ErrorCause modificationDate ruleOwner approvedBy approvedDate
134 BU Delta Lloyd Asset Management Globe$ GL_BR0066      trade HasValue       NEED Export Configuration             <NA>  Treasury Ramon Roos         <NA>
    resultApprovalDate dataelements       datasource referencedata                         en                      nl                       rule
134               <NA>       FXRATE riskforwards.xls             0 FXRate should not be empty FXRate moet gevuld zijn FXRate should have a value
                                                                                                                                                    condition Feedback
134 Fxrate is called spotrate in the databasse\nFxrate is not NULL and Fxrate is not a string consisting of whitespace only and Fxrate is not an empty string        0
         rule_load_date      source_file
134 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                         query
134 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tspotrate\t\t\t\t\t\tAS FXRATE\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE spotrate IS NULL OR LEN(RTRIM(spotrate))=0
    superset_query
134               
                                 BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner     approvedBy approvedDate
135 BU Delta Lloyd Asset Management Globe$ GL_BR0067      trade HasValue       NEED      Input             <NA>  Treasury Maarten Troost         <NA>
    resultApprovalDate  dataelements       datasource referencedata                                en                             nl
135               <NA> NOMINAL_VALUE riskforwards.xls             0 Nominal_Value should not be empty Nominal_value moet gevuld zijn
                                                                                                         rule
135 Nominal Value should have a value and and should not be equal to  an empty string nor a whitespace string
                                                                                                                                                                                  condition
135 Nominal_Value is called nominallocal  in the databasse\nnominallocal is not NULL and nominallocal is not a string consisting of whitespace only and nominallocal is not an empty string
    Feedback      rule_load_date      source_file
135        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                   query
135 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tNominallocal\t\t\t\t\tAS NOMINAL_VALUE\r\nFROM SourceData.dbo.GL_xls_riskforwards\r\nWHERE Nominallocal IS NULL OR LEN(RTRIM(Nominallocal))=0\r\n\r\n
    superset_query
135               
                                 BU system        BR entitytype    Depth Importance           ErrorCause modificationDate ruleOwner
136 BU Delta Lloyd Asset Management Globe$ GL_BR0068      trade HasValue       NEED Export Configuration             <NA>  Treasury
                               approvedBy approvedDate resultApprovalDate      dataelements              datasource referencedata                                 en
136 Afhankelijk van discussies asset tree         <NA>               <NA> DLAM.Asset.Type.2 limieten eigen geld.xls             0 DLAMAssetType2 should not be empty
                                 nl                                                                                    rule
136 DLAMAssetType2 moet gevuld zijn DLAMAsset Type2 should not be equal to NULL nor an empty string nor a whitespace string
                                                                                                                              condition Feedback      rule_load_date
136 DLAMAssetType2 is not null and DLAMAssetType is not an empty string and DLAMAssetType is not a string consisting of whitespace only        0 2016-04-25 14:20:58
         source_file
136 globe$_rules.csv
                                                                                                                                                                                                                                                                                           query
136 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLAssetType1,\r\n\t\tDLAssetType2,\r\n\t\tDLAssetType3 \r\nFROM SourceData.dbo.GL_xls_cashrisk\r\nWHERE DLAssetType2 IS NULL OR LEN(RTRIM(DLAssetType2)) = 0
    superset_query
136               
                                 BU system        BR entitytype    Depth Importance           ErrorCause modificationDate ruleOwner
137 BU Delta Lloyd Asset Management Globe$ GL_BR0069      trade HasValue       NEED Export Configuration             <NA>  Treasury
                               approvedBy approvedDate resultApprovalDate      dataelements              datasource referencedata                                 en
137 Afhankelijk van discussies asset tree         <NA>               <NA> DLAM.Asset.Type.3 limieten eigen geld.xls             0 DLAMAssetType3 should not be empty
                                 nl                                                                                   rule
137 DLAMAssetType3 moet gevuld zijn DLAMAssetType2 should not be equal to NULL nor an empty string nor a whitespace string
                                                                                                                              condition Feedback      rule_load_date
137 DLAMAssetType3 is not null and DLAMAssetType is not an empty string and DLAMAssetType is not a string consisting of whitespace only        0 2016-04-25 14:20:58
         source_file
137 globe$_rules.csv
                                                                                                                                                                                                                                                                                           query
137 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLAssetType1,\r\n\t\tDLAssetType2,\r\n\t\tDLAssetType3 \r\nFROM SourceData.dbo.GL_xls_cashrisk\r\nWHERE DLAssetType3 IS NULL OR LEN(RTRIM(DLAssetType3)) = 0
    superset_query
137               
                                 BU system        BR entitytype    Depth Importance           ErrorCause modificationDate ruleOwner
138 BU Delta Lloyd Asset Management Globe$ GL_BR0070      trade HasValue       NEED Export Configuration             <NA>  Treasury
                               approvedBy approvedDate resultApprovalDate dataelements              datasource referencedata                               en
138 Afhankelijk van discussies asset tree         <NA>               <NA> DLAM.Sector1 limieten eigen geld.xls             0 DLAMSector1  should not be empty
                              nl                                                                                rule condition Feedback      rule_load_date
138 DLAMSector1 moet gevuld zijn DLAMSector1 should not be equal to NULL nor an empty string nor a whitespace string         0        0 2016-04-25 14:20:58
         source_file
138 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                  query
138 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLSector1\t\t\t\t\tAS DLAMSector1,\r\n\t\tDLSector2\t\t\t\t\tAS DLAMSector2,\r\n\t\tDLSector3\t\t\t\t\tAS DLAMSector3\r\nFROM SourceData.dbo.GL_xls_cashrisk\r\nWHERE DLSector1 IS NULL OR LEN(RTRIM(DLSector1))=0
    superset_query
138               
                                 BU system        BR entitytype    Depth Importance           ErrorCause modificationDate ruleOwner
139 BU Delta Lloyd Asset Management Globe$ GL_BR0071      trade HasValue       NEED Export Configuration             <NA>  Treasury
                               approvedBy approvedDate resultApprovalDate dataelements              datasource referencedata                               en
139 Afhankelijk van discussies asset tree         <NA>               <NA> DLAM.Sector2 limieten eigen geld.xls             0 DLAMSector2  should not be empty
                              nl                                                                                rule condition Feedback      rule_load_date
139 DLAMSector2 moet gevuld zijn DLAMSector2 should not be equal to NULL nor an empty string nor a whitespace string         0        0 2016-04-25 14:20:58
         source_file
139 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                  query
139 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLSector1\t\t\t\t\tAS DLAMSector1,\r\n\t\tDLSector2\t\t\t\t\tAS DLAMSector2,\r\n\t\tDLSector3\t\t\t\t\tAS DLAMSector3\r\nFROM SourceData.dbo.GL_xls_cashrisk\r\nWHERE DLSector2 IS NULL OR LEN(RTRIM(DLSector2))=0
    superset_query
139               
                                 BU system        BR entitytype    Depth Importance           ErrorCause modificationDate ruleOwner
140 BU Delta Lloyd Asset Management Globe$ GL_BR0072      trade HasValue       NEED Export Configuration             <NA>  Treasury
                               approvedBy approvedDate resultApprovalDate dataelements              datasource referencedata                               en
140 Afhankelijk van discussies asset tree         <NA>               <NA> DLAM.Sector3 limieten eigen geld.xls             0 DLAMSector3  should not be empty
                              nl                                                                                rule condition Feedback      rule_load_date
140 DLAMSector3 moet gevuld zijn DLAMSector3 should not be equal to NULL nor an empty string nor a whitespace string         0        0 2016-04-25 14:20:58
         source_file
140 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                  query
140 SELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDLSector1\t\t\t\t\tAS DLAMSector1,\r\n\t\tDLSector2\t\t\t\t\tAS DLAMSector2,\r\n\t\tDLSector3\t\t\t\t\tAS DLAMSector3\r\nFROM SourceData.dbo.GL_xls_cashrisk\r\nWHERE DLSector3 IS NULL OR LEN(RTRIM(DLSector3))=0
    superset_query
140               
                                 BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner     approvedBy approvedDate
141 BU Delta Lloyd Asset Management Globe$ GL_BR0073      trade HasValue       NEED      Input             <NA>  Treasury Maarten Troost         <NA>
    resultApprovalDate dataelements              datasource referencedata                                 en                          nl
141               <NA>   IDENTIFIER limieten eigen geld.xls             0 The Identifier should not be empty Identifier moet gevuld zijn
                                                                       rule condition Feedback      rule_load_date      source_file
141 should not be equal to NULL nor an empty string nor a whitespace string         0        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                            query
141 \r\nSELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tPortfolioName\t\t\t\t\tAS PORTFOLIO_NAME,\r\n\t\tGlobescode\r\nFROM SourceData.dbo.GL_xls_cashrisk\r\nWHERE ID IS NULL OR LEN(RTRIM(ID)) = 0
    superset_query
141               
                                 BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner     approvedBy approvedDate
142 BU Delta Lloyd Asset Management Globe$ GL_BR0075      trade HasValue       NEED      Input             <NA>  Treasury Maarten Troost         <NA>
    resultApprovalDate  dataelements              datasource referencedata                                       en                             nl
142               <NA> NOMINAL_VALUE limieten eigen geld.xls             0 NominalValue should not be equal to NULL Nominal_value moet gevuld zijn
                                                                       rule condition Feedback      rule_load_date      source_file
142 should not be equal to NULL nor an empty string nor a whitespace string         0        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                               query
142 \r\nSELECT \r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tBedraginEUROS\t\t\t\t\tAS NOMINAL_VALUE,\r\n\t\tCurrency\t\t\t\t\t\tAS CURRENCY,\r\n\t\tTegenpartij\t\t\t\t\t\tAS COUNTERPARTY\r\nFROM SourceData.dbo.GL_xls_cashrisk\r\nWHERE BedraginEUROS IS NULL OR LEN(RTRIM(BedraginEUROS)) = 0\r\n\r\n
    superset_query
142               
                                 BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner     approvedBy approvedDate
143 BU Delta Lloyd Asset Management Globe$ GL_BR0076      trade HasValue       NEED      Input             <NA>  Treasury Maarten Troost         <NA>
    resultApprovalDate dataelements              datasource referencedata                            en                        nl
143               <NA>     CURRENCY limieten eigen geld.xls             0 Currency should not bee empty Currency moet gevuld zijn
                                                                                rule condition Feedback      rule_load_date      source_file
143 Currency should not be equal to NULL nor an empty string nor a whitespace string         0        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                        query
143 \r\nSelect\r\n\t\tDealcode\t\t\t\t\t\tAS tradeid,\r\n\t\tID\t\t\t\t\t\t\t\tAS insid,\r\n\t\tPortfolioName\t\t\t\t\tAS prfid,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tID\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\t\tDealCode,\r\n\t\tCurrency\t\t\t\t\t\tAS CURRENCY\r\nFrom\r\n  SourceData.dbo.GL_xls_cashrisk\r\nWhere \r\n  Currency is null OR LEN(RTRIM(Currency)) = 0\r\n
    superset_query
143               
                                 BU system        BR entitytype    Depth Importance ErrorCause modificationDate ruleOwner                            approvedBy
144 BU Delta Lloyd Asset Management Globe$ GL_BR0077  portfolio HasValue       NEED      Input             <NA>  Treasury Afhankelijk van discussies asset tree
    approvedDate resultApprovalDate    dataelements              datasource referencedata                            en                               nl
144         <NA>               <NA> PORTFOLIO_NAME  limieten eigen geld.xls             0 Portfolio should not be empty Portfolio_value moet gevuld zijn
                                                                                     rule condition Feedback      rule_load_date      source_file
144 Portfolioname should not be equal to NULL nor an empty string nor a whitespace string         0        0 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                       query
144 SELECT \r\n\t   PortfolioName\t\t\tAS prfid,\r\n\t   ID\t\t\t\t\t\tAS IDENTIFIER,\r\n\t   PortfolioName\t\t\tAS PORTFOLIO_NAME \r\nFROM \r\n\tSourceData.dbo.GL_xls_cashrisk\r\nWHERE \r\n\tPortfolioName=NULL\r\n\tOR LEN(RTRIM(PortfolioName))=0\r\n\r\n
    superset_query
144               
                                 BU system        BR entitytype                Depth Importance ErrorCause modificationDate ruleOwner     approvedBy approvedDate
145 BU Delta Lloyd Asset Management Globe$ GL_BR0078      trade ExternallyConsistent       NEED      Input             <NA>  Treasury Maarten Troost         <NA>
    resultApprovalDate dataelements                       datasource referencedata                                                             en
145               <NA>        PRICE GL_vx_fxdeals_bloomberg_matching             0 The absolute rate should be equal to the nearrate in bloomberg
                                                                nl                                                           rule condition Feedback
145 De absolute rate moet gelijk zijn aan de nearrate in Bloomberg The absolute rate should be equal to the nearrate in bloomberg         0        0
         rule_load_date      source_file
145 2016-04-25 14:20:58 globe$_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      query
145 select \r\n\tGL_Dealcode\t\t\t\t\t\t\t\tAS tradeid,\r\n\t--Description\t\t\t\t\t\t\tAS insid,\r\n\tGL_PortfolioName\t\t\t\t\t\tAS prfid,\r\n\t--Description\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tGL_TradeDate,\r\n\tGL_SettleDate,\r\n\tGL_BuyCurrency,\r\n\tGL_SellCurrency,\r\n\tGL_BuyAmount,\r\n\tGL_SellAmount,\r\n\tGL_DealCode,\r\n\tGL_SpotRate,\r\n\tBB_SpotRate,\r\n\tBB_SpotRate_Premiumed\r\n\tGL_Points,\r\n\tBB_Points,\r\n\tGL_allinrate,\r\n\tBB_AllInRate\r\n\tBB_Allinrate_premiumed,\r\n\tGL_DealType,\r\n\tGL_TegenPartij\r\n\tfrom(\r\n\t\tselect \r\n\t\t\t* \r\n\t\tfrom \r\n\t\t\tSourceData.dbo.GL_vx_fxdeals_bloomberg_matching\r\n\t\twhere\r\n\t\t\t-- matching globes record\r\n\t\t\tGL_DealCode is not null \r\n\t\t\t-- matching BB record\r\n\t\t\tand BB_TradeId is not NULL \r\n\t\t) as vx_fxdeals_bloomberg_matched\r\nwhere\r\n\t-- when BB is in 6 digits precision\r\n\t(ROUND(BB_allinrate,5)!=BB_allinrate and ABS (GL_allinrate-BB_AllInRate_premiumed)>=1e-6)\r\n\t-- when BB is in 5 digits precision\r\n\tOR (ROUND(BB_allinrate,4)!=BB_allinrate and ABS (GL_allinrate-BB_AllInRate_premiumed)>=1e-5)\r\n\t-- else compare in 4 digits precision\r\n\tOR (ABS (GL_allinrate-BB_AllInRate_premiumed)>=1e-4)\r\n\torder by \r\n\t\t--Ordered by date and max ammount such that probable related are next to each other\r\n\t\tTheDate ASC\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n -- BANQUE DE LUXEMBOURG FX TRADING +/- 0.015% op spotrate/allinrate afhankelijk van Buy of Sell wordt gecompenseerd met premium \r\n  -- FXSW003610, SpotDate is t+2 trade vind binnen t+2 plaats rente punten worden opgeteld bij spotrate in twee delen 06/02 t/m 09/02 (-1) en 09/02 t/m 10/02 (-0.6) Delta tussen points near leg en far leg is totale swap points
    superset_query
145               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate resultApprovalDate
146 BU Delta Lloyd Asset Management Portia PO_0001    holding HasValue       NEED      Input             <NA> Accounting Akke Velzeboer         <NA>               <NA>
    dataelements         datasource referencedata                         en                 nl                                         rule
146   BOOK_VALUE RM-PortiaTotal_P_                Nonempty numeric bookvalue Gevulde boekwaarde All holdings should have a defined bookvalue
                                         condition Feedback      rule_load_date      source_file
146 Instruments with bookvalue equal to NULL or ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                      query
146 SELECT DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n    BOOK_VALUE\r\nFROM\r\n    vx_PO_holding\r\nWHERE\r\n    BOOK_VALUE is NULL
                                                                                                        superset_query
146 SELECT\r\n\tinsid,\r\n\tprfid,\r\n    BOOK_VALUE\r\nFROM\r\n    vx_PO_holding\r\n--WHERE\r\n--    BOOK_VALUE is NULL
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
147 BU Delta Lloyd Asset Management Portia PO_0002  portfolio HasValue       NEED      Input             <NA> Data Management Sander van Laarhoven         <NA>
    resultApprovalDate dataelements         datasource referencedata                   en            nl                                             rule
147               <NA>  CLIENT_NAME RM-PortiaTotal_P_                Nonempty client naam Gevulde klant All portfolios should have a defined client name
                                          condition Feedback      rule_load_date      source_file
147 Portfolios with client name equal to NULL or ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                 query superset_query
147 SELECT DISTINCT\r\n\tprfid,\r\n    CLIENT_NAME\r\nFROM\r\n    vx_PO_portfolio\r\nWHERE\t\r\n    CLIENT_NAME is NULL\r\n\tOR LEN(LTRIM(CLIENT_NAME))=0               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
148 BU Delta Lloyd Asset Management Portia PO_0003 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                en                           nl
148               <NA>       COUPON RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonempty numeric coupon for loans Gevulde coupon voor leningen
                                       rule                                                                                       condition Feedback
148 All loans should have a defined coupon. Instruments with coupon equal to NULL and  DLAMAssetClass2 one of LIC, Bond, Other Fixed Income         
         rule_load_date      source_file
148 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                         query
148 SELECT DISTINCT\r\n\tinsid,\r\n    COUPONRATE,\r\n\tDLAMAssetClass2\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    COUPONRATE is NULL\r\n\tand DLAMAssetClass2 in ('LIC', 'Bond', 'Other Fixed Income')\r\n\tand scope_dm = 1
    superset_query
148               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
149 BU Delta Lloyd Asset Management Portia PO_0004 instrument HasValue       NEED      Input             <NA> Data Management Sander van Laarhoven         <NA>
    resultApprovalDate dataelements                               datasource referencedata                en               nl
149               <NA>     CURRENCY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonempty currency Gevulde currency
                                              rule                                     condition Feedback      rule_load_date      source_file
149 All instruments should have a defined currency Instruments with currency equal to NULL or ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                       query
149 SELECT DISTINCT\r\n\tinsid,\r\n    MUNT\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    ( MUNT is NULL\r\n\tOR LEN(RTRIM(MUNT)) = 0\r\n\t) and scope_dm = 1
    superset_query
149               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
150 BU Delta Lloyd Asset Management Portia PO_0005 instrument HasValue       NEED      Input             <NA> Data Management Sander van Laarhoven         <NA>
    resultApprovalDate      dataelements                               datasource referencedata                    en                   nl
150               <NA> DLAM.Asset.Type.2 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonempty asset type 2 Gevulde asset type 2
                                                                    rule                                              condition Feedback      rule_load_date
150 All instruments should hava a defined, non empty, dlam asset class 2 Instruments with dlam asset type 2 equal to NULL or ''          2016-04-26 16:05:43
         source_file
150 portia_rules.csv
                                                                                                                                                                                                 query
150 SELECT DISTINCT\r\n\tinsid,\r\n    DLAMAssetClass2\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n\tscope_dm = 1 \r\n\tand (\r\n\t\tDLAMAssetClass2 is NULL\r\n\t\tOR LEN(RTRIM(DLAMAssetClass2)) = 0\r\n\t\t)
    superset_query
150               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
151 BU Delta Lloyd Asset Management Portia PO_0006 instrument HasValue       NEED      Input             <NA> Data Management Sander van Laarhoven         <NA>
    resultApprovalDate      dataelements                               datasource referencedata                    en                   nl
151               <NA> DLAM.Asset.Type.3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonempty asset type 3 Gevulde asset type 3
                                                                    rule                                              condition Feedback      rule_load_date
151 All instruments should have a defined, non empty, dlam asset class 3 Instruments with dlam asset type 3 equal to NULL or ''          2016-04-26 16:05:43
         source_file
151 portia_rules.csv
                                                                                                                                                                                               query
151 SELECT DISTINCT\r\n\tinsid,\r\n    DLAMAssetClass3\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n\tscope_dm = 1\r\n\tand(\r\n\t\tDLAMAssetClass3 is NULL\r\n\t\tOR LEN(RTRIM(DLAMAssetClass3)) = 0\r\n\t\t)
    superset_query
151               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate                 ruleOwner              approvedBy
152 BU Delta Lloyd Asset Management Portia PO_0007 instrument HasValue       NEED      Input             <NA> Financial Risk Management Fred Schulte Fischedick
    approvedDate resultApprovalDate dataelements                               datasource referencedata                                                         en
152   2015-06-23         2015-06-23  DLAM.RATING RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                All instruments should have a nonempty dlam rating defined
                                                       nl
152 Alle instrumenten dienen een gevulde rating te hebben
                                                                                                               rule                                        condition
152 All instruments should have a non-empty and non-null dlam rating defined.\n\nIt could still be for example 'NR' Instruments with dlam rating equal to NULL or ''
    Feedback      rule_load_date      source_file
152          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                          query
152 SELECT DISTINCT\r\n\tinsid,\r\n    DLRating\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n\tscope_dm = 1 and\r\n\t(\r\n\t\tDLRating is NULL\r\n\t\tOR LEN(RTRIM(DLRating)) = 0\r\n\t)
    superset_query
152               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
153 BU Delta Lloyd Asset Management Portia PO_0008 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                     en                    nl
153               <NA> DLAM.Sector1 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonempty dlam sector 1 Gevulde dlam sector 1
                                                               rule                                          condition Feedback      rule_load_date      source_file
153 All instruments should have a defined, non empty, dlam sector 1 Instruments with dlam sector 1 equal to NULL or ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                   query
153 SELECT DISTINCT\r\n\tinsid,\r\n    DLAMSector1\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    ( DLAMSector1 is NULL\r\n\tOR LEN(RTRIM(LTRIM(DLAMSector1))) = 0 )\r\n\tand scope_dm = 1
    superset_query
153               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
154 BU Delta Lloyd Asset Management Portia PO_0009 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                     en                    nl
154               <NA> DLAM.Sector2 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonempty dlam sector 2 Gevulde dlam sector 2
                                                               rule                                          condition Feedback      rule_load_date      source_file
154 All instruments should have a defined, non empty, dlam sector 2 Instruments with dlam sector 2 equal to NULL or ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                         query
154 SELECT DISTINCT\r\n\tinsid,\r\n    DLAMSector2\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    (\r\n\t\tDLAMSector2 is NULL\r\n\t\tOR LEN(RTRIM(LTRIM(DLAMSector2))) = 0) \r\n\tand scope_dm = 1
    superset_query
154               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
155 BU Delta Lloyd Asset Management Portia PO_0010 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                     en                    nl
155               <NA> DLAM.Sector3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonempty dlam sector 3 Gevulde dlam sector 3
                                                               rule                                          condition Feedback      rule_load_date      source_file
155 All instruments should have a defined, non empty, dlam sector 3 Instruments with dlam sector 3 equal to NULL or ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                          query
155 SELECT DISTINCT\r\n\tinsid,\r\n    DLAMSector3\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n\t(\r\n\t\tDLAMSector3 is NULL\r\n\t\tOR LEN(RTRIM(LTRIM(DLAMSector3))) = 0\r\n\t)\r\n\tand scope_dm = 1
    superset_query
155               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
156 BU Delta Lloyd Asset Management Portia PO_0011 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                        en
156               <NA>   EXPIRATION RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Derivatives have nonempty expiration date
                                            nl                                                                                                     rule
156 Derivatives hebben gevulde expiratie datum All derivative instruments should have a defined, non empty, expiration date. Rights are no derivatives.
                                                                                                                                                                                                          condition
156 Instruments with \n\n  DLAMAssetClass2 equal to 'Equity Derivative' or 'Fixed income derivative'\n\n  and DLAMAssetClass3 not equal to Right\n\n  and expiration date equal to NULL, '' or not an existing date
    Feedback      rule_load_date      source_file
156          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                   query
156 SELECT DISTINCT\r\n\tinsid,\r\n    Expirationdate,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tscope_dm\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n\tDLAMAssetClass2 IN ('Equity Derivative','Fixed Income Derivative')\r\n\tand DLAMAssetClass3 != 'Right'\r\n\tand scope_dm = 1\r\n\tand (\r\n\t\tExpirationdate is NULL\r\n\t\tOR LEN(RTRIM(Expirationdate)) = 0\r\n\t\t)
    superset_query
156               
                                 BU system      BR entitytype    Depth Importance  ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
157 BU Delta Lloyd Asset Management Portia PO_0012 instrument HasValue       NEED Copy create             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                        en
157               <NA>   EXPIRATION RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonderivatives have empty expiration date
                                                      nl
157 Niet-derivatives hebben geen gevulde expiratie datum
                                                                                                                     rule
157 All non-derivative instruments should not have a defined, non empty, expiration date. Rights are also no derivatives.
                                                                                                                                                                                                                                                      condition
157 Instruments with \n\n  DLAMAssetClass2 not equal to 'Equity Derivative' or 'Fixed income derivative', or DLAMAssetClass2 equal to 'Equity Derivative' and DLAMAssetClass3 equal to Right\n\n  and expiration date not equal to NULL, '' or an existing date
    Feedback      rule_load_date      source_file
157          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                           query
157 SELECT DISTINCT\r\n\tinsid,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n    Expirationdate\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    Expirationdate is not NULL\r\n\tand NOT (\t\r\n\t\tDLAMAssetClass2 IN ('Equity Derivative','Fixed Income Derivative')\r\n\t\tand DLAMAssetClass3 != 'Right'\r\n\t\t)\r\n\tand scope_dm = 1
    superset_query
157               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
158 BU Delta Lloyd Asset Management Portia PO_0013 instrument HasValue       NEED      Input             <NA> Valuation Desk Ilona Balvert         <NA>
    resultApprovalDate dataelements                               datasource referencedata               en              nl
158               <NA>       FXRATE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonempty fx rate Gevulde fx rate
                                                                                                                                                                                     rule
158 All instruments should have a defined, non empty, fx rate.\n\nThe data load scripts parse the frate to a numeric value, any non-numeric value like the empty '' will also become NULL
                                condition Feedback      rule_load_date      source_file
158 Instruments with fxrate equal to NULL          2016-04-26 16:05:43 portia_rules.csv
                                                                                                   query superset_query
158 SELECT DISTINCT\r\n\tinsid,\r\n\tFXRATE\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    FXRATE is NULL               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
159 BU Delta Lloyd Asset Management Portia PO_0014 instrument HasValue       NEED      Input             <NA> Data Management Sander van Laarhoven         <NA>
    resultApprovalDate dataelements                               datasource referencedata            en           nl
159               <NA>   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonempty isin Gevulde isin
                                                                   rule                           condition Feedback      rule_load_date      source_file
159 All instruments should have a defined, non empty, isin (identifier) Instruments with isin equal to NULL          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                  query superset_query
159 SELECT DISTINCT\r\n\tinsid,\r\n\tISIN\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    ( ISIN is NULL\r\n\tOR LEN(LTRIM(ISIN))=0\r\n\t) and scope_dm = 1               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
160 BU Delta Lloyd Asset Management Portia PO_0015 instrument HasValue       NEED      Input             <NA> Data Management Sander van Laarhoven         <NA>
    resultApprovalDate dataelements                               datasource referencedata                     en                             nl
160               <NA>   ISSUE_DATE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Loans have issue dates Leningen hebben een issue date
                                                                                            rule
160 All loans (LIC, Bonds and other fixed income's) should have a defined, non empty, issue date
                                                                                              condition Feedback      rule_load_date      source_file
160 Instruments with \n\n  DLAMAssetClass2 one of LIC, Bond, Other Fixed Income\n\n  and issuedate NULL          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                               query
160 SELECT DISTINCT\r\n\tinsid, \r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tIssuedate\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    Issuedate is NULL\r\n\tand DlamAssetClass2 in ('LIC', 'Bond', 'Other Fixed Income')\r\n\tand scope_dm = 1
    superset_query
160               
                                 BU system      BR entitytype    Depth Importance  ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
161 BU Delta Lloyd Asset Management Portia PO_0016 instrument HasValue       NEED Copy create             <NA> Data Management Sander van Laarhoven         <NA>
    resultApprovalDate dataelements                               datasource referencedata                          en                                   nl
161               <NA>   ISSUE_DATE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonloans have no issue date Niet-leningen hebben geen issue date
                                                                                                   rule
161 All nonloans (LIC, Bonds and other fixed income's) should not have a defined, non empty, issue date
                                                                                                     condition Feedback      rule_load_date      source_file
161 Instruments with \n\n  DLAMAssetClass not one of LIC, Bond, Other Fixed Income\n\n  and issuedate not NULL          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                       query
161 SELECT DISTINCT\r\n\tinsid, \r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tIssuedate\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    Issuedate is not NULL\r\n\tand DlamAssetClass2 not in ('LIC', 'Bond', 'Other Fixed Income')\r\n\tand scope_dm = 1
    superset_query
161               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner    approvedBy approvedDate
162 BU Delta Lloyd Asset Management Portia PO_0017    holding HasValue       NEED      Input             <NA> Data Management Dennis Kolmus         <NA>
    resultApprovalDate dataelements         datasource referencedata                    en                  nl
162               <NA> MARKET_VALUE RM-PortiaTotal_P_                Nonempty market value Gevulde marktwaarde
                                                                                                                                                                          rule
162 All holdings should have a defined marketvalue\n\nThe data load scripts parses the value to a numeric value, any non-numeric value like the empty '' will also become NULL
                                       condition Feedback      rule_load_date      source_file
162 Holdings with\n\n   martket value NULL or ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                      query superset_query
162 SELECT DISTINCT\r\n\tinsid, \r\n\tprfid,\r\n\tMWinclLREur\r\nFROM\r\n    vx_PO_holding\r\nWHERE\r\n    MWinclLREur is NULL               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
163 BU Delta Lloyd Asset Management Portia PO_0018 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-15
    resultApprovalDate dataelements                               datasource referencedata                        en                                                nl
163               <NA>     MATURITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Loans have maturity dates Leningen (geen fondsen) hebben een maturity datum
                                                                           rule
163 All loans (LIC, Bonds and other fixed income's) should have a maturity date
                                                                                                   condition Feedback      rule_load_date      source_file
163 Instrumentes with\n\n    DLAMAssetClass2 one of LIC, Bond, Other Fixed Income\n\n  and maturitydate NULL          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                             query
163 SELECT DISTINCT\r\n\tinsid,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tMaturityDate\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    MaturityDate is NULL\r\n\tand DLAMAssetClass2 in ('Bond','LIC','Other Fixed Income')\r\n\tand scope_dm = 1
    superset_query
163               
                                 BU system      BR entitytype    Depth Importance  ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
164 BU Delta Lloyd Asset Management Portia PO_0019 instrument HasValue       NEED Copy create             <NA> Data Management Ronald Bark   2015-05-15
    resultApprovalDate dataelements                               datasource referencedata                             en
164               <NA>     MATURITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonloans have no maturity date
                                                         nl                                                                                      rule
164 Niet-leningen (bijv fondsen) hebben geen maturity datum All nonloans (LIC, Bonds, and other fixed income's) bonds should not have a maturity date
                                                                                                           condition Feedback      rule_load_date      source_file
164 Instrumentes with\n\n    DLAMAssetClass2 not one of LIC, Bond, Other Fixed Income\n\n  and maturitydate not NULL          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                     query
164 SELECT DISTINCT\r\n\tinsid,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tMaturityDate\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    MaturityDate is not NULL\r\n\tand DLAMAssetClass2 not in ('Bond','LIC','Other Fixed Income')\r\n\tand scope_dm = 1
    superset_query
164               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
165 BU Delta Lloyd Asset Management Portia PO_0020    holding HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-15
    resultApprovalDate  dataelements         datasource referencedata                                    en                    nl
165               <NA> NOMINAL_VALUE RM-PortiaTotal_P_                Holdings have a defined nominal value Gevulde nominal value
                                                                                                                                                                            rule
165 All holdings should have a defined nominal value\n\nThe data load scripts parses the value to a numeric value, any non-numeric value like the empty '' will also become NULL
                                 condition Feedback      rule_load_date      source_file
165 Holdings with\n\n   nominal value NULL          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                     query superset_query
165 SELECT DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tNominaalEur\r\nFROM\r\n    vx_PO_holding\r\nWHERE\r\n    NominaalEur is NULL               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
166 BU Delta Lloyd Asset Management Portia PO_0021 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-15
    resultApprovalDate dataelements                               datasource referencedata                                           en
166               <NA>  OPTION_TYPE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Equity derivatives have nonempty option type
                                               nl                                                                           rule
166 Equity derivatives hebben gevulde option type All equity derivatives (Dlam asset class 3) should have a nonempty option type
                                                                                             condition Feedback      rule_load_date      source_file
166 Instruments with \n\n   DLAMAssetClas2 = 'Equity Derivative'\n\n   and len(trim(option_type)) = ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                          query
166 SELECT \r\n\tinsid,\r\n\tOption_type,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    LEN(RTRIM(Option_type)) = 0\r\n\tand DLAMAssetClass3 = 'Equity Option'\r\n
    superset_query
166               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
167 BU Delta Lloyd Asset Management Portia PO_0022 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-15
    resultApprovalDate dataelements                               datasource referencedata                                           en
167               <NA>  OPTION_TYPE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonequity derivatives have empty option type
                                                nl                                                                             rule
167 Non-Equity derivatives hebben geen option type All non equity derivatives (Dlam asset class 3) should have an empty option type
                                                                                    condition Feedback      rule_load_date      source_file
167 Instruments with \n\n   DLAMAssetClas3 != 'Equity Derivative'\n\n   and option_type != ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                     query
167 SELECT  DISTINCT\r\n\tinsid,\r\n\tOption_type,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    LEN(RTRIM(Option_type)) != 0\r\n\tand DLAMAssetClass3 != 'Equity Option'\r\n
    superset_query
167               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
168 BU Delta Lloyd Asset Management Portia PO_0023 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-19
    resultApprovalDate      dataelements                               datasource referencedata                        en                          nl
168               <NA> PAYMENT_FREQUENCY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Numeric payment frequency Numerieke payment frequency
                                                     rule                              condition Feedback      rule_load_date      source_file
168 All instruments should have numeric payment frequency Instruments with paymentfrequency NULL          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                       query superset_query
168 SELECT DISTINCT\r\n\tinsid,\r\n\tPaymentFrequency\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    PaymentFrequency is null               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
169 BU Delta Lloyd Asset Management Portia PO_0024    holding HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-19
    resultApprovalDate   dataelements         datasource referencedata                                     en                                         nl
169               <NA> PORTFOLIO_NAME RM-PortiaTotal_P_                Holdings have a defined portfolio name Posities hebben een gedefnieerde portfolio
                                                           rule                              condition Feedback      rule_load_date      source_file
169 All holdings should have a defined non empty portfolio name Holdings with PortfolioNaam NULL or ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                   query
169 SELECT DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tPortfolioNaam\r\nFROM\r\n    vx_PO_holding\r\nWHERE\r\n    PortfolioNaam is null\r\n\tOR LEN(LTRIM(RTRIM(PortfolioNaam)))=0
    superset_query
169               
                                 BU system      BR entitytype    Depth Importance           ErrorCause modificationDate              ruleOwner     approvedBy
170 BU Delta Lloyd Asset Management Portia PO_0025    holding HasValue       NEED Export Configuration             <NA> Information Management Nanda Kartaram
    approvedDate resultApprovalDate dataelements         datasource referencedata                                       en                                           nl
170   2015-09-15               <NA>      proddat RM-PortiaTotal_P_                Portiatotal has export date on each line Portiatotal heeft export datum op elke regel
                                                                                                                                                                                      rule
170 All lines in the PortiaTotal export should have a defined export date.\n\nThe data load scripts parses the value to a date, any non-date value like the empty '' will also become NULL
                           condition                                                                                                                          Feedback
170 Holdings with ReportingDate NULL Voor nieuwe afdeling met Gerton Claessen? Aangezien nog niet bestaat, voor IM, Gijs Heuving, die op 22 juni terug is van vakantie
         rule_load_date      source_file
170 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                   query
170 SELECT DISTINCT\r\n\tSecuritynaam as insid,\r\n\tPortfolioNaam as prfid,\r\n\tReportingDate\r\nFROM\r\n    PO_portiatotal\r\nWHERE\r\n    ReportingDate is null\r\n    OR LEN(RTRIM(ReportingDate)) = 0
    superset_query
170               
                                 BU system      BR entitytype    Depth Importance           ErrorCause modificationDate              ruleOwner     approvedBy
171 BU Delta Lloyd Asset Management Portia PO_0026 instrument HasValue       NEED Export Configuration             <NA> Information Management Nanda Kartaram
    approvedDate resultApprovalDate dataelements                               datasource referencedata                                     en
171         <NA>               <NA>      proddat RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                SecsHld has exported date on each line
                                          nl
171 SecsHld heeft export datum op elke regel
                                                                                                                                                                                        rule
171 All lines in the SecsHld export should have a defined export date.\n\nThe data load scripts parses the value to a date value, any non-date value like the empty '' will also become NULL
                              condition
171 Instruments with ReportingDate NULL
                                                                                                                             Feedback      rule_load_date
171 Voor nieuwe afdeling met Gerton Claessen? Aangezien nog niet bestaat, voor IM, Gijs Heuving, die op 22 juni terug is van vakantie 2016-04-26 16:05:43
         source_file                                                                                                                                          query
171 portia_rules.csv SELECT DISTINCT\r\n\tName as insid,\r\n\trundate\r\nFROM\r\n    PO_secshld\r\nWHERE\r\n    rundate is null\r\n    OR LEN(RTRIM(rundate)) = 0\r\n
    superset_query
171               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate resultApprovalDate
172 BU Delta Lloyd Asset Management Portia PO_0027    holding HasValue       NEED      Input             <NA> Mid Office Kristine Prahl         <NA>         2015-06-16
    dataelements         datasource referencedata                                          en                                                     nl
172     QUANTITY RM-PortiaTotal_P_                Each holding should have a numeric quantity Elke positie dient een numerieke hoeveelheid te hebben
                                                                                                                                                                                          rule
172 The quantity of a holding needs to be provided and be numeric.\n\nThe data load scripts parses the value to a numeric value, any non-numeric value like the empty '' will also become NULL
                      condition Feedback      rule_load_date      source_file
172 Holdings with quantity NULL          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                         query superset_query
172 SELECT DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tQUANTITY\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tQUANTITY is NULL\r\n\tOR LEN(RTRIM(QUANTITY)) = 0               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
173 BU Delta Lloyd Asset Management Portia PO_0028 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-19
    resultApprovalDate dataelements                               datasource referencedata                                              en
173               <NA>     SECURITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Instruments have defined nonempty security name
                                                            nl                                                                  rule
173 Instrumenten hebben een gedefineerde gevulde security naam The security name of an instrument needs to be provided and non empty
                                   condition Feedback      rule_load_date      source_file
173 Instruments with SecurityNaam NULL or ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                             query superset_query
173 SELECT DISTINCT\r\n\tinsid,\r\n\tSecuritynaam\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE\r\n\tSecuritynaam is NULL\r\n\tOR LEN(LTRIM(Securitynaam)) = 0               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
174 BU Delta Lloyd Asset Management Portia PO_0029 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-19
    resultApprovalDate dataelements                               datasource referencedata                                        en
174               <NA>       STRIKE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Equity options have nonempty strike price
                                            nl
174 Equity options hebben gevulde strike price
                                                                                                                                                                                                       rule
174 All equity options (Dlam asset class 3) should have a nonempty strike price\n\nThe data load scripts parses the value to a numeric value, any non-numeric value like the empty '' will also become NULL
                                                                         condition Feedback      rule_load_date      source_file
174 Instruments with \n\n   DLAMAssetClas3 = 'Equity Option'\n\n   and strike null          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                    query
174 select DISTINCT\r\n\tinsid,\r\n\tSTRIKE,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nfrom\r\n\tvx_PO_instrument\r\nWHERE\r\n\tSTRIKE is NULL\r\n\tand DLAMAssetClass3='Equity Option'
    superset_query
174               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
175 BU Delta Lloyd Asset Management Portia PO_0030 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-19
    resultApprovalDate dataelements                               datasource referencedata                                         en
175               <NA>       STRIKE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Non Equity options have empty strike price
                                                      nl
175 Niet-equity options hebben geen gevulde strike price
                                                                                                                                                                                                          rule
175 All non equity options (Dlam asset class 3) should have an empty strike price.\n\nThe data load scripts parses the value to a numeric value, any non-numeric value like the empty '' will also become NULL
                                                                              condition Feedback      rule_load_date      source_file
175 Instruments with \n\n   DLAMAssetClas3 != 'Equity Option'\n\n   and strike not null          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                            query
175 select DISTINCT\r\n\tinsid,\r\n\tSTRIKE,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nfrom\r\n\tvx_PO_instrument\r\nWHERE\r\n\tnot STRIKE is NULL\r\n\tand not DLAMAssetClass3='Equity Option'
    superset_query
175               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
176 BU Delta Lloyd Asset Management Portia PO_0031 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-19
    resultApprovalDate dataelements                               datasource referencedata                                   en                                    nl
176               <NA>   UNDERLYING RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Derivatives have nonempty underlying Derivatives hebben gevulde underlying
                                                                                                         rule
176 All derivatives (Dlam asset class 2) except Rights (Dlam asset class 3) should have a nonempty underlying
                                                                                                                                                          condition
176 Instruments with \n\n   DLAMAssetClass2 in ('Equity Derivative','Fixed Income Derivative')\n\n   and DLAMAssetClass3 != 'Right'\n\n   and underlying NULL or ''
    Feedback      rule_load_date      source_file
176          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                query
176 select DISTINCT\r\n\tinsid,\r\n\tUNDERLYING,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nfrom\r\n\tvx_PO_instrument\r\nWHERE\r\n\t(UNDERLYING is NULL or LEN(LTRIM(UNDERLYING))=0)\r\n\tand DLAMAssetClass2 in ('Equity Derivative','Fixed Income Derivative')\r\n\tand DLAMAssetClass3 != 'Right'
    superset_query
176               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
177 BU Delta Lloyd Asset Management Portia PO_0032 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-19
    resultApprovalDate dataelements                               datasource referencedata                                   en
177               <NA>   UNDERLYING RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonderivatives have empty underlying
                                                 nl                                                                                                     rule
177 Niet-derivatives hebben geen gevulde underlying All non derivatives (Dlam asset class 2) and Rights (Dlam asset class 3) should have an empty underlying
                                                                                                                                                                    condition
177 Instruments with \n\n   not ( DLAMAssetClass2 in ('Equity Derivative','Fixed Income Derivative') and DLAMAssetClass3 != 'Right')\n\n   and underlying not NULL and not ''
    Feedback      rule_load_date      source_file
177          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                            query
177 select DISTINCT\r\n\tinsid,\r\n\tUNDERLYING,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nfrom\r\n\tvx_PO_instrument\r\nWHERE\r\n\tnot (UNDERLYING is NULL or LEN(LTRIM(UNDERLYING))=0)\r\n\tand not (\r\n\t\tDLAMAssetClass2 in ('Equity Derivative','Fixed Income Derivative')\r\n\t\tand DLAMAssetClass3 != 'Right')  \r\n-- this extra line prevents R from trimming the last ) from the query
    superset_query
177               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
178 BU Delta Lloyd Asset Management Portia PO_0033 instrument HasValue       NEED      Input             <NA> Data Management Ronald Bark   2015-05-19
    resultApprovalDate dataelements                               datasource referencedata                                     en
178               <NA>        PRICE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Instruments have defined numeric price
                                                      nl
178 Instrumenten hebben een gedefineerde numerieke prijs
                                                                                                                                                                        rule
178 All instruments should have a numeric price.\n\nThe data load scripts parses the value to a numeric value, any non-numeric value like the empty '' will also become NULL
                      condition Feedback      rule_load_date      source_file
178 instruments with koers NULL          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                           query superset_query
178 select DISTINCT\r\n\tinsid\r\n\t, KOERS\r\nfrom \r\n\tvx_PO_instrument\r\nwhere \r\n\tKOERS is NULL\r\n\tOR LEN(RTRIM(KOERS)) = 0               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
179 BU Delta Lloyd Asset Management Portia PO_0034    holding ValidRange       NEED      Input             <NA> Accounting Akke Velzeboer         <NA>
    resultApprovalDate dataelements         datasource referencedata                             en                                        nl
179               <NA>   BOOK_VALUE RM-PortiaTotal_P_                Bookvalue for nonzero quantity Boekwaarde bij hoeveelheid ongelijk aan 0
                                                                                                                 rule
179 All holdings with nonzero quantity should have nonzero bookvalue.\n\nThe holdings of fake portfolios are excluded
                                                                                                                                                                                                      condition
179 Holdings where quantity!=0\n\n   and book_value = 0\n\nand  prfid NOT IN ('zPearl dummy',\n\n  'COLL LEVEN',\n\n  'S00IM-PART',\n\n  'DL Bank Belgium',\n\n  'COLL KAS BANK')\n\n and prfid not like 'OP-%'
    Feedback      rule_load_date      source_file
179          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            query
179 select DISTINCT\r\n\tvx_PO_holding.insid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tvx_PO_holding.KOERS as KOERS,\r\n\tBOOK_VALUE\r\nfrom\r\n\tSourceData.dbo.vx_PO_holding\r\n\tleft join\r\n\tSourceData.dbo.vx_PO_instrument\r\n\ton vx_PO_holding.insid = vx_PO_instrument.insid\r\n\tand vx_PO_holding.ReportingDate = vx_PO_instrument.ReportingDate\r\nwhere\r\n\t-- applicable set\r\n\tQUANTITY != 0 --and vx_PO_holding.KOERS = 0\r\n\tand prfid NOT IN ('zPearl dummy',\r\n\t\t'COLL LEVEN',\r\n\t\t'S00IM-PART',\r\n\t\t'DL Bank Belgium',\r\n\t\t'COLL KAS BANK')\r\n\tand prfid not like 'OP-%'\r\n\tand vx_PO_holding.KOERS != 0\r\n\t-- failure filter\r\n\tand BOOK_VALUE = 0\r\n\t\r\n\t\r\n  --als purchase cost 0 is, is er ook geen book_value\r\n  --indien impaired, dan mag book value ook 0 zijn.\r\n  --indien koers 0, ook book_value 0
    superset_query
179               
                                 BU system      BR entitytype      Depth Importance           ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
180 BU Delta Lloyd Asset Management Portia PO_0035    holding ValidRange       NEED Export Configuration             <NA> Accounting Akke Velzeboer         <NA>
    resultApprovalDate dataelements         datasource referencedata                               en                                nl
180               <NA>   BOOK_VALUE RM-PortiaTotal_P_                Zero bookvalue for zero quantity Geen boekwaarde bij hoeveelheid 0
                                                                                                            rule
180 All holdings with zero quantity should have zero bookvalue.\n\nThe holdings of fake portfolios are excluded 
                                                                                                                                                                                                    condition
180 Holdings where quantity=0 \n\n   and book_value != 0\n\n  prfid NOT IN ('zPearl dummy',\n\n  'COLL LEVEN',\n\n  'S00IM-PART',\n\n  'DL Bank Belgium',\n\n  'COLL KAS BANK')\n\n and prfid not like 'OP-%'
    Feedback      rule_load_date      source_file
180          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               query
180 select DISTINCT\r\n\tvx_PO_holding.insid,\r\n\tprfid,\r\n\tSourceData.dbo.vx_PO_holding.QUANTITY,\r\n\tvx_PO_holding.KOERS as KOERS,\r\n\tBOOK_VALUE,\r\n\tabs(book_value)\r\nfrom\r\n\tSourceData.dbo.vx_PO_holding\r\n\tleft join\r\n\tSourceData.dbo.vx_PO_instrument\r\n\ton vx_PO_holding.insid = vx_PO_instrument.insid\r\n\tand vx_PO_holding.ReportingDate = vx_PO_instrument.ReportingDate\r\nwhere\r\n\t-- applicable set\r\n\tSourceData.dbo.vx_PO_holding.QUANTITY = 0\r\n\tand prfid NOT IN ('zPearl dummy',\r\n\t\t'COLL LEVEN',\r\n\t\t'S00IM-PART',\r\n\t\t'DL Bank Belgium',\r\n\t\t'COLL KAS BANK')\r\n\tand prfid not like 'OP-%'\r\n\t-- failure filter\r\n\tand BOOK_VALUE!=0\r\n\r\n  -- 8 en 9 niet in grootboek\r\n  -- * is vervallen\r\n  -- DL_L niet hier geadministreerd\r\n
    superset_query
180               
 names_orig names_sql_expected names_sql
                             X        V6
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
181 BU Delta Lloyd Asset Management Portia PO_0036  portfolio ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-19
    resultApprovalDate dataelements         datasource referencedata                                          en                                        nl
181               <NA>  CLIENT_NAME RM-PortiaTotal_P_                Each portfolio has one assigned client name Elke portfolio is toegewezen aan 1 client
                                                           rule                                                                       condition Feedback
181 A portfolio should only occur together with one client name Portfolios grouped by portfolio name\n\n  having count distinct client name > 1         
         rule_load_date      source_file
181 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                      query superset_query
181 select DISTINCT\r\n\tprfid\r\nfrom\r\n\tvx_PO_portfolio\r\ngroup by\r\n\tprfid, ReportingDate\r\nhaving\r\n\tcount(distinct(CLIENT_NAME))>1               
                                 BU system      BR entitytype      Depth Importance           ErrorCause modificationDate       ruleOwner           approvedBy
182 BU Delta Lloyd Asset Management Portia PO_0037  portfolio ValidRange       NEED Export Configuration             <NA> Data Management Sander van Laarhoven
    approvedDate resultApprovalDate dataelements         datasource referencedata                               en                                           nl
182   2015-09-30               <NA>  CLIENT_NAME RM-PortiaTotal_P_    clients.csv The client name defines a client De client name dient een client name te zijn
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     rule
182 The CLIENTNAAM column is used to indicate the client who owns the portfolio. This is different from the BusinessUnit column, which should indicate the managing business unit.\n\nUnfortunately the export is configured incorrectly, and thus reports the name at the granularity required by MidOffice's Deposit Check (Depot controle). This granularity level is almost equal to the portfolio level.\n\nThus the big amount of failures does not indicate that the Portia system is incorrect, but does indicate that the wrong data is provided to the next step in the solvency II risk calculation (the FRM Database's Load Validation Tool).
                                                                         condition
182 Portfolios with a client name that does not occur in the client name whitelist
                                                                                                                                                  Feedback
182 Een client /portfolio tree zou opgezet dienen te worden (Jira 2012). Nu geeft het veld Client geen aanvullende informatie tov het portfolio veld/naam.
         rule_load_date      source_file
182 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                           query
182 select DISTINCT\r\n\tprfid\r\n\t, CLIENT_NAME\r\nfrom\r\n\tvx_PO_portfolio\r\nwhere\r\n\tCLIENT_NAME not in \r\n\t(select CLIENT_NAME from valuerange_clients)\r\n\t--valuerange_clients is taken from clients.csv
    superset_query
182               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
183 BU Delta Lloyd Asset Management Portia PO_0038 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                             en                                    nl
183               <NA>       COUPON RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Zero coupon rate for non loans Couponrate van nul voor niet-leningen
                                                                                                                                                                                                                                               rule
183 The coupon is only applicable for fixed income and lic (inter company loans) instruments.\n\nAll other should therefore have couponrate 0.\n\nThus all non fixed income (dlam asset class2 ) which are also not LIC's should have couponrate 0.
                                                                                                                                condition Feedback      rule_load_date
183 Instruments with\n\n  (DLAMAssetClass1!='Fixed Income'    and DLAMAssetClass2!='LIC' and DLAMAssetClass2!='Deposit')\n\nand coupon!=0          2016-04-26 16:05:43
         source_file
183 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                    query
183 select DISTINCT\r\n\tinsid\r\n\t, COUPONRATE\r\n\t, DLAMAssetClass1\r\n\t, DLAMAssetClass2\r\n\t, DLAMAssetClass3\r\n\t, DLAMAssetClass4\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the subset for which the requirement holds\r\n\t(DLAMAssetClass1!='Fixed Income' \r\n\t\tand DLAMAssetClass2!='LIC'\r\n\t\tand DLAMAssetClass2!='Deposit')\r\n\t-- the ones failing the requirement\r\n\tand couponrate != 0
    superset_query
183               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
184 BU Delta Lloyd Asset Management Portia PO_0039 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                          en
184               <NA>       COUPON RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Zero coupon rate for specific fixed incomes
                                                  nl
184 Couponrate van nul voor specifieke fixed incomes
                                                                                                                                                                                            rule
184 There are some fixed income instruments which always have a zero couponrate.\n\nThese include: 'Fixed Income Fund', 'Fixed Income Derivative', 'Zero' coupon bonds and 'Other Fixed Income' 
                                                                                                                                                                                                        condition
184 Instruments with\n\n  DLAMAssetClass2='Fixed Income Fund'\n\n  or DLAMAssetClass2='Fixed Income Derivative'\n\n  or DLAMAssetClass3='Zero'\n\n  or DLAMAssetClass2='Other Fixed Income'\n\nand also coupon!=0
    Feedback      rule_load_date      source_file
184          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                       query
184 select DISTINCT\r\n\tinsid\r\n\t, COUPONRATE\r\n\t, DLAMAssetClass1\r\n\t, DLAMAssetClass2\r\n\t, DLAMAssetClass3\r\n\t, DLAMAssetClass4\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the subset for which the requirement holds\r\n\t(\tDLAMAssetClass2='Fixed Income Fund'\r\n\t\tor DLAMAssetClass2='Fixed Income Derivative'\r\n\t\tor DLAMAssetClass3='Zero'\r\n\t\tor DLAMAssetClass2='Other Fixed Income'\r\n\t)\r\n\t-- the ones failing the requirement\r\n\tand couponrate != 0
    superset_query
184               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
185 BU Delta Lloyd Asset Management Portia PO_0040 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                                     en
185               <NA>     CURRENCY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Instruments have currencies of 3 upper case characters
                                                         nl                                                                     rule
185 Instrumenten hebben een munt symbo0l van 3 hoofdletters A currency symbol should always be 3 characters which are all upper case
                                                                    condition Feedback      rule_load_date      source_file
185 Instruments with \n\n  stringlength munt != 3\n\n  or upper(MUNT) != MUNT          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                          query
185 select DISTINCT\r\n\tinsid\r\n\t,MUNT\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t(len(MUNT)!=3\r\n\tor UPPER(MUNT) COLLATE Latin1_General_CS_AS != MUNT COLLATE Latin1_General_CS_AS\r\n\t) and scope_dm = 1\r\n
    superset_query
185               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
186 BU Delta Lloyd Asset Management Portia PO_0041 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource     referencedata                                               en
186               <NA>     CURRENCY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  exchangerates.csv Instruments have one of the available currencies
                                                         nl
186 Instrumente hebben een van de beschikbare munt symbolen
                                                                                                                                             rule
186 A currency symbol should always be one of the available/known currencies.\n\nThe available currencies are taken from the same system (Portia)
                                                               condition Feedback      rule_load_date      source_file
186 Instruments with\n\n  munt not in any symbol of exchangerates export          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                 query superset_query
186 select DISTINCT\r\n\tinsid\r\n\t,MUNT\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tMUNT not in (select fxid from PO_exchangerates)\r\n\tand scope_dm = 1               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
187 BU Delta Lloyd Asset Management Portia PO_0042   currency ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements         datasource referencedata                                     en                                nl
187               <NA>     CURRENCY RM-PortiaTotal_P_                Currencies are 3 upper case characters Munt symbolen zijn 3 hoofdletters
                                                                        rule                                                                condition Feedback
187 A currency symbol should always be 3 characters which are all upper case currencies with \n\n  stringlength munt != 3\n\n  or upper(MUNT) != MUNT         
         rule_load_date      source_file
187 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                           query
187 select DISTINCT\r\n\tfxid\r\n\t,MUNT\r\nfrom\r\n\tvx_PO_currency\r\nwhere\r\n\tlen(MUNT)!=3\r\n\tor UPPER(MUNT) COLLATE Latin1_General_CS_AS != MUNT COLLATE Latin1_General_CS_AS
    superset_query
187               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
188 BU Delta Lloyd Asset Management Portia PO_0043   currency ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements         datasource     referencedata                                          en                                         nl
188               <NA>     CURRENCY RM-PortiaTotal_P_  exchangerates.csv Currency is one of the available currencies Het munt symbool is een van de beschikbare
                                                                                                                                             rule
188 A currency symbol should always be one of the available/known currencies.\n\nThe available currencies are taken from the same system (Portia)
                                                              condition Feedback      rule_load_date      source_file
188 currencies with\n\n  munt not in any symbol of exchangerates export          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                         query superset_query
188 select DISTINCT\r\n\tfxid\r\n\t,MUNT\r\nfrom\r\n\tvx_PO_currency\r\nwhere\r\n\tMUNT not in (select fxid from PO_exchangerates)               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
189 BU Delta Lloyd Asset Management Portia PO_0044 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate                         dataelements                               datasource             referencedata                                      en
189               <NA> DLAM.Asset.Type.2, DLAM.Asset.Type.3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  dlam_asset_class_tree.csv DLAM Asset type matches asset type tree
                                                                 nl
189 De asset type 2 en 3 moeten beschikbaar zijn in asset type tree
                                                                                                                                                                                                                                                                                    rule
189 A tree of DLAM Asset types is defined, mapping each value to a single specific value for one abstraction higher.\n\nAll found combinations of Dlam asset type 1 (the highest abstraction) till 4 (the lowest abstraction) should be available in the predefined asset type hierarchy
                                                                                                                             condition Feedback      rule_load_date
189 Instruments with the combination of DLAMAsset type 1,2,3,4 \n\nnot available in all allowed combinations of DLAMAsset type 1,2,3,4          2016-04-26 16:05:43
         source_file
189 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   query
189 select DISTINCT\r\n\tinstr.insid,\r\n\tinstr.DLAMAssetClass1,\r\n\tinstr.DLAMAssetClass2,\r\n\tinstr.DLAMAssetClass3,\r\n\tinstr.DLAMAssetClass4\r\nfrom\r\n\tvx_PO_instrument as instr\r\n\tleft join\r\n\tvaluerange_assetclass as def\r\n\ton instr.DLAMAssetClass1 = def.DLAMAssetClass1\r\n\tand instr.DLAMAssetClass2 = def.DLAMAssetClass2\r\n\tand instr.DLAMAssetClass3 = def.DLAMAssetClass3\r\n\tand instr.DLAMAssetClass4 = def.DLAMAssetClass4\r\nwhere\r\n\tdef.DLAMAssetClass1 is null -- equals to no match found
    superset_query
189               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate                 ruleOwner              approvedBy
190 BU Delta Lloyd Asset Management Portia PO_0045 instrument ValidRange       NEED      Input             <NA> Financial Risk Management Fred Schulte Fischedick
    approvedDate resultApprovalDate dataelements                               datasource referencedata                                           en
190   2015-06-23         2015-06-23  DLAM.RATING RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  ratingmap.csv The DLAM rating is one of the allowed values
                                                            nl                                                                                rule
190 De DLAM Rating dient 1 van de toegestane waarden te hebben The DLAM rating is described by NR (no rating) or one as available in ratingmap.csv
                                                                         condition Feedback      rule_load_date      source_file
190 instruments with a dlam rating != NR \n\n    and not existing in the ratingmap          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                              query
190 select DISTINCT\r\n\tinsid,\r\n\tDLRating\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tDLRating != 'NR'\r\n\tand DLRating not in (select DLAMRating from map_ratings)
    superset_query
190               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
191 BU Delta Lloyd Asset Management Portia PO_0046 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate                             dataelements                               datasource        referencedata                                  en
191               <NA> DLAM.Sector1, DLAM.Sector2, DLAM.Sector3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  dlam_sector_tree.csv DLAM Sector matches the sector tree
                                                                         nl
191 De dlam sector 1, 2 en 3 moeten beschikbaar zijn in de dlam sector tree
                                                                                                                                                                                                                                                                        rule
191 A tree of DLAM sectors is defined, mapping each value to a single specific value for one abstraction higher.\n\nAll found combinations of Dlam sector 1 (the highest abstraction) till 4 (the lowest abstraction) should be available in the predefined sector hierarchy
                                                                                                                     condition Feedback      rule_load_date
191 Instruments with the combination of DLAMSector 1,2,3,4 \n\nnot available in all allowed combinations of DLAMSector 1,2,3,4          2016-04-26 16:05:43
         source_file
191 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         query
191 select DISTINCT\r\n\tinstr.insid,\r\n\tinstr.DLAMAssetClass1,\r\n\tinstr.DLAMSector1,\r\n\tinstr.DLAMSector2,\r\n\tinstr.DLAMSector3,\r\n\tinstr.DLAMSector4,\r\n\tinstr.*\r\nfrom\r\n\tvx_PO_instrument as instr\r\n\tleft join\r\n\tvaluerange_sector as def\r\n\ton instr.DLAMSector1 = def.DLSector1\r\n\tand instr.DLAMSector2 = def.DLSector2\r\n\tand instr.DLAMSector3 = def.DLSector3\r\n\tand instr.DLAMSector4 = def.DLSector4\r\nwhere\r\n\tdef.DLSector1 is null -- equals to no match found
    superset_query
191               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
192 BU Delta Lloyd Asset Management Portia PO_0047 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                            en
192         2015-06-16   EXPIRATION RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                The Expiration date (if any) is in the future
                                                   nl                                                                                rule
192 De expiration date dient in de toekomst te liggen Instruments having an expiration date, should have an expiration date in the future
                                                  condition Feedback      rule_load_date      source_file
192 instruments with\n\n  expiration date <= reporting date          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                            query
192 select DISTINCT\r\n\tinsid,\r\n\tExpirationdate,\r\n\tReportingDate\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tExpirationdate<=ReportingDate\r\n\tand scope_dm = 1
    superset_query
192               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner    approvedBy approvedDate
193 BU Delta Lloyd Asset Management Portia PO_0048   currency ValidRange       NEED      Input             <NA> Data Management Dennis Kolmus         <NA>
    resultApprovalDate dataelements         datasource referencedata                                        en                                    nl
193         2015-06-16       FXRATE RM-PortiaTotal_P_                The FX rate needs to be strictly positive De fx rate dient groter dan 0 te zijn
                                                                  rule                   condition Feedback      rule_load_date      source_file
193 Currencies have a fx rate, which needs to be non zero and positive Currencies with fxrate <= 0          2016-04-26 16:05:43 portia_rules.csv
                                                                                        query superset_query
193 select DISTINCT\r\n\tfxid,\r\n\tFXRATE \r\nfrom\r\n\tvx_PO_currency\r\nwhere\r\n\tFXRATE <= 0               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner    approvedBy approvedDate
194 BU Delta Lloyd Asset Management Portia PO_0049   currency ValidRange       NEED      Input             <NA> Data Management Dennis Kolmus         <NA>
    resultApprovalDate dataelements         datasource referencedata                                                   en                                         nl
194         2015-06-16       FXRATE RM-PortiaTotal_P_                The FX rate needs to be constant per currency symbol De fx rate dient constant te zijn per munt
                                                           rule                                                                                  condition Feedback
194 One currency can only have one fx rate (on a specific date) Currencies and fx rates grouped by currency symbol\n\n  having more than 1 distinct fxrate         
         rule_load_date      source_file
194 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                   query superset_query
194 select DISTINCT\r\n\tfxid,\r\n\tReportingDate\r\nfrom\r\n\tvx_PO_currency\r\ngroup by\r\n\tfxid, ReportingDate\r\nhaving\r\n\tcount(distinct(FXRATE)) > 1               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
195 BU Delta Lloyd Asset Management Portia PO_0050 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                 en                                 nl
195         2015-06-16   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                DLINT ISINS are 11 characters long DLINT ISINS zijn 11 karakters lang
                                                                                                                                                                                                     rule
195 The ISIN field (identifier) is used for different identifiers.\n\nThe identifiers found need to be one of the expected formats.\n\nThe ones starting with DLINT should have a length of 11 characters
                                                                               condition Feedback      rule_load_date      source_file
195 Instruments with an isin that starts with 'DLINT'\n\n  but is not 11 characters long          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                               query
195 select DISTINCT\r\n\tinsid,\r\n\tISIN\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the set for which this rule holds\r\n\tISIN like 'DLINT%'\r\n\t-- getting the failures\r\n\tand len(ISIN)!=11\r\n\tand scope_dm = 1
    superset_query
195               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
196 BU Delta Lloyd Asset Management Portia PO_0051 instrument ValidRange       NEED      Input       2015-06-16 Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                  en
196               <NA>   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                11 character isins start with DLINT
                                           nl
196 ISINS van 11 karakters beginnen met DLINT
                                                                                                                                                                                         rule
196 The ISIN field (identifier) is used for different identifiers.\n\nThe identifiers found need to be one of the expected formats.\n\nThe ones having a length of 11, start with DLINT or U_
                                                                                               condition Feedback      rule_load_date      source_file
196 Instruments with an isin that are 11 characters long\n\n  but do not start with 'DLINT'\n\n nor 'U_'          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                               query
196 select DISTINCT\r\n\tinsid,\r\n\tISIN\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the set for which this rule holds\r\n\tlen(ISIN)=11\r\n\t-- getting the failures\r\n\tand ISIN not like 'DLINT%'\r\n\tand ISIN not like 'U_%'\r\n\tand scope_dm  = 1
    superset_query
196               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
197 BU Delta Lloyd Asset Management Portia PO_0052 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                              en                                     nl
197         2015-06-16   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                DLINT ISINS have numeric suffix DLINT ISINS hebben enkel opvolgcijfers
                                                                                                                                                                                                  rule
197 The ISIN field (identifier) is used for different identifiers.\n\nThe identifiers found need to be one of the expected formats.\n\nThe ones starting with DLINT should have only successive digits
                                                                                       condition Feedback      rule_load_date      source_file
197 Instruments with an isin that start with 'DLINT' and which 6 character suffix is not numeric          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                 query
197 select DISTINCT\r\n\tinsid,\r\n\tISIN,\r\n\tright(ISIN, 6) as isin_suffix\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the set for which this rule holds\r\n\tISIN like 'DLINT%'\r\n\t-- getting the failures\r\n\tand 1!=isnumeric(right(ISIN, 6))\r\n\tand scope_dm = 1
    superset_query
197               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
198 BU Delta Lloyd Asset Management Portia PO_0053 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                               en                               nl
198               <NA>   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                PART ISINS are 7 characters long PART ISINS zijn 7 karakters lang
                                                                                                                                                                                                                                                                                     rule
198 The ISIN field (identifier) is used for different identifiers.\n\nThe identifiers found need to be one of the expected formats.\n\nThe ones starting with PART should have a length of 7 characters.\n\nVerified with deltalloydlife.be (Fatima / Eric) by Ronald Bark on 9 june 2015
                                                                             condition                                             Feedback      rule_load_date
198 Instruments with an isin that starts with 'PART'\n\n  but is not 7 characters long 9 juni aan deltalloydlife.be (Fatima & Eric gevraagd 2016-04-26 16:05:43
         source_file
198 portia_rules.csv
                                                                                                                                                                                                             query
198 select DISTINCT\r\n\tinsid,\r\n\tISIN\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the set for which this rule holds\r\n\tISIN like 'PART%'\r\n\t-- getting the failures\r\n\tand len(ISIN)!=7\r\n\tand scope_dm = 1
    superset_query
198               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
199 BU Delta Lloyd Asset Management Portia PO_0054 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                en                                      nl
199               <NA>   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                7 character isins start with PART ISINS van 7 karakters beginnen met PART
                                                                                                                                                                                                                                                                  rule
199 The ISIN field (identifier) is used for different identifiers.\n\nThe identifiers found need to be one of the expected formats.\n\nThe ones having a length of 7, start with PART\n\nVerified with deltalloydlife.be (Fatima / Eric) by Ronald Bark on 9 june 2015
                                                                                condition                                             Feedback      rule_load_date
199 Instruments with an isin that are 7 characters long\n\n  but do not start with 'PART' 9 juni aan deltalloydlife.be (Fatima & Eric gevraagd 2016-04-26 16:05:43
         source_file
199 portia_rules.csv
                                                                                                                                                                                                                query
199 select DISTINCT\r\n\tinsid,\r\n\tISIN\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the set for which this rule holds\r\n\tlen(ISIN)=7\r\n\t-- getting the failures\r\n\tand ISIN not like 'PART%'\r\n\tand scope_dm = 1
    superset_query
199               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
200 BU Delta Lloyd Asset Management Portia PO_0055 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                             en                                    nl
200               <NA>   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                PART ISINS have numeric suffix PART ISINS hebben enkel opvolgcijfers
                                                                                                                                                                                                                                                                                  rule
200 The ISIN field (identifier) is used for different identifiers.\n\nThe identifiers found need to be one of the expected formats.\n\nThe ones starting with PART should have only successive digits\n\nVerified with deltalloydlife.be (Fatima / Eric) by Ronald Bark on 9 june 2015
                                                                                       condition                                             Feedback
200 Instruments with an isin that start with 'PART' and which' 3 character suffix is not numeric 9 juni aan deltalloydlife.be (Fatima & Eric gevraagd
         rule_load_date      source_file
200 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                query
200 select DISTINCT\r\n\tinsid,\r\n\tISIN,\r\n\tright(ISIN, 3) as isin_suffix\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the set for which this rule holds\r\n\tISIN like 'PART%'\r\n\t-- getting the failures\r\n\tand 1!=isnumeric(right(ISIN, 3))\r\n\tand scope_dm = 1
    superset_query
200               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
201 BU Delta Lloyd Asset Management Portia PO_0056 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                        en                           nl
201         2015-06-16   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                ISINS are in known format ISINS hebben bekende formaat
                                                                                                                                                                                                               rule
201 The ISIN field (identifier) is used for different identifiers.\n\nThe identifiers found need to be one of the expected formats.\n\nThis rule verifies that all ISINS have one of the known and expected formats
                                                                                                                                                  condition Feedback
201 Instruments with an isin that does not\n\n  start with DLINT, PART or U_S31, U_S33, U_Z31\n\n  and are not a regular 12 character isin or future ticker         
         rule_load_date      source_file
201 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         query
201 select DISTINCT\r\n\tinsid,\r\n\tISIN\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tnot ISIN like 'PART%'\r\n\tand not ISIN like 'DLINT%'\r\n\tand not ISIN like 'U\\_S31%' ESCAPE '\\'\r\n\tand not ISIN like 'U\\_S33%' ESCAPE '\\'\r\n\tand not ISIN like 'U\\_Z31%' ESCAPE '\\'\r\n\tand not (ISIN like '[A-Z][A-Z]%' and len(ISIN)=12) -- regular isin\r\n\tand not (ISIN like '[A-Z][A-Z ][FGHJKMNQUVXZ][0-9]' ) -- future symbol, 3rd character indicates delivery month\r\n\tand not ISIN = '' -- already covered by business rule PO_0014\r\n\tand scope_dm = 1
    superset_query
201               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
202 BU Delta Lloyd Asset Management Portia PO_0057 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                   en
202         2015-06-16   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Duplicated ISINS have equal IssuerID
                                                  nl
202 Gelijke ISINS dienen gelijke IssuerIDs te hebben
                                                                                                                                                                                                                                                                 rule
202 The ISIN field (identifier) is not unique per instrument.\n\nOne issuer can issue an instrument type on multiple exchanges, creating multiple instruments with the same ISIN.\n\nTherefor if two instruments have the same ISIN, they should have the same Issuer
                                                          condition Feedback      rule_load_date      source_file
202 Instruments grouped by ISIN having count(distinct issuerid) > 1          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                               query
202 select DISTINCT\r\n\tinsid,\r\n\tfails.ISIN,\r\n\tfails.num_issuers,\r\n\tIssuerId\r\nfrom\r\n\t(\r\n\tselect\r\n\t\tISIN,\r\n\t\tcount(distinct IssuerID) as num_issuers\r\n\tfrom\r\n\t\tvx_PO_instrument\r\n\tgroup by\r\n\t\tISIN\r\n\thaving\r\n\t\tcount(distinct IssuerID)>1\r\n\t\t) as fails\r\n\tleft join vx_PO_instrument\r\n\ton fails.ISIN = vx_PO_instrument.ISIN\r\n\twhere scope_dm = 1
    superset_query
202               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
203 BU Delta Lloyd Asset Management Portia PO_0058 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                             en                                           nl
203         2015-06-16   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Futures have 4 character ISINS Alle futures hebben een ISIN van 4 karakters
                                                                                                   rule                                                   condition
203 If the security class is future, the isin should indicate a future. These always have 4 characters. Instruments \n\n with SecClass='Future'\n\nand len(ISIN)!=4
    Feedback      rule_load_date      source_file
203          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                        query
203 select DISTINCT\r\n\tinsid,\r\n\tISIN,\r\n\tSecClass\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tSecClass = 'Future'\r\n\tand len(ISIN)!=4\r\n\tand scope_dm = 1
    superset_query
203               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
204 BU Delta Lloyd Asset Management Portia PO_0059 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                    en
204         2015-06-16   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                4 character ISINS are always a future
                                          nl
204 ISIN van 4 karakters zijn altijd futures
                                                                                                                                                                                                        rule
204 If the security class is future, the isin should indicate a future. \n\nThese always have 4 characters, and are the only ones being a future.\n\nThis rule verifies that there are no others of length 4
                                                      condition Feedback      rule_load_date      source_file
204 Instruments \n\n with SecClass!='Future'\n\nand len(ISIN)=4          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                        query
204 select DISTINCT\r\n\tinsid,\r\n\tISIN,\r\n\tSecClass\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tSecClass != 'Future'\r\n\tand len(ISIN)=4\r\n\tand scope_dm = 1
    superset_query
204               
                                 BU system      BR entitytype      Depth Importance  ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
205 BU Delta Lloyd Asset Management Portia PO_0060 instrument ValidRange       NEED Copy create             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                     en
205         2015-06-16   ISSUE_DATE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                The issue date (if any) is in the past
                                               nl
205 De issue date dient in het verleden te liggen
                                                                                                                                                                                                                                                                                                                                              rule
205 Instruments having an issue date, should have an issue date in the past.\n\nNewly issued instruments can have an issue date in the future, but these should not exist in the portiatotal export as they have no holding. \n\nExceptionally there can already be a position ahead of issueing. This will usually not be more than 10 days ahead
                                                      condition Feedback      rule_load_date      source_file
205 instruments with\n\n  issue date > reporting date + 10 days          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                            query
205 select DISTINCT\r\n\tinsid,\r\n\tIssuedate,\r\n\tReportingDate,\r\n\t[Description]\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tIssuedate > DateAdd(day, 10, ReportingDate)\r\n\tand scope_dm = 1\r\n
    superset_query
205               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
206 BU Delta Lloyd Asset Management Portia PO_0061 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                               en
206         2015-06-16   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Duplicated ISINS only for exchange and mix funds
                                                       nl
206 Dubbele ISINs enkel bij andere beurs of tbv MIX fonds
                                                                                                                                                                                                                                                                                                       rule
206 Duplicate ISINS can occur if and only if, the ISIN has been traded at multiple exchanges or it is duplicated for mix fund valuation (then it contains "tbv MIX" as suffix in the Description1). Find all ISINS which have duplications not explained by either multiple exchanges or mix fund versions.
                                                                                                                                                                                                                                                                  condition
206 Instruments grouped by equal ISIN's\n\n    with num for the number of instruments\n\n    num_exchanges for the number of different Exchange's\n\n    and num_TbvMIX as the number of Description1's with suffix 'tbv MIX'\n\n    Having num_exchanges+num_TbvMIX != num
    Feedback      rule_load_date      source_file
206          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     query
206 select DISTINCT\r\n\tinsid,\r\n\tfails.ISIN,\r\n\tnum_exchanges,\r\n\tnum_tbvmix,\r\n\tnum_isin,\r\n\t[Description]\r\nfrom\r\n\t(\t\r\n\tselect\r\n\t\texchange_count.ISIN,\r\n\t\tnum_exchanges,\r\n\t\tisnull(num_tbvmix, 0) as num_tbvmix,\r\n\t\tnum_isin\r\n\tfrom\r\n\t\t(\r\n\t\tselect\r\n\t\t\tISIN,\r\n\t\t\tcount(distinct(Exchange)) as num_exchanges\r\n\t\tfrom\r\n\t\t\tvx_PO_instrument\r\n\t\tgroup by\r\n\t\t\tISIN\r\n\t\t) as exchange_count\r\n\t\tleft join\r\n\t\t(\r\n\t\tselect\r\n\t\t\tISIN,\r\n\t\t\tcount(*) as num_tbvmix\r\n\t\tfrom\r\n\t\t\tvx_PO_instrument\r\n\t\twhere\r\n\t\t\tDescription like '%tbv MIX'\r\n\t\tgroup by ISIN\r\n\t\t\t) as mix_count\r\n\t\ton exchange_count.ISIN=mix_count.ISIN\r\n\t\tleft join\r\n\t\t(select\r\n\t\t\tISIN,\r\n\t\t\tcount(*) as num_isin\r\n\t\tfrom\r\n\t\t\tvx_PO_instrument\r\n\t\tgroup by ISIN\r\n\t\t) as isin_count\r\n\t\ton exchange_count.ISIN=isin_count.ISIN\r\n\t\twhere num_exchanges+isnull(num_tbvmix,0)!=num_isin\r\n\t) as fails\r\n\tleft join vx_PO_instrument as details\r\n\ton fails.ISIN = details.ISIN\r\n\twhere scope_dm = 1\r\n\r\norder by fails.ISIN\r\n\r\n--select ISIN, count(*) from vx_PO_instrument group by ISIN having(count(*))>1 order by ISIN\r\n--select insid, ISIN, KOERS, Duration, InitialDurationy, * from vx_PO_instrument where ISIN='DLINT006541'\r\n
    superset_query
206               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
207 BU Delta Lloyd Asset Management Portia PO_0062 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                            en
207         2015-06-16   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Listed instruments should have a regular ISIN
                                                   nl                                                        rule
207 Geliste ISINs dienen een reguliere isin te hebben All instruments that are listed, should have a regular isin
                                                                                                             condition Feedback      rule_load_date      source_file
207 Instruments which \n\n  are listed\n\n  do not have a 12 character regular isin\n\n  nor a 4 character future code          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                       query
207 select DISTINCT\r\n\tinsid,\r\n\t[Description],\r\n\tListed,\r\n\tISIN,\r\n\tISIN_Regular\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the verified group\r\n\tListed=1\r\n\t-- the ones failing the expectation\r\n\tand not (ISIN like '[A-Z][A-Z]%' and len(ISIN)=12) -- regular isin\r\n\tand not (ISIN like '[A-Z][A-Z ][FGHJKMNQUVXZ][0-9]' ) -- future symbol, 3rd character indicates delivery month\r\n\tand scope_dm = 1
    superset_query
207               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
208 BU Delta Lloyd Asset Management Portia PO_0063 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                                                         en
208         2015-06-16   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                ISINs with U_ prefix or PART have a 'DL Belgi? Life' Source and 'DLPR' SIC
                                                                                nl
208 ISINs beginnen met U_ of PART hebben een Source 'DL Belgi? Life' en SIC 'DLPR'
                                                                                                                                                                                                                       rule
208 All instruments that have an ISIN starting with U_ or PART but not having both 'DL Belgi? Life' as Source and 'DLPR' as SIC.\n\n\n\nVerified dependency: U_- or PART- ISIN => SICCode 'DLPR' & Source 'DL Belgi? Life'.
                                                                                                                                                                                 condition
208 Securities which \n\n\n\n-have ISIN starting with U_ or PART, and SICCode different from 'DLPR'\n\n\n\n-have ISIN starting with U_ or PART, and Source different from 'DL Belgi? Life'
    Feedback      rule_load_date      source_file
208          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                               query
208 select DISTINCT\r\n\tinsid,\r\n\tISIN,\r\n\tSource,\r\n\tSICCode, *\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- verified subset\r\n\t(\r\n\t\tISIN LIKE 'U\\_%' ESCAPE '\\'\r\n\t\tOR ISIN LIKE 'PART%'\r\n\t\t)\r\n\t-- non expected attributes\r\n\tand (\r\n\t\tSource!='DL Belgi� Life'\r\n\t\tOR SICCode!='DLPR'\r\n\t)\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
208               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
209 BU Delta Lloyd Asset Management Portia PO_0064 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                      en
209         2015-06-16   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Internal asset classes have DLINT isins
                                          nl
209 Interne asset classen hebben DLINT isins
                                                                                                                                                                                                                                                                                                                      rule
209 The asset classes Private Equity, LIC and LOS should have DLINT isins.\n\n\n\nThe LOS class also contains Private Placements which can have an ISIN. All other LOS'es should have DLINT isins, but because no distinction can be made cannot verify those\n\nVerified dependency: Internal AssetClass => Internal ISIN
                                                                                                     condition Feedback      rule_load_date      source_file
209 Securities with\n\n\n\n-asset class2 'Private Equity' or 'LIC'\n\n\n\n-and an ISIN not starting with DLINT          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            query
209 select DISTINCT\r\n\tinsid,\r\n\tISIN,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tSecClass\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- subset\r\n\t(\r\n\t\tDLAMAssetClass2='Private Equity'\r\n\t\tOR DLAMAssetClass2='LIC'\r\n\t\t-- OR DLAMAssetClass3='LOS' -- The LOS class also contains Private Placements which can have an ISIN.\r\n\t\t-- All other LOS'es should have DLINT isins, but because no distinction can be made cannot verify those.\r\n\t)\r\n\t-- failing reqs\r\n\tand (\r\n\t\tISIN not like 'DLINT%'\r\n\t)\r\n\tand scope_dm = 1
    superset_query
209               
                                 BU system      BR entitytype      Depth Importance  ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
210 BU Delta Lloyd Asset Management Portia PO_0065 instrument ValidRange       NEED Copy create             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                          en
210         2015-06-16     MATURITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                The maturity date (if any) is in the future
                                                 nl
210 De maturity date dient in de toekomst te liggen
                                                                                                                                                                                                rule
210 Instruments having a maturity date, should have a maturity date in the future.\n\nMatured instruments can have a maturity date in the past but these should not exist in the portiatotal export.
                                            condition Feedback      rule_load_date      source_file
210 instruments with\n\n  MaturityD <= reporting date          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                   query
210 select DISTINCT\r\n\tinsid,\r\n\tMaturityDate,\r\n\tReportingDate,\r\n\t[Description],\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tSecClass\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tMaturityDate<=ReportingDate\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
210               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
211 BU Delta Lloyd Asset Management Portia PO_0066    holding ValidRange       NEED      Input             <NA> Valuation Desk Ilona Balvert         <NA>
    resultApprovalDate dataelements         datasource referencedata                                                                         en
211               <NA> MARKET_VALUE RM-PortiaTotal_P_                Marketvalue for nonzero quantity should have the same sign as the quantity
                                                                                       nl
211 Marktwaarde bij hoeveelheid ongelijk aan 0 moet hetzelfde teken hebben als het aantal
                                                                                                                   rule
211 All holdings with nonzero quantity and nonzero price, should have a marketvalue with the same sign as the quantity.
                                                                                                                                                condition Feedback
211 Holdings where quantity!=0 \n\n   and ( (marketvalue = 0 and koers!=0)\n\n             or marketvalue!=0 and sign(quantity)!=sign(marketvalue)\n\n  )         
         rule_load_date      source_file
211 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                           query
211 select DISTINCT\r\n\tvx_PO_holding.insid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tKOERS,\r\n\tMWinclLREur\r\nfrom\r\n\tvx_PO_holding\r\nwhere\r\n\t-- applicable set\r\n\tQUANTITY != 0\r\n\t-- failure filter\r\n\tand (\t(MWinclLREur=0 AND KOERS!=0)\r\n\t\t\tOR (MWinclLREur!=0 AND sign(QUANTITY)!=SIGN(MWinclLREur))\r\n\t\t\t)
    superset_query
211               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
212 BU Delta Lloyd Asset Management Portia PO_0067    holding ValidRange       NEED      Input             <NA> Valuation Desk Ilona Balvert         <NA>
    resultApprovalDate dataelements         datasource referencedata                                 en                                 nl
212               <NA> MARKET_VALUE RM-PortiaTotal_P_                Zero marketvalue for zero quantity Geen marktwaarde bij hoeveelheid 0
                                                              rule                                             condition Feedback      rule_load_date      source_file
212 All holdings with zero quantity  should have zero marketvalue. Holdings where quantity=0 \n\n   and marketvalue != 0          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                    query
212 select DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tKOERS,\r\n\tMWinclLREur\r\nfrom\r\n\tvx_PO_holding\r\nwhere\r\n\t-- applicable set\r\n\tQUANTITY = 0\r\n\t-- failure filter\r\n\tand MWinclLREur!=0
    superset_query
212               
                                 BU system      BR entitytype      Depth Importance           ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
213 BU Delta Lloyd Asset Management Portia PO_0068    holding ValidRange       NEED Export Configuration             <NA> Valuation Desk Ilona Balvert         <NA>
    resultApprovalDate  dataelements         datasource referencedata                                                                          en
213               <NA> NOMINAL_VALUE RM-PortiaTotal_P_                Nominalvalue for nonzero quantity should have the same sign as the quantity
                                                                                               nl
213 Nominale waarde bij hoeveelheid ongelijk aan 0 moet hetzelfde teken hebben als de hoeveelheid
                                                                                                 rule
213 All holdings with nonzero quantity should have a nominal value with the same sign as the quantity
                                                                                                                                      condition Feedback
213 Holdings where quantity!=0 \n\n   and (nominal value = 0\n\n              or nominal value != 0 and sign(quantity) != sign (nominal value))         
         rule_load_date      source_file
213 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                    query
213 select DISTINCT\r\n\tvx_PO_holding.insid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tKOERS,\r\n\tMUNT,\r\n\tNominaalEur\r\nfrom\r\n\tvx_PO_holding\r\nwhere\r\n\t-- applicable set\r\n\tQUANTITY != 0\r\n\t-- failure filter\r\n\tand (NominaalEur=0\r\n\t\tOR (NominaalEur !=0 and SIGN(QUANTITY)!=SIGN(NominaalEur)\r\n\t\t))
    superset_query
213               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
214 BU Delta Lloyd Asset Management Portia PO_0069    holding ValidRange       NEED      Input             <NA> Valuation Desk Ilona Balvert         <NA>
    resultApprovalDate  dataelements         datasource referencedata                             en                                     nl
214               <NA> NOMINAL_VALUE RM-PortiaTotal_P_                Zero nominal for zero quantity Geen nominale waarde bij hoeveelheid 0
                                                              rule                                               condition Feedback      rule_load_date
214 All holdings with zero quantity should have zero nominal value Holdings where quantity=0 \n\n   and nominal value != 0          2016-04-26 16:05:43
         source_file
214 portia_rules.csv
                                                                                                                                                                                                              query
214 select DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tKOERS,\r\n\tMUNT,\r\n\tNominaalEur\r\nfrom\r\n\tvx_PO_holding\r\nwhere\r\n\t-- applicable set\r\n\tQUANTITY = 0\r\n\t-- failure filter\r\n\tand NominaalEur!=0
    superset_query
214               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
215 BU Delta Lloyd Asset Management Portia PO_0070 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate dataelements                               datasource referencedata                                            en
215         2015-06-16  OPTION_TYPE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Option type is Put or Call or an empty string
                                                              nl                                                rule
215 Optie type dient 'Put' of 'Call' of een lege string te zijn. The Option type is neither 'Put' nor 'Call' nor ''.
                                                                   condition Feedback      rule_load_date      source_file
215 Each instrument for which Option type is neither 'Put' nor 'Call' nor ''          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                               query superset_query
215 select DISTINCT\r\n\tinsid,\r\n\tOption_type\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tOption_type not in ('Call', 'Put', '')\r\n\tand scope_dm = 1               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate                 ruleOwner              approvedBy
216 BU Delta Lloyd Asset Management Portia PO_0071 instrument ValidRange       NEED      Input             <NA> Financial Risk Management Fred Schulte Fischedick
    approvedDate resultApprovalDate dataelements                               datasource referencedata                                 en
216   2015-06-23         2015-06-23  DLAM.RATING RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                All Bonds should have a DLAMRating
                                                 nl
216 Alle obligaties dienen een DLAMRating te hebben
                                                                                                                                                                      rule
216 When an instrument is a bond, it should have a DLAMRating. Deposits and inter company loans (LIC) are excluded.\n\n\n\nVerified relation: Bond => available DLAMRating
                                                                           condition Feedback      rule_load_date      source_file
216 Instruments with DLAMAssetClass2 equal to 'Bond'\n\nand DLAMRating equal to 'NR'          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                              query
216 select DISTINCT\r\n\tinsid,\r\n\tDLRating,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tSecClass,\r\n\tDescription\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the subset\r\n\tDLAMAssetClass2='Bond'\r\n\t-- the failed requirements\r\n\tand DLRating = 'NR'\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
216               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate                 ruleOwner              approvedBy
217 BU Delta Lloyd Asset Management Portia PO_0072 instrument ValidRange       NEED      Input             <NA> Financial Risk Management Fred Schulte Fischedick
    approvedDate resultApprovalDate dataelements                               datasource referencedata                                    en
217   2015-06-23         2015-06-23  DLAM.RATING RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                All nonbonds should not have a rating
                                                       nl
217 Alle niet-obligaties dienen geen DLAMRating te hebben
                                                                                                                        rule
217 When an instrument is not a bond, it should not have a DLAMRating\n\n\n\nVerified relation: available DLAMRating => Bond
                                                                                    condition Feedback      rule_load_date      source_file
217 Instruments with DLAMAssetClass2 not equal to 'Bond' \n\nand DLAMRating not equal to 'NR'          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                              query
217 select DISTINCT\r\n\tinsid,\r\n\tDLRating,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tSecClass,\r\n\tDescription\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the subset\r\n\tDLAMAssetClass2!='Bond'\r\n\t-- the ones failing the requirement\r\n\tand DLRating != 'NR'\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
217               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
218 BU Delta Lloyd Asset Management Portia PO_0073 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate      dataelements                               datasource referencedata                                     en
218         2015-06-16 PAYMENT_FREQUENCY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Payment frequency is regular frequency
                                                           nl                                                                                              rule
218 De betaalfrequentie bevat een reguliere betaal frequentie The payment frequency should be one of 0, 1 (yearly), 2 (halfyearly), 4 (quarterly), 12 (monthly)
                                                      condition Feedback      rule_load_date      source_file
218 Instruments with Paymentfrequency not one of 0, 1, 2, 4, 12          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                       query
218 select DISTINCT\r\n\tinsid,\r\n\tPaymentFrequency\r\nfrom \r\n\tvx_PO_instrument\r\nwhere\r\n\tPaymentFrequency not in (0, 1, 2, 4, 12)\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
218               
                                 BU system      BR entitytype      Depth Importance           ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
219 BU Delta Lloyd Asset Management Portia PO_0074 instrument ValidRange       NEED Export Configuration             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate      dataelements                               datasource referencedata                                    en
219         2015-06-16 PAYMENT_FREQUENCY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Derivatives have no payment frequency
                                         nl
219 Derivaten hebben geen betaal frequentie
                                                                                                                                                                rule
219 All instruments either have dividend or intrest payment frequencies, except for derivatives. The derivatives which have a payment frequency are invalid.\n\n\n\n
                                                                    condition Feedback      rule_load_date      source_file
219 Instruments which are a derivative \n\nand have nonzero payment frequency          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    query
219 select DISTINCT\r\n\tinsid,\r\n\tPaymentFrequency,\r\n\t[Description],\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nfrom \r\n\tvx_PO_instrument\r\nwhere\r\n\t--DLAMAssetClass3 IN ('Future', 'Equity Option', 'Index Future')\r\n\t--OR DLAMAssetClass2  IN ('Equity Derivative'))   \r\n\t--(DLAMAssetClass2='Equity Derivative' or DLAMAssetClass3='Future' OR DLAMAssetClass2 like '*erivative*')\r\n\tlower(DLAMAssetClass2) like '%derivative%'\r\n\tAND DLAMAssetClass3 != 'Right'\r\n\tand PaymentFrequency!=0\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
219               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
220 BU Delta Lloyd Asset Management Portia PO_0075 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate      dataelements                               datasource referencedata                                      en
220         2015-06-30 PAYMENT_FREQUENCY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nonderivatives have a payment frequency
                                            nl
220 Nietderivaten hebben een betaal frequentie
                                                                                                                                                            rule
220 All instruments either have dividend or intrest payment frequencies, except for derivatives. The nonderivatives which have no payment frequency are invalid.
                                                                     condition Feedback      rule_load_date      source_file
220 Instruments which are not a derivative \n\nand have zero payment frequency          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
220 select  DISTINCT\r\n\tinsid,\r\n\tPaymentFrequency,\r\n\t[Description],\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nfrom \r\n\tvx_PO_instrument\r\nwhere\r\n\t--not (DLAMAssetClass2='Equity Derivative' or DLAMAssetClass3='Future')\r\n\t--and PaymentFrequency=0\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\t(( lower(DLAMAssetClass2) like '%derivative%' AND DLAMAssetClass3 = 'Right') \r\n\t\tOR lower(DLAMAssetClass2) NOT like '%derivative%')\r\n\tand PaymentFrequency=0\r\n\tand scope_dm = 1\r\n\tORDER BY DLAMAssetClass3 DESC\r\n\t
    superset_query
220               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
221 BU Delta Lloyd Asset Management Portia PO_0076 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate      dataelements                               datasource referencedata                                                  en
221         2015-06-30 PAYMENT_FREQUENCY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Equities (non derivatives) have payment frequency 1
                                                      nl
221 Aandelen (niet derivaten) hebben betaal frequentie 1
                                                                                                                                                                                                                                          rule
221 All instruments either have dividend or intrest payment frequencies, except for derivatives. The nonderivative equities should all have payment frequency 1\n\nVerified relation: Equity (non equity derivative) => Payment frequency == 1
                                                                                                                     condition Feedback      rule_load_date
221 Instruments with DLAMAssetClass1 'Equity'  and AssetClass2 not 'Equity Derivative'\n\nand payment frequency not equal to 1          2016-04-26 16:05:43
         source_file
221 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                           query
221 select DISTINCT\r\n\tinsid,\r\n\tPaymentFrequency,\r\n\t[Description],\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2\r\nfrom \r\n\tvx_PO_instrument\r\nwhere\r\n\t(DLAMAssetClass1='Equity' and DLAMAssetClass2!='Equity Derivative')\r\n\tand PaymentFrequency!=1\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
221               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
222 BU Delta Lloyd Asset Management Portia PO_0077 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate                             dataelements                               datasource referencedata
222         2015-06-30 DLAM.Sector1, DLAM.Sector2, DLAM.Sector3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                  en                                                                           nl
222 Nontrivial sector for all but funds, derivatives, private equity Niet triviale sector voor alles behalve fondsen, derivaten en private equity
                                                                                                                                                                                                                                                    rule
222 All instruments which can have a sector assigned, should have a sector assigned.\n\nThe regular instruments (ordinary shares and bonds) should all have a sector defined. These are filtered by excluding all funds / derivatives / private equities
                                                                                                                                                                                                                                                                                                                                          condition
222 All instruments which have \n\n  DLAMAssetClass2!='Hedge Fund'\n\n and DLAMAssetClass2!='Equity Fund'\n\n and DLAMAssetClass2!='Fixed Income Fund'\n\n and DLAMAssetClass2!='Investment Fund'\n\n and DLAMAssetClass2!='Private Equity'\n\n and DLAMAssetClass2!='Deposit'\n\n and DLAMAssetClass2!='Equity Derivative'\n\n and DLAMSector1='-'
    Feedback      rule_load_date      source_file
222          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            query
222 select DISTINCT\r\n\tinsid,\r\n\tDLAMSector1,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tDLAMAssetClass4\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the subset\r\n\tDLAMAssetClass2!='Hedge Fund'\r\n\tand DLAMAssetClass2!='Equity Fund'\r\n\tand DLAMAssetClass2!='Fixed Income Fund'\r\n\tand DLAMAssetClass2!='Investment Fund'\r\n\tand DLAMAssetClass2!='Private Equity'\r\n\tand DLAMAssetClass2!='Deposit'\r\n\tand DLAMAssetClass2!='Equity Derivative'\r\n\tand DLAMAssetClass2!='Other'\r\n\t-- the failing attributes\r\n\tand DLAMSector1='-'\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
222               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
223 BU Delta Lloyd Asset Management Portia PO_0078    holding ValidRange       NEED      Input             <NA> Mid Office Kristine Prahl         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                                               en
223         2015-06-16     QUANTITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                If the Portfolio name starts with *, the quantity should be zero
                                                                    nl
223 Als de portfolio naam met een * begint, dient het aantal 0 te zijn
                                                                                                                                                                                                                                                                                                                                                                                                                    rule
223 If a portfolio has been marked unused (by the *), there shouldn't be any holding in it\n\n\n\nAll instruments within a portfolio name starting with an * should have no quantities for holdings.\n\nThe quantities can be neither positive (long positions) nor negative (short positions), only strictly zero (no position)\n\n\n\nVerified relation: (Portfolio Name starting with *) => (All its QUANTITY's == 0)
                                                            condition Feedback      rule_load_date      source_file
223 All holding with quantity != 0 and portfolio name starting with *          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                       query
223 select  DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tPortfolioNaam,\r\n\tQUANTITY\r\nfrom \r\n\tvx_PO_holding\r\nwhere\r\n\t-- the subset\r\n\tPortfolioNaam like '*%'\r\n\t-- the wrong attributes\r\n\tand QUANTITY!=0
    superset_query
223               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
224 BU Delta Lloyd Asset Management Portia PO_0079    holding ValidRange       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate   dataelements                               datasource referencedata                                           en
224         2015-06-30 PORTFOLIO_NAME RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                All Portfolio names should not have prefix *
                                                     nl
224 De portfolio naam dient niet met een * te beginnen.
                                                                                                                                                                                                                 rule
224 If a portfolio has been marked unused (by the *), there shouldn't be an active used version.\n\n\n\nThe export only contains positions, thus there should not be any PortfolioNaam's which exist with a * prefix.
                                              condition Feedback      rule_load_date      source_file
224 All holdings having PortfolioNaam starting with '*'          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                    query superset_query
224 select DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tPortfolioNaam,\r\n\tQUANTITY\r\nfrom\r\n\tvx_PO_holding \r\nwhere\r\n\tPortfolioNaam like '*%'               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
225 BU Delta Lloyd Asset Management Portia PO_0080    holding ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-20
    resultApprovalDate   dataelements                               datasource referencedata                                                      en
225         2015-06-30 PORTFOLIO_NAME RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Portfolio name and Securitynaam combinations are unique
                                                              nl
225 De combinaties van portfolio naam en Securitynaam zijn uniek
                                                                                                                                                                                                                            rule
225 The unique combinations of Portfolio naam and Security Naam occurring at multiple rows.\n\n\n\nVerified relation: ( X.(PortfolioNaam, Securitynaam) == Y.(PortfolioNaam, Securitynaam) ) => X==Y, for all postitions X and Y
                                                                                                                                           condition Feedback
225 For all combinations of Security.Naam and PortfolioNaam\n\n\n\nhaving more than one rows (instruments) occurrences\n\n\n\nreturn the instruments         
         rule_load_date      source_file
225 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                         query superset_query
225 select DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tcount(*) as num\r\nfrom\r\n\tvx_PO_holding\r\ngroup by\r\n\tinsid, prfid\r\nhaving \r\n\tcount(*)>1               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
226 BU Delta Lloyd Asset Management Portia PO_0081 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                      en                         nl
226         2015-06-30        PRICE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Prices are not negative Prijzen zijn niet negatief
                             rule                             condition Feedback      rule_load_date      source_file
226 Prices should not be negative All instruments with a negative price          2016-04-26 16:05:43 portia_rules.csv
                                                                                                        query superset_query
226 select DISTINCT\r\n\tinsid,\r\n\tKOERS,\r\n\t[Description]\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tKOERS<0               
                                 BU system      BR entitytype      Depth Importance           ErrorCause modificationDate              ruleOwner     approvedBy
227 BU Delta Lloyd Asset Management Portia PO_0082 instrument ValidRange       NEED Export Configuration             <NA> Information Management Nanda Kartaram
    approvedDate resultApprovalDate dataelements                               datasource referencedata
227         <NA>               <NA>      proddat RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                    en                                                                nl
227 ReportingDate is constant for all exported instruments in one dump ReportingDate is gelijk voor elk instrument in een export bestand
                                                                                      rule                                                                condition
227 Securities in the export file should all have the same export date (ReportingDate)\n\n All instruments having a reportingdate which is not unique in the export
                                                                                                                             Feedback      rule_load_date
227 Voor nieuwe afdeling met Gerton Claessen? Aangezien nog niet bestaat, voor IM, Gijs Heuving, die op 22 juni terug is van vakantie 2016-04-26 16:05:43
         source_file
227 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                         query
227 select DISTINCT\r\n\tinsid,\r\n\tvx_PO_instrument.source_date, \r\n\tvx_PO_instrument.source_file\r\nfrom\r\n\t(select source_date, source_file\r\n\tfrom vx_PO_instrument\r\n\tgroup by source_date, source_file\r\n\thaving count(distinct ReportingDate)>1\r\n\t) as failed_files\r\n\tleft join vx_PO_instrument\r\n\ton failed_files.source_date = vx_PO_instrument.source_date\r\n\tand failed_files.source_file = vx_PO_instrument.source_file
    superset_query
227               
                                 BU system      BR entitytype      Depth Importance           ErrorCause modificationDate              ruleOwner     approvedBy
228 BU Delta Lloyd Asset Management Portia PO_0083    holding ValidRange       NEED Export Configuration             <NA> Information Management Nanda Kartaram
    approvedDate resultApprovalDate dataelements         datasource referencedata                                                               en
228         <NA>               <NA>      proddat RM-PortiaTotal_P_                ReportingDate is constant for all exported positions in one dump
                                                                 nl                                                                                 rule
228 ReportingDate is gelijk voor elke holding in een export bestand Holdings in the export file should all have the same export date (ReportingDate)\n\n
                                                                condition
228 All holdings having a reportingdate which is not unique in the export
                                                                                                                             Feedback      rule_load_date
228 Voor nieuwe afdeling met Gerton Claessen? Aangezien nog niet bestaat, voor IM, Gijs Heuving, die op 22 juni terug is van vakantie 2016-04-26 16:05:43
         source_file
228 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                  query
228 select DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tvx_PO_holding.source_date, \r\n\tvx_PO_holding.source_file\r\nfrom\r\n\t(select source_date, source_file\r\n\tfrom vx_PO_holding\r\n\tgroup by source_date, source_file\r\n\thaving count(distinct ReportingDate)>1\r\n\t) as failed_files\r\n\tleft join vx_PO_holding\r\n\ton failed_files.source_date = vx_PO_holding.source_date\r\n\tand failed_files.source_file = vx_PO_holding.source_file
    superset_query
228               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
229 BU Delta Lloyd Asset Management Portia PO_0084    holding ValidRange       NEED        Bug             <NA> Mid Office Kristine Prahl         <NA>
    resultApprovalDate dataelements         datasource referencedata                                         en
229         2015-06-16     QUANTITY RM-PortiaTotal_P_                The quantity should not be small fractions
                                                                            nl
229 De aantallen stuks in een portefeuille dienen geen kleine fracties te zijn
                                                                                                                                                                                                                                                                                                                                                                                                                                        rule
229 The holding export should not contain quantities of (near)zero\n\n\n\nDue to bugs in Portia, after selling a full portfolio a small fraction (strictly bigger than -1, strictly less than 1) can remain left\n\n\n\nDatamanagement fixes this using 'buglists'. \n\n\n\nThis rule verifies that in this export the buglist is also applied\n\n\n\nIf the instrument is on the buglist, the static data is not verified by datamanagement
                           condition Feedback      rule_load_date      source_file
229 absolute QUANTITY is less than 1          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                   query
229 select DISTINCT\r\n\tprfid,\r\n\tinsid,\r\n\tQUANTITY,\r\n\tPosition\r\nfrom\r\n\tvx_PO_holding\r\nwhere\r\n\tABS(QUANTITY)<1\r\n\tAND ABS(QUANTITY)<>0.0\r\nORDER BY Prfid
    superset_query
229               
                                 BU system      BR entitytype      Depth Importance    ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
230 BU Delta Lloyd Asset Management Portia PO_0085 instrument ValidRange       NEED Export Timing             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                                     en
230         2015-06-30     SECURITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                The security identifier is unique id for static fields
                                                                            nl
230 De security id dient een unieke sleutel voor alle statische velden te zijn
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 rule
230 The Security name of an instrument should be its unique identifier.\n\nFor one security name the other attributes should be constant.\n\nOnly for Price there could be a difference in PortiaMaand (not PortiaProduction): 'Werkmaatschappijen' have their instruments at month end valued at 'bid', other clients at 'mid'. During the month both are valued at 'mid'.\n\nOther differences in price are because of timing issues with relation to the price import tool. PortiaTotal is created during the price-update proces.
                                                                                                                                                                                                                        condition
230 vx_PO_instrument is created by all unique used combinations of attributes (isin, price, security name, and so on).\n\nAll security names occurring twice therefore occur with at least two different values for one attribute
                                                                                                                                 Feedback      rule_load_date
230 OR vs RRPH Bid vs Mid pricing. \n\nKan en mag dus afwijkend zijn tenzij besloten wordt om S2 volgens een (1) standaard te rapporteren 2016-04-26 16:05:43
         source_file
230 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                            query
230 select DISTINCT\r\n\tinsid,\r\n\tvx_PO_instrument.SecurityNaam,\r\n\tsource_date,\r\n\tsource_file\r\nfrom\r\n\t(\r\n\tselect \r\n\t\tSecuritynaam\r\n\tfrom vx_PO_instrument\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\twhere scope_dm = 1\r\n\tgroup by Securitynaam\r\n\thaving count(*)>1\r\n\t) as duplicateds\r\n\tleft join vx_PO_instrument on duplicateds.Securitynaam=vx_PO_instrument.Securitynaam\r\n\torder by vx_PO_instrument.insid
    superset_query
230               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
231 BU Delta Lloyd Asset Management Portia PO_0086 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate dataelements                               datasource referencedata                                            en
231         2015-06-30       STRIKE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Available strike prices are strictly positive
                                          nl                                                  rule                                     condition Feedback
231 Beschikbare strike prijzen zijn positief The strike price, if any, should be strictly positive all instruments with strike non null and <= 0         
         rule_load_date      source_file
231 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                   query
231 select DISTINCT\r\n\tinsid,\r\n\tSTRIKE,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\nfrom\r\n\tvx_PO_instrument\r\nWHERE\r\n\tnot (STRIKE is NULL or LEN(LTRIM(STRIKE))=0)\r\n\tand STRIKE <=0 \r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
231               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
232 BU Delta Lloyd Asset Management Portia PO_0087 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate dataelements                               datasource referencedata                                               en
232         2015-06-30   UNDERLYING RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                The underlying instrument is existing instrument
                                                        nl                                                                             rule
232 Een onderliggend instrument is een bestaand instrument The underlying instruments should be an existing instrument identifier in Portia
                                                                        condition Feedback      rule_load_date      source_file
232 all instrument with an available underlyings which is not known as instrument          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                     query
232 select  DISTINCT\r\n\tunderl.insid,\r\n\tunderl.UNDERLYING,\r\n\tvx_PO_instrument.insid\r\nfrom (select distinct insid, UNDERLYING, scope_dm from vx_PO_instrument where UNDERLYING is not NULL) as underl\r\n\tleft join vx_PO_instrument on underl.UNDERLYING=vx_PO_instrument.insid\r\nwhere vx_PO_instrument.insid is null\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand underl.scope_dm = 1
    superset_query
232               
                                 BU system      BR entitytype    Depth Importance           ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
233 BU Delta Lloyd Asset Management Portia PO_0088 instrument HasValue       NEED Export Configuration             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                     en                             nl
233               <NA>       COUPON RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                No coupon for nonloans Geen coupon voor niet-leningen
                                                                                                                                         rule
233 Only loans should have a defined coupon. Equity should not get a coupon at all, thus not 0 but an empty string, resulting in a NULL value
                                                                                                  condition Feedback      rule_load_date      source_file
233 Instruments with coupon not equal to NULL and  DLAMAssetClass2 not one of LIC, Bond, Other Fixed Income          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                       query
233 SELECT DISTINCT\r\n\tinsid,\r\n    COUPONRATE,\r\n\tDLAMAssetClass2\r\nFROM\r\n    vx_PO_instrument\r\nWHERE\r\n    COUPONRATE != ISNULL(NULL,0)\r\n\tand DLAMAssetClass2 not in ('LIC', 'Bond', 'Other Fixed Income')\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
233               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
234 BU Delta Lloyd Asset Management Portia PO_0089 instrument SelfConsistent       NEED      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate dataelements                               datasource referencedata                                                                    en
234         2015-06-30       COUPON RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Bonds with zero coupon should have the coupon 0.00 in the description
                                                                                   nl
234 Obligaties zonder coupon dienen de coupon 0.00 in de omschrijving te hebben staan
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     rule
234 bonds with a 0 couponrate should have that coupon explicitly in the description, except for Floating rate notes. Floating rate notes should have no coupon in its description.\n\n\n\nVerified relation: (Zero coupon & is Bond) =>  There is a coupon of zero in description\n\nNote that the focus for this relation is that a coupon of zero should be in the description, where only Floating Rate Notes are allowed to have no description to implicitly indicate a zero coupon.
                                                                                                                                                                                        condition
234 All instruments with\n\n-SecClass=='Bond' \n\n\n\n-COUPON==0\n\n\n\n- DLAMAssetClass3!='Floating Rate Note'\n\n-no coupon in the description or a coupon not equal to zero in the description
    Feedback      rule_load_date      source_file
234          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 query
234 select DISTINCT\r\n\tinsid,\r\n\tCOUPONRATE,\r\n\tSecClass,\r\n\tDLAMAssetClass1\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tDescription1_Coupon,\r\n\tDescription1_CouponNum,\r\n\tDescription1\r\nfrom vx_PO_instrument\r\nwhere\r\n\t-- the zero coupon bonds that should have zero coupon in the description\r\n\tSecClass='Bond' \r\n\tand COUPONRATE=0\r\n\tand DLAMAssetClass3!='Floating Rate Note'\r\n\t-- the ones not having a coupon in the description, or the wrong one\r\n\tand (len(Description1_Coupon)=0 or Description1_CouponNum!=0)\r\n
    superset_query
234               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
235 BU Delta Lloyd Asset Management Portia PO_0090 instrument SelfConsistent       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                                                   en
235         2015-06-30       COUPON RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Bonds with nonzero coupon should have that coupon in the description
                                                                            nl
235 Obligaties met coupon dienen die coupon in de omschrijving te hebben staan
                                                                                                                                                                                                                                                                                                                                       rule
235 bonds with a nonzero couponrate should have that coupon explicitly in the description, except for Floating rate and fixed to floaters.\n\nVerified relation: (Nonzero coupon & is Bond) =>  The same coupon in description\n\nNote that the focus for this relation is that a coupon of nonzero should be explicitly in the description
                                                                                                                                                                                                                                                                   condition
235 All instruments with\n\n-SecClass=='Bond' \n\n\n\n-COUPON!=0\n\n\n\n- DLAMAssetClass3 not one of 'Floating Rate Note', 'Fix to Floater', 'Step-Up Bond', 'Inflation Linked Bond'\n\n-no coupon in the description or a coupon not equal to the COUPON in the description
    Feedback      rule_load_date      source_file
235          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
235 select DISTINCT\r\n\tinsid,\r\n\tCOUPONRATE,\r\n\tSecClass,\r\n\tDLAMAssetClass1\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3\r\n\tDescription1_Coupon,\r\n\tDescription1_CouponNum,\r\n\tDescription1\r\nfrom vx_PO_instrument\r\nwhere\r\n\t-- the nonzero coupon bonds that should have that coupon in the description\r\n\tSecClass='Bond' \r\n\tand COUPONRATE!=0\r\n\tand DLAMAssetClass3 not in ('Floating Rate Note', 'Fix to Floater', 'Step-Up Bond', 'Inflation Linked Bond')\r\n\t-- where the description doesn't match the couponrate\r\n\tand Description1_CouponNum!=COUPONRATE\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
235               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
236 BU Delta Lloyd Asset Management Portia PO_0091 instrument SelfConsistent       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                                           en
236         2015-06-30       COUPON RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Floating rate bonds should have no coupon in the description
                                                                                 nl
236 Floating rate obligaties dienen geen coupon in hun omschrijving te hebben staan
                                                                                                                                                                                                                                                                   rule
236 Floating rate notes should have no coupon in its description.\n\n\n\nIf there is a coupon in its description it should be 0, or the coupon should be equal to the actual used couponrate\n\nVerified relation: (Floating rate note)=>(No coupon in the Description)
                                                                                                                                                                                                                                      condition
236 All instruments with\n\n-SecClass=='Bond' \n\n\n\n-DLAMAssetClass3 one of 'Floating Rate Note', 'Fix to Floater', 'Step-Up Bond', 'Inflation Linked Bond'\n\n-and a coupon in the description\n\n-description coupon != coupon, or coupon=0
    Feedback      rule_load_date      source_file
236          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           query
236 select DISTINCT\r\n\tinsid,\r\n\tCOUPONRATE,\r\n\tSecClass,\r\n\tDLAMAssetClass1\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tDescription1_Coupon,\r\n\tDescription1_CouponNum,\r\n\tDescription1\r\nfrom vx_PO_instrument\r\nwhere\r\n\t-- the bonds that should not have a coupon in the description\r\n\tSecClass='Bond' \r\n\tand DLAMAssetClass3 in ('Floating Rate Note', 'Fix to Floater', 'Step-Up Bond', 'Inflation Linked Bond')\r\n\t-- the ones having a coupon in the description\r\n\tand len(Description1_Coupon)!=0 \r\n\tand (COUPONRATE!=Description1_CouponNum or COUPONRATE=0)\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
236               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
237 BU Delta Lloyd Asset Management Portia PO_0092 instrument SelfConsistent       NEED      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate dataelements                               datasource referencedata                                                                 en
237         2015-06-30   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Futures have their first 4 characters of ISINs as BB ticker prefix
                                                                         nl
237 Futures hebben een hun eerste 4 characters van diens ISIN als BB ticker
                                                                                                                                                                                                                            rule
237 Futures have an ISIN that closely resembles the BB ticker. The BB ticker is equal to the first 4 characters of the future, with the exchange behind it. Verified dependency: SecClass == Future => BBTicker starts with ISIN
                                                                                                                                 condition Feedback      rule_load_date
237 Securities which\n\n-have SecClass 'Future' and the first 4 characters of ISIN are not equal to the first 4 characters of BBTicker\n\n          2016-04-26 16:05:43
         source_file
237 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
237 select DISTINCT\r\n\tinsid,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tisin,\r\n\tBBTicker,\r\n\tleft(isin, 4) as isin_prefix,\r\n\tleft(BBTicker, 4) as bbticker_prefix\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the futures (secclass comes from secshld and could be not available)\r\n\t(SecClass='Future' or DLAMAssetClass3 in ('Future', 'Index Future'))\r\n\t-- unexpected relation isin - bb ticker\r\n\tand left(isin, 4) != left(BBTicker, 4)\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
237               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
238 BU Delta Lloyd Asset Management Portia PO_0093 instrument SelfConsistent       NEED      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate dataelements                               datasource referencedata                                            en
238         2015-06-30     CURRENCY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                The Symbol should be equal to the CurrencyIs.
                                                                         nl
238 De munt (SYMBOL) dient gelijk aan de initiele munt (CurrencyIs) te zijn
                                                                                                                                                                                                          rule
238 When an instrument is issued in a currency, it should remain being in that currency. Except if the currency does not exist at all any more. Verified relation: SYMBOL == CurrencyIs (with some exceptions)
                                                                                                                                                                                                                                                                                                                                                                                                               condition
238 Securities wich have a CurrencyIs not equal to SYMBOL\n\n\n\n-except if SYMBOL is EUR and CurrencyIs is one of DEM, FRF or NLG\n\n\n\nThere are more currencies transformed into EUR, but the filter has been updated to only contain actually occurring values.\n\n\n\nIf new values occur, the business rule will fail again indicating that either the business rule exceptions or the instruments are incorrect.
    Feedback      rule_load_date      source_file
238          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                query
238 select DISTINCT\r\n\tinsid,\r\n\tMUNT,\r\n\tCurrencyIs\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the unexpected relation\r\n\t CurrencyIs != MUNT\r\n\t -- the exceptions because initial currencies changed during period\r\n\t and not (MUNT = 'EUR' and CurrencyIs in ('DEM', 'FRF', 'NLG'))\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
238               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
239 BU Delta Lloyd Asset Management Portia PO_0094 instrument SelfConsistent       NEED      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate                             dataelements                               datasource referencedata
239         2015-06-30 DLAM.Sector1, DLAM.Sector2, DLAM.Sector3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                         en                                                            nl
239 DLAMSector country should be equal to DLAMCountryOfRisk DLAMSector landen dienen gelijk te zijn aan DLAMCountryOfRisk
                                                                                                                                                                                                                                               rule
239 If the DLAMSector contains a country (sovereign debt), it should be equal to the country of risk, as the country is where the money is located.\n\n\n\nVerified relation: (Country in DLAMSector) => (DLAMCountryOfRisk== DLAMSector's Country)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             condition
239 All instruments having a country in DLAMSector2 or DLAMSector3 that is different from the DLAMCountryofRisk\n\n\n\n- except if neither DLAMSector2 nor DLAMSector3 contains a country\n\n\n\n- this means only DLAMSectors 'Sovereigns' and 'Other Sovereigns (in foreign currency)'\n\nMore specifically:\n\nwith \n\n   SectorCountry_ = if DLAMSector1=='Sovereigns' & DLAMSector2!='Other Sovereigns (in local currency)'\n\n                 then DLAMSector2\n\n                 else if DLAMSector2 == 'Covered'\n\n                 then DLAMSector3\n\n                 else if DLAMSector2=='Other Sovereigns (in foreign currency)'\n\n                 then DLAMSector3\n\n                 else NA\n\n SectorCountry = if SectorCountry_=='Other'\n\n                 then NA\n\n                 else if SectorCountry_=='US'\n\n                 then 'United States'\n\n                 else if SectorCountry_==UK\n\n                 then United Kingdom\n\n                 else SectorCountry_\n\nwhere \n\n     SectorCountry!=NA & \n\n     SectorCountry!=DLAMCountryofRis
    Feedback      rule_load_date      source_file
239          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                           query
239 select DISTINCT\r\n\tinsid,\r\n\tDLAMSector1,\r\n\tDLAMSector2,\r\n\tDLAMSector3,\r\n\tSectorCountry,\r\n\tDLAMCountryofRisk\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tSectorCountry != DLAMCountryofRisk\r\n\tand scope_dm = 1\r\n
    superset_query
239               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
240 BU Delta Lloyd Asset Management Portia PO_0095 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate      dataelements                               datasource referencedata                     en                        nl
240         2015-06-30 DLAM.Asset.Type.2 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Nontrivial asset class Niet triviale asset class
                                                    rule                                               condition Feedback      rule_load_date      source_file
240 All instruments should have an asset class assigned. All instruments which have \n\n and DLAMAssetClass2='-'          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                     query
240 select DISTINCT\r\n\tinsid,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tDLAMAssetClass2='-'\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
240               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
241 BU Delta Lloyd Asset Management Portia PO_0096 instrument SelfConsistent       NEED Export Configuration             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                                                      en
241         2015-06-30     SECURITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                The holding's Securitynaam should be known in the static data (as Name)
                                                                                  nl
241 De instrument naam van een positie dient voor te komen in de static data export.
                                                                                                                                                                                                                                                                                                                                                                                            rule
241 Securities in the portiatotal holding export, should all be known in the SecsHld static data check export\n\n\n\nThis verifies that all instruments in RM-PortiaTotal_P_20140930.csv are also (indirectly) checked by checks on DM-SecsHLD Portia 30-09-2014.csv\n\n\n\nInstruments with zero holding, or with a starred PortfolioNaam or Securitynaam are excluded from this quality check.
                                                                                             condition Feedback      rule_load_date      source_file
241 All holdings of quantity>0 with Securitynaam not in DM-SecsHLD Portia 30-09-2014.csv's Name column          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                query
241 select DISTINCT\r\n\tinsid,\r\n\tSecuritynaam,\r\n\tsecshld_Securitynaam\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- instruments having at least one nonzero holding\r\n\texists (\r\n\t\tselect * from vx_PO_holding where\r\n\t\tvx_PO_holding.insid = vx_PO_instrument.insid\r\n\t\tand vx_PO_holding.QUANTITY!=0\r\n\t\t)\r\n\t-- the ones where no secshld line could be found\r\n\tand secshld_Securitynaam is null\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
241               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
242 BU Delta Lloyd Asset Management Portia PO_0097 instrument SelfConsistent       NEED Export Configuration             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata
242         2015-06-30       COUPON RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                                  en
242 All instruments in the portiatotal export should have same COUPON as in secshld.
                                                                                                     nl
242 Alle instrumenten in de portiatotal export dienen eenzelfde COUPON te hebben als de secshld export.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       rule
242 Securities in the portiatotal holding export, which are known in \n\n\n\nDM-SecsHLD Portia 30-09-2014.csv\n\n\n\n, should have the same static data. This rule verifies COUPON\n\nThis rule verifies that all instruments in RM-PortiaTotal_P_20140930.csv which are also (indirectly) checked by checks on DM-SecsHLD Portia 30-09-2014.csv actually check the same data element values.\n\nNote that there are 2 different coupon values related to an instrument. The assigned entered coupon, and the one calculated by Portia. Both reports use the calculated one
                                                                                                              condition Feedback      rule_load_date      source_file
242 All holdings with Securitynaam in DM-SecsHLD Portia 30-09-2014.csv's Name column, which have a different COUPONRATE          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                    query
242 select DISTINCT\r\n\tinsid,\r\n\tCOUPONRATE,\r\n\tsecshld_COUPONRATE,\r\n\tReportingDate,\r\n\tsecshld_ReportingDate,\r\n\tRunTime as secshld_ReportingTime\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tsecshld_COUPONRATE != COUPONRATE\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
242               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
243 BU Delta Lloyd Asset Management Portia PO_0098 instrument SelfConsistent       NEED Export Configuration             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate                         dataelements                               datasource referencedata
243         2015-06-30 DLAM.Asset.Type.2, DLAM.Asset.Type.3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                                      en
243 All instruments in the portiatotal export should have same asset type as in secshld.
                                                                                                         nl
243 Alle instrumenten in de portiatotal export dienen eenzelfde asset type te hebben als de secshld export.
                                                                                                                                                                                                                                                                                                                                                                                             rule
243 Securities in the portiatotal holding export, which are known in \n\n\n\nDM-SecsHLD Portia 30-09-2014.csv\n\n\n\n, should have the same static data. This rule verifies Asset Type\n\nThis rule verifies that all instruments in RM-PortiaTotal_P_20140930.csv which are also (indirectly) checked by checks on DM-SecsHLD Portia 30-09-2014.csv actually check the same data element values.
                                                                                                                        condition Feedback      rule_load_date
243 All holdings with Securitynaam in DM-SecsHLD Portia 30-09-2014.csv's Name column, which have a different Asset type hierarchy          2016-04-26 16:05:43
         source_file
243 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       query
243 select DISTINCT\r\n\tinsid,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tDLAMAssetClass4,\r\n\tsecshld_DLAMAssetClass1,\r\n\tsecshld_DLAMAssetClass2,\r\n\tsecshld_DLAMAssetClass3,\r\n\tsecshld_DLAMAssetClass4,\r\n\tReportingDate,\r\n\tsecshld_ReportingDate,\r\n\tRunTime as secshld_ReportingTime\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t(secshld_DLAMAssetClass1!= DLAMAssetClass1\r\n\tOR secshld_DLAMAssetClass2!= DLAMAssetClass2\r\n\tOR secshld_DLAMAssetClass3!= DLAMAssetClass3\r\n\tOR secshld_DLAMAssetClass4!= DLAMAssetClass4\r\n\t)\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
243               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
244 BU Delta Lloyd Asset Management Portia PO_0099 instrument SelfConsistent       NEED Export Configuration             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate                             dataelements                               datasource referencedata
244         2015-06-30 DLAM.Sector1, DLAM.Sector2, DLAM.Sector3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                                       en
244 All instruments in the portiatotal export should have same dlam sector as in secshld.
                                                                                                          nl
244 Alle instrumenten in de portiatotal export dienen eenzelfde dlam sector te hebben als de secshld export.
                                                                                                                                                                                                                                                                                                                                                                                              rule
244 Securities in the portiatotal holding export, which are known in \n\n\n\nDM-SecsHLD Portia 30-09-2014.csv\n\n\n\n, should have the same static data. This rule verifies dlam sector\n\nThis rule verifies that all instruments in RM-PortiaTotal_P_20140930.csv which are also (indirectly) checked by checks on DM-SecsHLD Portia 30-09-2014.csv actually check the same data element values.
                                                                                                                         condition Feedback      rule_load_date
244 All holdings with Securitynaam in DM-SecsHLD Portia 30-09-2014.csv's Name column, which have a different dlam sector hierarchy          2016-04-26 16:05:43
         source_file
244 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      query
244 select DISTINCT\r\n\tinsid,\r\n\tDLAMSector1,\r\n\tDLAMSector2,\r\n\tDLAMSector3,\r\n\tDLAMSector4,\r\n\tsecshld_DLAMSector1,\r\n\tsecshld_DLAMSector2,\r\n\tsecshld_DLAMSector3,\r\n\tsecshld_DLAMSector4\r\n\tReportingDate,\r\n\tsecshld_ReportingDate,\r\n\tRunTime as secshld_ReportingTime\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t(secshld_DLAMSector1!= DLAMSector1\r\n\tOR secshld_DLAMSector2!= DLAMSector2\r\n\tOR secshld_DLAMSector3!= DLAMSector3\r\n\tOR secshld_DLAMSector4!= DLAMSector4\r\n\t)\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
244               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
245 BU Delta Lloyd Asset Management Portia PO_0100 instrument SelfConsistent       NEED Export Configuration             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate dataelements                               datasource referencedata
245         2015-06-30     CURRENCY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                                            en
245 All instruments in the portiatotal export should have same currency  (MUNT) as in secshld.
                                                                                                   nl
245 Alle instrumenten in de portiatotal export dienen eenzelfde munt te hebben als de secshld export.
                                                                                                                                                                                                                                                                                                                                                                                                      rule
245 Securities in the portiatotal holding export, which are known in \n\n\n\nDM-SecsHLD Portia 30-09-2014.csv\n\n\n\n, should have the same static data. This rule verifies the currency (munt)\n\nThis rule verifies that all instruments in RM-PortiaTotal_P_20140930.csv which are also (indirectly) checked by checks on DM-SecsHLD Portia 30-09-2014.csv actually check the same data element values.
                                                                                                            condition Feedback      rule_load_date      source_file
245 All holdings with Securitynaam in DM-SecsHLD Portia 30-09-2014.csv's Name column, which have a different currency          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                           query
245 select DISTINCT\r\n\tinsid,\r\n\tMUNT,\r\n\tsecshld_MUNT,\r\n\tReportingDate,\r\n\tsecshld_ReportingDate,\r\n\tRunTime as secshld_ReportingTime\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tsecshld_MUNT!= MUNT\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
245               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate                 ruleOwner
246 BU Delta Lloyd Asset Management Portia PO_0101 instrument SelfConsistent       NEED Export Configuration             <NA> Financial Risk Management
                 approvedBy approvedDate resultApprovalDate dataelements                               datasource referencedata
246 Fred Schulte Fischedick   2015-06-23         2015-06-23  DLAM.RATING RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                                       en
246 All instruments in the portiatotal export should have same dlam rating as in secshld.
                                                                                                         nl
246 Alle instrumenten in de portiatotal export dienen eenzelfde dlamrating te hebben als de secshld export.
                                                                                                                                                                                                                                                                                                                                                                                                  rule
246 Securities in the portiatotal holding export, which are known in \n\n\n\nDM-SecsHLD Portia 30-09-2014.csv\n\n\n\n, should have the same static data. This rule verifies the dlam rating\n\nThis rule verifies that all instruments in RM-PortiaTotal_P_20140930.csv which are also (indirectly) checked by checks on DM-SecsHLD Portia 30-09-2014.csv actually check the same data element values.
                                                                                                               condition Feedback      rule_load_date      source_file
246 All holdings with Securitynaam in DM-SecsHLD Portia 30-09-2014.csv's Name column, which have a different dlam rating          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                            query
246 select DISTINCT\r\n\tinsid,\r\n\tDLRating,\r\n\tsecshld_DLRating,\r\n\tReportingDate,\r\n\tsecshld_ReportingDate,\r\n\tRunTime as secshld_ReportingTime\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tsecshld_DLRating != DLRating\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
246               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
247 BU Delta Lloyd Asset Management Portia PO_0102 instrument SelfConsistent       NEED Export Configuration             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate dataelements                               datasource referencedata
247         2015-06-30   ISSUE_DATE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                                     en
247 All instruments in the portiatotal export should have same issuedate as in secshld.
                                                                                                        nl
247 Alle instrumenten in de portiatotal export dienen eenzelfde issuedate te hebben als de secshld export.
                                                                                                                                                                                                                                                                                                                                                                                                 rule
247 Securities in the portiatotal holding export, which are known in \n\n\n\nDM-SecsHLD Portia 30-09-2014.csv\n\n\n\n, should have the same static data. This rule verifies the Issue Date\n\nThis rule verifies that all instruments in RM-PortiaTotal_P_20140930.csv which are also (indirectly) checked by checks on DM-SecsHLD Portia 30-09-2014.csv actually check the same data element values.
                                                                                                              condition Feedback      rule_load_date      source_file
247 All holdings with Securitynaam in DM-SecsHLD Portia 30-09-2014.csv's Name column, which have a different issue date          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                query
247 select DISTINCT\r\n\tinsid,\r\n\tIssuedate,\r\n\tsecshld_IssueDate,\r\n\tReportingDate,\r\n\tsecshld_ReportingDate,\r\n\tRunTime as secshld_ReportingTime\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tsecshld_IssueDate != Issuedate\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
247               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
248 BU Delta Lloyd Asset Management Portia PO_0103 instrument SelfConsistent       NEED Export Configuration             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate dataelements                               datasource referencedata
248         2015-06-30     MATURITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                                        en
248 All instruments in the portiatotal export should have same maturitydate as in secshld.
                                                                                                           nl
248 Alle instrumenten in de portiatotal export dienen eenzelfde maturitydate te hebben als de secshld export.
                                                                                                                                                                                                                                                                                                                                                                                                    rule
248 Securities in the portiatotal holding export, which are known in \n\n\n\nDM-SecsHLD Portia 30-09-2014.csv\n\n\n\n, should have the same static data. This rule verifies the Maturity Date\n\nThis rule verifies that all instruments in RM-PortiaTotal_P_20140930.csv which are also (indirectly) checked by checks on DM-SecsHLD Portia 30-09-2014.csv actually check the same data element values.
                                                                                                                 condition Feedback      rule_load_date
248 All holdings with Securitynaam in DM-SecsHLD Portia 30-09-2014.csv's Name column, which have a different maturity date          2016-04-26 16:05:43
         source_file
248 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                            query
248 select DISTINCT\r\n\tinsid,\r\n\tMaturityDate,\r\n\tsecshld_MaturityDate,\r\n\tReportingDate,\r\n\tsecshld_ReportingDate,\r\n\tRunTime as secshld_ReportingTime\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tsecshld_MaturityDate != MaturityDate\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
248               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
249 BU Delta Lloyd Asset Management Portia PO_0104 instrument SelfConsistent       NEED Export Configuration             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate dataelements                               datasource referencedata
249         2015-06-30  OPTION_TYPE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                                       en
249 All instruments in the portiatotal export should have same option type as in secshld.
                                                                                                          nl
249 Alle instrumenten in de portiatotal export dienen eenzelfde option type te hebben als de secshld export.
                                                                                                                                                                                                                                                                                                                                                                                                  rule
249 Securities in the portiatotal holding export, which are known in \n\n\n\nDM-SecsHLD Portia 30-09-2014.csv\n\n\n\n, should have the same static data. This rule verifies the option type\n\nThis rule verifies that all instruments in RM-PortiaTotal_P_20140930.csv which are also (indirectly) checked by checks on DM-SecsHLD Portia 30-09-2014.csv actually check the same data element values.
                                                                                                               condition Feedback      rule_load_date      source_file
249 All holdings with Securitynaam in DM-SecsHLD Portia 30-09-2014.csv's Name column, which have a different option type          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                    query
249 select DISTINCT\r\n\tinsid,\r\n\tOptionType,\r\n\tsecshld_OptionType,\r\n\tReportingDate,\r\n\tsecshld_ReportingDate,\r\n\tRunTime as secshld_ReportingTime\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tsecshld_OptionType != OptionType\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
249               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
250 BU Delta Lloyd Asset Management Portia PO_0105  portfolio SelfConsistent       NEED      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate   dataelements         datasource referencedata                                                                en
250         2015-06-30 PORTFOLIO_NAME RM-PortiaTotal_P_                If the client is marked deleted, it's PortfolioNaam should be too
                                                                                            nl
250 Als de klanten naam gemarkeerd is als verwijderd, dient de portfolio naam dat ook te zijn.
                                                                             rule                                                                            condition
250 If the CLIENTNAAM starts with *, it's PortfolioNaam should also start with *. Each PortfolioNaam that doesn't start with * while the CLIENTNAAM does start with *.
    Feedback      rule_load_date      source_file
250          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                   query
250 select DISTINCT\r\n\tprfid,\r\n\tPORTFOLIO_NAME,\r\n\tCLIENT_NAME\r\nfrom\r\n\tvx_PO_portfolio\r\nwhere\r\n\t-- the ones with marked for deletion client names\r\n\tCLIENT_NAME like '*%'\r\n\t-- the ones with not marked for deletion portfolio name\r\n\tand PORTFOLIO_NAME not like '*%'
    superset_query
250               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
251 BU Delta Lloyd Asset Management Portia PO_0106 instrument SelfConsistent       NEED      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate            dataelements                               datasource referencedata
251         2015-06-30 OPTION_TYPE, IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                    en                                                                       nl
251 Option type corresponds with ISIN option type (for Equity Options) Optie type is gelijk aan het optie type in de ISIN (voor Equity Options)
                                                                                                                    rule
251 For Equity Option's the ISIN identifier also contains the option type (P/C). These should correspond with the option
                                                                                                                                                                                                                                                                                                                        condition
251 For DLAMAssetClass3 with 'Equity Option', the option type in the isin (identifie) at th position, which is P or C, should be equal to the first character of the Option_type column, which is Put or Call.\n\n\n\nInstruments which Securitynaam is starred are are excluded from this (and other static data) quality check.
    Feedback      rule_load_date      source_file
251          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                            query
251 select DISTINCT\r\n\tinsid,\r\n\tSUBSTRING(ISIN,5,1) as OptionInISIN,\r\n\tleft(Option_type, 1) as OptionInOptionType,\r\n\tOption_type,\r\n\tISIN,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tSecClass\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\tDLAMAssetClass3 = 'Equity Option'\r\n\tand left(Option_type, 1)!=SUBSTRING(ISIN,5,1)\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
251               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate                 ruleOwner              approvedBy
252 BU Delta Lloyd Asset Management Portia PO_0107 instrument SelfConsistent       NEED      Input             <NA> Financial Risk Management Fred Schulte Fischedick
    approvedDate resultApprovalDate dataelements                               datasource referencedata
252   2015-06-23         2015-06-23  DLAM.RATING RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  ratingmap.csv
                                                                        en                                                                                          nl
252 The DLAMRating should be equal to the rounded average of input ratings De DLAM rating dient gelijk te zijn aan het afgeronde gemiddelde van de markt waarderingen.
                                                                                                                                                                                                                                                                                                                                                                         rule
252 When an instrument has market (input) ratings (MoodyRatin, SPRating, FitchRatin), the DLAM rating should be equal to it. The average is also available as AgncyAvRatin.\n\nThis rule does an end-to-end check of available market ratings => .. => DLAMRating.\n\n\n\nNote the different labels/levels per rating source. \n\n\n\nTranslation is done using ratingmap.csv
                                                                                                                                                                                                                       condition
252 With 'AgncyAvRating.Recalc' as the average of available market (Moody, S&P, Fitch) ratings\n\n\n\nthe instruments for which DLAMRating != round(AgncyAvRating.Recalc)\n\n-excluded are instruments without any market rating
    Feedback      rule_load_date      source_file
252          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          query
252 select DISTINCT\r\n\tinsid,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tMOODY,\r\n\tMOODY_level,\r\n\tSP,\r\n\tSP_level,\r\n\tFitch,\r\n\tFitch_level,\r\n\tavg_moody_sp_fitch,\r\n\tDLRating,\r\n\tDLRating_level\r\nfrom\r\n\t(select *,\r\n\t\t(ISNULL(MOODY_level, 0) + ISNULL(SP_level, 0) + ISNULL(Fitch_level, 0))\r\n\t\t /\r\n\t\t(case \r\n\t\t  when MOODY = 'NR' and SP = 'NR' and Fitch = 'NR' then 1 \r\n\t\t  when MOODY = 'NR' and SP = 'NR' and Fitch != 'NR' then 1\r\n\t\t  when MOODY = 'NR' and SP != 'NR' and Fitch = 'NR' then 1\r\n\t\t  when MOODY = 'NR' and SP != 'NR' and Fitch != 'NR' then 2\r\n\t\t  when MOODY != 'NR' and SP = 'NR' and Fitch = 'NR' then 1\r\n\t\t  when MOODY != 'NR' and SP = 'NR' and Fitch != 'NR' then 2\r\n\t\t  when MOODY != 'NR' and SP != 'NR' and Fitch = 'NR' then 2\r\n\t\t  when MOODY != 'NR' and SP != 'NR' and Fitch != 'NR' then 3 end) as avg_moody_sp_fitch\r\n\tfrom\r\n\t\tvx_PO_instrument\r\n\t) as vx_PO_instrument_extra\r\nwhere\r\n\t-- applicable subset, all with at least one external rating\r\n\t(MOODY != 'NR'\r\n\tor SP != 'NR'\r\n\tor Fitch != 'NR')\r\n\tand (\r\n\t-- unexpected attributes\r\n\tround(avg_moody_sp_fitch, 0) != DLRating_level\r\n\t)\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
252               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate                 ruleOwner              approvedBy
253 BU Delta Lloyd Asset Management Portia PO_0108 instrument SelfConsistent       NEED      Input             <NA> Financial Risk Management Fred Schulte Fischedick
    approvedDate resultApprovalDate dataelements                               datasource referencedata                                          en
253   2015-06-23         2015-06-23  DLAM.RATING RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  ratingmap.csv DLAMRating should be equal to AgncyAvRating
                                                                             nl
253 De DLAM Rating dient gelijk te zijn aan de rating in de AgncyAvRating kolom
                                                                                                                                                                                                                                                                                                                                                                                                     rule
253 When an instrument has market (input) ratings (MoodyRatin, SPRating, FitchRatin), the DLAM rating should be equal to it. The average is also available as AgncyAvRatin.\n\nThis rule does verifies the last step in the chain of available market ratings => AgncyAvRating  => DLAMRating.\n\n\n\nNote the different labels/levels per rating source. \n\n\n\nTranslation is done using ratingmap.csv
                                                                                                       condition Feedback      rule_load_date      source_file
253 The instruments for which DLAMRating != AgncyAvRating\n\n-excluded are instruments without any market rating          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             query
253 select DISTINCT\r\n\tinsid,\r\n\tDLAMAssetClass1,\r\n\tDLAMAssetClass2,\r\n\tMOODY,\r\n\tMOODY_level,\r\n\tSP,\r\n\tSP_level,\r\n\tFitch,\r\n\tFitch_level,\r\n\tDLRating,\r\n\tDLRating_level,\r\n\tsecshld_AgncyAvRating_level\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- applicable subset, all with at least one external rating\r\n\tsecshld_AgncyAvRating_level != NULL\r\n\tand\r\n\t-- unexpected attributes\r\n\tsecshld_AgncyAvRating_level != DLRating_level\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
253               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
254 BU Delta Lloyd Asset Management Portia PO_0109    holding SelfConsistent       NEED Export Configuration             <NA> Valuation Desk Ilona Balvert         <NA>
    resultApprovalDate                  dataelements         datasource                            referencedata
254               <NA> MARKET_VALUE, PRICE, QUANTITY RM-PortiaTotal_P_  exchangerates.csv\n\n\n\n, tipsrates.csv
                                                                                                                 en
254 Quantity times clean price (in eur), plus clean accrued intrest, times inflation principal, equals market value
                                                                                                                           nl
254 Hoeveelheid keer prijs (in eur), plus lopende rente, beiden gecorrigeerd voor inflatie premie, is gelijk aan markt waarde
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               rule
254 One whould expect the quantity times the price to be the market value. \n\n\n\nHowever the definition of 'MW incl LR (Eur)' also contains the LR (lopende rente), which is the Acrued Interest. \n\n\n\nSpecific bonds are inflation linked, which' principal should also be added to the market value\n\n\n\nThe actual calculation thus is (quantity * clean_europrice  + accrued interest) * inflation correction == market value\n\n\n\nBecause of the large quantities, the original 10 digit accurate FXRate is taken\n\n\n\nAlso units of both quantity and price needs to be taken care of. For example, bonds are priced at 100 to indicate 100%\n\n\n\nFor instruments which are not tips, a tips rate of 1 should be used\n\nVerified relation: For all instruments: TIPS * (KOERS*FXRATE*QUANTITY*UNITPRICE + AcruedInterestEur) == MW.incl.LR..Eur\n\nGlobal cause for many differences is the AccruedInterest(EUR) in the export, which is the sum of absolute AI's of the underlying slots, instead of the regular sum (as is included in the marketvalue formula)\n\nAdditionally, the market value, accrued interest and the quantity are rounded to integers, and the fxrate and price are rounded to 4digits
                                                                                                                                                                                                                                                                          condition
254 If Quantity equals 0, a MWinclLREur of 0 is expected\n\n\n\notherwise a MWinclLREur of TIPS * (KOERS * FXRATE * QUANTITY * UNITPRICE + AcruedInterestEur) is expected\n\n\n\n(For bonds UNITPRICE usually is 0.01)\n\n\n\nPrice differences of less than 1 are ignored.\n\n\n\n
                                                             Feedback      rule_load_date      source_file
254 Seems to be oke, but the TIPS rate part will need to  be verified 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          query
254 SELECT\r\n\t*\r\nFROM\r\n\r\n(select DISTINCT\r\n\t*,\r\n\t-- the absolute difference between expected and found marketvalue\r\n\tabs(MWinclLREur_expected - MWinclLREur) as delta_abs,\r\n\tcase when MWinclLREur = 0 \r\n\tthen NULL\r\n\telse abs(100*(MWinclLREur_expected - MWinclLREur)/MWinclLREur) \r\n\tend as delta_abs_percent,\r\n\t-- if difference is because of quantity, what is the difference\r\n\tcase when (MWinclLREur - AcruedInterestEur) = 0 \r\n\tthen NULL\r\n\telse QUANTITY*(MWinclLREur_expected - MWinclLREur)/ (MWinclLREur - AcruedInterestEur)\r\n\tend as delta_quantity,\r\n\t-- if difference is because of koers, what is the difference\r\n\tcase when (MWinclLREur - AcruedInterestEur) = 0 \r\n\tthen NULL\r\n\telse KOERS*(MWinclLREur_expected - MWinclLREur)/ (MWinclLREur - AcruedInterestEur)\r\n\tend as delta_koers,\r\n\tcase when (MWinclLREur - AcruedInterestEur) = 0\r\n\tthen NULL\r\n\telse FXRATE * (MWinclLREur_expected - MWinclLREur)/(MWinclLREur - AcruedInterestEur)\r\n\tend as delta_fx\r\n\r\nfrom\r\n\t(\r\n\tselect\r\n\t\tvx_PO_holding.insid,\r\n\t\tprfid,\r\n\t\tDLAMAssetClass3,\r\n\t\tvx_PO_holding.MWinclLREur,\r\n\t\tcase QUANTITY \r\n\t\twhen 0 then 0\r\n\t\telse \r\n\t\tcase when QUANTITY < 0 then\r\n\t\t\tISNULL(PO_inflation.Koers,1) * (vx_PO_holding.KOERS * PO_exchangerates.FXRATE * QUANTITY * UNITPRICE - AcruedInterestEur) --if quantity is negative, then AcruedInterestEur should be substracted\r\n\t\telse \r\n\t\t\tISNULL(PO_inflation.Koers,1) * (vx_PO_holding.KOERS * PO_exchangerates.FXRATE * QUANTITY * UNITPRICE + AcruedInterestEur) --default case\r\n\t\tend\r\n\t\tend as MWinclLREur_expected,\r\n\r\n\t\tvx_PO_holding.dep_fxid,\r\n\t\tvx_PO_holding.MUNT,\r\n\t\tvx_PO_holding.KOERS,\r\n\t\tPO_inflation.Koers as infKoers,\r\n\t\tPO_exchangerates.FXRATE,\r\n\t\tvx_PO_holding.FXRATE as holding_FXRate,\r\n\t\tQUANTITY,\r\n\t\tUNITPRICE,\r\n\t\tAcruedInterestEur\r\n\tfrom\r\n\t\tvx_PO_holding\r\n\t\tleft join\r\n\t\tPO_exchangerates\r\n\t\t\ton vx_PO_holding.dep_fxid = PO_exchangerates.fxid\r\n\t\tleft join\r\n\t\t(select distinct insid, UNITPRICE from vx_PO_instrument) as pricing_attr\r\n\t\t\ton vx_PO_holding.insid = pricing_attr.insid\r\n\t\tleft join\r\n\t\tPO_tips\r\n\t\t\ton vx_PO_holding.insid = PO_tips.[SECURITY]\r\n\t\tleft join \r\n\t\tPO_Inflation \r\n\t\t\ton vx_PO_holding.insid = PO_Inflation.[security]\r\n\t\t\tAND vx_PO_holding.insid IN (SELECT insid from vx_PO_instrument WHERE DLAMAssetClass3 like '%flation%')\r\n) as PO_holding_extra\r\n)as PO_holding_delta\r\nwhere\r\n\t-- the MW is defined in EUR (not cents), thus only listing differences > 1 absolute euro\r\n\tdelta_abs_percent > 0.1 AND delta_abs > 1 --filtering on treshold for to elimenate rounding differences\r\n    and delta_abs != 0 \r\n\r\n--end
    superset_query
254               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
255 BU Delta Lloyd Asset Management Portia PO_0110    holding SelfConsistent       NEED Export Configuration       2015-05-29 Valuation Desk Ilona Balvert         <NA>
    resultApprovalDate            dataelements         datasource referencedata                                                                             en
255               <NA> NOMINAL_VALUE, QUANTITY RM-PortiaTotal_P_  tipsrates.csv When quantity not zero, nominal value (eur) should be TIPS * fxrate * quantity
                                                                                                         nl
255 Bij een hoeveelheid ongelijk aan nul, dient nominale waarde gelijk te zijn aan TIPS * fxrate * quantity
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        rule
255 Nominal value (eur) should be equal to quantity * fxrate * tips\n\n\n\nFor instruments which are not tips, a tips rate of 1 should be used\n\n\n\nAll holdings where the difference between nominal value (eur) and expected_Nominal is more than 1e-4 per quantity\n\n\n\n1e-4 is used as accuracy threshold because of numeric precisions of underlying values (FXRATE, the issue with rounded FXRate's is covered by rule PO_0111\n\nThe nominal value is rounded to integers, which it shouldn't be.
                                                                                                                                                                                                                                                                                                                                                              condition
255 For inflation protected instruments, take their TIPS rate\n\n\n\nFor other instruments, take 1 as TIPS rate\n\n\n\nAll instruments where the absolute difference between \n\n\n\n  quantity * fxrate * tips (the expected nominal) \n\n\n\nand \n\n\n\n  Nominaal (eur) (the actual nominal)\n\n\n\nthe difference is more than 1e-4 per quantity, and at least 0.5
                                                             Feedback      rule_load_date      source_file
255 Seems to be oke, but the TIPS rate part will need to  be verified 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       query
255 SELECT\r\n\t*\r\nFROM\r\n(select DISTINCT\r\n\t*,\r\n\t-- the absolute difference between expected and found marketvalue\r\n\tabs(NominaalEur_expected - NominaalEur) as delta_abs,\r\n\tcase when NominaalEur = 0 \r\n\tthen NULL\r\n\telse abs(100*(NominaalEur_expected - NominaalEur)/NominaalEur) \r\n\tend as delta_abs_percent\r\nfrom\r\n\t(\r\n\tselect\r\n\t\tvx_PO_holding.insid,\r\n\t\tprfid,\t\r\n\t\tQUANTITY,\r\n\t\tvx_PO_holding.KOERS as holding_koers,\r\n\t\tvx_PO_holding.NominaalEur,\r\n        (PO_exchangerates.FXRATE * QUANTITY)*ISNULL(PO_inflation.Koers,1) as NominaalEur_expected, -- Tips Koers is rounded since koers is rounded in report\r\n\t\tvx_PO_holding.dep_fxid,\r\n\t\tvx_PO_holding.MUNT,\r\n\t\tPO_exchangerates.FXRATE,\r\n\t\tvx_PO_holding.FXRATE as holding_FXRate,\r\n\t\tPO_Inflation.Koers as Inflation_rate,\r\n\t\tPO_tips.Koers AS poTips,\r\n\t\tvx_PO_instrument.DLAMAssetClass1,\r\n\t\tvx_PO_instrument.DLAMAssetClass2,\r\nvx_PO_instrument.DLAMAssetClass3,\r\nvx_PO_instrument.DLAMAssetClass4\r\n\r\n\tfrom\r\n\t\tvx_PO_holding\r\n\t\tleft join\r\n\t\tPO_exchangerates\r\n\t\t\ton vx_PO_holding.dep_fxid = PO_exchangerates.fxid\r\n\t\tleft join\r\n\t\tPO_tips\r\n\t\t\ton vx_PO_holding.insid = PO_tips.[SECURITY]\r\n\t\tleft join \r\n\t\tPO_Inflation \r\n\t\t\ton vx_PO_holding.insid = PO_Inflation.[security]\r\n\t\t\tAND vx_PO_holding.insid IN (SELECT insid from vx_PO_instrument WHERE DLAMAssetClass3 like '%flation%')\r\n\t\tleft join vx_PO_instrument \r\n\t\t\ton vx_PO_holding.insid = vx_PO_instrument.insid\r\n) as PO_holding_extra)\r\nas PO_holding_delta\r\nwhere\r\n\tdelta_abs_percent > 0.1 AND delta_abs > 1 --filtering on treshold for to elimenate rounding differences\r\n\tAND delta_abs != 0\r\n\torder by MUNT\r\n\r\n
    superset_query
255               
                                 BU system      BR entitytype          Depth Importance           ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
256 BU Delta Lloyd Asset Management Portia PO_0111   currency SelfConsistent       NEED Export Configuration             <NA> Valuation Desk Ilona Balvert         <NA>
    resultApprovalDate dataelements         datasource     referencedata                                         en                                                 nl
256               <NA>       FXRATE RM-PortiaTotal_P_  exchangerates.csv The FXRate corresponds with exported rates De FXRate is gelijk aan de gedetailleerde fx rate.
                                                                                                                                                                                                                                                                                                                         rule
256 The FXRate should be equal to the closing foreign exchange rate\n\n\n\nThe export used by FRM actually is rounded to 5 digits, while Portia contains a precision of 9 digits.\n\n\n\nTo have correct FX calculations the full available precision should be used.\n\n\n\nVerified relation: MUNT => FXRATE.orig == FXRATE
                                                                                                 condition Feedback      rule_load_date      source_file
256 All currencies that have an exchange rate which does not match exactly with the specific exchangerate.          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                 query
256 select DISTINCT\r\n\tvx_PO_currency.fxid,\r\n\tvx_PO_currency.FXRATE,\r\n\tPO_exchangerates.FXRATE as FXRATE_expected,*\r\nfrom\r\n\tvx_PO_currency\r\n\tleft join\r\n\tPO_exchangerates\r\n\t\ton vx_PO_currency.fxid = PO_exchangerates.fxid\r\n\t\tand vx_PO_currency.ReportingDate = PO_exchangerates.ReportingDate\r\nwhere\r\n\tvx_PO_currency.FXRATE != PO_exchangerates.FXRATE\r\n\tor PO_exchangerates.FXRATE is null
    superset_query
256               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
257 BU Delta Lloyd Asset Management Portia PO_0112 instrument SelfConsistent       NICE      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate               dataelements                               datasource          referencedata                                                    en
257         2015-06-30 DLAM.Sector1, DLAM.Sector2 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  mapping_wft_sector.csv Only whitelisted combinations of DLAMSector2 with WFT
                                                     nl
257 Enkel toegestane combinaties van DLAMSector2 en WFT
                                                                                                                                              rule
257 DLAMSector2 is strongly correlated to WFT, only predefined expected combinations are allowed.\n\n\n\nVerified correlation: WFT <=> DLAMSector2
                                                                                                                                                                                 condition
257 All instruments having a combination of DLAMSector2 and WFT that is not whitelisted\n\n\n\n- except if WFT equals 'Overig'\n\n\n\n- except if DLAMSector is unavailable (equal to '-')
    Feedback      rule_load_date      source_file
257          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    query
257 select DISTINCT\r\n\tinstr.insid,\r\n\tinstr.DLAMSector1,\r\n\tinstr.DLAMSector2,\r\n\tinstr.Sector2NoCountry,\r\n\tinstr.WFT,\r\n\t-- Get string concatenated value of all Sector2NoCountries which are allowed with the provided WFT\r\n\treplace(replace(replace((cast((\r\n\tselect distinct Sector2NoCountry as X\r\n\tfrom valuewhitelist_wft_sector as inner_list\r\n\twhere inner_list.WFT = instr.WFT\r\n\tfor xml path('')) as varchar(max))), \r\n\t'</X><X>', ', '),'<X>', ''),'</X>','') as allowed_Sector2NoCountries_with_WFT,\r\n\r\n\t-- Get string concatenated value of all WFT which are allowed with the provided Sector2NoCountry\r\n\treplace(replace(replace((cast((\r\n\tselect distinct WFT as X\r\n\tfrom valuewhitelist_wft_sector as inner_list\r\n\twhere inner_list.Sector2NoCountry = instr.Sector2NoCountry\r\n\tfor xml path('')) as varchar(max))), \r\n\t'</X><X>', ', '),'<X>', ''),'</X>','') as allowed_WFT_with_sector\r\nfrom\r\n\tvx_PO_instrument instr\r\nwhere\r\n\t-- set in scope\r\n\tDLAMSector1!='' and DLAMSector1!='-'\r\n\tand WFT!='Overig'\r\n\t-- and not on the whitelist\r\n\tand not exists (\r\n\t\tselect * from valuewhitelist_wft_sector wl where wl.WFT = instr.WFT and wl.Sector2NoCountry = instr.Sector2NoCountry\r\n\t\t)\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
257               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
258 BU Delta Lloyd Asset Management Portia PO_0113 instrument SelfConsistent       NICE      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate                             dataelements                               datasource                      referencedata
258         2015-06-30 DLAM.Sector1, DLAM.Sector2, DLAM.Sector3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  whitelist_industry_dlamsector3.csv
                                                            en                                                       nl
258 Only whitelisted combinations of DLAMSector3 with INDUSTRY Enkel toegestane combinaties van DLAMSector3 en INDUSTRY
                                                                                                                                                                                                                                                                                rule
258 DLAMSector3 is strongly correlated to INDUSTRY, only predefined expected combinations are allowed.\n\n\n\nBecause of the tree of DLAMSector1->DLAMSector2->DLAMSector3, checking DLAMSector3 also verifies DLAMSector1 and 2.\n\n\n\nVerified relation: INDUSTRY <=> DLAMSector3
                                                                                                                          condition Feedback      rule_load_date
258 All instruments having a combination of DLAMSector3 and INDUSTRY that is not whitelisted\n\n\n\n, except if INDUSTRY equals '-'          2016-04-26 16:05:43
         source_file
258 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         query
258 select DISTINCT\r\n\tinstr.insid,\r\n\tinstr.DLAMSector1,\r\n\tinstr.DLAMSector2,\r\n\tinstr.DLAMSector3,\r\n\t-- not that the secshld_INDUSTRY has different values than the portiatotal.INDUSTRY (the portiatotal versions are abbreviated)\r\n\tinstr.secshld_INDUSTRY,\r\n\t-- Get string concatenated value of all Sector2NoCountries which are allowed with the provided WFT\r\n\tSTUFF(\r\n            (SELECT\r\n                ', ' + t2.DLAMSector3\r\n                FROM valuewhitelist_industry_sector t2\r\n                WHERE instr.secshld_INDUSTRY = t2.INDUSTRY \r\n                ORDER BY t2.DLAMSector3\r\n                FOR XML PATH(''), TYPE\r\n            ).value('.','varchar(max)')\r\n            ,1,2, ''\r\n        ) AS allowed_DLAMSector3_with_given_INDUSTRY,\r\n\r\n\tSTUFF(\r\n        (SELECT\r\n            ', ' + t2.INDUSTRY\r\n            FROM valuewhitelist_industry_sector t2\r\n            WHERE instr.DLAMSector3=t2.DLAMSector3\r\n            ORDER BY t2.INDUSTRY\r\n            FOR XML PATH(''), TYPE\r\n        ).value('.','varchar(max)')\r\n        ,1,2, ''\r\n    ) AS allowed_INDUSTRY_with_given_DLAMSector3\r\nfrom\r\n\tvx_PO_instrument instr\r\nwhere\r\n\t-- set in scope\r\n\tDLAMSector1!='' and DLAMSector1!='-'\r\n\tand secshld_INDUSTRY !='-' and secshld_INDUSTRY is not NULL\r\n\t-- and not on the whitelist\r\n\tand not exists (\r\n\t\tselect \r\n\t\t\t* \r\n\t\tfrom valuewhitelist_industry_sector wl \r\n\t\twhere \r\n\t\t\twl.INDUSTRY = instr.secshld_INDUSTRY\r\n\t\t\tand wl.DLAMSector3 = instr.DLAMSector3\r\n\t\t)\r\n\t-- but should be in scope of datamanagement (requiring correct static data)\r\n\tand scope_dm = 1
    superset_query
258               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
259 BU Delta Lloyd Asset Management Portia PO_0114 instrument SelfConsistent       NICE      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate dataelements                               datasource            referencedata                                                    en
259         2015-06-30 DLAM.Sector2 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  whitelist_dra_sector.csv Only whitelisted combinations of DLAMSector2 with DRA
                                                     nl
259 Enkel toegestane combinaties van DLAMSector2 en DRA
                                                                                                                                                                                                                                                                                         rule
259 DLAMSector2 strongly correlates with DRA, only predefined combinations are allowed\n\n\n\nBecause of the tree of DLAMSector1->DLAMSector2->DLAMSector3, checking DLAMSector2 (which implies a DLAMSector1 value) also verifies DLAMSector1.\n\n\n\nVerified relation: DRA <=> DLAMSector2
                                                                                                                                                                          condition
259 All instruments having a combination of DLAMSector2 and DRA that is not whitelisted\n\n\n\n- except if DRA equals 'Overige sectoren'\n\n\n\n- except if DLAMSector is undefined
    Feedback      rule_load_date      source_file
259          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
259 select DISTINCT\r\n\tinstr.insid,\r\n\tinstr.DLAMSector1,\r\n\tinstr.DLAMSector2,\r\n\tinstr.DLAMSector3,\r\n\tinstr.Sector2NoCountry,\r\n\tinstr.DRA,\r\n\t-- Get string concatenated value of all Sector2NoCountries which are allowed with the provided WFT\r\n\tSTUFF(\r\n            (SELECT\r\n                ', ' + t2.Sector2NoCountry\r\n                FROM valuewhitelist_dra_sector t2\r\n                WHERE instr.DRA = t2.DRA \r\n                ORDER BY t2.Sector2NoCountry\r\n                FOR XML PATH(''), TYPE\r\n            ).value('.','varchar(max)')\r\n            ,1,2, ''\r\n        ) AS allowed_Sector2NoCountry_with_given_DRA,\r\n\r\n\tSTUFF(\r\n        (SELECT\r\n            ', ' + t2.DRA\r\n            FROM valuewhitelist_dra_sector t2\r\n            WHERE instr.Sector2NoCountry=t2.Sector2NoCountry\r\n            ORDER BY t2.DRA\r\n            FOR XML PATH(''), TYPE\r\n        ).value('.','varchar(max)')\r\n        ,1,2, ''\r\n    ) AS allowed_DRA_with_given_Sector2NoCountry\r\nfrom\r\n\tvx_PO_instrument instr\r\nwhere\r\n\t-- set in scope\r\n\tDLAMSector1!='' and DLAMSector1!='-'\r\n\tand DRA !='Overige sectoren'\r\n\t-- and not on the whitelist\r\n\tand not exists (\r\n\t\tselect \r\n\t\t\t* \r\n\t\tfrom valuewhitelist_dra_sector wl \r\n\t\twhere \r\n\t\t\twl.DRA = instr.DRA\r\n\t\t\tand wl.Sector2NoCountry = instr.Sector2NoCountry\r\n\t\t)
    superset_query
259               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
260 BU Delta Lloyd Asset Management Portia PO_0115 instrument SelfConsistent       NICE      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate dataelements                               datasource                   referencedata                                                      en
260         2015-06-30 DLAM.Sector3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  whitelist_gics1_dlamsector3.csv Only whitelisted combinations of DLAMSector3 with GICS1
                                                       nl
260 Enkel toegestane combinaties van DLAMSector3 en GICS1
                                                                                                                                                                                                                                                                                                                                                                                          rule
260 DLAMSector3 correlates with GICS1, only predefined combinations are allowed\n\n\n\nBecause of the tree of DLAMSector1->DLAMSector2->DLAMSector3, checking DLAMSector3 also verifies DLAMSector1 and 2.\n\n\n\nVerified relation: GICS1 <=> DLAMSector3\n\nIf GICS1 doesn't indicate any sector (is '-'), or when the DLAM sector doesn't (DLAMSector1 = '-' or ''), the check is not done.
                                                                                                                                                                condition
260 All instruments having a combination of DLAMSector3 and GICS1 that is not whitelisted\n\n\n\n- except if GICS1 equals '-'\n\n- except if DLAMSector1 equals '' or '-'
    Feedback      rule_load_date      source_file
260          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         query
260 select DISTINCT\r\n\tinstr.insid,\r\n\tinstr.DLAMSector1,\r\n\tinstr.DLAMSector2,\r\n\tinstr.DLAMSector3,\r\n\tinstr.GICS1,\r\n\t-- Get string concatenated value of all Sector2NoCountries which are allowed with the provided WFT\r\n\tSTUFF(\r\n            (SELECT\r\n                ', ' + t2.DLAMSector3\r\n                FROM valuewhitelist_gics1_sector t2\r\n                WHERE instr.GICS1 = t2.GICS1 \r\n                ORDER BY t2.DLAMSector3\r\n                FOR XML PATH(''), TYPE\r\n            ).value('.','varchar(max)')\r\n            ,1,2, ''\r\n        ) AS allowed_DLAMSector3_with_given_GICS1,\r\n\r\n\tSTUFF(\r\n        (SELECT\r\n            ', ' + t2.GICS1\r\n            FROM valuewhitelist_gics1_sector t2\r\n            WHERE instr.DLAMSector3=t2.DLAMSector3\r\n            ORDER BY t2.GICS1\r\n            FOR XML PATH(''), TYPE\r\n        ).value('.','varchar(max)')\r\n        ,1,2, ''\r\n    ) AS allowed_GICS1_with_given_DLAMSector3\r\nfrom\r\n\tvx_PO_instrument instr\r\nwhere\r\n\t-- set in scope\r\n\tDLAMSector1!='' and DLAMSector1!='-'\r\n\tand GICS1 !='-'\r\n\t-- and not on the whitelist\r\n\tand not exists (\r\n\t\tselect \r\n\t\t\t* \r\n\t\tfrom valuewhitelist_gics1_sector wl \r\n\t\twhere \r\n\t\t\twl.GICS1 = instr.GICS1\r\n\t\t\tand wl.DLAMSector3 = instr.DLAMSector3\r\n\t\t)
    superset_query
260               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
261 BU Delta Lloyd Asset Management Portia PO_0116 instrument SelfConsistent       NICE      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate                         dataelements                               datasource                  referencedata
261         2015-06-30 DLAM.Asset.Type.2, DLAM.Asset.Type.3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  whitelist_assetclass_cedar.csv
                                                              en                                                                         nl
261 Only whitelisted combinations of Asset class and CEDAR occur Alleen verwachte combinaties van Asset class en CEDAR dienen voor te komen
                                                                                                                                                                                                                                                                                                                                                              rule
261 Only whitelisted combinations of Asset class and CEDAR occur\n\n\n\nBecause of the allowed tree of DLAMAssetClass1,2 and 3, verifying DLAMAssetClass 2 and 3 also verify 1.\n\n\n\nVerified relation: CEDAR <=> (DLAMAssetClass2, DLAMAssetClass3)\n\nSome differences can occur which are hard to change if the Asset Class is correct (and the CEDAR is not)
                                                                                                                             condition Feedback      rule_load_date
261 All instruments that \n\n\n\nhave a combination of DLAMAssetClass2, DLAMAssetClass3 and CEDAR\n\n\n\nwhich is not on the whitelist          2016-04-26 16:05:43
         source_file
261 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         query
261 select DISTINCT\r\n\tinstr.insid,\r\n\tinstr.DLAMAssetClass1,\r\n\tinstr.DLAMAssetClass2,\r\n\tinstr.DLAMAssetClass3,\r\n\tinstr.CEDAR,\r\n\t-- Get string concatenated value of all Sector2NoCountries which are allowed with the provided WFT\r\n\tSTUFF(\r\n            (SELECT\r\n                ', ' + t2.DLAMAssetClass3\r\n                FROM valuewhitelist_cedar_assetclass t2\r\n                WHERE instr.CEDAR = t2.CEDAR \r\n                ORDER BY t2.DLAMAssetClass3\r\n                FOR XML PATH(''), TYPE\r\n            ).value('.','varchar(max)')\r\n            ,1,2, ''\r\n        ) AS allowed_DLAMAssetClass3_with_given_CEDAR,\r\n\r\n\tSTUFF(\r\n        (SELECT\r\n            ', ' + t2.CEDAR\r\n            FROM valuewhitelist_cedar_assetclass t2\r\n            WHERE instr.DLAMAssetClass3=t2.DLAMAssetClass3\r\n            ORDER BY t2.CEDAR\r\n            FOR XML PATH(''), TYPE\r\n        ).value('.','varchar(max)')\r\n        ,1,2, ''\r\n    ) AS allowed_CEDAR_with_given_DLAMAssetClass3\r\nfrom\r\n\tvx_PO_instrument instr\r\nwhere\r\n\t-- in scope for datamanagement\r\n\tscope_dm = 1\r\n\t-- and not on the whitelist\r\n\tand not exists (\r\n\t\tselect \r\n\t\t\t* \r\n\t\tfrom valuewhitelist_cedar_assetclass wl \r\n\t\twhere \r\n\t\t\twl.CEDAR = instr.CEDAR\r\n\t\t\tand wl.DLAMAssetClass2 = instr.DLAMAssetClass2\r\n\t\t\tand wl.DLAMAssetClass3 = instr.DLAMAssetClass3\r\n\t\t)
    superset_query
261               
[1] "Differences in 'allowed_DLAMAssetClass3_with_given_CEDAR'"
         insid
4 FPP AAV Port
                                                                                                                                                                                                                                                 allowed_DLAMAssetClass3_with_given_CEDAR
4 -, -, -, -, ADR, Asset Allocation Fund, Common Stock, Debt Fund, Dutch Certificate CVA, Equity Regional Fund, Equity Theme Fund, Equity Value Fund, Money Market Fund, Office, Other, Other Equity Fund, Other Fixed Income Fund, Parking, Real Estate Fund, Residential, Retail, Right
         insid
4 FPP AAV Port
                                                                                                                                                                                                                                                allowed_DLAMAssetClass3_with_given_CEDAR
4 -, -, -, -, ADR, Asset Allocation Fund, Common Stock, Debt Fund, Dutch Certificate CVA, Equity Regional Fund, Equity Theme Fund, Equity Value Fund, Money Market Fund, Office, Other, Other Equity Fund, Other Fixed Income Fund, Parking, Real Estate Fund, Residential, Retail, Righ
  difference
4       <NA>
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
262 BU Delta Lloyd Asset Management Portia PO_0117 instrument SelfConsistent       NICE      Input             <NA> Data Management Ronald Bark   2015-05-21
    resultApprovalDate      dataelements                               datasource                referencedata
262         2015-06-30 DLAM.Asset.Type.3 RM-PortiaTotal_P_  ,  DM-SecsHLD Portia  whitelist_cic_assetclass.csv
                                                                 en                                                                             nl
262 Only whitelisted combinations of Asset class and CIC_Code occur Alleen verwachte combinaties van Asset class en CIC_Code dienen voor te komen.
                                                                                                                                                                                                                                                        rule
262 Only whitelisted combinations of Asset class and CIC_Code occur. The CIC_Code are the characters 3 and 4 of CIC (the inital 2 characters indicate the country)\n\n\n\nVerified relation CIC_Code <=> (DLAMAssetClass1, DLAMAssetClass2, DLAMAssetClass3)
                                                                                                                                   condition Feedback
262 All instruments that \n\n\n\nhave a combination of DLAMAssetClass1, 2 and 3 and the CIC number code\n\n\n\nwhich is not on the whitelist         
         rule_load_date      source_file
262 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            query
262 select DISTINCT\r\n\tinstr.insid,\r\n\tinstr.DLAMAssetClass1,\r\n\tinstr.DLAMAssetClass2,\r\n\tinstr.DLAMAssetClass3,\r\n\tinstr.CIC_Code,\r\n\tinstr.CIC,\r\n\t-- Get string concatenated value of all Sector2NoCountries which are allowed with the provided WFT\r\n\tSTUFF(\r\n            (SELECT\r\n                ', ' + t2.DLAMAssetClass1\r\n                FROM valuewhitelist_cic_assetclass t2\r\n                WHERE instr.CIC_Code = t2.CIC_Code \r\n                GROUP BY t2.DLAMAssetClass1\r\n                ORDER BY t2.DLAMAssetClass1\r\n                FOR XML PATH(''), TYPE\r\n            ).value('.','varchar(max)')\r\n            ,1,2, ''\r\n        ) AS allowed_DLAMAssetClass1_with_given_CIC_Code,\r\n\tSTUFF(\r\n            (SELECT\r\n                ', ' + t2.DLAMAssetClass2\r\n                FROM valuewhitelist_cic_assetclass t2\r\n                WHERE instr.CIC_Code = t2.CIC_Code \r\n                GROUP BY t2.DLAMAssetClass2\r\n                ORDER BY t2.DLAMAssetClass2\r\n                FOR XML PATH(''), TYPE\r\n            ).value('.','varchar(max)')\r\n            ,1,2, ''\r\n        ) AS allowed_DLAMAssetClass2_with_given_CIC_Code,\r\n\tSTUFF(\r\n            (SELECT \r\n                ', ' + t2.DLAMAssetClass3\r\n                FROM valuewhitelist_cic_assetclass t2\r\n                WHERE instr.CIC_Code = t2.CIC_Code \r\n                GROUP BY t2.DLAMAssetClass3\r\n                ORDER BY t2.DLAMAssetClass3\r\n                FOR XML PATH(''), TYPE\r\n            ).value('.','varchar(max)')\r\n            ,1,2, ''\r\n        ) AS allowed_DLAMAssetClass3_with_given_CIC_Code,\r\n\tSTUFF(\r\n        (SELECT \r\n            ', ' + t2.CIC_Code\r\n            FROM valuewhitelist_cic_assetclass t2\r\n            WHERE instr.DLAMAssetClass3=t2.DLAMAssetClass3\r\n            GROUP BY t2.CIC_Code\r\n            ORDER BY t2.CIC_Code\r\n            FOR XML PATH(''), TYPE\r\n        ).value('.','varchar(max)')\r\n        ,1,2, ''\r\n    ) AS allowed_CIC_Code_with_given_DLAMAssetClass3\r\nfrom\r\n\tvx_PO_instrument instr\r\nwhere\r\n\t-- in scope for datamanagement\r\n\tscope_dm = 1\r\n\t-- and not on the whitelist (only if starts with XT or is null).\r\n\t-- XT is not a country code, but an indication for a mapping according to DLAM policy\r\n\tand (instr.CIC like 'XT%' or instr.CIC is null)\r\n\tand not exists (\r\n\t\tselect \r\n\t\t\t* \r\n\t\tfrom valuewhitelist_cic_assetclass wl \r\n\t\twhere \r\n\t\t\twl.CIC_Code = instr.CIC_Code\r\n\t\t\tand wl.DLAMAssetClass1 = instr.DLAMAssetClass1\r\n\t\t\tand wl.DLAMAssetClass2 = instr.DLAMAssetClass2\r\n\t\t\tand wl.DLAMAssetClass3 = instr.DLAMAssetClass3\r\n\t\t)\r\n-- this extra line prevents R from trimming the last ) from the quer
    superset_query
262               
                                 BU system      BR entitytype           Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
263 BU Delta Lloyd Asset Management Portia PO_0118 instrument OuterConsistent       NEED      Input             <NA> Mid Office Kristine Prahl         <NA>
    resultApprovalDate dataelements                                                         datasource referencedata
263         2015-06-16     QUANTITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia, fndstt.dat, portsaldo.csv              
                                                                            en                                                                           nl
263 All kasbank managed holdings in portia should exist in the kasbank exports Alle kasbank beheerde posities in Portia dienen ook in kasbank voor te komen
                                                                                                                                                                                                                                                                            rule
263 The Kasbank holds the depot for certain assets. Those which have been marked as managed by the kasbank, should exist in the kasbank export with the same quantity.\n\nThis rule indicates holdings as a failure when they do exist in Portia, but not in the kasbank export.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   condition
263 Given all holdings of portsaldo, \n\nand all holdings in portiatotal with portfolionaam's that don't exist in portsaldo, but do start with 'Coll',\n\nand all holdings in portiatotal with DLAMAssetClass3 equal to LOS,\n\nWhich match\n\n  custodian like 'KAS%'\n\n and ISIN not like 'DLINT%'\n\n and not (len(ISIN)=4 and securityDescription like '%fut%')\n\n and not (securityDescription like 'call%')\n\n and not (securityDescription like 'put%')\n\n and not (securityDescription like '%tbv MIX')\n\nThose holdings which do not exist (based on ISIN) in the fndstt.dat (kasbank) export 
    Feedback      rule_load_date      source_file
263          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          query
263 select  DISTINCT\r\n\tisnull(vx_PO_kasbank_vs_instrument.insid, isnull(PO_portiatotal.Securitynaam, vx_PO_kasbank_vs_instrument.ISIN)) as insid,\r\n\tinstr_diff,\r\n\tvx_PO_kasbank_vs_instrument.isin,\r\n\tisnull(vx_PO_kasbank_vs_instrument.[description], PO_portiatotal.[Description]) as Description,\r\n\tisnull(vx_PO_kasbank_vs_instrument.munt, PO_portiatotal.MUNT) as munt,\r\n\tportia_instr_quantity,\r\n\tkasbank_instr_quantity,\r\n\tportia_isin_quantity,\r\n\tkasbank_isin_quantity,\r\n\tportia_num_positions,\r\n\tkasbank_num_positions,\r\n\tall_prfids,\r\n\t\tisnull(portia_instr_quantity, kasbank_instr_quantity)\r\n\r\nfrom \r\n\tvx_PO_kasbank_vs_instrument\r\n\tleft join PO_portiatotal \r\n\ton ((vx_PO_kasbank_vs_instrument.isin is null and PO_portiatotal.ISIN is null) or vx_PO_kasbank_vs_instrument.isin=PO_portiatotal.ISIN )\r\n\tand vx_PO_kasbank_vs_instrument.insid is NULL\r\nwhere\r\n\tkasbank_instr_quantity is null\r\n\t--already in view: and custodian != 'KAS NL (REG)'\r\n\t--and not exists (select * from vx_whitelist where BR='PO_0118' and vx_whitelist.insid=isnull(vx_PO_kasbank_vs_instrument.insid, isnull(PO_portiatotal.Securitynaam, vx_PO_kasbank_vs_instrument.ISIN)))\r\norder by \r\n\tisin,\r\n\tisnull(portia_instr_quantity, kasbank_instr_quantity)
    superset_query
263               
 names_orig names_sql_expected names_sql
                             X       V13
                                 BU system      BR entitytype           Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
264 BU Delta Lloyd Asset Management Portia PO_0119 instrument OuterConsistent       NEED      Input             <NA> Mid Office Kristine Prahl         <NA>
    resultApprovalDate dataelements                                                         datasource referencedata
264               <NA>     QUANTITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia, fndstt.dat, portsaldo.csv              
                                                           en                                                       nl
264 All holdings in the kasbank export should exist in portia Alle kasbank posities dienen ook in Portia voor te komen
                                                                                                                                                                                                                                                                                                rule
264 The Kasbank holds the depot for certain assets. Those which have been marked in Portia as managed by the kasbank, should exist in the kasbank export with the same quantity.\n\nThis rule indicates holdings as a failure when they do exist in the Kasbank export but not in the Portia export.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        condition
264 Given all holdings in fndstt.dat (kasbank)\n\n    That don't start with RTS,\n\nThose holdings which do not exist (based on ISIN) in Portia, defined as holdings in portsaldo, \n\nand all holdings in portiatotal with portfolionaam's that don't exist in portsaldo, but do start with 'Coll',\n\nand all holdings in portiatotal with DLAMAssetClass3 equal to LOS,\n\nWhich match\n\n  custodian like 'KAS%'\n\n and ISIN not like 'DLINT%'\n\n and not (len(ISIN)=4 and securityDescription like '%fut%')\n\n and not (securityDescription like 'call%')\n\n and not (securityDescription like 'put%')\n\n and not (securityDescription like '%tbv MIX')
    Feedback      rule_load_date      source_file
264          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              query
264 select  DISTINCT\r\n\tisnull(vx_PO_kasbank_vs_instrument.insid, isnull(PO_portiatotal.Securitynaam, vx_PO_kasbank_vs_instrument.ISIN)) as insid,\r\n\tinstr_diff,\r\n\tvx_PO_kasbank_vs_instrument.isin,\r\n\tisnull(vx_PO_kasbank_vs_instrument.[description], PO_portiatotal.[Description]) as Description,\r\n\tisnull(vx_PO_kasbank_vs_instrument.munt, PO_portiatotal.MUNT) as munt,\r\n\tportia_instr_quantity,\r\n\tkasbank_instr_quantity,\r\n\tportia_isin_quantity,\r\n\tkasbank_isin_quantity,\r\n\tportia_num_positions,\r\n\tkasbank_num_positions,\r\n\tall_depositaccountnr\r\nfrom \r\n\tvx_PO_kasbank_vs_instrument\r\n\tleft join PO_portiatotal \r\n\ton vx_PO_kasbank_vs_instrument.isin=PO_portiatotal.ISIN \r\n\tand vx_PO_kasbank_vs_instrument.insid is NULL\r\nwhere\r\n\tportia_instr_quantity is null\r\n\tand isnull(vx_PO_kasbank_vs_instrument.[description],'') not like 'RTS%'\r\n\t--and not exists (select * from vx_whitelist where BR='PO_0119' and vx_whitelist.insid=isnull(vx_PO_kasbank_vs_instrument.insid, isnull(PO_portiatotal.Securitynaam, vx_PO_kasbank_vs_instrument.ISIN)))\r\norder by \r\n\tisin
    superset_query
264               
                                 BU system      BR entitytype           Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
265 BU Delta Lloyd Asset Management Portia PO_0120    holding OuterConsistent       NEED      Input             <NA> Mid Office Kristine Prahl         <NA>
    resultApprovalDate dataelements                                                         datasource               referencedata
265               <NA>     QUANTITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia, fndstt.dat, portsaldo.csv fndstt_known_mismatches.csv
                                                                                en                                                                               nl
265 All matching holdings between kasbank and portia, need to have same quantities All posities die in Portia en de Kasbank voorkomen dienen te matchen op quantity
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 rule
265 The Kasbank holds the depot for certain assets. Those which have been marked as managed by the kasbank, should exist in the kasbank export with the same quantity.\n\nThis rule indicates holdings as a failure when they exist both in Portia and Kasbank, but do not match on Quantity. \n\nIf the currency is known, the quantity is matched per currency. If the currency is not uniquely identified, then comparisons are done based on ISIN only\n\nThe portia holdings are mainly defined by the portsaldo export.\n\nThe records in portiatotal of portfolio's not mentioned in portsaldo, but which do start with 'coll' (of collateral) or have dlamassetclass 3 equal to LOS, are added.\n\nFrom these, only actual holdings (quantity>0), \n\ncustodian which start with KAS, but are not equal to KAS NL (REG),\n\nand don't have an DLINT isin,\n\nand aren't a future, call nor put\n\nare kept as holdings to be expected in kasbank.\n\nInstruments with description starting with 'FRN ' are excluded\n\nMidOffice has provided a list 'fndstt_known_mismatches.csv', based on their 'standaard fouten' which contains instruments which do exist both in portia and kasbank,but are expected to have different quantities because of factors / face value usag
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             condition
265 Given all holdings of portsaldo, \n\nand all holdings in portiatotal with portfolionaam's that don't exist in portsaldo, but do start with 'Coll',\n\nand all holdings in portiatotal with DLAMAssetClass3 equal to LOS,\n\nwhich match\n\n  custodian like 'KAS%'\n\nand custodian not like 'KAS NL (REG)'\n\n and ISIN not like 'DLINT%'\n\n and not (len(ISIN)=4 and securityDescription like '%fut%')\n\n and not (securityDescription like 'call%')\n\n and not (securityDescription like 'put%')\n\nWhich exist (based on ISIN) in the fndstt.dat (kasbank) export,\n\nwhich do not have a description starting with 'FRN '\n\nBut do not match based on Quantity:\n\n both portia and kasbank have a holding on the isin (else covered by PO_0119 or PO_0118)\n\n where that total holding is different\n\n and only the positions where records in portia or kasbank can't be matched on the other based on quantity\n\n  
    Feedback      rule_load_date      source_file
265          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
265 select  DISTINCT\r\n\tisnull(insid, isnull(isin_one_name.Securitynaam, comparison.ISIN)) as insid,\r\n\tholding_diff,\r\n\tcomparison.isin,\r\n\tdescription,\r\n\tmunt,\r\n\tportia_quantity,\r\n\tkasbank_quantity,\r\n\tisin_diff,\r\n\tportia_isin_quantity,\r\n\tkasbank_isin_quantity,\r\n\tprfid,\r\n\tdepositaccountnr,\r\n\tcustodian\r\nfrom \r\n\tvx_PO_kasbank_vs_holding as comparison\r\n\t-- if the isin exists in portiatotal with one insid, get that insid to enrich kasbank lines\r\n\tleft join ( select isin_names.* from (select isin from PO_portiatotal group by isin having count(distinct securitynaam)=1) as one_name left join\r\n\t(select distinct isin, securitynaam from PO_portiatotal) as isin_names on one_name.ISIN=isin_names.ISIN) as isin_one_name\r\n\ton ((comparison.isin is null and isin_one_name.ISIN is null) or comparison.isin=isin_one_name.ISIN )\r\n\tand comparison.insid is NULL\r\nwhere\r\n\tportia_isin_quantity is not null and kasbank_isin_quantity is not null -- instruments which exist in both systems\r\n\tand abs(isin_diff) >= 0.1 -- but which quantities are different on isin level\r\n\tand (portia_quantity is null or kasbank_quantity is null)  -- then only show the holdings which do not match\r\n\tand description not like 'FRN %'\r\n\tand not exists (\r\n\t\tselect * \r\n\t\tfrom PO_fndstt_known_mismatches as ignore\r\n\t\twhere BR='PO_0120' \r\n\t\t\tand ignore.insid=isnull(comparison.insid, isnull(isin_one_name.Securitynaam, comparison.ISIN))\r\n\t\t\tand (ignore.prfid is null or\r\n\t\t\t\tignore.prfid=comparison.prfid))\r\norder by \r\n\tcomparison.isin--,\r\n--\tisnull(portia_isin_quantity, kasbank_isin_quantity),\r\n--\tisnull(portia_quantity, kasbank_quantity)
    superset_query
265               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
266 BU Delta Lloyd Asset Management Portia PO_0121    holding SelfConsistent       NEED      Input             <NA> Mid Office Kristine Prahl         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                                              en
266         2015-06-16     QUANTITY RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                If the Security name starts with *, the quantity should be zero
                                                                   nl
266 Als de security naam met een * begint, dient het aantal 0 te zijn
                                                                                                                                                                                                                                                                                                           rule
266 If a security has been marked unused (by the *), there shouldn't be a  holding in it\n\n\n\nThe quantities can be neither positive (long positions) nor negative (short positions), only strictly zero (no position)\n\n\n\nVerified relation: (Security Name starting with *) => (All its QUANTITY's == 0)
                                                           condition Feedback      rule_load_date      source_file
266 All holding with quantity != 0 and security name starting with *          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                     query
266 select  DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tSecuritynaam,\r\n\tQUANTITY\r\nfrom \r\n\tvx_PO_holding\r\nwhere\r\n\t-- the subset\r\n\tSecuritynaam like '*%'\r\n\t-- the wrong attributes\r\n\tand QUANTITY!=0
    superset_query
266               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
267 BU Delta Lloyd Asset Management Portia PO_0122   currency ValidRange       NEED      Input             <NA> Valuation Desk Ilona Balvert         <NA>
    resultApprovalDate dataelements         datasource referencedata               en                           nl
267               <NA>       FXRATE RM-PortiaTotal_P_                EUR has fxrate 1 De FXRate is 1 voor munt EUR
                                                               rule                           condition Feedback      rule_load_date      source_file
267 The FXRate has unit EUR, therefore the EUR should have FXRate 1 The currency EUR , with FXRATE != 1          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                         query superset_query
267 select DISTINCT\r\n\tfxid,\r\n\tReportingDate,\r\n\tMUNT,\r\n\tFXRATE\r\nfrom\r\n\tvx_PO_currency\r\nwhere\r\n\tMUNT = 'EUR'\r\n\tand FXRATE != 1               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
268 BU Delta Lloyd Asset Management Portia PO_0123 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                  en                                  nl
268         2015-06-30   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                DLBINT ISINS are 12 characters long DLBINT ISINS zijn 12 karakters lang
                                                                                                                                                                                                                                                                                        rule
268 The ISIN field (identifier) is used for different identifiers.\n\nThe identifiers found need to be one of the expected formats.\n\nThe ones starting with DLBINT should have a length of 12 characters.\n\nVerified with deltalloydlife.be (Fatima / Eric) by Ronald Bark on 9 june 2015
                                                                                condition Feedback      rule_load_date      source_file
268 Instruments with an isin that starts with 'DLBINT'\n\n  but is not 12 characters long          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                               query
268 select DISTINCT\r\n\tinsid,\r\n\tISIN\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the set for which this rule holds\r\n\tISIN like 'DLBINT%'\r\n\t-- getting the failures\r\n\tand len(ISIN)!=12\r\n
    superset_query
268               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
269 BU Delta Lloyd Asset Management Portia PO_0124 instrument ValidRange       NEED      Input             <NA> Data Management Ronald Bark         <NA>
    resultApprovalDate dataelements                               datasource referencedata                                         en
269         2015-06-30   IDENTIFIER RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                DLBINT ISINS have a 6 digit numeric suffix
                                                        nl
269 DLBINT ISINS hebben een 6 digit numeriek achtervoegsel
                                                                                                                                                                                                                                                                                        rule
269 The ISIN field (identifier) is used for different identifiers.\n\nThe identifiers found need to be one of the expected formats.\n\nThe ones starting with DLBINT should have a six digit numeric suffix\n\nVerified with deltalloydlife.be (Fatima / Eric) by Ronald Bark on 9 june 2015
                                                                                         condition Feedback      rule_load_date      source_file
269 Instruments with an isin that start with 'DLBINT' and which' 6 character suffix is not numeric          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                             query
269 select DISTINCT\r\n\tinsid,\r\n\tISIN,\r\n\tright(ISIN, 6) as isin_suffix\r\nfrom\r\n\tvx_PO_instrument\r\nwhere\r\n\t-- the set for which this rule holds\r\n\tISIN like 'DLBINT%'\r\n\t-- getting the failures\r\n\tand 1!=isnumeric(right(ISIN, 6))
    superset_query
269               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
270 BU Delta Lloyd Asset Management Portia PO_0125   currency SelfConsistent       NEED      Input             <NA> Valuation Desk Ilona Balvert         <NA>
    resultApprovalDate dataelements         datasource     referencedata                                                            en
270               <NA>       FXRATE RM-PortiaTotal_P_  exchangerates.csv The rounded FXRate corresponds with rounded exported FX rates
                                                                       nl
270 De afgeronde FXRate is gelijk aan de afgeronde geexporteerde FX rate 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           rule
270 The FXRate should be equal to the closing foreign exchange rate\n\n\n\nThe export used by FRM actually is rounded to 5 digits, while Portia contains a precision of 9 digits.\n\n\n\nTo have correct FX calculations the full available precision should be used.\n\n\n\n \n\nWhile the full precision of the fx rates is verified by PO_0111, this rule does a less strict check: If they are equal after rounding.\n\nThis allows specific fx rates to become exceptions if they are not only incorrect in full precision, but also after rounding.\n\nVerified relation: MUNT => rounded(FXRATE.orig) == rounded(FXRATE)
                                                                                                                                  condition Feedback
270 All currencies that have an exchange rate which does not match, rounded to 5 digits, with the accurate exchangerate rounded to 5 digits         
         rule_load_date      source_file
270 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                              query
270 select DISTINCT\r\n\tvx_PO_currency.fxid,\r\n\tvx_PO_currency.FXRATE,\r\n\tPO_exchangerates.FXRATE as FXRATE_expected,*\r\nfrom\r\n\tvx_PO_currency\r\n\tleft join\r\n\tPO_exchangerates\r\n\t\ton vx_PO_currency.fxid = PO_exchangerates.fxid\r\n\t\tand vx_PO_currency.ReportingDate = PO_exchangerates.ReportingDate\r\nwhere\r\n\tROUND(vx_PO_currency.FXRATE, 5) != ROUND(PO_exchangerates.FXRATE, 5)
    superset_query
270               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
271 BU Delta Lloyd Asset Management Portia PO_0126 instrument SelfConsistent       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements                               datasource referencedata                                                  en
271               <NA>    Issuer-ID RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Issuer-ID can only be assigned to one IssuerID-Naam
                                                           nl rule condition Feedback      rule_load_date      source_file
271 Issuer-ID mag maar aan ��n IssuerID-Naam worden toegekend                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      query
271 SELECT DISTINCT\r\n\tvx_PO_instrument.insid,\r\n\tvx_PO_instrument.issuerID,\r\n\tissuerIDNaam,\r\n\tcnt.Aantal_issuerIDNaam\r\nFROM\r\n\tvx_PO_instrument\r\n\tINNER JOIN (SELECT\r\n\t\t\t\t\tIssuerID,\r\n\t\t\t\t\tcount(distinct issuerIDNaam) as Aantal_issuerIDNaam\r\n\t\t\t\tFROM\r\n\t\t\t\t\tvx_PO_instrument\r\n\t\t\t\tGROUP BY IssuerID\r\n\t\t\t\tHAVING COUNT(distinct issuerIDNaam) > 1 AND issuerID <> 1) cnt -- issuerID = 1 is filtered since these still need to be mapped to a issuerIDNaam  \r\n\t\tON vx_PO_instrument.IssuerID = cnt.IssuerID\r\nORDER BY vx_PO_instrument.IssuerID, issuerIDNaam
    superset_query
271               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
272 BU Delta Lloyd Asset Management Portia PO_0127 instrument hasValue       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements                               datasource referencedata                        en                           nl rule condition
272               <NA>    Issuer-ID RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Issuer-ID cannot be empty Issuer-ID mag niet leeg zijn               
    Feedback      rule_load_date      source_file                                                                                                           query
272          2016-04-26 16:05:43 portia_rules.csv SELECT  DISTINCT\r\n\tinsid,\r\n\tIDENTIFIER,\r\n\tIssuerID\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE IssuerID IS NULL
    superset_query
272               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
273 BU Delta Lloyd Asset Management Portia PO_0128 instrument HasValue       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate  dataelements                               datasource referencedata                            en                               nl rule
273               <NA> IssuerID-Naam RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                IssuerID-Naam cannot be empty IssuerID-Naam mag niet leeg zijn     
    condition Feedback      rule_load_date      source_file
273                    2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                         query
273 SELECT DISTINCT\r\n\tinsid,\r\n\tIDENTIFIER,\r\n\tIssuerIDNaam,\r\n\tIssuerID\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE\r\n\tISNULL(ltrim(IssuerIDNaam),'') = '' AND IssuerID <> 1 --IssuerID =1 are filtered since they need to be mapped\r\nORDER BY IssuerIDNaam
    superset_query
273               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate resultApprovalDate
274 BU Delta Lloyd Asset Management Portia PO_0129    holding HasValue       NEED      Input       2015-10-25 Mid Office Kristine Prahl   2015-10-26               <NA>
    dataelements                               datasource referencedata                        en                           nl rule condition Feedback
274    CUSTODIAN RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                CUSTODIAN cannot be empty CUSTODIAN mag niet leeg zijn                        
         rule_load_date      source_file
274 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                  query superset_query
274 SELECT DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tCUSTODIAN\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tISNULL(ltrim(rtrim(CUSTODIAN)),'') = ''                
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
275 BU Delta Lloyd Asset Management Portia PO_0130 instrument HasValue       NEED      Input       2015-10-25 Valuation Desk Ilona Balvert   2015-10-26
    resultApprovalDate dataelements                               datasource referencedata                      en                         nl rule condition Feedback
275               <NA>      FVLevel RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                FVLevel cannot be empty FVLevel mag niet leeg zijn                        
         rule_load_date      source_file
275 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                  query superset_query
275 SELECT DISTINCT\r\n\tinsid,\r\n\tISIN,\r\n\t[Description],\r\n\tFVLevel\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE\r\n\tISNULL(FVLevel,'')=''               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate      ruleOwner    approvedBy approvedDate
276 BU Delta Lloyd Asset Management Portia PO_0131 instrument ValidRange       NEED      Input       2015-10-25 Valuation Desk Ilona Balvert   2015-10-26
    resultApprovalDate dataelements                               datasource referencedata                                    en
276               <NA>      FVLevel RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                FVLevel must have the value 1, 2 or 3
                                         nl rule condition Feedback      rule_load_date      source_file
276 FVLevel moet de waarde 1, 2 of 3 hebben                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                           query
276 SELECT DISTINCT\r\n\tinsid,\r\n\tISIN,\r\n\t[Description],\r\n\tFVLevel\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE\r\n\tNOT FVLevel IS NULL AND FVLevel NOT IN (1,2,3)
    superset_query
276               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate resultApprovalDate
277 BU Delta Lloyd Asset Management Portia PO_0132    holding HasValue       NEED      Input       2015-10-25 Mid Office Kristine Prahl   2015-10-26               <NA>
    dataelements                               datasource referencedata                      en                         nl rule condition Feedback      rule_load_date
277     Position RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Postion cannot be empty Positon mag niet leeg zijn                         2016-04-26 16:05:43
         source_file                                                                                                                            query superset_query
277 portia_rules.csv SELECT DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tSECURITY,\r\n\tPosition\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tISNULL(Position,'') = ''               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
278 BU Delta Lloyd Asset Management Portia PO_0133    holding ValidRange       NEED      Input       2015-10-25 Mid Office Kristine Prahl   2015-10-26
    resultApprovalDate dataelements                               datasource referencedata                                      en
278               <NA>     Position RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Postion must be filled with "L" or "S".
                                         nl rule condition Feedback      rule_load_date      source_file
278 Postion moet gevuld zijn met "L" of "S"                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                           query
278 SELECT  DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tSECURITY,\r\n\tPosition\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tNOT Position IS NULL AND Position NOT IN ('L', 'S')
    superset_query
278               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
279 BU Delta Lloyd Asset Management Portia PO_0134    holding ValidRange       NEED      Input       2015-10-25 Mid Office Kristine Prahl   2015-10-26
    resultApprovalDate dataelements                               datasource referencedata
279               <NA>     Position RM-PortiaTotal_P_  ,  DM-SecsHLD Portia               
                                                                               en
279 If Quantity value is greater then "0", then Position must be filled with "L".
                                                                                            nl rule condition Feedback      rule_load_date      source_file
279 Indien Quantity-waarde groter of gelijk is aan "0", dan moet Postion gevuld worden met "L"                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                 query
279 \r\nSELECT DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tPosition\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tQuantity >0  \r\n\tAND ISNULL(Position,'') NOT IN ('L')
    superset_query
279               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
280 BU Delta Lloyd Asset Management Portia PO_0135    holding ValidRange       NEED      Input       2015-10-25 Mid Office Kristine Prahl   2015-10-26
    resultApprovalDate dataelements                               datasource referencedata                                                                         en
280               <NA>     Position RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                If Quantity value is less than "0", then Position must be filled with "S".
                                                                                   nl rule condition Feedback      rule_load_date      source_file
280 Indien Quantity-waarde kleiner is dan "0", dan moet Postion gevuld worden met "S"                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                  query
280 \r\nSELECT DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tPosition\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tQuantity < 0  \r\n\tAND ISNULL(Position,'') NOT IN ('S')
    superset_query
280               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
281 BU Delta Lloyd Asset Management Portia PO_0136  portfolio ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata
281               <NA>  Cedar_BU_Nr RM-PortiaTotal_P_               
                                                                                                          en
281 Cedar_BU_Nr starting with 64, must have a Portfolio_Naam beginning with "DL_I", "DL_L", "DL_M" of "Trio"
                                                                                                            nl rule condition                       Feedback
281 Cedar_BU_Nr startend met 64, moet een Portfolio_Naam hebben beginnend met "DL_I", "DL_L", "DL_M" of "Trio"                Regel ook valideren met Gerton
         rule_load_date      source_file
281 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                            query
281 \r\nSELECT DISTINCT\r\n    prfid,\r\n\tPORTFOLIO_NAME,\r\n\tCedar_BU_Nr\r\nFROM\r\n\tvx_PO_portfolio\r\nWHERE\r\n\tCedar_BU_Nr like '64%'\r\n\tAND LEFT(PORTFOLIO_NAME, 4) NOT IN ('DL_I', 'DL_L', 'DL_M', 'TRIO')
    superset_query
281               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
282 BU Delta Lloyd Asset Management Portia PO_0137  portfolio SelfConsistent       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                                                      en
282               <NA>  Cedar_BU_Nr RM-PortiaTotal_P_                Portfolio_Naam can only be assigned to one Cedar_BU_Nr 
                                                               nl rule condition Feedback      rule_load_date      source_file
282 Portfolio_Naam mag maar aan ��n Cedar_BU_Nr  worden toegekend                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               query
282 \r\nSELECT DISTINCT\r\n\tprfid,\r\n\tCedar_BU_Nr,\r\n\tCLIENT_NAME,\r\n\tcnt.PORTFOLIO_NAME,\r\n\tcnt.aantal_Cedar_BU_Nrs\r\nFROM\r\n\tvx_PO_portfolio\r\n\tINNER JOIN (SELECT\r\n\t\t\t\t\tPORTFOLIO_NAME,\r\n\t\t\t\t\tCOUNT(DISTINCT Cedar_BU_Nr) AS aantal_Cedar_BU_Nrs\r\n\t\t\t\tFROM\r\n\t\t\t\t\tvx_PO_portfolio\r\n\t\t\t\tGROUP BY\r\n\t\t\t\t\tPORTFOLIO_NAME\r\n\t\t\t\tHAVING \r\n\t\t\t\t\tCOUNT(DISTINCT Cedar_BU_Nr) > 1 ) AS cnt\r\n\t\tON vx_PO_portfolio.PORTFOLIO_NAME = cnt.PORTFOLIO_NAME\r\nORDER BY cnt.PORTFOLIO_NAME
    superset_query
282               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
283 BU Delta Lloyd Asset Management Portia PO_0138 instrument SelfConsistent       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements                               datasource referencedata                                                   en
283               <NA>   Fonds ISIN RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Fonds ISIN should also appear als underlying in ISIN
                                                                   nl rule condition Feedback      rule_load_date      source_file
283 Fonds ISIN zal ook als onderliggend stuk in ISIN moeten voorkomen                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                          query
283 \r\nSELECT  DISTINCT\r\n\tinsid,\r\n\tFondsISIN,\r\n\tISIN,\r\n\tDescription\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tISNULL(FondsISIN,'') != '' \r\n\tAND  \r\n\tFondsISIN NOT IN (SELECT DISTINCT ISIN FROM vx_PO_instrument)\r\n
    superset_query
283               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
284 BU Delta Lloyd Asset Management Portia PO_0139 instrument ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements                               datasource referencedata                                                                           en
284               <NA>   Fonds ISIN RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                If Fonds ISIN is equal to ISIN, then DLAMAssetClass3 should always be a fund
                                                                                       nl rule condition Feedback      rule_load_date      source_file
284 Als Fonds ISIN gelijk is aan ISIN, dan dient DLAMAssetClass3 altijd een fonds te zijn                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                        query
284 \r\nSELECT  DISTINCT\r\n\t\r\n\tinsid,\r\n\tISIN,\r\n\tFondsISIN,\r\n\tDLAMAssetClass3\r\nFROM\r\n\tvx_PO_holding\r\nWHERE \r\n\tFondsISIN = ISIN\r\n\tAND DLAMAssetClass3 not  like '%fund%'\r\n
    superset_query
284               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
285 BU Delta Lloyd Asset Management Portia PO_0140  portfolio SelfConsistent       NEED      Input       2015-10-25 Data Management Sander van Laarhoven   2015-10-26
    resultApprovalDate dataelements         datasource referencedata                                                   en
285               <NA>    Risk Type RM-PortiaTotal_P_                Portfolio_Naam can only be assigned to one Risk Type
                                                            nl rule condition Feedback      rule_load_date      source_file
285 Portfolio_Naam mag maar aan ��n Risk Type worden toegekend                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                   query
285 \r\nSELECT DISTINCT\r\n\tprfid,\r\n\tcount(distinct RiskType) As aantal_risktypes\r\nFROM\r\n\tvx_PO_portfolio\r\nGROUP BY prfid\r\nHAVING COUNT(distinct RiskType) > 1
    superset_query
285               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
286 BU Delta Lloyd Asset Management Portia PO_0141  portfolio HasValue       NEED      Input       2015-10-25 Data Management Sander van Laarhoven   2015-10-26
    resultApprovalDate dataelements         datasource referencedata                        en                           nl rule condition Feedback      rule_load_date
286               <NA>    Risk Type RM-PortiaTotal_P_                Risk Type cannot be empty Risk Type mag niet leeg zijn                         2016-04-26 16:05:43
         source_file                                                                                          query superset_query
286 portia_rules.csv \r\nSELECT  DISTINCT\r\n\t*\r\nFROM\r\n\tvx_PO_portfolio\r\nWHERE\r\n\tISNULL(RiskType, '') = ''                
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
287 BU Delta Lloyd Asset Management Portia PO_0142  portfolio ValidRange       NEED      Input       2015-10-25 Data Management Sander van Laarhoven   2015-10-26
    resultApprovalDate dataelements         datasource referencedata                                                                              en
287               <NA>    Risk Type RM-PortiaTotal_P_                Only zPearl Dummy and NUS in Portfolio_Naam are allowed to have a Risk Type "-"
                                                                               nl rule condition                    Feedback      rule_load_date      source_file
287 Alleen zPearl Dummy en NUS in Portfoilio_Naam, mogen een Risk Type "-" hebben                Regel ook valideren met FRM 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                        query superset_query
287 \r\nSELECT  DISTINCT\r\n\t*\r\nFROM\r\n\tvx_PO_portfolio\r\nWHERE\r\n\tRiskType = '-'\r\n\tAND PORTFOLIO_NAME  NOT IN ('NUS', 'zPearl Dummy')               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
288 BU Delta Lloyd Asset Management Portia PO_0143  portfolio ValidRange       NEED      Input       2015-10-25 Data Management Sander van Laarhoven   2015-10-26
    resultApprovalDate dataelements         datasource referencedata                                                                                           en
288               <NA>    Risk Type RM-PortiaTotal_P_                Funds with Risk Type "Vermogensbeheer" must have a Portfolio_Naam starting with "VB" or "EP"
                                                                                                     nl rule condition                    Feedback      rule_load_date
288 Fondsen met Risk Type "Vermogensbeheer" moeten een Portfolio_Naam hebben beginnend met "VB" of "EP"                Regel ook valideren met FRM 2016-04-26 16:05:43
         source_file                                                                                                                                              query
288 portia_rules.csv SELECT  DISTINCT\r\n\t *\r\nFROM\r\n\tvx_PO_portfolio\r\nWHERE\r\n\tRiskType = 'Vermogensbeheer' \r\n\tAND LEFT(PORTFOLIO_NAME,2) NOT IN ('VB', 'EP') 
    superset_query
288               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
289 BU Delta Lloyd Asset Management Portia PO_0144  portfolio ValidRange       NEED      Input       2015-10-25 Data Management Sander van Laarhoven   2015-10-26
    resultApprovalDate dataelements         datasource referencedata                                                                                en
289               <NA>    Risk Type RM-PortiaTotal_P_                Funds with Risk Type "Collateral" must have a Portfolio_Naam starting with "COLL"
                                                                                          nl rule condition                    Feedback      rule_load_date
289 Fondsen met Risk Type "Collateral" moeten een Portfolio_Naam hebben beginnend met "COLL"                Regel ook valideren met FRM 2016-04-26 16:05:43
         source_file
289 portia_rules.csv
                                                                                                                                                          query
289 \r\n\r\nSELECT  DISTINCT\r\n\t prfid,\r\n\t*\r\nFROM\r\n\tvx_PO_portfolio\r\nWHERE\r\n\tRiskType = 'Collateral'\r\n\tAND LEFT(PORTFOLIO_NAME, 4) NOT IN ('COLL')
    superset_query
289               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
290 BU Delta Lloyd Asset Management Portia PO_0145  portfolio ValidRange       NEED      Input       2015-10-25 Data Management Sander van Laarhoven   2015-10-26
    resultApprovalDate dataelements         datasource referencedata                                                                       en
290               <NA>    Risk Type RM-PortiaTotal_P_                Funds with Risk Type "GSB" must have a Portfolio_Naam starting with "PF"
                                                                                 nl rule condition                    Feedback      rule_load_date      source_file
290 Fondsen met Risk Type "GSB" moeten een Portfolio_Naam hebben beginnend met "PF"                Regel ook valideren met FRM 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                query superset_query
290 \r\nSELECT DISTINCT\r\n\r\n prfid, \r\n\t*\r\nFROM\r\n\tvx_PO_portfolio\r\nWHERE\r\n\tRiskType = 'GSB'\r\n\tAND LEFT(PORTFOLIO_NAME, 2) NOT IN ('PF')               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
291 BU Delta Lloyd Asset Management Portia PO_0146    holding HasValue       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements                               datasource referencedata                         en                            nl rule condition
291               <NA>   Trade Date RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Trade Date cannot be empty Trade Date mag niet leeg zijn               
    Feedback      rule_load_date      source_file                                                                                                              query
291          2016-04-26 16:05:43 portia_rules.csv SELECT  DISTINCT\r\n\t*\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tTradeDate IS NULL\r\n\tOR ISNULL(TradeDate, '') = '' 
    superset_query
291               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
292 BU Delta Lloyd Asset Management Portia PO_0147    holding ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements                               datasource referencedata                                                                  en
292               <NA>   Trade Date RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                Trade Date must have a current date or a date that lies in the past
                                                                                   nl rule condition Feedback      rule_load_date      source_file
292 Trade Date moet de datum van vandaag hebben of een datum dat in het verleden ligt                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                          query superset_query
292 \r\n\r\nSELECT DISTINCT\r\n\tinsid,\r\n\tTradeDate,\r\n\tsource_date,\r\n\r\n\t*\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tTradeDate > source_date               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
293 BU Delta Lloyd Asset Management Portia PO_0148 instrument HasValue       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements                               datasource referencedata                        en                           nl rule condition
293               <NA>    UNIT SIZE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                UNIT SIZE cannot be empty UNIT SIZE mag niet leeg zijn               
    Feedback      rule_load_date      source_file                                                                                                                query
293          2016-04-26 16:05:43 portia_rules.csv \r\n\r\nSELECT  DISTINCT\r\n   insid,\r\n\tUNITSIZE\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tISNULL(UNITSIZE, '') = '' 
    superset_query
293               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
294 BU Delta Lloyd Asset Management Portia PO_0149 instrument ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements                               datasource referencedata                                                    en
294               <NA>    UNIT SIZE RM-PortiaTotal_P_  ,  DM-SecsHLD Portia                UNIT SIZE must always be greater than or equal to "0"
                                                     nl rule condition Feedback      rule_load_date      source_file
294 UNIT SIZE moet altijd groter of gelijk aan "0" zijn                         2016-04-26 16:05:43 portia_rules.csv
                                                                          query superset_query
294 SELECT  DISTINCT\r\n\t*\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tUNITSIZE < 0                
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
295 BU Delta Lloyd Asset Management Portia PO_0150 instrument HasValue       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate    dataelements         datasource referencedata                              en                                 nl rule condition Feedback
295               <NA> DLAMAssetClass1 RM-PortiaTotal_P_                DLAMAssetClass1 cannot be empty DLAMAssetClass1 mag niet leeg zijn                        
         rule_load_date      source_file                                                                                query superset_query
295 2016-04-26 16:05:43 portia_rules.csv SELECT  DISTINCT\r\n\t*\r\nFROM\r\n\tVX_PO_instrument\r\nWHERE DLAMAssetClass1 IS NULL               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
296 BU Delta Lloyd Asset Management Portia PO_0151 instrument ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate    dataelements         datasource referencedata                                      en
296               <NA> DLAMAssetClass1 RM-PortiaTotal_P_                DLAMAssetClass1 matches Asset Type Tree
                                                           nl rule condition Feedback      rule_load_date      source_file
296 DLAMAssetClass1 dient voor te komen in de Asset Type Tree                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                     query
296 SELECT  DISTINCT\r\n\t*\r\nFROM\r\n\tVX_PO_instrument\r\nWHERE \r\n\tDLAMAssetClass1  NOT IN (SELECT DISTINCT DLAMAssetClass1 FROM valuerange_assetclass)
    superset_query
296               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
297 BU Delta Lloyd Asset Management Portia PO_0152 instrument SelfConsistent       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                                                                            en
297               <NA>       Listed RM-PortiaTotal_P_                If Listed is equal to "Nee", then Exchange must be empty or filled with "-"  
                                                                                   nl rule condition Feedback      rule_load_date      source_file
297 Indien Listed gelijk is aan "Nee", dan moet Exchange leeg of gevuld zijn met "-"                          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                             query
297 \r\nSELECT DISTINCT\r\n\tinsid,  Exchange, Listed\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tListed = 0 AND NOT ISNULL(Exchange,'-') = '-' -- zie external data config portia  
    superset_query
297               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
298 BU Delta Lloyd Asset Management Portia PO_0153 instrument ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                                       en                                        nl rule condition
298               <NA>       Listed RM-PortiaTotal_P_                Listed must be filled with "Ja" of "Nee" Listed moet gevuld zijn met "Ja" of "Nee"               
    Feedback      rule_load_date      source_file
298          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                        query
298 SELECT DISTINCT\r\n\tinsid, IDENTIFIER, Description,  Listed, Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tListed NOT IN (0,1) -- zie external data config portia  
    superset_query
298               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
299 BU Delta Lloyd Asset Management Portia PO_0154 instrument ValidRange       NEED      Input       2015-10-22 Data Management Ronald Bark   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                                                                                      en
299               <NA>       Listed RM-PortiaTotal_P_                If Listed is equal to "Ja", then Exchange must have a value with the exception of "-"  
                                                                                                nl rule condition Feedback      rule_load_date      source_file
299 Indien Listed gelijk is aan "Ja", dan moet Exchange een waarde hebben met uitzondering van "-"                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                    query
299 SELECT DISTINCT\r\n\tinsid, IDENTIFIER, Description,  Listed, Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tListed = 1  -- zie external data config portia\r\n\tAND ISNULL(Exchange, '-') = '-'  
    superset_query
299               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
300 BU Delta Lloyd Asset Management Portia PO_0155 instrument SelfConsistent       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                                                               en
300               <NA>       Listed RM-PortiaTotal_P_                If Listed is equal to "Ja", then DLAMAssetClass3 cannot be "LOS"
                                                                           nl rule condition Feedback      rule_load_date      source_file
300 Indien Listed gelijk is aan "Ja", dan mag DLAMAssetClass3 geen "LOS" zijn                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                              query
300 SELECT DISTINCT\r\n\tinsid, IDENTIFIER, Description,  Listed, Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tListed = 1  -- zie external data config portia\r\n\tAND DLAMAssetClass3 = 'LOS'
    superset_query
300               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
301 BU Delta Lloyd Asset Management Portia PO_0156 instrument HasValue       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                         en                              nl rule condition Feedback
301               <NA>     Exchange RM-PortiaTotal_P_                Exchange must have a value Exchange moet een waarde hebben                        
         rule_load_date      source_file
301 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                  query superset_query
301 \r\n\r\nSELECT DISTINCT\r\n\tinsid, IDENTIFIER, Description,   Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tISNULL(ltrim(Exchange), '') = ''                
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
302 BU Delta Lloyd Asset Management Portia PO_0157 instrument ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                                                                                                 en
302               <NA>     Exchange RM-PortiaTotal_P_                Exchange must be filled with "-" or consist out of capital letters which is 2 or 3 characters long
                                                                                          nl rule condition Feedback      rule_load_date      source_file
302 Exchange moet gevuld zijn met "-" of uit hoofdletters bestaan dat 2 tot 3 tekens lang is                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                   query
302 \r\nSELECT DISTINCT\r\n\tinsid, IDENTIFIER, Description,  Listed, Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tExchange != '-'\r\n\tAND (Exchange != UPPER(Exchange)\r\n\t\tOR (NOT (Exchange LIKE '[a-Z][a-Z][a-Z]' OR Exchange LIKE '[a-Z][a-Z]')))\r\n\r\n\r\n
    superset_query
302               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
303 BU Delta Lloyd Asset Management Portia PO_0158 instrument ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                              en                                 nl rule condition Feedback
303               <NA>     Exchange RM-PortiaTotal_P_                Exchange test on current values Exchange testen op huidige waarden                        
         rule_load_date      source_file
303 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           query
303 SELECT DISTINCT\r\n\tinsid, IDENTIFIER, Description,  Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tExchange NOT IN ('-',\r\n'FP',\r\n'GF',\r\n'AT',\r\n'AV',\r\n'LX',\r\n'SS',\r\n'FH',\r\n'GB',\r\n'SGX',\r\n'NZ',\r\n'KS',\r\n'GH',\r\n'BC',\r\n'MM',\r\n'DC',\r\n'HB',\r\n'MC',\r\n'ICF',\r\n'KP',\r\n'TT',\r\n'TE',\r\n'LI',\r\n'AU',\r\n'GR',\r\n'MSE',\r\n'SM',\r\n'SP',\r\n'TI',\r\n'SE',\r\n'GU',\r\n'BB',\r\n'CI',\r\n'SO',\r\n'HK',\r\n'RO',\r\n'GY',\r\n'VX',\r\n'TB',\r\n'GS',\r\n'SW',\r\n'SB',\r\n'ID',\r\n'IM',\r\n'PL',\r\n'UN',\r\n'EUX',\r\n'SN',\r\n'US',\r\n'BZ',\r\n'LIF',\r\n'PW',\r\n'SJ',\r\n'GM',\r\n'PM',\r\n'LN',\r\n'SK',\r\n'JP',\r\n'NO',\r\n'KN',\r\n'FM',\r\n'HM',\r\n'GD',\r\n'NA',\r\n'GI',\r\n'CN')
    superset_query
303               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
304 BU Delta Lloyd Asset Management Portia PO_0159 instrument SelfConsistent       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate    dataelements         datasource referencedata                                                 en
304               <NA> SecDescription2 RM-PortiaTotal_P_                SecDescription2 can only be assigned to 1 Exchange
                                                            nl rule condition Feedback      rule_load_date      source_file
304 SecDescription2 mag maar aan ��n Exchange worden toegekend                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                query
304 \r\nSELECT  DISTINCT\r\n\tinsid, IDENTIFIER, Description,  SecDescription2, Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tSecDescription2 IN (\r\nSELECT DISTINCT\r\n\tSecDescription2\r\nFROM\r\n\tvx_PO_instrument\r\nGROUP BY SecDescription2\r\nHAVING COUNT(Distinct Exchange) > 1 AND SecDescription2 NOT IN (' ', '-'))
    superset_query
304               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
305 BU Delta Lloyd Asset Management Portia PO_0160 instrument ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata
305               <NA>    Exchange  RM-PortiaTotal_P_               
                                                                                                                         en
305 If Exchange consists out of 3 characters, then DLAMAssetClass2 must be "Fixed Income Derivative" or "Equity Derivative"
                                                                                                                       nl rule condition Feedback      rule_load_date
305 Indien Exchange uit 3 tekens bestaat, dan moet DLAMAssetsClass2 "Fixed Income Derivative" of "Equity Derivative" zijn                         2016-04-26 16:05:43
         source_file
305 portia_rules.csv
                                                                                                                                                                                                                                query
305 \r\nSELECT DISTINCT\r\n\tinsid, IDENTIFIER, Description,  DLAMAssetClass2, Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tlen(Exchange) = 3 AND DLAMAssetClass2 NOT  IN ('Fixed Income Derivative', 'Equity Derivative')\r\n\t
    superset_query
305               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
306 BU Delta Lloyd Asset Management Portia PO_0161 instrument ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                                                                                 en
306               <NA>    Exchange  RM-PortiaTotal_P_                If Exchange has a value with the exception "-", then Listed must be equal to "Ja" 
                                                                                                  nl rule condition Feedback      rule_load_date      source_file
306 Indien Exchange een waarde heeft met uitzondering van "-", dan moet Listed gelijk zijn aan "Ja"                          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                     query
306 \r\nSELECT DISTINCT\r\n\tinsid, IDENTIFIER, Description,  Listed, Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tISNULL(Exchange, '-') != '-' \r\n\tAND Listed != 1
    superset_query
306               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
307 BU Delta Lloyd Asset Management Portia PO_0162 instrument ValidRange       NEED      Input       2015-10-22 Data Management Ronald Bark   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                                                                          en
307               <NA>    Exchange  RM-PortiaTotal_P_                If Exchange is empty or filled with "-", then Listed must be equal to "Nee"
                                                                                  nl rule condition Feedback      rule_load_date      source_file
307 Indien Exchange leeg of gevuld is met "-", dan moet Listed gelijk zijn aan "Nee"                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                               query
307 \r\nSELECT DISTINCT\r\n\tinsid, IDENTIFIER, Description,  Listed, Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\t(ISNULL(Exchange, '- ') = '-' OR ltrim(Exchange) = '' )\r\n\tAND Listed != 0
    superset_query
307               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
308 BU Delta Lloyd Asset Management Portia PO_0163 instrument HasValue       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                          en                             nl rule condition Feedback
308               <NA>  Description RM-PortiaTotal_P_                Description cannot be empty Description mag niet leeg zijn                        
         rule_load_date      source_file
308 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                       query
308 \r\nSELECT DISTINCT\r\n\tinsid, IDENTIFIER, Description,  Listed, Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tISNULL(ltrim(Description), '') = ''
    superset_query
308               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
309 BU Delta Lloyd Asset Management Portia PO_0164 instrument ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate    dataelements         datasource referencedata
309               <NA> SecDescription2 RM-PortiaTotal_P_               
                                                                                                                                                                                                               en
309 If SecDescription2 ends with "Corp", "Govt", "Mtge" or "Pfd", then the format of SecDescription2 must be as follows: 12 characters followed by 1 spacing and end with either "Corp", "Govt", "Mtge" or "Pfd" 
                                                                                                                                                                                                         nl
309 Indien SecDescription2 eindigt met "Corp", "Govt", "Mtge" of "Pfd", dan is de opmaak van SecDescription2 als volgt: 12 tekens gevolgd door ��n spatie en eindigend met "Corp", "Govt", "Mtge" of "Pfd" 
    rule condition Feedback      rule_load_date      source_file
309                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                     query
309 \r\nSELECT DISTINCT\r\n\tinsid, IDENTIFIER, SecDescription2, len(SecDescription2) AS LenSecDescription2\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\t((SecDescription2 like '% Corp'\r\n\tOR SecDescription2 like '% Govt'\r\n\tOR SecDescription2 like '% Mtge'\r\n\t) AND len(SecDescription2) != (12+1+4))\r\n\tOR (SecDescription2 like '% Pfd' AND len(SecDescription2) != (12+1+3))\r\n
    superset_query
309               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
310 BU Delta Lloyd Asset Management Portia PO_0165 instrument ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate    dataelements         datasource referencedata                                              en
310               <NA> SecDescription2 RM-PortiaTotal_P_                SecDescription2 cannot contain a double spacing
                                                   nl rule condition Feedback      rule_load_date      source_file
310 SecDescription2 mag geen dubbele spaties bevatten                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                 query
310 \r\nSELECT DISTINCT\r\n\tinsid, IDENTIFIER, SecDescription2, len(SecDescription2) AS LengthSecDescription2\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tSecDescription2 like '%  %' --2 spaties!\r\n\t
    superset_query
310               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
311 BU Delta Lloyd Asset Management Portia PO_0166    holding SelfConsistent       NEED      Input       2015-10-25 Mid Office Kristine Prahl   2015-10-26
    resultApprovalDate dataelements         datasource referencedata                                                                                en
311               <NA>     Position RM-PortiaTotal_P_                If Position is filled with "L", then QUANTITY should be equal or greater then "1"
                                                                                nl rule condition Feedback      rule_load_date      source_file
311 Indien positie gevuld is met 'L' dan moet quantity groter of gelijk zijn dan 1                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                    query
311 \r\nSELECT DISTINCT\r\n\tinsid,\r\n\tprfid,\r\n\tQUANTITY,\r\n\tPosition\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tQuantity < 1  \r\n\tAND ISNULL(Position,'') = ('L')\r\n\tAND Quantity <> 0 
    superset_query
311               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
312 BU Delta Lloyd Asset Management Portia PO_0167    holding SelfConsistent       NEED      Input       2015-10-25 Mid Office Kristine Prahl   2015-10-26
    resultApprovalDate dataelements         datasource referencedata                                                                            en
312               <NA>     Position RM-PortiaTotal_P_                If Position is filled with "S", then QUANTITY should be less or equal to "-1"
                                                                                      nl rule condition Feedback      rule_load_date      source_file
312 Indien positie gevuld is met 'S' dan moet quantity kleiner zijn dan of gelijk aan -1                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                     query
312 \r\nSELECT DISTINCT\r\n\tprfid, insid, Position, QUANTITY\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tISNULL(Position, '') = 'S'\r\n\tAND Quantity > -1\r\n\tAND Quantity <> 0
    superset_query
312               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
313 BU Delta Lloyd Asset Management Portia PO_0168 instrument ValidRange       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate    dataelements         datasource referencedata
313               <NA> SecDescription2 RM-PortiaTotal_P_               
                                                                                                                                                       en
313 If SecDescription2 has a value, then SecDescription2 must end with 1 spacing followed by "Corp", "Govt", "Mtge", "Pfd", "Index", "Equity" or "Comdty"
                                                                                                                                                                        nl
313 Indien SecDescription2 een waarde heeft, dan dient SecDesription2 te eindigen met ��n spatie gevolgd door "Corp", "Govt", "Mtge", "Pfd", "Index", "Equity" of "Comdty"
    rule condition Feedback      rule_load_date      source_file
313                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                query
313 --PO_0168_instrument_ValidRange_If SecDescription2 has a value then SecDescription2 must end with 1 spacing followed by Corp Govt Mtge Pfd Index Equity or Comdty\r\n\r\n\r\nSELECT DISTINCT\r\n\tSecuritynaam as insid, \r\n\tPortfolioNaam,  \r\n\tSecDescription2\r\nFROM\r\n\tPO_portiatotal\r\nWHERE\r\n\tISNULL(SecDescription2, '-') != '-'  --empty string = value?\r\n\tAND NOT (SecDescription2 LIKE '% Corp'\r\n\t\t\tOR SecDescription2 LIKE '% Govt' \r\n\t\t\tOR SecDescription2 LIKE '% Mtge' \r\n\t\t\tOR SecDescription2 LIKE '% Pfd' \r\n\t\t\tOR SecDescription2 LIKE '% Index' \r\n\t\t\tOR SecDescription2 LIKE '% Equity' \r\n\t\t\tOR SecDescription2 LIKE '% Comdty')\r\n\t\t\torder by Securitynaam
    superset_query
313               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate resultApprovalDate
314 BU Delta Lloyd Asset Management Portia PO_0169    holding HasValue       NEED      Input       2015-10-25 Accounting Akke Velzeboer   2015-10-26               <NA>
     dataelements         datasource referencedata                            en                               nl rule condition Feedback      rule_load_date
314 Purchase Cost RM-PortiaTotal_P_                Purchase Cost cannot be empty Purchase Cost mag niet leeg zijn                         2016-04-26 16:05:43
         source_file
314 portia_rules.csv
                                                                                                                                                                      query
314 --PO_0169_holding_HasValue_Purchase Cost cannot be empty\r\nSELECT DISTINCT\r\n\tinsid, prfid,  PurchaseCost\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tPurchaseCost IS NULL
    superset_query
314               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate  ruleOwner     approvedBy approvedDate
315 BU Delta Lloyd Asset Management Portia PO_0170    holding SelfConsistent       NEED      Input       2015-10-25 Accounting Akke Velzeboer   2015-10-26
    resultApprovalDate  dataelements         datasource referencedata                                                                      en
315               <NA> Purchase Cost RM-PortiaTotal_P_                If Quantity is equal to "0", then Purchase Cost must have the value "0"
                                                                                      nl rule condition Feedback      rule_load_date      source_file
315 Indien Quantity gelijk is aan "0", dan mag Purchase Cost alleen de waarde "0" hebben                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                    query
315 --PO_0170_holding_SelfConsistent_If Quantity is equal to 0 then Purchase Cost must have the value 0\r\nSELECT DISTINCT\r\n\tinsid, prfid, QUANTITY, purchaseCost, c.PORTFOLIO\r\nFROM\r\n\tvx_PO_holding h\r\n\tINNER JOIN PO_CEDAR c  --rule only applies to portfolios which go to CEDAR\r\n\t\tON h.PORTFOLIO_NAME = c.PORTFOLIO\r\nWHERE\r\n\tQuantity = 0 \r\n\tAND purchaseCost != 0\r\nORDER BY prfid
    superset_query
315               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
316 BU Delta Lloyd Asset Management Portia PO_0176 instrument SelfConsistent       NEED      Input       2015-10-26 Data Management Ronald Bark   2015-10-27
    resultApprovalDate  dataelements         datasource referencedata                                                                    en
316               <NA> Underlying BB RM-PortiaTotal_P_                If UNDERLYING has a value, then Underlying BB must have value as well
                                                                                  nl rule condition Feedback      rule_load_date      source_file
316 Indien UNDERLYING een waarde heeft, dan moet Underlying BB ook een waarde hebben                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                              query
316 --PO_0176_instrument_SelfConsistent_If UNDERLYING has a value then Underlying BB must have value as well\r\nSELECT DISTINCT\r\n\tinsid, IDENTIFIER, underlying, underlyingbb\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE\r\n\t(ISNULL(UNDERLYING, '') != '' \r\n\tAND ISNULL(UNDERLYINGBB, '') = '') \r\n\tOR\r\n\t(ISNULL(UNDERLYING, '') = '' \r\n\tAND ISNULL(UNDERLYINGBB, '') != '')  
    superset_query
316               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner  approvedBy approvedDate
317 BU Delta Lloyd Asset Management Portia PO_0177 instrument SelfConsistent       NEED      Input       2015-10-26 Data Management Ronald Bark   2015-10-27
    resultApprovalDate  dataelements         datasource referencedata
317               <NA> Underlying BB RM-PortiaTotal_P_               
                                                                                                                     en
317 If DLAMAssetClass2 is equal to "Equity Derivative" or "Fixed Income Derivative", then Underlying BB cannot be empty
                                                                                                                                                                           nl
317 Indien DLAMAssetClass2 gelijk is aan "Equity Derivative" of "Fixed Income Derivative" tenzij DLAMAssetClass3 is gelijk aan 'Right', dan mag Underlying BB niet leeg zijn"
    rule condition Feedback      rule_load_date      source_file
317                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               query
317 --PO_0177_instrument_SelfConsistent_If DLAMAssetClass2 is equal to Equity Derivative or Fixed Income Derivative and DLAMAssetClass3 not equal to Right then Underlying BB cannot be empty\r\nSELECT DISTINCT\r\n\tinsid, identifier, DLAMAssetClass2, DLAMAssetClass3, underlying, UNDERLYINGbb\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE\r\n\t(DLAMAssetClass2 IN ('Equity Derivative', 'Fixed Income Derivative')\r\n\t\tAND DLAMAssetClass3 NOT IN ('Right')) \r\n\tAND ISNULL(UNDERLYINGBB, '') = '' 
    superset_query
317               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
318 BU Delta Lloyd Asset Management Portia PO_0178 instrument SelfConsistent       NEED      Input       2015-10-26 Data Management Sander van Laarhoven   2015-10-27
    resultApprovalDate  dataelements         datasource referencedata
318               <NA> Underlying BB RM-PortiaTotal_P_               
                                                                                                                                                             en
318 If DLAMAssetClass2 is not equal to "Equity Derivative" or "Fixed Income Derivative" tenzij DLAMAssetClass3 equqls 'Right', then Underlying BB must be empty
                                                                                                                                                                          nl
318 Indien DLAMAssetClass2 ongelijk is aan "Equity Derivative" of "Fixed Income Derivative", tenzij DLAMAassetClass3 is gelijk aan 'Right', dan moet Underlying BB leeg zijn
    rule condition Feedback      rule_load_date      source_file
318                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  query
318 --PO_0178_instrument_SelfConsistent_If DLAMAssetClass2 is not equal to Equity Derivative or Fixed Income Derivative or DLAMAssetClass3 is equal to Right then Underlying BB must be empty\r\nSELECT DISTINCT\r\n\tinsid, identifier, DLAMAssetClass2, DLAMAssetClass3, UNDERLYINGbb\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE\r\n\t(DLAMAssetClass2 NOT IN ('Equity Derivative', 'Fixed Income Derivative') OR DLAMAssetClass3 = 'Right')\r\n\tAND ISNULL(ltrim(UNDERLYINGBB), '') != ''  
    superset_query
318               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate       ruleOwner           approvedBy approvedDate
319 BU Delta Lloyd Asset Management Portia PO_0179 instrument HasValue       NEED      Input       2015-10-22 Data Management Sander van Laarhoven   2015-10-23
    resultApprovalDate dataelements         datasource referencedata                     en                        nl rule                             condition
319               <NA>       Listed RM-PortiaTotal_P_                Listed cannot be empty Listed mag niet leeg zijn      All instruments where Listed = NULL()
    Feedback      rule_load_date      source_file
319          2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                  query
319 SELECT DISTINCT\r\n\tinsid, IDENTIFIER, Description,  Listed, Exchange\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE \r\n\tListed = NULL -- zie external data config portia  
    superset_query
319               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate              ruleOwner approvedBy approvedDate
320 BU Delta Lloyd Asset Management Portia PO_0180 instrument HasValue       NEED      Input       2015-10-26 Information Management  Tom Bosch   2015-10-27
    resultApprovalDate dataelements         datasource referencedata                       en                          nl rule condition Feedback      rule_load_date
320               <NA>     Duration RM-PortiaTotal_P_                Duration cannot be empty Duration mag niet leeg zijn                         2016-04-26 16:05:43
         source_file
320 portia_rules.csv
                                                                                                                                                                                 query
320 --PO_0180_instrument_HasValue_Duration cannot be empty\r\n\r\nSELECT DISTINCT\r\n\tinsid, \r\n\tidentifier,\r\n\tduration\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE\r\n\tDuration IS NULL 
    superset_query
320               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate              ruleOwner approvedBy approvedDate
321 BU Delta Lloyd Asset Management Portia PO_0181 instrument ValidRange       NEED      Input       2015-10-26 Information Management  Tom Bosch   2015-10-27
    resultApprovalDate dataelements         datasource referencedata                                       en                                              nl rule
321               <NA>     Duration RM-PortiaTotal_P_                Duration can only have a numerical value Duration mag alleen een numerieke waarde hebben     
    condition Feedback      rule_load_date      source_file
321                    2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                               query
321 --PO_0181_instrument_ValidRange_Duration can only have a numerical value\r\n\r\n\r\nSELECT DISTINCT\r\n\tinsid, \r\n\tidentifier,\r\n\tduration\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE\r\n\tISNUMERIC(Duration) <> 1 
    superset_query
321               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate              ruleOwner           approvedBy
322 BU Delta Lloyd Asset Management Portia PO_0182 instrument SelfConsistent       NEED      Input       2015-10-26 Information Management Sander van Laarhoven
    approvedDate resultApprovalDate dataelements         datasource referencedata
322   2015-10-27               <NA>     Duration RM-PortiaTotal_P_               
                                                                                                             en
322 If DLAMAssetClass2 equals to "LIC" or DLAMAssetsClass3 equals to "LOS", then Duration does not equal to "0"
                                                                                                                               nl rule condition Feedback
322 Indien DLAMAssetClass2 gelijk is aan "LIC" of DLAMAssetsClass3 gelijk is aan "LOS", dan mag Duration niet gelijk zijn aan "0"                        
         rule_load_date      source_file
322 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                         query
322 --PO_0182_instrument_SelfConsistent_If DLAMAssetClass2 equals to LIC or DLAMAssetsClass3 equals to LOS then Duration does not equal to 0\r\n\r\nSELECT DISTINCT\r\n\tinsid,\r\n\tIDENTIFIER,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tDuration\r\nFROM\t\r\n\tvx_PO_instrument\r\nWHERE\r\n\t(DLAMAssetClass2 = 'LIC'\r\n\tOR DLAMAssetClass3 = 'LOS')\r\n\tAND Duration = 0
    superset_query
322               
                                 BU system      BR entitytype          Depth Importance ErrorCause modificationDate              ruleOwner           approvedBy
323 BU Delta Lloyd Asset Management Portia PO_0183 instrument SelfConsistent       NEED      Input       2015-10-26 Information Management Sander van Laarhoven
    approvedDate resultApprovalDate dataelements         datasource referencedata
323   2015-10-27               <NA>     Duration RM-PortiaTotal_P_               
                                                                                                                            en
323 If DLAMAssetClass2 does not equal to "LIC" or DLAMAssetsClass3 does not equal to "LOS", then Duration must be equal to "0"
                                                                                                                               nl rule condition Feedback
323 Indien DLAMAssetClass2 ongelijk is aan "LIC" of DLAMAssetsClass3 ongelijk is aan "LOS", dan moet Duration gelijk zijn aan "0"                        
         rule_load_date      source_file
323 2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                              query
323 --PO_0183_instrument_SelfConsistent_If DLAMAssetClass2 does not equal to LIC or DLAMAssetsClass3 does not equal to LOS then Duration must be equal to 0\r\n\r\nSELECT DISTINCT\r\n\tinsid,\r\n\tIDENTIFIER,\r\n\tDLAMAssetClass2,\r\n\tDLAMAssetClass3,\r\n\tDuration\r\nFROM\r\n\tvx_PO_instrument\r\nWHERE\r\n\tNOT (DLAMAssetClass2 = 'LIC' OR \r\n\t\tDLAMAssetClass3 = 'LOS')\r\n\tAND Duration != 0
    superset_query
323               
                                 BU system      BR entitytype    Depth Importance ErrorCause modificationDate              ruleOwner approvedBy approvedDate
324 BU Delta Lloyd Asset Management Portia PO_0184 instrument HasValue       NEED      Input       2015-10-26 Information Management  Tom Bosch   2015-10-27
    resultApprovalDate          dataelements         datasource referencedata                                    en                                       nl rule
324               <NA> Acrued Interest (Eur) RM-PortiaTotal_P_                Acrued Interest (Eur) cannot be empty Acrued Interest (Eur) mag niet leeg zijn     
    condition Feedback      rule_load_date      source_file
324                    2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                               query
324 --PO_0184_holding_HasValue_Acrued Interest Eur cannot be empty\r\n\r\nSELECT DISTINCT\r\n\t*\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tAcruedInterestEur IS NULL\r\n
    superset_query
324               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate              ruleOwner approvedBy approvedDate
325 BU Delta Lloyd Asset Management Portia PO_0185 instrument ValidRange       NEED      Input       2015-10-26 Information Management  Tom Bosch   2015-10-27
    resultApprovalDate          dataelements         datasource referencedata                                                    en
325               <NA> Acrued Interest (Eur) RM-PortiaTotal_P_                Acrued Interest (Eur) can only have a numerical value
                                                              nl rule condition Feedback      rule_load_date      source_file
325 Acrued Interest (Eur) mag alleen een numerieke waarde hebben                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     query
325 /*\r\n\r\nPO_0185_holding_ValidRange_Acrued Interest Eur can only have a numerical value\r\n*/\r\n\r\n\r\n\r\nSELECT DISTINCT\r\n\tinsid,\r\n\tPortfolioNaam,\r\n\tAcruedInterestEur\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tISNUMERIC(AcruedInterestEur) <> 1\r\n\r\n\t/*\r\n\tTake the following into account?  ISNUMERIC returns 1 for some characters that are not numbers, \r\n\tsuch as plus (+), minus (-), and valid currency symbols such as \r\n\tthe dollar sign ($). For a complete list of currency symbols, \r\n\tsee money and smallmoney (Transact-SQL).*/\r\n 
    superset_query
325               
                                 BU system      BR entitytype      Depth Importance ErrorCause modificationDate  ruleOwner              approvedBy approvedDate
326 BU Delta Lloyd Asset Management Portia PO_0186    holding ValidRange       NEED      input       2015-10-28 Mid Office Esther De Melo Joaquim    2015-10-28
    resultApprovalDate dataelements         datasource referencedata
326               <NA>    CUSTODIAN RM-PortiaTotal_P_               
                                                                                                                                                                                                                                                                                                                                                               en
326 Custodian must have one of the following values:  "AAM NL (DOM)", "AAM NL (EUR)", "BNP (CED)", "BNP PARIB (DOM)", "BNP PARIB (EUR)", "CACEIS (CED)", "CACEIS (DOM)", "EFA LX (CED)", "EFA LX (DOM)", "KAS NL (CED)", "KAS NL (DOM)", "KAS NL (EUR)", "KAS NL (REG)", "RBC (CED)", "RBC (DOM)", "REGISTER EXTERN", "REGISTER INTERN", 'zNederland' or "zBELGIE
                                                                                                                                                                                                                                                                                                                                                                    nl
326 Custodian dient ��n van de volgende waarden te hebben: "AAM NL (DOM)", "AAM NL (EUR)", "BNP (CED)", "BNP PARIB (DOM)", "BNP PARIB (EUR)", "CACEIS (CED)", "CACEIS (DOM)", "EFA LX (CED)", "EFA LX (DOM)", "KAS NL (CED)", "KAS NL (DOM)", "KAS NL (EUR)", "KAS NL (REG)", "RBC (CED)", "RBC (DOM)", "REGISTER EXTERN", "REGISTER INTERN", 'zNederland' of "zBELGIE
    rule condition Feedback      rule_load_date      source_file
326                         2016-04-26 16:05:43 portia_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   query
326 SELECT DISTINCT\r\n\tprfid, insid, CUSTODIAN\r\nFROM\r\n\tvx_PO_holding\r\nWHERE\r\n\tCUSTODIAN NOT IN ('BNP (CED)', \r\n\t'AAM NL (DOM)',\r\n'AAM NL (EUR)',\r\n'BNP PARIB (DOM)',\r\n'BNP PARIB (EUR)',\r\n'CACEIS (CED)',\r\n'CACEIS (DOM)',\r\n'EFA LX (CED)',\r\n'EFA LX (DOM)',\r\n'KAS NL (CED)',\r\n'KAS NL (DOM)',\r\n'KAS NL (EUR)',\r\n'KAS NL (REG)',\r\n'RBC (CED)',\r\n'RBC (DOM)',\r\n'REGISTER EXTERN',\r\n'REGISTER INTERN',\r\n'zBELGIE',\r\n'zNederland'\r\n)\r\n\t\r\n\r\n\r\n       
    superset_query
326               
                                 BU system       BR entitytype      Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
327 BU Delta Lloyd Asset Management    VIS VIS_0001 instrument ValidRange       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate dataelements                    datasource referencedata                                    en                                             nl
327               <NA>   IDENTIFIER DL Direct Property 01/31/2015          <NA> InstrumentIdentifier should be unique De naam van een instrument dient uniek te zijn
                                          rule                                  condition Feedback      rule_load_date   source_file
327 All instruments should have a unique value All instruments sharing an instrument name     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          query
327 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: Each Identifier should be unique \r\n**************************************************************************/\r\n\r\nSELECT\r\n\tXLS.IDENTIFIER as insid ,\r\n\tXLS.PORTFOLIO_NAME as prfid,\r\n\tXLS.IDENTIFIER,\r\n\tID.Count,\r\n\tXLS.BUSINESS_UNITS,\r\n\tXLS.MARKET_VALUE\r\nFROM\r\n\t(SELECT  UPPER(IDENTIFIER) as IDENTIFIER\r\n\t\t\t,COUNT(*)\t\t\t\tAS [Count]  \r\n\tFROM  [VIS_DL_Direct_Property]\r\n\tGROUP BY UPPER(IDENTIFIER)\r\n\tHAVING COUNT(*) > 1) ID\r\n\tLEFT JOIN [VIS_DL_Direct_Property] XLS\r\n\t\tON UPPER(XLS.IDENTIFIER) = ID.IDENTIFIER\r\nORDER BY XLS.IDENTIFIER
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          superset_query
327 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: Each Identifier should be unique \r\n**************************************************************************/\r\n\r\nSELECT\r\n\tXLS.IDENTIFIER as insid ,\r\n\tXLS.PORTFOLIO_NAME as prfid,\r\n\tXLS.IDENTIFIER,\r\n\tID.Count,\r\n\tXLS.BUSINESS_UNITS,\r\n\tXLS.MARKET_VALUE\r\nFROM\r\n\t(SELECT  UPPER(IDENTIFIER) as IDENTIFIER\r\n\t\t\t,COUNT(*)\t\t\t\tAS [Count]  \r\n\tFROM  [SourceData].[dbo].[VIS_DL_Direct_Property]\r\n\tGROUP BY UPPER(IDENTIFIER)\r\n\tHAVING COUNT(*) > 1) ID\r\n\tLEFT JOIN [SourceData].[dbo].[VIS_DL_Direct_Property] XLS\r\n\t\tON UPPER(XLS.IDENTIFIER) = ID.IDENTIFIER\r\nORDER BY XLS.IDENTIFIER \r
                                 BU system       BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
328 BU Delta Lloyd Asset Management    VIS VIS_0002 instrument SelfConsistent       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate         dataelements                    datasource referencedata                                                          en
328               <NA> IDENTIFIER, SECURITY DL Direct Property 01/31/2015          <NA> For all instruments identifier and security should be equal
                                                                     nl                                                        rule
328 De identifier en security dienen gelijk te zijn voor een instrument For all instruments identifier and security should be equal
                                                  condition Feedback      rule_load_date   source_file
328 Instruments where identifier and security are not equal     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          query
328 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: Identifier and Security should be equal\r\n**************************************************************************/\r\n\r\nSELECT DISTINCT \r\n\t\tIDENTIFIER as insid,\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\tPORTFOLIO_NAME as prfid,\r\n\t\t[Security],\r\n    IDENTIFIER,\r\n\t[Security]\r\nFROM [VIS_DL_Direct_Property]\r\nWHERE \r\n\tISNULL(IDENTIFIER, 'NO VALUE ID') != ISNULL([Security], 'NO VALUE SEC')\r\n\tOR ISNULL(IDENTIFIER, 'NO VALUE ID') != ISNULL([DESCRIPTION], 'NO VALUE DESC')\r\n
    superset_query
328               
                                 BU system       BR entitytype      Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
329 BU Delta Lloyd Asset Management    VIS VIS_0003 instrument ValidRange       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate dataelements                    datasource referencedata                              en                            nl
329               <NA>     CURRENCY DL Direct Property 01/31/2015          <NA> All currencies should be in EUR Alle valuta's moeten EUR zijn
                            rule                                      condition Feedback      rule_load_date   source_file
329 All currencies should be EUR Instruments where currency is not equal to EUR     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                          query
329 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: All values should be in Euro's\r\n**************************************************************************/\r\n\r\nSELECT  DISTINCT\r\n\t\tIDENTIFIER as insid,\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\tPORTFOLIO_NAME as prfid,\r\n\t      CURRENCY,\r\n        FXRATE\r\nFROM [VIS_DL_Direct_Property]\r\nWHERE ISNULL(CURRENCY, 'NP VALUE') != 'EUR'\r\n
    superset_query
329               
                                 BU system       BR entitytype      Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
330 BU Delta Lloyd Asset Management    VIS VIS_0004 instrument ValidRange       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate dataelements                    datasource referencedata                      en                                          nl
330               <NA>       FXRATE DL Direct Property 01/31/2015          <NA> All fxrates should be 1 Alle wisselkoersen moeten gelijk aan 1 zijn
                                                                rule                                  condition Feedback      rule_load_date   source_file
330 All fxrates should be equal to 1 because all currencies are EUR. Instruments where fxrate is not equal to 1     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    query
330 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: When currency is Euro fxrate should be 1\r\n**************************************************************************/\r\n--No check on CURRENCY = 'EUR' needed because BR VIS_0003\r\nSELECT  DISTINCT\r\n\t\tIDENTIFIER as insid,\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\tPORTFOLIO_NAME as prfid,\r\n\t    CURRENCY,\r\n\t\tFXRATE\r\nFROM [VIS_DL_Direct_Property]\r\nWHERE \r\n\tISNULL(CURRENCY, 'NO VALUE') != 'EUR'\r\n\tAND ISNULL(FXRATE,0) != 1
    superset_query
330               
                                 BU system       BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
331 BU Delta Lloyd Asset Management    VIS VIS_0005 instrument SelfConsistent       NEED       <NA>       2015-03-03  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate dataelements                               datasource referencedata                                                              en
331               <NA> MARKET_VALUE DL Direct Property 01/31/2015, DB_TO_FRM          <NA> MarketValue in FRM Report should be equal to MarketValue in VIS
                                                                                 nl
331 De marktwaarde in het FRM Report dient gelijk te zijn aan de marktwaarde in VIS
                                                                                                                                                           rule
331 MarketValue in FRM Report should be equal to MarketValue in VIS\nThe business unit is required to be DLAM or empty, to exclude German and Belgian property.
                                                                 condition Feedback      rule_load_date   source_file
331 Instruments where marktetvalue is not equal between VIS and FRM Report     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         query
331 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: MarketValue in DB should equal MarketValue in XLS\r\n**************************************************************************/\r\n\r\n\r\n\r\n\r\n\tSELECT\r\n\t\tDISTINCT\r\n\t\tDB.IDENTIFIER as insid,\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\tDB.PORTFOLIO_NAME as prfid,\r\n\t\tDB.MARKET_VALUE\t\t\t\t\t\t\t\t\t\t\t\tAS DB_MARKETVALUE,\r\n\t\tXLS.MARKET_VALUE\t\t\t\t\t\t\t\t\t\t\tAS XLS_MARKETVALUE,\r\n\t\tDB.MARKET_VALUE - XLS.MARKET_VALUE\t\t\t\t\t\t\tAS DELTA_MARKETVALUE,\r\n\t\tXLS.BUSINESS_UNITS\r\n\t\t,*\r\n\tFROM \r\n\t\tVIS_DB_TO_FRM\tDB\r\n\t\tINNER JOIN[VIS_DL_Direct_Property] XLS\r\n\t\t\tON XLS.IDENTIFIER = DB.IDENTIFIER\r\n\tWHERE \r\n\t\t(XLS.BUSINESS_UNITS = 'DLAM' OR XLS.BUSINESS_UNITS IS NULL)\r\n\t\tAND DB.MARKET_VALUE != XLS.MARKET_VALUE\r\n\t\tAND MONTH(xls.reporting_date) IN (1,2,3,4,5,6)\r\n\r\n\tORDER BY DB.IDENTIFIER ASC
    superset_query
331               
                                 BU system       BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
332 BU Delta Lloyd Asset Management    VIS VIS_0006 instrument SelfConsistent       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate                            dataelements                    datasource referencedata                                                      en
332               <NA> BOOK_VALUE, MARKET_VALUE, NOMINAL_VALUE DL Direct Property 01/31/2015          <NA> BookValue, NominalValue and MarketValue should be equal
                                                               nl                                                    rule
332 BookValue, NominalValue and MarketValue dienen gelijk te zijn BookValue, NominalValue and MarketValue should be equal
                                                                  condition Feedback      rule_load_date   source_file
332 Instruments where BookValue, NominalValue and MarketValue are not equal     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          query
332 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: BookValue, NominalValue and MarketValue should be equal\r\n**************************************************************************/\r\n\r\nSELECT  DISTINCT\r\n\t\tIDENTIFIER as insid,\r\n\t\tPORTFOLIO_NAME as prfid,\r\n\t\tBOOK_VALUE,\r\n\t\tMARKET_VALUE,\r\n\t\tNOMINAL_VALUE\r\nFROM [VIS_DL_Direct_Property]\r\nWHERE \r\n\tMARKET_VALUE != NOMINAL_VALUE\r\n\tOR ISNULL(BOOK_VALUE, -0.1) != ISNULL(MARKET_VALUE, -0.2) \r\n\tOR BOOK_VALUE != NOMINAL_VALUE \r\n\t 
    superset_query
332               
                                 BU system       BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
333 BU Delta Lloyd Asset Management    VIS VIS_0007 instrument SelfConsistent       NICE       <NA>       2015-03-03  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate dataelements                                               datasource referencedata
333               <NA>   IDENTIFIER DL Direct Property 01/31/2015, DB_TO_FRM, DM_D_VGD_CMPLX          <NA>
                                                                                en
333 Identifier should be the concatenation of city, comma and property description
                                                                                                    nl
333 Identifier dient de samenvoeging van de plaats een komma en de beschrijving van het onroerend goed
                                                                                                                                                                                                                                                                                                                                                                        rule
333 Identifier should be the concatenation of city comma and property description\nThe expected identifier is generated in the DB_TO_FRM view\nThis verifies that all relevant database rows are actually exported, and that the identifiers are written in the expected format.\nThe business unit is required to be DLAM or empty, to exclude German and Belgian property.
                                                                                                                                                                                                                                    condition
333 With a concatenation of \n DM_D_VGD_CMPLX.CMPLX_WPL_NM, DM_D_VGD_CMPLX.CMPLX_NM \nas expected_identifier \nall expected_identifiers not available in the export, \nand all identifiers in the export not available as expected_identifier
    Feedback      rule_load_date   source_file
333     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            query
333 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: Identifier should have the following format City, ComplexName\r\n**************************************************************************/\r\nSELECT\r\n\tXLS.IDENTIFIER as insid,\r\n\tDB.IDENTIFIER\t\t\t\t\t\t\t\t\t\t\t\tAS EXPECTED_IDENTIFIER,\r\n\tXLS.IDENTIFIER\t\t\t\t\t\t\t\t\t\t\t\tAS IDENTIFIER,\r\n\tISNULL(DB.IDENTIFIER,XLS.IDENTIFIER)\t\t\t\t\t\tAS KEY_DB_XLS,\r\n\tXLS.BUSINESS_UNITS,\r\n\t*\r\nFROM \r\n\tVIS_DB_TO_FRM\tDB\r\n\tFULL OUTER JOIN [VIS_DL_Direct_Property] XLS\r\n\t\tON XLS.IDENTIFIER = DB.IDENTIFIER\r\nWHERE \r\n\t(XLS.BUSINESS_UNITS = 'DLAM' OR XLS.BUSINESS_UNITS IS NULL)\r\n\tAND (DB.IDENTIFIER IS NULL OR XLS.IDENTIFIER IS NULL)\r\nORDER BY KEY_DB_XLS ASC
    superset_query
333               
                                 BU system       BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
334 BU Delta Lloyd Asset Management    VIS VIS_0008 instrument SelfConsistent       NEED       <NA>       2015-03-03  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate dataelements                                                                                  datasource referencedata
334               <NA>  CLIENT_NAME DL Direct Property 01/31/2015, DB_TO_FRM, DM_F_VGD_FIN_GEV, DM_V_VGD_RAP_MAAND, DM_D_VGD_MY          <NA>
                                                    en                                                         nl
334 Client name should correspond with working company Client name dient te corresponderen met de working company
                                                                                                                                                                                                          rule
334 Client name should correspond with working company: \nWHEN MY.WMY_COD = 'L' THEN 'DL Leven'\nWHEN MY.WMY_COD = 'F' THEN 'Delta Lloyd Fund'\nThis expected client name is created within our DB_TO_FRM view
                                                                              condition Feedback      rule_load_date   source_file
334 Instruments where the client name does not correspond with the expected client name     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     query
334 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: Client should correspond with working company\r\n**************************************************************************/\r\n\r\n\r\n\tSELECT DISTINCT\r\n\t\tDB.IDENTIFIER as insid,\r\n\t\tMY.WMY_COD\t\t\t\t\t\tAS WORKING_COMPANY_CODE,\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\tDB.CLIENT_NAME\t\t\t\t\tAS EXPECTED_CLIENT_NAME,\r\n\t\tXLS.CLIENT_NAME\t\t\t\t\tAS CLIENT_NAME\r\n\tFROM \r\n\t\tVIS_DB_TO_FRM\tDB\r\n\t\tINNER JOIN [VIS_DL_Direct_Property] XLS\r\n\t\t\tON XLS.IDENTIFIER = DB.IDENTIFIER\r\n\t\tINNER JOIN VIS_DM_F_VGD_FIN_GEV FG\r\n\t\t\tON FG.CMPLX_ID = DB.CMPLX_ID\r\n\t\tINNER JOIN VIS_DM_V_VGD_RAP_MAAND RM\r\n\t\t\tON RM.LD_DAT_ID = FG.RAP_MND_ID\r\n\t\tLEFT JOIN VIS_DM_D_VGD_MY MY\r\n\t\t\tON MY.MY_ID = FG.MY_ID\r\n\r\n\tWHERE \r\n\t\tXLS.BUSINESS_UNITS = 'DLAM'\r\n\t\tAND RM.LM_EEJJMM_NR = LEFT(convert(varchar, REPORTING_DATE, 112),6)\r\n\t\tAND DB.CLIENT_NAME != XLS.CLIENT_NAME\r\n\r\n\tORDER BY DB.IDENTIFIER ASC
    superset_query
334               
                                 BU system       BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
335 BU Delta Lloyd Asset Management    VIS VIS_0009 instrument SelfConsistent       NEED       <NA>       2015-03-03  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate      dataelements                                               datasource referencedata                                              en
335               <NA> DLAM.Asset.Type.2 DL Direct Property 01/31/2015, DB_TO_FRM, DM_D_VGD_CMPLX          <NA> DL AssetType 2 should correspond with occupance
                                                         nl
335 DL AssetType 2 dient te corresponderen met de occupance
                                                                                                                                                                                                                                                                                                                       rule
335 DL AssetType 2 should correspond with the occupance; \nIf DM_D_VGD_CMPLX.EIG_GBRK_DL_COD is D or H, then it is of own occupance having 'Owner Occupied' as Asset Type 2\n, else it is not own occupance with Asset Type 2 equal to 'Investment Property'\nThis expected asset type is created within our DB_TO_FRM view
                                                                                                                                                                                       condition
335 Instruments with own occupance where DL Asset Type 2 is not equal to 'Owner Occupied', \nand instruments which have not own occupance and DL Asset Type 2 not equal to 'Investment Property'
    Feedback      rule_load_date   source_file
335     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       query
335 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: AssetType 2 should correspond with occupancy\r\n**************************************************************************/\r\n\r\n\tSELECT DISTINCT\r\n\t\tDB.IDENTIFIER as insid,\t\r\n\t\tVS.EIG_GBRK_DL_OMS\t\t\tAS [Occupancy],\t\t\t\t\t\t\t\r\n\t\tDB.[DLAssetType2] \t\t\tAS [DB_DLAssetType2],\r\n\t\tXLS.[DLAssetType2]\t\t\t  AS [DLAssetType2]\r\n\tFROM \r\n\t\tVIS_DB_TO_FRM\tDB\r\n\t\tINNER JOIN[VIS_DL_Direct_Property] XLS\r\n\t\t\tON XLS.IDENTIFIER = DB.IDENTIFIER\r\n\t\tLEFT JOIN VIS_DM_D_VGD_CMPLX VS\r\n\t\t\tON DB.CMPLX_ID = VS.CMPLX_ID\r\n\r\n\tWHERE \r\n\t\tXLS.BUSINESS_UNITS = 'DLAM'\r\n\t\tAND DB.[DLAssetType2] != XLS.[DLAssetType2]\r\n\r\n\tORDER BY DB.IDENTIFIER ASC
    superset_query
335               
                                 BU system       BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
336 BU Delta Lloyd Asset Management    VIS VIS_0010 instrument SelfConsistent       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate      dataelements                                               datasource referencedata                                                  en
336               <NA> DLAM.Asset.Type.3 DL Direct Property 01/31/2015, DB_TO_FRM, DM_D_VGD_CMPLX          <NA> DL AssetType 3 should correspond with property type
                                                                    nl
336 DL AssetType 3 dient te corresponderen met het goed onroerend type
                                                                                                                                                                                                                                                                                                                                                                                                                                         rule
336 DL AssetType 3 should correspond with the expected asset type based on the property type\n when complex code (C.CMPLX_COD) is \n one of (01, 02, 03) THEN DLAMAssetType 3 is 'Residential'\n one of (04,05) then it is 'Retail'\n equal to 06 then it is 'Office'\n equal to 08 then it is 'Development'\t\n else if the identifier contains 'parkeer' then it is 'Parking'\nThis expected asset type is created within our DB_TO_FRM view
                                   condition Feedback      rule_load_date   source_file
336 Instruments with non matching asset type     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     query
336 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: AssetType 3 should correspond with property type\r\n**************************************************************************/\r\n\r\n\r\nSELECT DISTINCT\r\n\t\tDB.identifier      AS insid, \r\n       VS.cmplx_oms, \r\n       DB.[dlassettype3]  AS [DB_DL AssetType 3], \r\n       XLS.[dlassettype3] AS [XLS_DL AssetType 3] \r\nFROM   vis_db_to_frm DB \r\n       INNER JOIN [VIS_DL_Direct_Property] XLS \r\n               ON XLS.identifier = DB.identifier \r\n       LEFT JOIN vis_dm_d_vgd_cmplx VS \r\n              ON DB.cmplx_id = VS.cmplx_id \r\nWHERE  ( XLS.business_units = 'DLAM' \r\n          OR XLS.business_units IS NULL ) \r\n       AND DB.[dlassettype3] != XLS.[dlassettype3] \r\nORDER  BY DB.identifier ASC 
    superset_query
336               
                                 BU system       BR entitytype      Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
337 BU Delta Lloyd Asset Management    VIS VIS_0011 instrument ValidRange       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate dataelements                    datasource referencedata                                           en
337               <NA> DLAM.Sector1 DL Direct Property 01/31/2015          <NA> DL Sector 1 should be equal to 'Real Estate'
                                                     nl                                        rule                                     condition Feedback
337 DL Sector 1 dient gelijkt te zijn aan 'Real Estate' DL Sector 1 should be equal to 'Real Estate Instruments where DL Sector is not equal to 1     <NA>
         rule_load_date   source_file
337 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                   query
337 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: DL Sector 1 should be equal to Real Estate\r\n**************************************************************************/\r\n\r\nSELECT  DISTINCT\r\n\t\tIDENTIFIER as insid,\r\n\t\t[DLSector1]       AS [DLSector1]\r\nFROM [VIS_DL_Direct_Property]\r\nWHERE ISNULL([DLSector1], 'NO VALUE') != 'Real Estate'
    superset_query
337               
                                 BU system       BR entitytype      Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
338 BU Delta Lloyd Asset Management    VIS VIS_0012 instrument ValidRange       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate dataelements                    datasource referencedata                                               en
338               <NA> DLAM.Sector2 DL Direct Property 01/31/2015          <NA> DL Sector 2 should be equal to 'Direct Property'
                                                         nl                                            rule                                     condition Feedback
338 DL Sector 2 dient gelijkt te zijn aan 'Direct Property' DL Sector 2 should be equal to 'Direct Property Instruments where DL Sector is not equal to 1     <NA>
         rule_load_date   source_file
338 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                       query
338 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: DL Sector 1 should be equal to Real Estate\r\n**************************************************************************/\r\n\r\nSELECT  DISTINCT\r\n\t\tIDENTIFIER as insid,\r\n\t\t[DLSector2]     AS [DLSector2]\r\nFROM [VIS_DL_Direct_Property] \r\nWHERE ISNULL([DLSector2], 'NO VALUE')  != 'Direct Property'
    superset_query
338               
                                 BU system       BR entitytype      Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
339 BU Delta Lloyd Asset Management    VIS VIS_0013 instrument ValidRange       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate dataelements                    datasource referencedata                                 en                                        nl
339               <NA> DLAM.Sector3 DL Direct Property 01/31/2015          <NA> DL Sector 3 should be equal to '-' DL Sector 3 dient gelijkt te zijn aan '-'
                                  rule                                         condition Feedback      rule_load_date   source_file
339 DL Sector 3 should be equal to '-' Instruments where DL Sector 3 is not equal to '-'     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                      query
339 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: DL Sector 1 should be equal to Real Estate\r\n**************************************************************************/\r\n\r\nSELECT  DISTINCT \r\n\t\tIDENTIFIER as insid,\r\n\t\t[DLSector3]       AS [DLSector3]\r\nFROM [VIS_DL_Direct_Property]\r\nWHERE [DLSector3] != '-'
    superset_query
339               
                                 BU system       BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
340 BU Delta Lloyd Asset Management    VIS VIS_0014 instrument SelfConsistent       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate   dataelements                                                                                  datasource referencedata en
340               <NA> PORTFOLIO_NAME DL Direct Property 01/31/2015, DB_TO_FRM, DM_F_VGD_FIN_GEV, DM_V_VGD_RAP_MAAND, DM_D_VGD_MY          <NA>   
                                                              nl
340 Portfolioname dient te corresponderen met de working company
                                                                                                                                                                                                                                 rule
340 Portfolio name should correspond with working company:\n  WHEN DM_D_VGD_MY.WMY_COD = 'L' THEN 'DL Leven'\n WHEN DM_D_VGD_MY.WMY_COD = 'F' THEN 'DL Vastgoed F'\nThis expected portfolio name is created within our DB_TO_FRM view
                                                                                                                             condition Feedback      rule_load_date
340 Instruments where the portfolio name does not correspond with the expected portfolio name\nDB_TO_FRM contains the expected values.     <NA> 2016-04-11 10:41:05
      source_file
340 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           query
340 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: PortfolioName should correspond with working company\r\n**************************************************************************/\r\n\r\n\r\nSELECT DISTINCT\r\n\t\tDB.identifier      AS insid, \r\n       XLS.portfolio_name AS prfid, \r\n       MY.wmy_cod         AS WORKING_COMPANY_CODE, \r\n       DB.portfolio_name  AS EXPECTED_PORTFOLIO_NAME, \r\n       XLS.portfolio_name AS PORTFOLIO_NAME\r\n\t   ,RM.lm_eejjmm_nr\r\n\t   ,LEFT(convert(varchar, REPORTING_DATE, 112),6),\r\n\t   XLS.REPORTING_DATE\r\nFROM   vis_db_to_frm DB \r\n       INNER JOIN [VIS_DL_Direct_Property] XLS \r\n               ON XLS.identifier = DB.identifier \r\n       INNER JOIN vis_dm_f_vgd_fin_gev FG \r\n               ON FG.cmplx_id = DB.cmplx_id \r\n       INNER JOIN vis_dm_v_vgd_rap_maand RM \r\n               ON RM.ld_dat_id = FG.rap_mnd_id \r\n       LEFT JOIN vis_dm_d_vgd_my MY \r\n              ON MY.my_id = FG.my_id \r\nWHERE  ( XLS.business_units = 'DLAM' \r\n          OR XLS.business_units IS NULL ) \r\n       AND RM.lm_eejjmm_nr = LEFT(convert(varchar, REPORTING_DATE, 112),6)\r\n       AND DB.portfolio_name != XLS.portfolio_name \r\nORDER  BY DB.identifier ASC 
    superset_query
340               
 names_orig names_sql_expected names_sql
                             X        V7
                                 BU system       BR entitytype      Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
341 BU Delta Lloyd Asset Management    VIS VIS_0015 instrument ValidRange       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate dataelements                    datasource referencedata                                                en
341               <NA>      proddat DL Direct Property 01/31/2015          <NA> Production date should be constant in export file
                                                      nl                                              rule                                           condition Feedback
341 Production date moet constant zijn in de export file Production date should be constant in export file Instruments where production date is not consistent     <NA>
         rule_load_date   source_file
341 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        query
341 /**************************************************************************\r\n*Author: Donald Posthuma\r\nDescription: The production date of the report should be consistent in report\r\n**************************************************************************/\r\n\r\nDECLARE @CountDate AS INT\r\nSELECT @CountDate = COUNT(DISTINCT REPORTING_DATE) FROM sourcedata.dbo.[VIS_DL_Direct_Property]\r\n\r\nSELECT DISTINCT \r\n\t IDENTIFIER as insid,\r\n       REPORTING_DATE as proddat\r\nFROM (SELECT TOP (@CountDate-1) REPORTING_DATE AS proddat FROM [VIS_DL_Direct_Property] group by REPORTING_DATE order by count(*) asc) as minorityDates\r\n    LEFT JOIN [VIS_DL_Direct_Property] on minorityDates.proddat = [VIS_DL_Direct_Property].REPORTING_DATE
    superset_query
341               
                                 BU system       BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
342 BU Delta Lloyd Asset Management    VIS VIS_0016 instrument SelfConsistent       NEED       <NA>             <NA>  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate dataelements                    datasource referencedata                                                                   en
342               <NA>      proddat DL Direct Property 01/31/2015          <NA> The Production should be equal to the date mentioned in the filename
                                                                                nl
342 De productie datum dient gelijk te zijn aan de datum die de bestandsnaam bevat
                                                                                                                                                    rule
342 Production date should be equal to the date mentioned in the filename.\nThis verifies that both the filename and the records indicate the same date.
                                                              condition Feedback      rule_load_date   source_file
342 Instruments where production date is not equal to the filename date     <NA> 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                             query
342 SELECT distinct IDENTIFIER as insid,\r\n       REPORTING_DATE as proddat\r\n\t  , CONVERT(date, reporting_date, 105)\r\nFROM [VIS_DL_Direct_Property]\r\nWHERE CONVERT(date,REPORTING_DATE, 105) != source_date
    superset_query
342               
 names_orig names_sql_expected names_sql
                             X        V3
                                 BU system       BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
343 BU Delta Lloyd Asset Management    VIS VIS_0017 instrument SelfConsistent       NICE       <NA>       2015-03-03  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate      dataelements                    datasource referencedata                                        en
343               <NA> DLAM.Asset.Type.2 DL Direct Property 01/31/2015          <NA> Asset Type 2 should be consistently cased
                                                                      nl
343 De Asset Type 2 dient consequent geschreven te zijn qua hoofdletters
                                                                                                   rule
343 The asset type should be written in the same way.\nThis rule verifies consistency in capitalization
                                                                                                                                                    condition Feedback
343 All asset types having a different number of instruments \nwhen grouped by asset type case sensitive \ncompared to grouped by asset type case insensitive     <NA>
         rule_load_date   source_file
343 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            query
343 \r\n/* BAD PERFORMANCE ON LARGE DATASETS! */\r\n\r\nSELECT DISTINCT\r\n\t   identifier            AS insid, \r\n       DLAssetType2          AS [DLAssetType2],\r\n\t   --add what appears to be the standard version of the DLAssetType2 capitalisation, based on number of instances per capitalisation\r\n\t   (SELECT TOP 1 DLAssetType2 COLLATE sql_latin1_general_cp1_cs_as FROM VIS_DL_Direct_Property d WHERE lower(DLassetType2) = lower(v.DLAssetType2) GROUP BY DLAssetType2 COLLATE sql_latin1_general_cp1_cs_as ORDER BY COUNT(*) DESC) \r\nFROM\tVIS_DL_Direct_Property v\r\nWHERE\r\n\t--subquery here returns the lowercase version of the assettypes2 which have multiple casings in the databse\r\n\t--multiple casings are identified by forcing the collation to sql_latin1_general_cp1_cs_as which is\r\n\t--case sensitive and accent sensitive\r\n\t--using lower case to group by to insure no case sensitive collation is used for the GROUP BY by accident\r\n\tlower(DLAssetType2) in (SELECT lower(DLAssetType2)\r\n\t\t\t\t\t\t\tFROM VIS_DL_Direct_Property\r\n\t\t\t\t\t\t\tGROUP BY lower(DLAssetType2)\r\n\t\t\t\t\t\t\tHAVING \tcount(distinct DLAssetType2) != count(distinct dlassetType2 collate sql_latin1_general_cp1_cs_as))\r\n\r\n
    superset_query
343               
 names_orig names_sql_expected names_sql
                             X        V3
                                 BU system       BR entitytype          Depth Importance ErrorCause modificationDate ruleOwner       approvedBy approvedDate
344 BU Delta Lloyd Asset Management    VIS VIS_0018 instrument SelfConsistent       NICE       <NA>       2015-03-03  Vastgoed Gerald Warmerdam   2015-10-08
    resultApprovalDate      dataelements                    datasource referencedata                                        en
344               <NA> DLAM.Asset.Type.3 DL Direct Property 01/31/2015          <NA> Asset Type 3 should be consistently cased
                                                                      nl
344 De Asset Type 3 dient consequent geschreven te zijn qua hoofdletters
                                                                                                   rule
344 The asset type should be written in the same way.\nThis rule verifies consistency in capitalization
                                                                                                                                                    condition Feedback
344 All asset types having a different number of instruments \nwhen grouped by asset type case sensitive \ncompared to grouped by asset type case insensitive     <NA>
         rule_load_date   source_file
344 2016-04-11 10:41:05 vis_rules.csv
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           query
344 SELECT  DISTINCT\r\n\t\txls.identifier            AS insid, \r\n       xls_cased.[dlassettype3]  AS [DLAssetType3], \r\n       xls_noncased.dlassettype3 AS Standard_DLAssetType3, \r\n       xls_cased.num_casesensitive, \r\n       xls_noncased.num_caseinsensitive \r\nFROM   (SELECT XLS.[dlassettype3] COLLATE sql_latin1_general_cp1_cs_as AS \r\n               DLAssetType3, \r\n               Count(*)                                                AS \r\n                      num_casesensitive \r\n        FROM   [VIS_DL_Direct_Property] XLS \r\n        GROUP  BY XLS.[dlassettype3] COLLATE sql_latin1_general_cp1_cs_as) AS \r\n       xls_cased \r\n       INNER JOIN (SELECT XLS.[dlassettype3] AS DLAssetType3, \r\n                          Count(*)           AS num_caseinsensitive \r\n                   FROM   [VIS_DL_Direct_Property] \r\n                          XLS \r\n                   GROUP  BY XLS.[dlassettype3]) AS xls_noncased \r\n               ON Upper(xls_cased.dlassettype3) = Upper( \r\n                  xls_noncased.dlassettype3) \r\n       LEFT JOIN [VIS_DL_Direct_Property] XLS \r\n              ON xls_cased.dlassettype3 = XLS.[dlassettype3] \r\nWHERE  num_caseinsensitive != num_casesensitive \r\nORDER  BY xls_cased.[dlassettype3], \r\n          XLS.identifier ASC  
    superset_query
344               

