#Reads data from locations not managed by git
source("R/config.R")
source("R/source.reat.R")

portiapath <- function(...){
  return(file.path(portia_data_path, do.call(file.path, list(...))))
}
destination_connect <- function(){db.connect(sourcedata_connection)}

# the DM-SecsHld.csv export of Portia which Data Management uses everyday to verify the static data of Portia
po_secshld <- list(
			origin = portiapath(dmsec_file),
			read = function(x)read.csv(x, na.strings=c(), check.names=F),
			name="PO_secshld",
			destination=destination_connect,
			cols.map=list(
				DLAMRatingManFlag="CIC", #Solvency II Complementary Identification Code (CIC)
				GrootboekKlasse = "CEDAR" #Names GrootboekKlasse in the orig csv, but CEDAR in the dm excel
				),
		constants=list(
							source_date=as.Date(source_date_f)
							)
		, 
		typechanges=list(
			list(trynumeric=T, col.ignore=c('Sedol','ISSUER','PriceSymbol','Cusip')),
			list(Date.format="%d-%m-%Y"),
			list(col.names=c("Listed","X5strategi2","X5Kapitaal","RegisterExtern"),
				 boolean.call=list(TrueValue="Ja",FalseValue="Nee",NAValue="")),
			#list(col.names=c("AutoQuote"),
			#	 boolean.call=list(TrueValue=c("Yes","Y"),FalseValue="No")),
			list(col.names=c("Name","Description1","Description2","ISIN","PriceSymbol","Sedol","BBTicker"),
				 tocharacter=T)
			),
		val_col = "COUPON"
    )

# The RM-PortiaTotal (ultimo maand) export of Portia which Risk Management imports daily to get the holdings of Portia. The rules have been run on the Month-fork.
po_portiatotal <- 
		list(
			destination=destination_connect,
			origin = portiapath(portia_total_file),
      read = function(path)
			{
        orig <- read.csv(path, row.names=NULL, header=T, na.strings=c())
        #the datarows hold extraneous ,'s, so colnames do not match
        headers <- read.csv(path, header=F, nrows=1, stringsAsFactors=F)
        orig <- orig[,1:ncol(headers)]
        colnames(orig)<-make.names(as.vector(headers[1,]))
        orig
      },
			name="PO_portiatotal",
			constants=list(
			  source_date=as.Date(source_date_f)
			) , 
			typechanges=
			  list(
			    list(trynumeric=T),
			    list(Date.format="%d/%m/%Y"),
			    list(col.names="Listed",
			         boolean.call=list(TrueValue="Ja", FalseValue="Nee", NAValue=""))
			  ),
			cols.map=list("ContractSize" = "UNIT SIZE"),
			val_col = "KOERS"
		)

# The export of KasBank, of the holdings they think DeltaLloyd has. All numbers are integers, fndstt_description.csv defines how many decimals the values actually have.
po_fndstt_def <- list(
				  destination = destination_connect,
				  origin = portiapath(fndstt_file),
				  read = function(path){
					cat("Loading fndstt definition file\r\n")
					def <- load.data(save = F,
									 list(destination=destination_connect,
										  # Got from MidOffice a print and digital screenshot of the fndstt column descriptions.
										  origin= portiapath(fndstt__desc_file),
										  read=read.csv,
										  typechanges=list(trynumeric=T)))
					cat("Loaded fndstt definition file \r\n")
					orig <- read.fwf(path, widths=def$prep$L, col.names=def$prep$Description)
					cat("Taking care of decimals in following columns:\r\n")
					print(colnames(orig)[!is.na(def$prep$decimals)])
					cat("Current value ranges:\r\n")
					print(summary(orig[!is.na(def$prep$decimals)]))
					for(i in which(!is.na(def$prep$decimals))){
						orig[,i] <- orig[,i]/10^def$prep$decimals[i]
					}
					cat("Final value ranges:\r\n")
					print(summary(orig[,!is.na(def$prep$decimals)]))
					orig
				  },
				  name = "PO_fndstt",
				  constants = list(
								   source_date = as.Date(source_date_f)
								   ),
				  typechanges = list(
									 list(trynumeric=T),
									 list(Date.format="%y%m%d")
									 ),
					val_col = "interestrate"
				  )

# Received at the start of the project the holdings of portia, as reported by DataManagement.
# They however use a different format than RiskManagement uses, so this report has not been used any more.
# holding_file <- file.path(dlam_data_path, "portia_exports/DataManagement/DLAM_HOLDING_2014-09-15.csv")
# holding_orig<-read.csv(holding_file, na.strings=c(), sep = "\t", skip=8)

# The export of Portia used by MidOffice to perform the depotcontrole (comparing holdings listed by Portia to the holdings listed by Kasbank)
po_portsaldo_def <- list(
					   destination = destination_connect,
					   origin = portiapath(portia_saldo_file),
					   read = function(x)read.csv(x, na.strings=c(), stringsAsFactors=F, header=F),
					   name = "PO_portsaldo",
					   constants = list(source_date = as.Date(source_date_f)),
					   cols.map=list(
							V1="portfolioNaam",
							V2="ISIN",
							V3="securityDescription",
							V4="longQuantity",
							V5="shortQuantity",
							V6="quantity",
							V7="custodian",
							V8="proddat"
							),
					   typechanges = list(
										  list(trynumeric=T),
										  list(Date.format="%d/%m/%y")
										  ),
					   val_col = c("V6","quantity")
					   )

# The tips rates for instruments, received this from Data Management.
po_tipsrates_def <-list(
					origin = portiapath(fb_hist_file),
					read = function(x)read.csv(x, strip.white=T),
					name = "PO_tips",
					destination = sourcedata_connect,
					constants = list(source_date = as.Date(source_date_f)),
					cols.drop="SicCode",
					filter=list(
								list(col.name="ISIN",value="^GRAND TOTAL", type="regex", keep=F)
								),
					val_col = "Koers"
					)


# The tips rates for instruments, received this from Data Management.
po_inflationrates_def <-list(
  origin = portiapath(fb_hist_infl_file),
  read = function(x)read.csv(x, strip.white=T),
  name = "PO_Inflation",
  destination = sourcedata_connect,
  constants = list(source_date = as.Date(source_date_f)),
  cols.drop="SicCode",
  filter=list(
    list(col.name="ISIN",value="^GRAND TOTAL", type="regex", keep=F)
  ),
  val_col = "Koers"
)

# The day closing exchange rates, which should be used for reporting. Received from Data Management
po_exchangerates_def <- list(
						  origin = portiapath(portia_hfx_file),
						  read = function(x)read.csv(x, stringsAsFactors=F, strip.white=TRUE),
						  name = "PO_exchangerates",
						  constants = list(source_date = as.Date(source_date_f)),
						  cols.map = list(
						    "NAME" = "NAME",
						    "CURRENCY" = "fxid",
						    "Rate" = "FXRATE",
						    "RATEDATE" = "ReportingDate",
						    "EURtoVV" = "INV_FXRATE"),
						  cols.drop = c("RATETYPE"),
						  typechanges = list(
						    list(Date.format = "%d/%m/%y")),
              						  constants = list(source_date = as.Date(source_date_f)),
#						  cols.map = list(
#							#	"VALUTAS" = "name",
#								"CODE" = "fxid",
#								"WISSELKOERS" = "FXRATE",
#								"ReportingDate" = "RATEDATE",
#								"INVERSEWISSELKOERS" = "INV_FXRATE"),
#						  cols.drop = c("X","X1"),
#						  typechanges = list(
#											 list(Date.format = "%d/%m/%y")#
#											 ),
						  destination = sourcedata_connect,
              val_col = c("Rate", "FXRATE")
						  )

# The full list of all portfolios available in Portia. Received from Data Management
#po_portfolios_def <- list(
#						  origin = portiapath("DataManagement/FA_Portfolios.csv"),
#						  read = function(x)read.csv(x, stringsAsFactors=F, strip.white=TRUE),
#						  name = "PO_portfolios",
#						  constants = list(source_date = as.Date("2015-06-30")),
#						  typechanges = list(
#											 list(trynumeric=T, col.ignore = c('DEPOT'))
#											 ),
#						  destination = sourcedata_connect
#						  )

#portfolios to cedar as received from tom bosch
po_cedar_def <- list(
  						  origin = portiapath(cedar_file),
  						  read = function(x)read.csv(x, stringsAsFactors=F, skip=1, header = FALSE),
  						  name = "PO_CEDAR",
  						  constants = list(source_date = as.Date(source_date_f)),
  						  cols.map = list(
  						    "V1" = "PORTFOLIO"),
  						  destination = sourcedata_connect,
  						  val_col = c("V1", "PORTFOLIO")
  						  )
  