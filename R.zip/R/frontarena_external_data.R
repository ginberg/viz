#Reads data from locations not managed by git
source("R/config.R")
source("R/source.reat.R")

destination_connect <- function(){db.connect(sourcedata_connection)}

# Preprocesses the csv header containing metadata by parsing (date)time
preprocess.meta <- function(metadataframe){
  metadataframe_values <- data.frame(as.list(as.character(metadataframe$V2)))
  names(metadataframe_values) <- gsub("\\W","",metadataframe$V1)
  metadataframe <- metadataframe_values
  metadataframe$Time <- factor(as.character(as.POSIXlt(sub("(.*)\\(UTC(.*):(.*)\\)","\\1\\2\\3", metadataframe$Time), format="%Y-%m-%d %H:%M:%S %z")))
  return(metadataframe)
}

#CURRENCY,RATE TYPE,Rate,RATE DATE,EUR-to-VV  
# The day closing exchange rates, which should be used for reporting. Received from Data Management
fa_exchangerates_def <- list(
  origin = fapath(fa_hfx_file),
  read = function(x)read.csv(x, stringsAsFactors=F, strip.white=TRUE),
  name = "FA_exchangerates",
  constants = list(source_date = as.Date(source_date_fa_f)),
  cols.map = list(
    #"NAME" = "name",
    "CURRENCY" = "fxid",
    "Rate" = "FXRATE",
    "RATEDATE" = "ReportingDate",
    "EURtoVV" = "INV_FXRATE"),
  cols.drop = c("RATETYPE"),
  typechanges = list(
    list(Date.format = "%d/%m/%Y")
  ),
  destination = sourcedata_connect,
  val_col = c("Rate", "FXRATE")
)


##fa_exchangerates_def <- list(
#  destination=destination_connect,
#  name = "FA_exchangerates",
#  origin = fapath("FX_2015-08-17.csv"),
#  read = function(x) read.csv(x, na.strings=c(), stringsAsFactors = F, check.names=F, strip.white=TRUE),
##  typechanges=list( # list of all transformations in order 
##    list(trynumeric=T),
##    list(POSIXct.call=list(format="%d/%m/%Y %H:%M:%S", alt_suffix="_date", alt_format="%d/%m/%Y")),
##    list(POSIXct.call=list(format="%Y-%m-%d %H:%M:%S", alt_suffix="_date", alt_format="%Y-%m-%d")),
##    list(POSIXct.format="%d/%m/%Y")
##  ),
#  constants = list(source_date = as.Date(source_date_fa_f))
#  
#)


# Front Arena holding report, received from Data Management
#fa_holding<-list(
#			destination=destination_connect,
#			name="FA_holding",
#			 origin = fapath("DLAM_HOLDING_2014-12-01.xls"),
#			 read=function(x) read.delim(x, na.strings=c(), skip=8, stringsAsFactors = TRUE, check.names=F),
#			 read.meta = function(x)preprocess.meta(read.delim(x, na.strings=c(), skip=0, stringsAsFactors = TRUE, check.names=F, header=F )[2:5,]),
#			 cols.map = list(X1 = "InstrumentName"),
#			  typechanges=list(
#				list(trynumeric=T)
#			  ),
#			constants = list(source_date = as.Date(source_date_fa_f))
#)


# Front Arena trades report, received from Data Management
#fa_trades<-list(
#			destination=destination_connect,
#  name="FA_trades",
#  origin = fapath("DLAM_TRADES_2014-12-01.xls"),
#  read = function(x) read.delim(x, na.strings=c(), skip=8, stringsAsFactors = TRUE, check.names=F),
#  read.meta = function(x) preprocess.meta(read.delim(x, na.strings=c(), skip=0, stringsAsFactors = TRUE, check.names=F, header=F )[2:5,]),
#  cols.map = list(X1 = "id"),
#  typechanges=list( # list of all transformations in order 
#    list(trynumeric=T),
#    list(POSIXct.call=list(format="%d/%m/%Y %H:%M:%S", alt_suffix="_date", alt_format="%d/%m/%Y")),
#    list(POSIXct.format="%d/%m/%Y")),
#			constants = list(source_date = as.Date(source_date_fa_f))
#
#)

# FA_Loshist
# Front Arena loans (all LOS), received from DataManagement, taken from R Applicatie Data:\111_Front_Arena-Output-Prd\Financial Risk Database
fa_loan <- list(
			destination=destination_connect,
  name = "FA_loan",
  origin = fapath(fa_loan_file),
  read = function(x) read.csv(x, na.strings=c(), stringsAsFactors = T, check.names=F),
  typechanges=list( # list of all transformations in order 
    list(trynumeric=T),
    list(POSIXct.call=list(format="%d/%m/%Y %H:%M:%S", alt_suffix="_date", alt_format="%d/%m/%Y")),
    list(POSIXct.call=list(format="%Y-%m-%d %H:%M:%S", alt_suffix="_date", alt_format="%Y-%m-%d")),
    list(POSIXct.format="%d/%m/%Y")
  ),
	constants = list(source_date = as.Date(source_date_fa_f)),
  val_col = "Price"
)

# FA_DerivHist, received from DataManagement, taken from R Applicatie Data:\111_Front_Arena-Output-Prd\Financial Risk Database 
fa_deriv <- list(
			destination=destination_connect,
  name = "FA_deriv",
  origin = fapath(fa_derivatives_file),
  read = function(x) read.csv(x, na.strings=c(), stringsAsFactors = T, check.names=F),
  typechanges=list( # list of all transformations in order 
    list(trynumeric=T),
    list(POSIXct.call=list(format="%Y-%m-%d %H:%M:%S", alt_suffix="_date", alt_format="%Y-%m-%d")),
    list(POSIXct.format="%d/%m/%Y")
  ),
	constants = list(source_date = as.Date(source_date_fa_f)),
  val_col = "Price"
)

#FA_DerivativesReport,received from DataManagement, taken from R Applicatie Data:\111_Front_Arena-Output-Prd\Financial Risk Database 
fa_derivreport <- list(
			destination=destination_connect,
  name = "FA_derivreport",
  origin = fapath(dl_derivatives_file),
  read = function(x) read.csv2(x, na.strings=c(), stringsAsFactors = T, check.names=F),
  typechanges=list( # list of all transformations in order 
    list(trynumeric=T),
    list(POSIXct.call=list(format="%Y-%m-%d %H:%M:%S", alt_suffix="_date", alt_format="%Y-%m-%d")),
    list(POSIXct.format="%Y-%m-%d")
  ),
	constants = list(source_date = as.Date(source_date_fa_f)),
  val_col = "Price"
)

#,received from DataManagement, taken from R Applicatie Data:\111_Front_Arena-Output-Prd\Financial Risk Database 
#eur_spred <- list(
#			destination=destination_connect,
#				  name = "FA_eur_swa_6m_spread",
#				  origin = frmpath("EUR_SWA_6M_SPREAD-2015-01-08.csv"),
#				  read = function(x) read.csv(x, stringsAsFactors = TRUE, check.names=F),
#			constants = list(source_date = as.Date("2015-01-08"))
#				  )
