#Read some common input files
flog.debug("loading data file %s", commonpath(frm_fields_file))
frmmap <- read.csv(commonpath(frm_fields_file), stringsAsFactors=F, na.strings=c("","NA"))
flog.debug("loading data file %s", commonpath(dataelements_descriptions_file))
s2Descriptions <- read.csv(commonpath(dataelements_descriptions_file), stringsAsFactors=F, na.strings=c("","NA"))
colnames(s2Descriptions)[3]<-"Description"
flog.debug("loading data file %s", fapath(fieldmapping_fa_db))
fa_dbmap <- read.csv(fapath(fieldmapping_fa_db), stringsAsFactors=F, fileEncoding="UTF-8", strip.white=T)