library(shiny)
library(shinydashboard)
library(ggplot2)
library(reshape2)
library(plyr)
library(scales)
library(DT)
library(plotly)

dashboard_input_path <- "Z:/Shared Data/5501_ProjectDataQuality/3_Output Data/dashboard"
portia_filename <- "Portia_dqa"
portia_current_date <- "2016-05-16"
fa_filename <- "FrontArena_dqa"
fa_current_date <- "2016-04-13"
globes_filename <- "Globe$_dqa"
globes_current_date <- "2016-04-22"
vis_filename <- "VIS_dqa"
vis_current_date <- "2016-04-29"

errors <- "errors"
failed <- "failed"
whitelisted <- "whitelisted"
blacklisted <- "blacklisted"
unhandled <- "unhandled"
types <- c(unhandled, blacklisted, whitelisted)
selected<- c(unhandled, blacklisted, whitelisted)
failures_text <- "Failures"
DEName <- "DEName"