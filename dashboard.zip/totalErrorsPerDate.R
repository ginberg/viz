## Server.R ##
source("global.R")
source("server.R")

dataelements <- read.csv(file.path(dashboard_input_path, "dataelement_descriptions.csv"))[,c("Number", "Data.Element")]
names(dataelements) <- c("Data.Element", "Description")
df <- merge(renameColumns(getDFErrors(dashboard_input_path, portia_filename)), dataelements)
df <- df[!duplicated(df$BR.number),]

df <- aggregate(list(errors=df$errors, whitelisted=df$whitelisted,
               failed=df$failed,blacklisted=df$blacklisted,
               unhandled=df$unhandled),by=list(Date = df$Source.Date), FUN=sum)

df <- subsetDF(df, types)
df$Date <- as.character(df$Date)

df <- melt(df[,c('Date', rev(types))], id = 'Date')
df$variable <- factor(df$variable, levels = rev(levels(df$variable)))
colnames(df) <- c("Date","category", "value")

ggplot(data=df, aes(x = Date, y= value, fill = category)) + geom_bar(stat="identity")

# wanted 
# date     category    value
# 1-1-2016 blacklis    100