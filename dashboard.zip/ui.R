## ui.R ##
source("global.R")

dbHeader <- dashboardHeader(title = "DQSS dashboard")

shinyUI(dashboardPage(
  dbHeader,
  dashboardSidebar(
    a(href="http://www.deltalloyd.nl", img(src="deltalloyd.png", width = 230, height= 60)),
    selectInput("system", "System",
                c("Portia" = "po",
                  "Front Arena" = "fa",
                  "Globes" = "gl",
                  "VIS" = "vi")),
    checkboxGroupInput("types","Types",types, selected = selected),
    uiOutput("sliderBR"),
    uiOutput("sliderDE")
  ),
  dashboardBody(
    tags$head(
      tags$link(rel = "stylesheet", type = "text/css", href = "custom.css")
    ),
    tabsetPanel(
      tabPanel("BR", 
               fluidRow(plotlyOutput("totalBR", height = 600, width = 1600)),
               fluidRow(
                 box(plotlyOutput("plotBR", height = 250)),
                 box(uiOutput("selectBR"), dataTableOutput("detailsBR"))
               )),
      tabPanel("DE", 
               fluidRow(plotlyOutput("totalDE", height = 600, width = 1400)),
               fluidRow(
                 box(plotlyOutput("plotDE", height = 250)),
                 box(uiOutput("selectDE"), dataTableOutput("detailsDE"))
               )
      )
    )
  )
))